﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, GeneralInfoModel } from '../../../models/Run/RunModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService, CardModule } from 'primeng/primeng';
import { FlyoutExistsDataModel } from '../../../models/FlyoutExistsDataModel';
import { KeyValue } from '../../../Models/KeyValue';
import { RunDataService } from "../run.data.service";
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
  templateUrl: 'RunSummary.component.html',
  selector: "runSummary",
  providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})

export class RunSummaryComponent implements OnInit {
  @Input()
  propertyType: string;
  title: string;
  defaultUnit: string;
  @Input()
  // run1: RunModel;
  deleteIconPath: string;
  disabledDeleteIconPath: string;
  IsallowedChange: boolean = true;
  isCollapsed = false;
  setStyles: boolean;
  lstTechnicians1: any;
  Headerlabel: string;
  lstTechnicians2: any;
  techListCols: KeyValue[];
  @ViewChild('roleTable') dataTableComponent: any;
  selectedApplicationCode: string;
  IsallowedSave: boolean;
  LocalAccess: boolean = false;
  shouldToggle: boolean = false;
  addIconPath = Constants.addIcon;
  minusIconPath = Constants.minusIcon;
  check: boolean = false;
  toolTip: string;
  sortField: string;
  sortOrder: number;
  recCols: any;
  cols: any = [];
  runSaved: string = "Run Details Saved Successfully";

  isGeneralInfo: boolean = true;
  isCatalyst: boolean = true;
  isFeed: boolean = true;
  isAnalyticalSample: boolean = true;
  isTMS: boolean = true;
  isAdditionalInfo: boolean = true;
  isNIRSpec: boolean = true;
  isTCCalibratonInfo: boolean = true;
  isRunBoilingPoints: boolean = true;
  isRecipe: boolean = false;
  stdboilingPointstitle: any;
  isProcessSpec: boolean = true;
  run: RunSetupModel;
  constructor(private runService: RunService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
    private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService, public runDataService: RunDataService) {
    this.deleteIconPath = Constants.deleteIconPath;
    this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    this.Headerlabel = "Expand All";

  }

  ngOnInit() {
    debugger;
    //this.run = new RunModel();
    // this.isGeneralInfo = false;
    // this.isAdditionalInfo = false;
    // this.isCatalyst = false;
    // this.isFeed = false;
    // this.isAnalyticalSample = false;
    // this.isTMS = false;
    // this.isNIRSpec = false;
    // this.isTCCalibratonInfo = false;
    // this.isRunBoilingPoints = false;
    // this.isProcessSpec = false;



    this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);
    // if (Object.keys(this.run.GeneralInfo).length > 0) {
    //     this.isGeneralInfo = true;
    // }
    // if (Object.keys(this.run.AdditionalInfo).length > 0) {
    //     this.isAdditionalInfo = true;
    // }
    // if (this.run.Cataysts.length > 0) {
    //     this.isCatalyst = true;
    // }
    // if (this.run.FeedInfo != undefined && Object.keys(this.run.FeedInfo).length > 0 && this.run.MetaData.RunFeedId != undefined && this.run.MetaData.RunFeedId != null) {
    //     this.isFeed = true;
    // }
    // if (this.run.lstAnalyticalSamples != undefined && this.run.lstAnalyticalSamples.length > 0) {
    //     this.isAnalyticalSample = true;
    // }
    // if (this.run.lstTMF_Calibrations.length > 0) {
    //     this.isTMS = true;
    // }
    // if (this.run.lstNIRSpec.length > 0) {
    //     this.isNIRSpec = true;
    // }
    // if (this.run.lstTC_Calibrations.length > 0) {
    //     this.isTCCalibratonInfo = true;
    // }
    if (this.run.lstRunCutBoilingPoints.length > 0) {
      this.isRunBoilingPoints = true;
      if (this.run.MetaData.ModeType != null && this.run.MetaData.ModeType != undefined) {
        this.stdboilingPointstitle = "Standard Boiling Points" + " " + "[" + this.run.MetaData.ModeType + "]";
      }
      else {
        this.stdboilingPointstitle = "Standard Boiling Points";
      }
    }
    if (this.run.Recipe != undefined) {
      debugger;
      this.isRecipe = true;
    }
    if (this.run.lstProcessSpec.length > 0) {
      this.isProcessSpec = true;
    }

  }

  getToolTip(rowData: any, col: string, index: number) {
    let columnIndex = this.cols.findIndex(x => x == col);
    let inductionIndex = this.cols.findIndex(x => x == "Induction");
    switch (rowData.Description != undefined && rowData.Description.toLowerCase()) {
      case "fresh feed - lhsv":
        if (columnIndex > 3 && columnIndex <= inductionIndex) {
          this.toolTip = "LHSV = " + parseFloat(this.run.RecipeMaster[index][col] * 3600 + "").toFixed(2) + " hr-1";
        }
        else if (columnIndex > 3) {
          this.toolTip = "LHSV = " + parseFloat(this.run.RunModedata.LHSV * 3600 + "").toFixed(2) + " hr-1";
        }
        else {
          this.toolTip = "";
        }
        break;
      case "fresh h2 feed - scfb":
        if (columnIndex > 3 && columnIndex <= inductionIndex) {
          this.toolTip = "SCFB = " + parseFloat(this.run.RecipeMaster[index][col] + "").toFixed(2) + " SCFB";
        } else if (columnIndex > 3) {
          this.toolTip = "SCFB = " + this.run.RunModedata.SCFB + " SCFB";
        }
        else {
          this.toolTip = "";
        }
        break;
      case "fresh h2 feed - ghsv":
        if (columnIndex > 3) {
          this.toolTip = "GHSV = " + parseFloat(((rowData[col] * 3600) / this.run.MetaData.CatalystVolume) + "").toFixed(2) + " hr-1";
        }
        else {
          this.toolTip = "";
        }
        break;
      default:
        break;
    }
  }
  ExpandAll() {
    this.Headerlabel = "Collapse All";
    this.shouldToggle = true;
  }
  CollapseAll() {
    this.Headerlabel = "Expand All";
    this.shouldToggle = false;
  }


  ngDoCheck() {
    if (!this.check) {
      if (Constants.UserPrivileges.length > 1) {
        for (let i in Constants.UserPrivileges) {
          //if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "ROLE" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
          if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000016" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
            this.IsallowedSave = true;
            this.check = true;
          }
        }
      }
    }

  }

}
