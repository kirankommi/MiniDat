﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.DOE;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace MINIDAT.DataAccess.Repository.DOE
{
    public class DOERepository : IDOERepository
    {

        private IDatabase _db;
        public DOERepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public string DeleteDOE(int strudyID)
        {
            IDataReader rdr = null;

            using (IDbCommand cmd = _db.CreateCommand("[md].[Delete_DOE]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_int_studyID", strudyID);
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);
                if (rdr.Read())
                {
                    return Convert.ToString(rdr["Result"]);
                }
            }
            return "";
        }

        public Study GetDOEInformation(int studyID)
        {
            IDataReader rdr = null;
            Study sd = new Study();
            using (IDbCommand cmd = _db.CreateCommand("[md].[Get_DOE_Information]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_int_StudyID", studyID);
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);

                //study details IDSQ	Name	SpecialistNM	SpecialistID	Estimation	Objective	Strategy	DOEQuestion	Conclusion	FinalDate	CreatedEID
                if (rdr.Read())
                {
                    sd.IDSQ = Convert.ToInt32(rdr["IDSQ"]);
                    sd.Name = Convert.ToString(rdr["Name"]);
                    sd.SpecialistID = Convert.ToString(rdr["SpecialistID"]);
                    sd.SpecialistNM = Convert.ToString(rdr["SpecialistNM"]);
                    sd.Estimation = Convert.ToInt32(rdr["Estimation"]);
                    sd.Objective = Convert.ToString(rdr["Objective"]);
                    sd.Strategy = Convert.ToString(rdr["Strategy"]);
                    sd.DOEQuestion = Convert.ToString(rdr["DOEQuestion"]);
                    sd.Conclusion = Convert.ToString(rdr["Conclusion"]);
                    sd.FinalDate = Convert.ToString(rdr["FinalDate"]);
                    sd.CreatedEID = Convert.ToString(rdr["CreatedEID"]);
                    sd.ApprochingGate = Convert.ToString(rdr["ApprochingGate"]);
                }

                //Project Detail
                rdr.NextResult();
                sd.Project = new DOE_Project();
                if (rdr.Read())
                {
                    sd.Project.ID = Convert.ToInt32(rdr["ID"]);
                    sd.Project.Name = Convert.ToString(rdr["Name"]);
                    sd.Project.NW1 = Convert.ToString(rdr["NW1"]);
                    sd.Project.NW2 = Convert.ToString(rdr["NW2"]);
                    sd.Project.NW3 = Convert.ToString(rdr["NW3"]);
                    sd.Project.TechLead = Convert.ToString(rdr["TechLead"]);
                }

                //Runs 

                Dictionary<int, List<DOEBed>> bedList = new Dictionary<int, List<DOEBed>>();
                Dictionary<int, List<double?>> conversions = new Dictionary<int, List<double?>>();
                Dictionary<int, FeedInfo> FeedInfos = new Dictionary<int, FeedInfo>();
                Dictionary<int, ModeInfo> modeInfos = new Dictionary<int, ModeInfo>();
                rdr.NextResult();
                sd.Runs = new List<Run>();
                while (rdr.Read())
                {
                    Run rn = new Run();
                    rn.DOEID = Convert.ToInt32(rdr["DOEID"]);
                    rn.Plant = Convert.ToString(rdr["Plant"]);
                    rn.RunNum = Convert.ToInt32(rdr["RunNum"]);
                    rn.NetworkNUM = Convert.ToString(rdr["NetworkNUM"]);
                    rn.StartDate = Convert.ToString(rdr["StartDate"]);
                    rn.EndDate = Convert.ToString(rdr["EndDate"]);
                    rn.Status = getStatus(Convert.ToString(rdr["STATUS"]));
                    rn.DOERun = Convert.ToInt32(rdr["DOERun"]);
                    rn.RUN_ID = Convert.ToInt32(rdr["RUN_ID"]);
                    rn.NIRFlagInd = Convert.ToString(rdr["NIRFlag"]);
                    sd.Runs.Add(rn);
                    bedList.Add(rn.RUN_ID.Value, new List<DOEBed>());
                    conversions.Add(rn.RUN_ID.Value, new List<double?>());
                    FeedInfos.Add(rn.RUN_ID.Value, new FeedInfo());
                    modeInfos.Add(rn.RUN_ID.Value, new ModeInfo());
                }

                //Catalyst Template Info
                rdr.NextResult();
                while (rdr.Read())
                {
                    CatalystInfo catalystInfo = new CatalystInfo();
                    catalystInfo.TemplateID = Convert.ToInt32(rdr["TemplateID"]);
                    catalystInfo.TemplateName = Convert.ToString(rdr["TemplateName"]);
                    catalystInfo.LoadingSubmitted = Convert.ToString(rdr["LoadingSubmitted"]);
                    catalystInfo.RxLoaded = Convert.ToString(rdr["RxLoaded"]);
                    sd[Convert.ToInt32(rdr["RUN_ID"])].CatalystTemplate = catalystInfo;
                }


                //Beds
                rdr.NextResult();
                while (rdr.Read())
                {
                    DOEBed bed = new DOEBed();
                    bed.BedNumber = Convert.ToInt32(rdr["BedNumber"]);
                    bed.CatalystVolume = Convert.ToDecimal(rdr["CatalystVolume"]);
                    bed.Split = Convert.ToInt32(rdr["SPIT"]);
                    bed.DiluentDesignation = Convert.ToString(rdr["DiluentDesignation"]);
                    bed.DiluentVolume = Convert.ToDecimal(rdr["DiluentVolume"]);
                    bed.DiluentID = Convert.ToInt32(rdr["DiluentID"]);
                    bed.Catalyst = new Model.Catalyst.CatalystLite();
                    bed.Catalyst.CatalystId = Convert.ToInt32(rdr["CatalystId"]);
                    bed.Catalyst.CatalystDesignation = Convert.ToString(rdr["CatalystDesignation"]);
                    bed.Catalyst.CatalystFamilyName = Convert.ToString(rdr["CatalystFamilyName"]);
                    bed.Catalyst.CatalystTypeName = Convert.ToString(rdr["CatalystTypeName"]);
                    bed.Catalyst.AnalyticalStatusName = Convert.ToString(rdr["AnalyticalStatusName"]);
                    bed.Catalyst.BulkLocationInd = Convert.ToString(rdr["BulkLocationInd"]);
                    bed.Catalyst.CatalystLeaderName = Convert.ToString(rdr["CatalystLeaderName"]);
                    bedList[Convert.ToInt32(rdr["RUN_ID"])].Add(bed);
                }

                //Mode Info
                rdr.NextResult();
                while (rdr.Read())
                {
                    ModeInfo mode = new ModeInfo();
                    mode.ModeID = DBNull.Value != rdr["MODE_ID"] ? Convert.ToInt32(rdr["MODE_ID"]) : default(int?);
                    mode.ModeNumber = Convert.ToString(rdr["ModeNumber"]);
                    mode.Description = Convert.ToString(rdr["Description"]);
                    mode.ModeType = Convert.ToString(rdr["ModeType"]);
                    mode.SulfidingType = Convert.ToString(rdr["SulfidingType"]);
                    mode.ControlName = Convert.ToString(rdr["ControlName"]);
                    mode.Pressure = rdr["Pressure"].FormatDouble();
                    mode.LHSV = rdr["LHSV"].FormatDouble();
                    mode.SCFB = rdr["SCFB"].FormatDouble();
                    mode.Conditions = Convert.ToInt16(rdr["Conditions"]);
                    mode.Sort = rdr["SORT"].FormatDouble();
                    modeInfos[Convert.ToInt32(rdr["RUN_ID"])] = mode;
                }

                //Conversion
                rdr.NextResult();
                while (rdr.Read())
                {
                    conversions[Convert.ToInt32(rdr["RUN_ID"])].Add(rdr["CONVERSION_MSR"].FormatDouble());
                }

                //FeedInfo
                rdr.NextResult();
                while (rdr.Read())
                {
                    FeedInfo fd = new FeedInfo();
                    fd.ID = Convert.ToInt32(rdr["ID"]);
                    fd.Name = Convert.ToString(rdr["Name"]);
                    fd.Desc = Convert.ToString(rdr["Desc"]);
                    fd.HasDopant = Convert.ToBoolean(rdr["HasDopant"]);
                    FeedInfos[Convert.ToInt32(rdr["RUN_ID"])] = fd;

                }


                //Associating the beds & Conversions to the Run catalyst template object
                foreach (var item in bedList)
                {
                    Run rn = sd[item.Key];
                    rn.CatalystTemplate.Beds = bedList[item.Key];
                    rn.Feed = FeedInfos[item.Key];
                    rn.Mode = modeInfos[item.Key];
                    rn.Mode.Conversion = conversions[item.Key];
                }

                rdr.NextResult();
                sd.File_List = new List<Model.DOE.FileInfo>();
                while (rdr.Read())
                {
                    sd.File_List.Add(new Model.DOE.FileInfo()
                    {
                        UID = Convert.ToInt32(rdr["UID"]),
                        FileName = Convert.ToString(rdr["FileName"]),
                        Description = Convert.ToString(rdr["Description"]),
                        isDirty = false
                    });
                }
                if (sd.Runs.Count > 0)
                {
                    sd.Estimation = 0;
                    foreach (var run in sd.Runs)
                    {
                        DateTime startTime, endTime;
                        if (DateTime.TryParse(run.StartDate, out startTime) && DateTime.TryParse(run.EndDate, out endTime))
                        {
                            sd.Estimation += endTime.Subtract(startTime).TotalMinutes;
                        }
                    }
                    sd.Estimation = (sd.Estimation == 0 ? 0 : sd.Estimation / 1440).FormatDoubleWithPrecision(2);
                }
            }
            return sd;
        }
        public string getStatus(string status)
        {
            switch (status)
            {
                case "RNCMP":
                    return "Completed";
                case "RNINP":
                    return "In Progress";
                default:
                    return "Queued";
            }
        }
        public MasterData GetMasterData()
        {
            MasterData MD = new MasterData();
            IDataReader objSqlDr = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_DOE_MasterData]"))
            {
                objSqlDr = _db.ExecuteReader(command);
                while (objSqlDr.Read())
                {
                    MD.Projects.Add(new DOE_Project()
                    {
                        ID = Convert.ToInt32(objSqlDr["PROJECT_ID_SQ"]),
                        Name = Convert.ToString(objSqlDr["PROJECT_NM"]),
                        NW1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                        NW2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                        NW3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                        TechLead = Convert.ToString(objSqlDr["TECH_LEAD"])
                    });
                }
                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.StudyLst.Add(new Study()
                    {
                        Name = Convert.ToString(objSqlDr["STUDY_NM"]),
                        SpecialistID = Convert.ToString(objSqlDr["MGR_SPCL_ID"]),
                        SpecialistNM = Convert.ToString(objSqlDr["SPCL_NM"]),
                        //ApprochingGate = Convert.ToString(objSqlDr["APRCH_GATE_CD"]),
                        Objective = Convert.ToString(objSqlDr["STDY_OBJT_DESC"]),
                        Strategy = Convert.ToString(objSqlDr["SPCL_STRATEGY_DESC"]),
                        DOEQuestion = Convert.ToString(objSqlDr["DOE_QSTN_DESC"]),
                        Conclusion = Convert.ToString(objSqlDr["DOE_CONCLUSION_DESC"]),
                        FinalDate = Convert.ToString(objSqlDr["DOE_FINAL_DT"]),
                        Estimation = Convert.ToInt32(objSqlDr["EST_DURATION"]),
                        Project = new DOE_Project()
                        {
                            ID = Convert.ToInt32(objSqlDr["PROJECT_ID_SQ"]),
                            Name = Convert.ToString(objSqlDr["PROJECT_NM"]),
                            NW1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                            NW2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                            NW3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                            TechLead = Convert.ToString(objSqlDr["TECH_LEAD"])
                        }
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.PlantList.Add(new Plant()
                    {
                        Key = Convert.ToString(objSqlDr["PLANT_KEY"]),
                        Name = Convert.ToString(objSqlDr["PLANT_CD"]),
                        Location = Convert.ToString(objSqlDr["LOCATION_NM"])
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.Modes.Add(new DOEMode()
                    {
                        ModeID= Convert.ToInt32(objSqlDr["MODE_ID_SQ"]),
                        ModeNumber = Convert.ToInt32(objSqlDr["MODE_NUM"]),
                        ModeType = Convert.ToString(objSqlDr["OBJECTIVE_NM"]),
                        ControlName = Convert.ToString(objSqlDr["CONTROL_METHOD_NM"]),
                        SulfidingType = Convert.ToString(objSqlDr["SULFIDING_TYPE_NM"]),
                        Pressure = objSqlDr["PRESSURE"].FormatDecimal(),
                        LHSV = objSqlDr["LHSV"].FormatDecimal(),
                        SCFB = objSqlDr["SCFB"].FormatDecimal(),
                        Duration = Convert.ToInt32(objSqlDr["DURATION"]),
                        Conditions = Convert.ToInt32(objSqlDr["CONDITION"])
                    });
                }

                if (objSqlDr.NextResult())
                {
                    while (objSqlDr.Read())
                    {
                        MD.Feeds.Add(new FeedInfo()
                        {
                            ID = Convert.ToInt32(objSqlDr["FEED_ID_SQ"]),
                            Name = Convert.ToString(objSqlDr["FEED_NM"]),
                            Desc = Convert.ToString(objSqlDr["FEED_DESC"]),
                            BookNum = Convert.ToString(objSqlDr["FEED_BOOK_NUM"]),
                            UOPNum = Convert.ToString(objSqlDr["FEED_UOP_NUM"]),
                            HasDopant = Convert.ToBoolean(objSqlDr["HasDopant"]),
                            DensityMsr = Convert.ToString(objSqlDr["DENSITY_MSR"]).FormatDoubleWithPrecision(3)
                        });
                    }
                }
                //MD.ColumnPref.ColumnPreferences = "[{\"name\":\"General Information\",\"displayName\":\"General Information\",\"isVisible\":true,\"isFrozen\":true,\"isStatic\":true,\"childrens\":[{\"name\":\"Plant #\",\"displayName\":\"Plant #\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Run #\",\"displayName\":\"Plant #\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Estimated / Actual Start Date \",\"displayName\":\"Estimated / Actual Start Date\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Estimated / Actual Complition Date\",\"displayName\":\"Estimated / Actual Complition Date\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Status\",\"displayName\":\"Status\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1}],\"rowSpan\":2,\"colSpan\":5},{\"name\":\"DOE Run #\",\"displayName\":\"DOE Run #\",\"isVisible\":true,\"isStatic\":true,\"isFrozen\":true,\"rowSpan\":2,\"colSpan\":1},{\"name\":\"Requester_Specialist\",\"displayName\":\"Specialist\",\"isVisible\":true,\"isStatic\":true,\"isFrozen\":true,\"rowSpan\":2,\"colSpan\":1},{\"name\":\"Network\",\"displayName\":\"Network\",\"isVisible\":true,\"isStatic\":true,\"isFrozen\":true,\"rowSpan\":2,\"colSpan\":1},{\"name\":\"Catalyst Info\",\"displayName\":\"Catalyst Info\",\"isVisible\":true,\"isFrozen\":true,\"childrens\":[{\"name\":\"Catalyst ID\",\"displayName\":\"Catalyst ID\",\"isVisible\":true,\"isFrozen\":true,\"isStatic\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Catalyst Template Loading\",\"displayName\":\"Catalyst Loading Template\",\"isVisible\":false,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Catalyst Family\",\"displayName\":\"Catalyst Family\",\"isVisible\":false,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Leader_MPT_RES\",\"displayName\":\"Catalyst Leader (MPT/RES)\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Analystical Status_Quality\",\"displayName\":\"Analytical Status/ Quality\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Bulk Location\",\"displayName\":\"Bulk Location\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Loading Submitted\",\"displayName\":\"Loading Submitted\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Rx Loaded\",\"displayName\":\"Rx Loaded\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1}],\"rowSpan\":2,\"colSpan\":6},{\"name\":\"Model Info\",\"displayName\":\"Mode Info\",\"isVisible\":true,\"isFrozen\":true,\"childrens\":[{\"name\":\"Mode #\",\"displayName\":\"Mode #\",\"isVisible\":true,\"isFrozen\":true,\"isStatic\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Mode\",\"displayName\":\"Mode\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Control\",\"displayName\":\"Control\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Sulfiding\",\"displayName\":\"Sulfiding\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Pressure\",\"displayName\":\"Pressure\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"LHSV\",\"displayName\":\"LHSV\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"SCFB\",\"displayName\":\"H2/HC\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Condition\",\"displayName\":\"Condition\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Temp_NET Conversion\",\"displayName\":\"Temp/NET Conversion\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"SORT\",\"displayName\":\"SORT\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1}],\"rowSpan\":2,\"colSpan\":10},{\"name\":\"Feed Info\",\"displayName\":\"Feed Info\",\"isVisible\":true,\"isFrozen\":true,\"childrens\":[{\"name\":\"Feedstock Name\",\"displayName\":\"Feedstock Name\",\"isVisible\":true,\"isFrozen\":true,\"isStatic\":true,\"rowSpan\":1,\"colSpan\":1},{\"name\":\"Flush Required\",\"displayName\":\"Flush Required\",\"isVisible\":true,\"isFrozen\":true,\"rowSpan\":1,\"colSpan\":1}],\"rowSpan\":2,\"colSpan\":2},{\"name\":\"Action\",\"displayName\":\"Action\",\"isVisible\":true,\"isFrozen\":true,\"isStatic\":true,\"rowSpan\":2,\"colSpan\":1}]";
            }

            return MD;
        }

        public PoolMasterData GetPoolMasterData()
        {
            PoolMasterData mstr = new PoolMasterData();
            IDataReader objSqlDr = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_DOEPOOL_MasterData]"))
            {
                objSqlDr = _db.ExecuteReader(command);
                mstr.Specialists = new List<KeyValue>();
                while (objSqlDr.Read())
                {
                    mstr.Specialists.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["Key"]),
                        Value = Convert.ToString(objSqlDr["Value"])
                    });
                }
                objSqlDr.NextResult();
                mstr.Statuses = new List<KeyValue>();
                while (objSqlDr.Read())
                {
                    mstr.Statuses.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["Key"]),
                        Value = Convert.ToString(objSqlDr["Value"])
                    });
                }
            }
            return mstr;
        }

        public string SaveDOE(SaveModel saveMdl)
        {
            IDataReader rdr = null;

            #region Serializing the List as XML
            XmlSerializer serializer = new XmlSerializer(saveMdl.DOE.GetType());
            StringBuilder strBuilder = new StringBuilder();
            using (StringWriter strWriter = new StringWriter(strBuilder))
            {
                serializer.Serialize(strWriter, saveMdl.DOE);
            }
            //strBuilder.Replace("utf-16", "utf-8");
            #endregion


            using (IDbCommand cmd = _db.CreateCommand("md.Insert_Update_DOE_Information_Sp"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_xml_doe_Detail", strBuilder.ToString());
                parameters.Add("proc_ar_delete_Ids", saveMdl.DeleteIds);
                parameters.Add("proc_vr_Created_By_User_Id", saveMdl.DOE.CreatedEID);
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);
                if (rdr.Read())
                {
                    if (string.IsNullOrEmpty(rdr["ERROR"].ToString()))
                    {
                        return rdr["STUDY_ID"].ToString();
                    }
                    else
                    {
                        throw new Exception(rdr["ERROR"].ToString());
                    }
                }
            }
            throw new Exception("Unable to save");

        }

        public List<PoolModel> SearchDOE(PoolModel doe)
        {
            List<PoolModel> doeList = new List<PoolModel>();
            using (IDbCommand cmd = _db.CreateCommand("[md].[Search_DOE_Pool_Sp]"))
            {
                IDataReader rdr = null;
                IDictionary parameters = new Dictionary<string, object>();

                parameters.Add("@proc_vr_Project", doe.Project);
                parameters.Add("@proc_vr_Study", doe.Study);
                parameters.Add("@proc_vr_Specialist", doe.Specialist);
                parameters.Add("@proc_vr_FromCreated", doe.FromCreated);
                parameters.Add("@proc_vr_ToCreated", doe.ToCreated);
                parameters.Add("@proc_vr_FromClosed", doe.FromClosed);
                parameters.Add("@proc_vr_ToClosed", doe.ToClosed);
                parameters.Add("@proc_vr_Status", doe.Status);
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);
                while (rdr.Read())
                {
                    doeList.Add(new PoolModel()
                    {
                        StudyID = Convert.ToInt32(rdr["Study_ID_SQ"]),
                        Project = Convert.ToString(rdr["PROJECT_NM"]),
                        Study = Convert.ToString(rdr["STUDY_NM"]),
                        Specialist = Convert.ToString(rdr["Specialist"]),
                        FromCreated = Convert.ToString(rdr["CREATED_ON_DT"]),
                        FromClosed = Convert.ToString(rdr["DOE_FINAL_DT"]),
                        Status = Convert.ToString(rdr["DOE_STATUS_CD"]),
                        FileCount=Convert.ToInt32(rdr["FILE_CNT"])
                    });
                }
            }
            return doeList;
        }

        public string UploadFiles(List<DoeFileModel> Files, string DeleteIDs, int studyID, string UserID)
        {
            foreach (DoeFileModel file in Files)
            {
                using (IDbCommand cmd = _db.CreateCommand("[md].[Insert_Update_DOE_Document_sp]"))
                {
                    IDataReader rdr = null;
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_StudyID", studyID);
                    parameters.Add("proc_xml_doe_file", file.getData());
                    parameters.Add("proc_vr_FileName", file.FileName);
                    parameters.Add("proc_vr_Description", file.Description);
                    parameters.Add("proc_vr_content_Type", file.ContentType);
                    parameters.Add("proc_id_File_ID", file.UID);
                    parameters.Add("CREATED_BY_USER_ID", UserID);
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                }
            }
            if (DeleteIDs.Split(',').Length > 0)
            {
                using (IDbCommand cmd = _db.CreateCommand("[md].[Delete_DOE_Document_sp]"))
                {
                    IDataReader rdr = null;
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_StudyID", studyID);
                    parameters.Add("proc_ary_DeleteIDs", DeleteIDs);
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                }
            }
            return "Uploaded";
        }


        public DoeFileModel GetDocument(string fileId, string studyID)
        {
            var doc = new DoeFileModel();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("FILE_ID", fileId);
            parameters.Add("Study_Id", studyID);
            using (IDbCommand cmd = _db.CreateCommand("MD.Get_DOE_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.UID = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileData = (byte[])reader["DATA"];
                }
                reader.Close();
                return doc;
            }
        }

        public List<DoeFileModel> GetStudyDocument(string studyID)
        {
            List<DoeFileModel> files = new List<DoeFileModel>();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("Study_Id", studyID);
            using (IDbCommand cmd = _db.CreateCommand("MD.Get_Study_Documents_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    DoeFileModel doc = new DoeFileModel();
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.UID = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileData = (byte[])reader["DATA"];
                    files.Add(doc);
                }
                reader.Close();
            }
            return files;
        }

        public List<DOEFile> BrowseFiles()
        {
            List<DOEFile> docs = new List<DOEFile>();
            IDictionary parameters = new Dictionary<string, object>();
            using (IDbCommand cmd = _db.CreateCommand("[md].[Get_All_DOE_Documents_Sp]"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    DOEFile doc = new DOEFile();
                    doc.StudyNM = Convert.ToString(reader["STUDY_NM"]);
                    doc.StudyID = Convert.ToInt32(reader["STUDY_ID_SQ"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileSize = Math.Round(Convert.ToDecimal(reader["SIZE"]) > 1024 ? Convert.ToDecimal(reader["SIZE"]) / 1024 : Convert.ToDecimal(reader["SIZE"]), 2);
                    doc.SizeUnit = Convert.ToDecimal(reader["SIZE"]) > 1024 ? "KB" : "Bytes";
                    doc.LastUpdatedDateTime = Convert.ToString(reader["LASTUPDTEDATE"]);
                    docs.Add(doc);
                }
                reader.Close();
                return docs;
        }
    }

        //public string SaveColPreferences(ColumnsPreferences columnPref)
        //{
        //    IDataReader rdr = null;
        //    using (IDbCommand cmd = _db.CreateCommand("md.Insert_Update_DOE_Column_Preferences_sp"))
        //    {
        //        IDictionary parameters = new Dictionary<string, object>();
        //        parameters.Add("proc_vr_ColumnPreferences", columnPref.ColumnPreferences.ToString());
        //        parameters.Add("CREATED_BY_USER_ID", columnPref.UserId);
        //        _db.CreateParameters(cmd, parameters);
        //        rdr = _db.ExecuteReader(cmd);
        //        return "Saved Successfully";
        //    }
        //}
        //public ColumnsPreferences GetColumnPreferences(string userId)
        //{
        //    ColumnsPreferences column= new ColumnsPreferences() ;
        //    IDataReader objSqlDr = null;
        //    using (IDbCommand command = _db.CreateCommand("[md].[Get_DOE_Column_Preferences_sp]"))
        //    {
        //        IDictionary parameters = new Dictionary<string, object>();
        //        parameters.Add("USER_ID", userId);
        //        _db.CreateParameters(command, parameters);
        //        objSqlDr = _db.ExecuteReader(command);
        //        while (objSqlDr.Read())
        //        {
        //            column.ColumnPreferences = objSqlDr["PREFERENCE"].ToString();
        //        }
        //    }
        //        return column;
        //}

    }
}
