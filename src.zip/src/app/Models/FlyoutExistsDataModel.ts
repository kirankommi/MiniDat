﻿export class FlyoutExistsDataModel {
    ExistsList: Array<any>;
    SourceColumn: string;
    MatchColumn: string;
    SourceColumn2: string;
    MatchColumn2: string;
}