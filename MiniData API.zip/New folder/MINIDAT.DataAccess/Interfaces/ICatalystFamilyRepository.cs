﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystFamilyRepository : ICRUDRepository<CatalystFamilyModel>
    {
        CatalystFamilySearchModel GetCatalystFamilyData(CatalystFamilyModel catalystFamily);
        string DeleteCatalystFamilyData(CatalystFamilyModel catalystFamily);
        void SaveCatalystFamilyData(CatalystFamilyModel _catalystFamily, string userId);      

    }
}
