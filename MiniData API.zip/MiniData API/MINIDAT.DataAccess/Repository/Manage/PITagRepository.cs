﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleRepository.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Manage;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class PITagRepository : IPITagRepository
    {
        private IDatabase _db;
        public PITagRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="N", Value="Inactive"},
                    new KeyValue() {Key="Y", Value="Active"},
                };


        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="PITag"></param>
        /// <returns></returns>
        public PITagSearchModel GetPITagData(PITagModel PITag)
        {
            try
            {
                PITagSearchModel piTagarr = new PITagSearchModel();
                if (PITag == null)
                {
                    return piTagarr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[Search_Process_Information_Tags_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Plant_Cd", PITag.Plantcode);
                    parameters.Add("proc_vr_Pi_Tag_Nm", PITag.PITagName);
                    parameters.Add("proc_in_Log_Read_Label_Txt", PITag.LogsheetReadingLabel);
                    parameters.Add("proc_nm_Min_Value_Msr", PITag.MinRange);
                    parameters.Add("proc_nm_Max_Value_Msr", PITag.MaxRange);
                    parameters.Add("proc_nm_Label_Read_Order_Num", PITag.DisplayOrder);
                    parameters.Add("proc_vr_Input_Variable_Typ", PITag.ValueTypeName == "Select" ? null: PITag.ValueTypeName);                  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    piTagarr.lstPITags.Clear();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)piTagarr.lstReadingTypes).Add(new KeyValue()
                        {
                            Key = reader["INPUT_VARIABLE_TYP"].ToString(),
                            Value = reader["INPUT_VARIABLE_TYP"].ToString()
                        });                        
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        PITagModel newRole = new PITagModel()
                        {
                            //Plantcode = new KeyValue()
                            //{
                            //    Key = reader["PLANT_KEY"].ToString(),
                            //    Value = reader["PLANT_CD"].ToString()
                            //},
                            PITagID = reader["PI_TAG_ID_SQ"].ToString(),
                            Plantcode = reader["PLANT_CD"].ToString(),
                            PITagName = reader["PI_TAG_NM"].ToString(),
                            LogsheetReadingLabel = reader["LOG_READ_LABEL_TXT"].ToString(),
                            MinRange = reader["MIN_VALUE_MSR"].FormatDouble(),
                            MaxRange = reader["MAX_VALUE_MSR"].FormatDouble(),
                            DisplayOrder = Convert.ToInt32(reader["LABEL_READ_ORDER_NUM"]),
                            PIValueType = new KeyValue() { Key = reader["INPUT_VARIABLE_TYP"].ToString(), Value = reader["INPUT_VARIABLE_TYP"].ToString() }
                        };
                        piTagarr.lstPITags.Add(newRole);
                    }

                   reader.NextResult();
                    ApplicationModel appModel = new ApplicationModel();
                    // rolesearchModel.ApplicationList.Add(new ApplicationModel { ApplicationId = "3", ApplicationName = "FeedStock DAT" });
                    while (reader.Read())
                    {
                        appModel = new ApplicationModel
                        {
                            ApplicationId = Convert.ToString(reader["SRC_SYSTEM_ID"]),
                            ApplicationName = Convert.ToString(reader["SRC_SYSTEM_NM"])

                        };
                        //   roleList.Add(appModel);
                        piTagarr.ApplicationList.Add(appModel);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        piTagarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }

                    piTagarr.Status.Clear();
                    reader.Close();
                    ((List<KeyValue>)piTagarr.Status).AddRange(statuses);
                    return piTagarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="PITag"></param>
        /// <returns></returns>
        public string DeletePITagData(PITagModel pITag)
        {
            try
            {
                if (pITag == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("Delete_Process_Information_Tags_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Pi_Tag_Id", string.IsNullOrEmpty(pITag.PITagID) ? (object)null : pITag.PITagID); ;
                    parameters.Add("proc_vr_Plant_cd", string.IsNullOrEmpty(pITag.Plantcode) ? (object)null : pITag.Plantcode);
                    parameters.Add("proc_vr_PI_Tag_NM", string.IsNullOrEmpty(pITag.PITagName) ? (object)null : pITag.PITagName);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SavePITagData(PITagModel PITag, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || PITag == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("Insert_Update_Process_Info_Tags_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Pi_Tag_Id", string.IsNullOrEmpty(PITag.PITagID)?(object)null : PITag.PITagID);
                    parameters.Add("proc_vr_Plant_cd", string.IsNullOrEmpty(PITag.Plantcode) ? (object)null : PITag.Plantcode);
                    parameters.Add("proc_vr_Pi_Tag_Nm", string.IsNullOrEmpty(PITag.PITagName) ? (object)null : PITag.PITagName);
                    parameters.Add("proc_in_Log_Read_Label_Txt", string.IsNullOrEmpty(PITag.LogsheetReadingLabel) ? (object)null : PITag.LogsheetReadingLabel);
                    parameters.Add("proc_nm_Min_Value_Msr", PITag.MinRange);
                    parameters.Add("proc_nm_Max_Value_Msr", PITag.MaxRange);
                    parameters.Add("proc_nm_Label_Read_Order_Num", PITag.DisplayOrder);
                    parameters.Add("proc_vr_Input_Variable_Typ", PITag.ValueTypeName);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// search role
        /// </summary>
        /// <param name="PITag"></param>
        /// <returns></returns>
        public PITagSearchModel GetPlantsData(PlantModel plant)

        {
            try
            {
                PITagSearchModel piTagarr = new PITagSearchModel();
                if (plant == null)
                {
                    return piTagarr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[Search_Plant_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Plant_Cd", plant.Plantcode);
                    parameters.Add("proc_in_Building_Cd ", plant.BuildingNumber);
                    parameters.Add("proc_vr_Location_Cd", plant.Location);                  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    piTagarr.lstPlants.Clear();
                   
                    while (reader.Read())
                    {
                        PlantModel newPlant = new PlantModel()
                        {
                           
                            Plantcode = reader["PLANT_CD"].ToString(),
                            BuildingNumber = reader["BUILDING_NM"].ToString(),
                            Location = reader["LOCATION_cD"].ToString()
                        };
                        piTagarr.lstPlants.Add(newPlant);
                    }
                    //reader.NextResult();
                    //while (reader.Read())
                    //{
                    //    piTagarr.RecordsFetched = (int)reader["ROW_NUM"];
                    //}
                    //reader.NextResult();
                    //while (reader.Read())
                    //{
                    //    piTagarr.RecordsFetched = (int)reader["proc_in_Rec_Cnt"];
                    //} 
                    return piTagarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        public void Update(PITagModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(PITagModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<PITagModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(PITagModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
