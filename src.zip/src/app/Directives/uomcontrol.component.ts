import { Component, Input, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import * as Constants from '../Shared/globalconstants';

@Component({
  //moduleId: module.id,
  selector: 'UomControl',
  templateUrl: 'uomcontrol.component.html'
})
export class UomControl implements OnInit, OnChanges {
  //    @Input() unitGroupName: string;
  //    @Input() displayUnit: any;
  //    @Input() baseValue: number;
  @Input() pHolder: string;
  @Input() isDisabled: boolean;
  @Input() uomObj: any;
  @Output() change: EventEmitter<any> = new EventEmitter<any>();
  @Output() changeBaseValue: EventEmitter<any> = new EventEmitter<any>();
  displayValue: any;
  units: any = [];
  IsUIChange: boolean = false;
  localUnitGroupName: string;
  check: boolean;
  oldBaseValue: any;
  baseChanged: boolean;

  constructor() {
    this.units = [];
    this.IsUIChange = false;
    this.localUnitGroupName = null;
    this.check = false;
    this.displayValue = null;
    this.oldBaseValue = null;
    this.baseChanged = false;
  }

  ngOnInit() {
  }

  ngOnChanges(changes) {
    if (changes && changes.uomObj) {
      this.onGroupChange();
      this.localUnitGroupName = this.uomObj.unitGroupName;
      this.setDefaultUnit();
      this.check = true;
    }
  }


  ngDoCheck() {
    if (!this.check) {
      if (Constants.UserSessionData != Constants.Undefined) {
        if (Constants.UnitGroups.length > 1 && Constants.UomVariables.length > 1) {
          if (this.uomObj && (this.uomObj.unitGroupName !== this.localUnitGroupName)) {
            this.onGroupChange();
            this.localUnitGroupName = this.uomObj.unitGroupName;
            this.setDefaultUnit();
            this.check = true;
          }
        }
      }
    }
    if (this.uomObj && (this.oldBaseValue != this.uomObj.baseValue)) {
      this.onBaseValueChange();
      this.oldBaseValue = this.uomObj.baseValue;
    }
  }


  GetPrecison() {
    let variable = Constants.UomVariables.filter((x: any) => x.UnitGroupName == this.uomObj.unitGroupName)[0];
    if (this.uomObj.precision != null) {
      return this.uomObj.precision;
    }
    else if (variable != null) {
      return variable.Precision;
    }
    else {
      return 6;
    }
  }

  onGroupChange() {
    let unitGroup: any;
    if (this.uomObj.unitGroupName != undefined && this.uomObj.unitGroupName != null && this.uomObj.unitGroupName != '') {
      let temp = Constants.UnitGroups;
      unitGroup = Constants.UnitGroups.filter((x: any) => x.UnitGroupName == this.uomObj.unitGroupName)[0];
      if (unitGroup != null) {
        this.units = unitGroup.Units;
      }
    }
  }

  setDefaultUnit() {
    if (this.units.length > 0) {
      let defaultUnitId = Constants.UomVariables.filter((x: any) => x.UnitGroupName == this.uomObj.unitGroupName)[0].DefaultUnitID;
      if (this.uomObj.customDefaultUnit != null) {
        this.uomObj.displayUnit = this.units.filter((x: any) => x.UnitName == this.uomObj.customDefaultUnit)[0];
      }
      else {
        this.uomObj.displayUnit = this.units.filter((x: any) => x.UnitId == defaultUnitId)[0];
      }
    }
  }


  onUnitChange(unit: any) {
    if (((this.displayValue != undefined && this.displayValue != null) || this.baseChanged) && this.uomObj.displayUnit != undefined && this.uomObj.displayUnit != null) {
      let unit = this.uomObj.displayUnit;
      this.baseChanged = false;
      if (unit != null && unit != undefined) {
        if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
          this.displayValue = (unit.Slope / this.uomObj.baseValue) - unit.Intercept;
        }
        else {
          this.displayValue = (this.uomObj.baseValue - unit.Intercept) / unit.Slope;
        }
        this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
        this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
        this.uomObj.displayValue = this.displayValue;
        this.uomObj.displayValue = this.displayValue;
        this.changeBaseValue.emit(this.uomObj);
      }
    }
  }

  onValueChange() {
    this.change.emit(null);
    if (this.displayValue != null && this.displayValue != null) {
      this.updateBaseValue();
    }
    else {
      this.uomObj.baseValue = null;
    }
  }

  updateBaseValue() {
    if (this.displayValue != undefined && this.displayValue != null && this.uomObj.displayUnit != undefined) {
      if (!isNaN(this.displayValue)) {
        var unit = this.uomObj.displayUnit;
        if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
          this.uomObj.baseValue = unit.Slope / (this.displayValue + unit.Intercept);
          this.IsUIChange = true;
        }
        else {
          this.uomObj.baseValue = this.displayValue * unit.Slope + unit.Intercept;
          this.IsUIChange = true;
        }
      }
      else {
        this.onUnitChange(this.uomObj.displayUnit);
      }
      debugger;

      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
      this.uomObj.displayValue = this.displayValue;
      this.changeBaseValue.emit(this.uomObj);
    }
  }

  onBaseValueChange() {
    if (this.uomObj.baseValue == null) {
      this.displayValue = null;
    }
    else {
      if (!this.IsUIChange) {
        if (!isNaN(this.uomObj.baseValue) && this.uomObj.baseupdate) {
          this.baseChanged = true;
        }
        this.onUnitChange(this.uomObj.displayUnit);
      }
      else {
        this.IsUIChange = false;
      }
    }
  }
}
