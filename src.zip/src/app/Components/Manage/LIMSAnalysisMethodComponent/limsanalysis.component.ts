import { Component, Input, OnInit, ViewChild, ElementRef, Renderer } from '@angular/core';
import { LIMSComponentService } from '../../../services/limscomponent.service';

import { LimsComponentModel, KeyValue, LimsOpFlyoutModel, LimsComponentFlyoutModel } from '../../../models/LimsComponentModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    templateUrl: 'limsanalysismethod.component.html',
    styleUrls: ['limsanalysis.component.css'],
    providers: [LIMSComponentService, AlertMessage, HttpActionService, ConfirmationService]
})

export class LIMSAnalysisComponent implements OnInit {
    @Input()
    propertyType: string;
    UOMGroupDisabled: boolean = true;
    UOMUnitNameDisabled: boolean = true;
    title: string;
    LIMSOpNameDisabled: boolean = true;
    FDMSComNameDisabled: boolean = true;
    defaultUnit: string;
    LimsComponentList: LimsComponentModel[];
    LimsOpList: LimsComponentModel[];
    LimsOpFlyoutList: LimsOpFlyoutModel[];
    LimsCompFlyoutList: LimsComponentFlyoutModel[];
    LimsOpFlyoutMaster: any;
    LimsCompFlyoutMaster: any;
    LimsCompFlyoutMasterTotal: any;
    @Input()
    LimsOpComponentList: any[];
    uomUnitListRes: KeyValue[];
    uomGroupListRes: KeyValue[];
    IsallowedSave: boolean=false;
    totalRecords: number;
    LimsComponentData: LimsComponentModel;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    limsCompSaved: string = "LimsComponent Details Saved Successfully";
    limsCompDeleted: string = "LimsComponent Deleted Successfully";
    limsOperationCols: any[] = [];
    limsCompCols: any[] = [];
    isCollapsed = false;
    setStyles: boolean;
    insertUpdate: boolean = false;
    @ViewChild('roleTable') dataTableComponent: any;
    selComponentType: string;
    constructor(private limsComponentService: LIMSComponentService, public el: ElementRef, public renderer: Renderer,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService
    ) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    onClick(event: any) {

    }

    ngOnInit() {
        this.LimsComponentList = [];
        this.LimsOpFlyoutList = [];
        this.LimsCompFlyoutList = [];
        this.LimsComponentData = new LimsComponentModel();
        this.getFlyoutLIMSOperation();
        this.getFlyoutLIMSComponent();
        this.getLIMSComponent();
        this.title = Constants.ManageLimsComponent;
    }

    getFlyoutLIMSOperation() {
        debugger;
        this.limsComponentService.getLimsOperationList(this.LimsComponentData)
            .subscribe(
            (data: any) => {
                this.LimsOpList = data;
                //debugger;
                //for (let iz of data) {
                //    this.LimsOpFlyoutList.push({ AnalysisTypeName: iz.AnalysisTypeName, LIMSOperationName: iz.LIMSOperationName, UOM: iz.UOM });
                //}
                this.limsOperationCols.push({ Key: "AnalysisTypeName", Value: "Analysis Type" });
                this.limsOperationCols.push({ Key: "LIMSOperationName", Value: "LIMS Operation" });
                debugger;
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    getFlyoutLIMSComponent() {
        debugger;
        this.limsCompCols = [];
        this.limsComponentService.getLimsComponentList(this.LimsComponentData)
            .subscribe(
            (data: any) => {
                this.LimsOpComponentList = data;
                debugger;
                for (let iz of data) {
                    this.LimsCompFlyoutList.push({ ComponentType: iz.ComponentType, ComponentName: iz.ComponentLabel, });
                }
                this.limsCompCols.push({ Key: "ComponentType", Value: "Component Type" });
                this.limsCompCols.push({ Key: "ComponentName", Value: "Component Name" });
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
        this.LimsCompFlyoutMasterTotal = this.LimsCompFlyoutList;
    }

    getLIMSComponent() {
        this.limsComponentService.getLimsComponent(this.LimsComponentData)
            .subscribe(
            (data: any) => {
                this.LimsComponentList = data.LIMSAnalysisComponentList;
                this.LimsComponentData.uomGroupList = data.LIMSAnalysisComponentFilter.UOMGroupList;
                this.LimsComponentData.UOMGroupName = Constants.Select;
                this.LimsComponentData.uomUnitList = data.LIMSAnalysisComponentFilter.UOMlist;
                this.uomUnitListRes = data.LIMSAnalysisComponentFilter.UOMlist;
                this.uomGroupListRes = data.LIMSAnalysisComponentFilter.UOMGroupList;
                this.LimsComponentData.UOMUnitName = Constants.Select;
                //  this.totalRecords = data.LIMSAnalysisComponentFilter.TotalRecords;
                this.totalRecords = data.LIMSAnalysisComponentList.length;
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    saveLimsComponent() {
        let response: any;
        let fieldSelected = this.getFieldByName(this.LimsComponentData.UOMUnitName);
        this.LimsComponentData.uomUnitList = fieldSelected;
        // this.defaultUnit = fieldSelected.filter((m: any) => m.Default == "Y")[0].Value
        //   this.LimsComponentData.UOMUnitName = this.defaultUnit;
        if (this.isDataValid()) {
            this.limsComponentService.insertUpdateLimsComponent(this.LimsComponentData)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.alertMessage.displaySuccessMessage("LimsComponentSaved")
                        this.onReset();
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.limsCompSaved });
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    isDataValid() {
        if (this.LimsComponentData == null || !this.LimsComponentData.LIMSOperationName || !this.LimsComponentData.LIMSComponent || !this.LimsComponentData.FDMSComponent ||
            this.LimsComponentData.UOMGroupName == Constants.Select || this.LimsComponentData.UOMUnitName == Constants.Select ||
            !(this.LimsComponentData.Precision>=0)) {
            return false;
        }
        return true;
    }

    onUomGroupChange(LimsComponentData: any) {
        let fieldSelected = this.getFieldByName(LimsComponentData.UOMGroupName);
        this.LimsComponentData.uomUnitList = fieldSelected;
        this.defaultUnit = fieldSelected.filter((m: any) => m.Default == "Y")[0].Key
        this.LimsComponentData.UOMUnitName = this.defaultUnit;
    }

    getFieldByName(uomGrp: string) {
        let x = this.uomUnitListRes.filter((m: any) => m.Key == uomGrp);
        if (x != null && x.length > 0)
            return x;
        else
            return null;
    }

    getFieldByGrpName(uomGrp: string) {
        let x = this.uomGroupListRes.filter((m: any) => m.Key == uomGrp);
        if (x != null && x.length > 0)
            return x;
        else
            return null;
    }

    onDelete(uomTemplate: LimsComponentModel) {
         this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
             result = result == Constants.ConfirmTrue; //casting string to boolean
             if (result) { this.deleteUom(uomTemplate); }
         });
    }

    deleteUom(uom: LimsComponentModel) {
        this.limsComponentService.deleteUomTemplate(uom)
            .subscribe(
            (data: any) => {
                if (data == "Success") {
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.limsCompDeleted });
                    this.onReset();
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            (err: any) => { }
            //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    getDelPath() {
        if (!this.IsallowedSave) {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;
    }
    ngDoCheck() {
        if (Constants.UserPrivileges.length > 1) {
            for (let i in Constants.UserPrivileges) {
                if (Constants.UserPrivileges[i].Action.toUpperCase() == "MANAGE/LIMSCOMPONENT" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                    this.IsallowedSave = true;
                }
            }
        }
    }

    onReset() {
        this.LimsComponentData = new LimsComponentModel();
        this.LimsComponentData.UOMGroupName = Constants.Select;
        this.LimsComponentData.UOMUnitName = Constants.Select;
        this.getLIMSComponent();
        this.dataTableComponent.reset();
        this.UOMGroupDisabled = true;
        this.UOMUnitNameDisabled = true;
        this.LIMSOpNameDisabled = true;
        this.FDMSComNameDisabled = true;
        this.insertUpdate = false;
        this.LimsComponentList = [];
        this.LimsCompFlyoutList = [];
        this.LimsCompFlyoutMaster.selectedRow = {};
        this.getFlyoutLIMSComponent();

    }

    onRowUnselect($event: any) { }

    onRowSelect(event: any) {
        debugger;
        this.insertUpdate = true;
        this.LimsCompFlyoutList = [];
        this.LimsComponentData.LIMSOperationName = event.data.LIMSOperationName;
        this.LimsComponentData.LIMSComponent = event.data.LIMSComponent;
        this.LimsComponentData.FDMSComponent = event.data.FDMSComponent;
        this.LimsComponentData.Precision = event.data.Precision;
        this.LimsComponentData.AnalysisTypeName = event.data.AnalysisTypeName;
        this.propertyType = event.data.ComponentType;
        this.LimsComponentData.ComponentType = event.data.ComponentType;
        //if (event.data.ComponentType == "Physical Property")
        if (event.data.ComponentType == "Property")
        {
            this.UOMGroupDisabled = true;
            this.UOMUnitNameDisabled = true;
        }
        else if (event.data.ComponentType == "Component") {
            this.UOMGroupDisabled = true;
            this.UOMUnitNameDisabled = true;
        }
        let fieldSelected = this.getFieldByGrpName(event.data.UOM);
        let unitFieldSelected = this.getFieldByName(event.data.UOM);
        this.LimsComponentData.UOMGroupName = fieldSelected.filter((m: any) => m.Key == event.data.UOM)[0].Key;
        this.LimsComponentData.UOM = fieldSelected[0].Value;
        this.LimsComponentData.UOMUnitName = event.data.UOMUnitName;//unitFieldSelected.filter((m: any) => m.Default == "Y")[0].Key;
        this.limsComponentService.getLimsComponentList(this.LimsComponentData)
            .subscribe(
            (data: any) => {
                this.LimsOpComponentList = data;
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
        this.LimsCompFlyoutList = this.LimsCompFlyoutMasterTotal.filter((m: any) => m.ComponentType.includes(event.data.ComponentType));
        this.updateUOMNameList();
    }

    getRowUOMUnitName(data: any) {
        let unitFieldSelected = this.getFieldByName(data.UOM);
        let UOMUnitName = unitFieldSelected.filter((m: any) => m.Default == "Y")[0].Value;
        //  UOMUnitName=      this.LimsComponentData.uomGroupList.filter(x => x.Key == UOMUnitName)[0].Value
        return UOMUnitName;
    }

    updateSelection(event: any) {
        debugger;
        this.updateLimsCompSelection(event);
        this.LimsCompFlyoutList = this.LimsCompFlyoutMasterTotal.filter((m: any) => m.ComponentType.includes(this.selComponentType));
    }
    updateLimsCompSelection(event: any)
    {
        debugger;
        this.LimsOpFlyoutMaster = this.LimsOpList;
        this.LimsCompFlyoutMaster = this.LimsCompFlyoutList;
        //if (event.AnalysisTypeName == "Sim Dist") {
        if ((event.AnalysisTypeName == "Feed Sim Dist") || (event.AnalysisTypeName == "Product Sim Dist"))
        {
            this.selComponentType = "Simulated Distillation";
        }
        //else if (event.AnalysisTypeName == "Property")
        else if ((event.AnalysisTypeName == "Feed Physical Property") || (event.AnalysisTypeName == "Product Physical Property")
            || (event.AnalysisTypeName == "Catalyst Physical Property"))
        {
            this.selComponentType = "Property";
        }
        //else if (event.AnalysisTypeName == "GC & DHA")
        else if ((event.AnalysisTypeName == "Feed GC") || (event.AnalysisTypeName == "Offline GC"))
        {
            this.selComponentType = "Component";
        }
        if (this.LimsOpFlyoutMaster.selectedRow != undefined)
        {
            this.LimsComponentData.LIMSOperationName = this.LimsOpFlyoutMaster.selectedRow.LIMSOperationName;
            let fieldSelected = this.uomGroupListRes.filter((m: any) => m.Value == this.LimsOpFlyoutMaster.selectedRow.UOM);

            let unitFieldSelected = this.getFieldByName(fieldSelected[0].Key);
            this.LimsComponentData.UOMGroupName = fieldSelected[0].Key;
            this.LimsComponentData.UOM = fieldSelected[0].Value;
            this.LimsComponentData.UOMUnitName = unitFieldSelected.filter((m: any) => m.Default == "Y")[0].Key;

            this.LimsComponentData.AnalysisTypeName = this.LimsOpFlyoutMaster.selectedRow.AnalysisTypeName; //Aded by Jithender for passing on Analysis type Name to SP
        }
        if (this.LimsCompFlyoutMaster.selectedRow != undefined)
        {
            this.LimsOpFlyoutMaster.selectedRow = undefined;
            //  this.LimsComponentData.FDMSComponent = this.LimsCompFlyoutMaster.selectedRow.ComponentName;
            this.LimsComponentData.FDMSComponent = event.ComponentName;           
        }
        this.updateUOMNameList();
    }
    updateUOMNameList() {
        this.LimsComponentData.currentUOMUnitList = [];
        this.LimsComponentData.currentUOMUnitList = this.LimsComponentData.uomUnitList.filter(x => x.Key == this.LimsComponentData.UOMGroupName);

    }
    onCollapse() {
        let datatable = this.el.nativeElement.querySelector('#roleGrid > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divRole > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }
    precisionChange(event: any, eventType: string) { 
        let _minPrecision = 0;
        if (event.target.value != "") {
            if (event && (+event.target.value) > 15) {
                setTimeout(() => { this.LimsComponentData.Precision = 15; }, 50);
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Maximum 15' });
            } else if ((+event.target.value) < _minPrecision) {

                setTimeout(() => { this.LimsComponentData.Precision = 0; }, 50);
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Minimum 0' });
            }
        }
    }
}

