import { Component, OnInit, ViewChild, ElementRef, Renderer } from '@angular/core';
import { UomService } from '../../../services/uom.service';
import { UomTemplate, TemplateVariable, TemplateData } from '../../../models/uomtemplate';
import { KeyValue } from '../../../models/UserModel';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { UomManageVariablesComponent } from './uom-manage-variables.component';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { HttpActionService } from '../../../services/httpaction.service';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    templateUrl: 'uom.component.html',
    providers: [UomService, messageModalUtility, AlertMessage, HttpActionService, ConfirmationService]
})

export class UomComponent implements OnInit {
    title: string;
    uomApplications: any;
    uomTemplateName: string;
    inputUom: UomTemplate;
    uomTemplates: UomTemplate[] = [];
    templateVariables: TemplateVariable[]
    totalRecords: number;
    sortField: string;
    sortOrder: number;
    IsallowedSave: boolean=false;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    setStyles: boolean;
    isCollapsed = false;
    datList: KeyValue[];
    uomSaved: string = "UOM Details Saved Successfully";
    uomDeleted: string = "UOM Deleted Successfully";
    defaultUomMsg: string = "Default UOM can not be Modified";
    dupUomMsg: string = "UOM Template Already Exists";
    IsallowedChange: boolean = true;
    @ViewChild('uomTable') dataTableComponent: any;

    constructor(private uomService: UomService, public el: ElementRef, public renderer: Renderer,
        private messageService: messageModalUtility, private modalService: NgbModal, private alertMessage: AlertMessage
        , private confirmationService: ConfirmationService) {
        this.sortField = "";
        this.sortOrder = 0;
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
        this.inputUom = new UomTemplate();
        this.datList = [];
        debugger;
    }

    ngOnInit() {
        this.getUomList();
        this.title = Constants.ManageUOMTemplate;
        this.loadDatNames();

    }

    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUompTable > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 37 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse() {
        let datatable = this.el.nativeElement.querySelector('#divUompTable > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 37 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    loadDatNames() {
        this.uomService.getApplications()
            .subscribe(
            (data: any) => {
                this.uomApplications = data;
                this.inputUom.ApplicationId = 5;
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    getUomList() {
        debugger;
        this.uomService.getUomTemplates()
            .subscribe(
            (data: any) => {
                this.uomTemplates = data;
                this.totalRecords = (this.uomTemplates != null && this.uomTemplates != Constants.Undefined) ? this.uomTemplates.length : 0;
            },
            err => { }
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    searchTemplates() { 
        this.uomService.searchUomTemplates(this.inputUom)
            .subscribe(
            (data: any) => {
                this.uomTemplates = data;
                this.totalRecords = (this.uomTemplates != null && this.uomTemplates != Constants.Undefined) ? this.uomTemplates.length : 0;
            },
            err => this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    getUomVariables(uomTemplate: UomTemplate)
    {
        debugger;

        this.uomService.getTemplateVariables(uomTemplate.TemplateID)
            .subscribe(
            (data: any) => {
                this.templateVariables = data;
                if (this.templateVariables.length > 0) {
                    //this.displayVariablesModal(uomTemplate, this.templateVariables);
                }
            },
            err => { }
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    displayVariablesModal(uomTemplate: UomTemplate, templateVariables: TemplateVariable[]): Promise<any>
    {
        debugger;
        let modalRef = this.modalService.open(UomManageVariablesComponent, { backdrop: "static", size: "lg", windowClass: "xlModal" });

        //let templateData: TemplateData = new TemplateData(uomTemplate, templateVariables);
        //modalRef.componentInstance.templateData = templateData;
        return modalRef.result;
    }

    onMakeDefault(uomTemplate: UomTemplate) { 
        this.uomService.makeDefaultUom(uomTemplate)
            .subscribe(
            (data: any) => {
                if (data == Constants.Success) {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.uomSaved });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    saveUOMTemplate() {
        if (this.isDataValid()) {
            this.uomService.saveUomTemplate(this.inputUom)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.uomSaved });
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
    }

    onDelete(uomTemplate: UomTemplate) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteUom(uomTemplate); }
        });
    }

    deleteUom(uomTemplate: UomTemplate) {

        this.uomService.deleteUomTemplate(uomTemplate)
            .subscribe(
            (data: any) => {
                if (data == Constants.Success) {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.uomDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    canbeChanged()
    {
        debugger;
        if (this.inputUom.TemplateName == "Default Template") {
            return true
        }
        else
            false;
    }
    onReset() {
        this.inputUom = new UomTemplate();
        this.inputUom.ApplicationId = 5;
        this.sortField = "";
        this.sortOrder = 0;
        this.getUomList();
        this.dataTableComponent.selection = null
        this.dataTableComponent.reset();
    }

    onRowSelect(event: any) {
        debugger;
        this.inputUom.TemplateName = event.data.TemplateName;
        this.inputUom.ApplicationId = event.data.ApplicationId;
        this.inputUom.TemplateID = event.data.TemplateID;
    }

    onRowUnselect($event: any) { }

    isDataValid() {
        if (this.inputUom == null || !this.inputUom.TemplateName || this.inputUom.TemplateName.trim() == "" || this.inputUom.ApplicationId == undefined || this.inputUom.ApplicationId <= 0) {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
        else if (this.inputUom.TemplateID == "1") {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.defaultUomMsg });
        }
        else if ((this.inputUom.TemplateID == null || this.inputUom.TemplateID == undefined) && this.uomTemplates.filter((x: any) => x.TemplateName == this.inputUom.TemplateName && x.ApplicationId == this.inputUom.ApplicationId)[0] != null) {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.dupUomMsg });
        }
        else {
            return true;
        }
    }

    // getDelPath(isDefault: string, templateId: string) {
    //     if (isDefault == 'Y' || templateId === '1' || !this.IsallowedSave) {
    //         return this.disabledDeleteIconPath;
    //     }
    //     return this.deleteIconPath;
    // }
    ngDoCheck() {
        if (Constants.UserPrivileges.length > 1) {
            for (let i in Constants.UserPrivileges) {

                if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toLowerCase() == "manage/uom" && Constants.UserPrivileges[i].PrivilegeName.toLowerCase() == "write") {
                    this.IsallowedSave = true;
                }
            }
        }
    }
}
