import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { currentRunInfoComponent } from './currentRunInfo.component';
import { doeComponent } from './doe.component';
import { basicInformationComponent } from './basicInformation.component';
import { catalystTemplateComponent } from './catalystTemplate.component';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { AlertMessage } from '../../Services/alertmessage.service';
import { doePoolComponent } from './doePool.component';
const routes: Routes = [
  {
    path: 'DOE/:studyID',
    component: doeComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'DOE/:studyID/:doeRun',
    component: doeComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'Pool',
    component: doePoolComponent
  },
  {
    path: 'DOE',
    component: doeComponent,
    resolve: {
      UOM: routeResolver
    }
  }
];


@NgModule({
  imports: [sharedModule,
    RouterModule.forChild(routes)
  ],
  providers: [AlertMessage],
  declarations: [
    currentRunInfoComponent, doeComponent, basicInformationComponent, catalystTemplateComponent, doePoolComponent   ]
}
)
export class experimentModule {

}
