﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystSizeService } from '../../../Services/CatalystServices/CatalystSize.service';
import { CatalystSizeModel, KeyValue } from '../../../models/Catalyst/CatalystSizeModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'CatalystSize.component.html',
    providers: [CatalystSizeService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystSizeComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystSize: CatalystSizeModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    catalystSizeList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    catalystSizeSaved: string = "Catalyst Size Details Saved Successfully";
    catalystSizeDeleted: string = "Catalyst Size Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private catalystSizeService: CatalystSizeService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {       
        this.catalystSize = new CatalystSizeModel();
        this.catalystSize.CatalystSizeID = null;
        this.catalystSize.CatalystSizeName = null;      
        this.getcatalystSizesList();
        this.title = Constants.ManageCatalystSize;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystSize.CatalystSizeID = event.data.CatalystSizeID;
        this.catalystSize.CatalystSizeName = event.data.CatalystSizeName;         
        this.catalystSize.StatusName = event.data.StatusCode.Key;
    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getcatalystSizesList()
    {       
        this.catalystSizeService.getCatalystSizeInformation(this.catalystSize)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystSizeList = data.LstcatalystSizes;              
                this.Statuses = data.lstStatus;            
                this.totalRecords = data.RecordsFetched;              
                if (this.catalystSize.StatusName == undefined || this.catalystSize.StatusName == null)
                { this.catalystSize.StatusName = Constants.Select; }               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystSize()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.catalystSizeService.saveCatalystSizeInformation(this.catalystSize)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystSizeSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(catalystSize: CatalystSizeModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteCatalystSizeInfo(catalystSize);}
        });
    }

    deleteCatalystSizeInfo(catalystSize: CatalystSizeModel)
    {
        debugger;     
        this.catalystSizeService.deleteCatalystSize(catalystSize)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystSizeDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }   

    onReset() {
        debugger;
        this.catalystSize = new CatalystSizeModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.catalystSize.CatalystSizeName = null;       
        this.getcatalystSizesList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.catalystSize == null || !this.catalystSize.CatalystSizeName || this.catalystSize.StatusName == "Select" )
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {       
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {                   
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000023" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
