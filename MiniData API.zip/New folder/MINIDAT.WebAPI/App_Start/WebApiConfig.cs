﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http.Headers;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MINIDAT.WebAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            //// Web API configuration and services

            //// Web API routes
            //config.MapHttpAttributeRoutes();

            //config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //     routeTemplate: "api/{controller}/{action}/{id}",
            //    defaults: new { id = RouteParameter.Optional, action = "Get" }
            //);
            //config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));

            if (config == null) throw new System.ArgumentNullException("config");
            //config.MessageHandlers.Add(new AvoidOptionHandler());
            config.MessageHandlers.Add(new SessionValidateHandler());
            

            if (ConfigurationManager.AppSettings["JsonProtectionEnabled"] == "true") config.MessageHandlers.Add(new JsonProtector());
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{id}",
                defaults: new { id = RouteParameter.Optional, action = "Get" }
            );

            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));

            var cors = new EnableCorsAttribute(origins: @"http://localhost:4200,http://localhost:60717", headers:"Origin, X-Requested-With, Content-Type, Accept, Authorization, recCnt",methods: "GET, POST, PUT, DELETE, OPTIONS");
            //var cors = new EnableCorsAttribute("*", "*", "*");
            cors.SupportsCredentials = true;
            config.EnableCors(cors);
        }
    }
}
