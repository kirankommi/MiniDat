import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-check-raw-data',
  templateUrl: './check-raw-data.component.html',
  styleUrls: ['./check-raw-data.component.css']
})
export class CheckRawDataComponent implements OnInit {
  checkRawTab:string = "logSheet";
  sub:any;
  plant:string;
  run:string;
  test:string;
  TestStartTime:string;
  TestEndTime:string;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
        this.plant = params['plant'];
        this.run = params['run'];
        this.test = params['test'];
        //this.TestStartTime = params['TestStartTime'];
        //this.TestEndTime = params['TestEndTime'];
    });
  }

  
}
