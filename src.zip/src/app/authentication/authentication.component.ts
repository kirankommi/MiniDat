import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionService } from '../Shared/session.service';
@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css']
})
export class AuthenticationComponent implements OnInit {

  url: string;
    constructor(private http: Http, private route: ActivatedRoute,
      private router: Router, private _SessionService: SessionService) {
        this.url  = environment.apiendpoints + '/Account/UserInfo';
    }

    ngOnInit() {
        this.router.navigate(['/dashboard']);
    //this.http.post( this.url, {
    //})
    //  .subscribe(
    //    response => {
    //      if ( response != null) {
    //        const userDetails = response.json();
    //        if ( userDetails.email != null) {
    //          sessionStorage.setItem('userDetails', JSON.stringify(userDetails));
    //          this.router.navigate(['/dashboard']);
    //          //this.router.navigate(['/project']);
    //        } else {
    //          this.router.navigate(['/noaccess']);
    //        }
    //      }
    //    },
    //    err => {
    //      console.log('Error occured');
    //    }
    //  );
  }

}
