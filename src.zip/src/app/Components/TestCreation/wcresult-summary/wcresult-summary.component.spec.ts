import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WCResultSummaryComponent } from './wcresult-summary.component';

describe('WCResultSummaryComponent', () => {
  let component: WCResultSummaryComponent;
  let fixture: ComponentFixture<WCResultSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WCResultSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WCResultSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
