﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	ILimsComponentRepository.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	05 june 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.Model.Manage.LimsComponent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ILimsComponentRepository
    {
        IList<GetLIMSAnalysisMethodComponentBindUOMModel> GetLIMSAnalysisMethodComponentBindUOM( string User);
        IList<LIMSAnalysisMethodComponentModel> GetLIMSAnalysisComponentData(LIMSAnalysisMethodComponentModel limsAnalysisMethodFilter, string User);
        void SaveLIMSComponent(LIMSAnalysisMethodComponentModel LIMSComponent, string User);
        void DeleteLIMSComponent(LIMSAnalysisMethodComponentModel LIMSMethod);

        //Flyout Methods
        IList<LIMSAnalysisMethodComponentModel> GetOperations(LIMSAnalysisMethodComponentModel filter);
        IList<FDMSComponent> GetComponent(FDMSComponent filter);
        bool CheckIsComponentExists(string name);
        //Flyout Method for MINIDATRunAnalyticalSchedule
        IList<LIMSAnalysisMethodComponentModel> GetLIMSOperationsList(LIMSAnalysisMethodComponentModel filter);
    }
}
