import { Component, OnInit, AfterViewInit, ViewEncapsulation, ViewChild, ViewChildren, ElementRef, QueryList } from '@angular/core';
import { columnManipulator, customColumn } from '../../Directives/columnManipulator';
import * as  DoeConstants from '../DOE/doeConstants';
import { trigger, transition, animate, style } from '@angular/animations';
import * as  Constants from '../../Shared/globalconstants';
import { minisQService } from "../../services/MinisQServices/minisq.service";
import { DataTable, SelectItem, Listbox } from 'primeng/primeng';
// import { stringify } from '@angular/compiler/src/util';
// import { element } from 'protractor';
// import { filter } from 'rxjs-compat/operator/filter';
// import { debug } from 'util';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { appService } from 'src/app/Services/app.service';
import { Router } from '@angular/router';
// import { CatalystFamily } from 'src/app/Models/Catalyst/CatalystModel';
// import { Bed } from 'src/app/models/Catalyst/CatalystLoadingModel';

@Component({
 
  selector: 'app-minisQ',
  templateUrl: 'minisQ.component.html',
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateX(-100%)' }),
        animate('200ms ease-in', style({ transform: 'translateX(0%)' }))
      ]),
      transition(':leave', [
        //animate('200ms ease-in', style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ],
  styleUrls: ['minisQ.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [minisQService]
})
export class MinisQComponent implements OnInit, AfterViewInit {
  @ViewChild('statusFiltersMinis') statusFiltersMinisRef: Listbox;
  ngAfterViewInit(): void {
    this.collapseHeaders('General Information', 'generalCollapseCtrl');
    this.collapseHeaders('Catalyst Info', 'catalystCollapseCtrl');
    this.collapseHeaders('Model Info', 'modeCollapseCtrl');
    this.collapseHeaders('Feed Info', 'feedCollapseCtrl');
  }
  state?: { [k: string]: any; }
  columns: customColumn[] = DoeConstants.minisQcolumns;
  innerHeight: number = 0;
  // innerWidth: number = 0;
  parent: string = "";
  tempColumns: customColumn[] = [];
  manipulator: columnManipulator;
  tableProps: any;
  generalCollapseCtrl: boolean = true;
  catalystCollapseCtrl: boolean = true;
  modeCollapseCtrl: boolean = true;
  feedCollapseCtrl: boolean = true;
  constants: any = {};
  runs: any[] = [];
  selectedRun: any;
  routerLinkVariable = "../../Run/RunSetup/"; 
  showEditDoe: boolean = false;
  // goToDoe: boolean = false;
  masterRuns: any[] = [];
  selectedStatusFilter: any;
  selectedRuns: any[] = [];
  runsForReorder: SelectItem[];
  userId: string;
  masterData: { Projects: any, StudyNames: any, PlantRuns: any, Plants: any, ColumnPref: any } = { Projects: [], StudyNames: [], PlantRuns: [], Plants: [], ColumnPref: [] };
  reOrder: boolean = false;
  filters: { ProjectName: any, StudyName: any, RunNum: any, Plant: any, Status: any, CatalystDesignation: any, CatalystFamily: any, CatalystLeader: any, Feed: any, Requestor: any } =
    { ProjectName: [], StudyName: [], RunNum: [], Plant: [], Status: [], CatalystDesignation: [], CatalystFamily: [], CatalystLeader: [], Feed: [], Requestor: [] };
  previousVal: any;
  currentVal: any;
  constructor(public service: minisQService, private router: Router, private alertMessage: AlertMessage, public appservice: appService) {
    this.setInnerWidthHeightParameters();
    this.constants = Constants;
    this.manipulator = new columnManipulator(this.columns);
    this.tableProps = this.manipulator.updateProperties(true);
  }
  getMasterData() {
    this.service.getMasterData().subscribe((data: any) => {
      this.masterData = data;
    
      if (null != this.masterData.ColumnPref) {
        this.tempColumns = JSON.parse(this.masterData.ColumnPref);
        this.columns.forEach((q) => this.updateModel(q, false));

      }
      this.manipulator = new columnManipulator(this.columns);
      this.tableProps = this.manipulator.updateProperties(true);
    });
  }
  updateModel(column: customColumn, isChild: boolean) {
    if (isChild) {
      this.columns.find(x => x.name == this.parent).childrens.find(y => y.name == column.name).isVisible =
        this.tempColumns.find(x => x.name == this.parent).childrens.find(y => y.name == column.name).isVisible;
    } else {
      this.parent = column.name;
    }
    if (column.childrens) {
      column.childrens.forEach((q) => this.updateModel(q, true));
    }
  }
  ngOnInit() {
    this.getMasterData();

    this.appservice.getSessionData().subscribe(q => {
      this.userId = q.User.EID;
    });
    this.getStudies(true);
    this.selectedStatusFilter = [{ Key: "2", Value: "In Progress", Default: null, Groupcd: 0 }, { Key: "3", Value: "Queued", Default: null, Groupcd: 0 }]
  }
  getStudies(isInitial: boolean) {
    this.service.getStudiesData().subscribe((data: any) => {
      this.runs = this.masterRuns = data.Runs;
      if (!isInitial) {
        this.runs = this.filterRuns(this.masterRuns, this.filters, false);
        this.runs.sort((a, b) => (a.RunNum > b.RunNum) ? 1 : -1);

      }
      else {
        this.selectedStatusFilter.forEach(element => {
          this.filters.Status.push(element.Value);
        });
        this.runs = this.filterRuns(this.masterRuns, this.filters, false);
        this.sortRuns();
      }
    });
  }
  sortRuns() {
    this.runs.sort((a, b) => (parseInt(a.Plant) > parseInt(b.Plant)) ? 1 : -1);
    this.runs.sort((a, b) => (parseInt(a.RunNum) > parseInt(b.RunNum)) ? 1 : -1);
    this.runs.sort((a, b) => (parseInt(a.Plant) < parseInt(b.Plant)) ? -1 : (parseInt(a.Plant) < parseInt(b.Plant)) ? ((parseInt(a.RunNum) < parseInt(b.RunNum)) ? -1 : 1) : 1);
  }
  onRowSelect(event) {
    debugger;
    this.selectedRun = event.data;
    // this.goToDoe = true;
    this.showEditDoe = event.data.Status == 'Queued' ? true : false;
  }
  onRowUnselect(event) {
    this.selectedRun = null;
    this.showEditDoe = false;
    // this.goToDoe = false;
  }
  goToDOE(event) {
    // if (event.target.innerText == "GO TO DOE") {
    //   if (null != this.selectedRun) {
    //     this.router.navigateByUrl('/Experiment/DOE/' + this.selectedRun.StudyId);
    //   }
    // } else {
      if (null != this.selectedRun) {
        this.router.navigateByUrl('/Experiment/DOE/' + this.selectedRun.StudyId + '/' + this.selectedRun.DOERun);
      }
    // }

  }
  onRowReorder(event, dt: DataTable) {
    if (!this.reOrder) {
      this.sortRuns();
      this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'Warning', detail: "Please filter by a specific Plant # to order/reorder the Run #" });

      return false;
    }
    let nextRuns: boolean;
    if (event.dropIndex < event.dragIndex) {
      nextRuns = this.checkStatusOfRuns(event.dropIndex + 1, dt);

    } else {
      nextRuns = this.checkStatusOfRuns(event.dropIndex, dt);

    }

    if (!nextRuns) {
      if (event.dropIndex == event.dragIndex || event.dropIndex == event.dragIndex + 1) {
        this.runs.sort((a, b) => (a.RunNum > b.RunNum) ? 1 : -1)
      } else {
        if (event.dropIndex < event.dragIndex && (dt.value[event.dropIndex].Status == "In Progress" || dt.value[event.dropIndex].Status == "Completed")) {
          this.runs.sort((a, b) => (a.RunNum > b.RunNum) ? 1 : -1)

          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Error', detail: "Can't reorder In Progress/Completed runs" });

        } else if (event.dropIndex > event.dragIndex &&
          (dt.value[event.dropIndex - 1].Status == "In Progress" || dt.value[event.dropIndex - 1].Status == "Completed")) {
          this.runs.sort((a, b) => (a.RunNum > b.RunNum) ? 1 : -1)

          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Error', detail: "Can't reorder In Progress/Completed runs" });

        }
        else {
          // debugger;


          this.service.reOrderPlantRuns({
            Runs: this.runs, DropIndex: event.dropIndex, DragIndex: event.dragIndex,
            Plant: this.filters.Plant[0], UserId: this.userId, IsDragged: true
          }).subscribe((data: any) => {

            if (data) {
              this.getStudies(false);

              this.alertMessage.displayMessage({ severity: Constants.severityInfo, summary: 'Success', detail: "successfully reordered runs" });
            }
          });

        }
      }
    }
    else {
      this.runs.sort((a, b) => (a.RunNum > b.RunNum) ? 1 : -1)

      this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'Warning', detail: "Next runs status is In Progress/Completed" });

    }
  }

  checkStatusOfRuns(dropIndex: number, dt: DataTable): boolean {
    let isInProgress: boolean = false;
    for (let index = dropIndex; index < dt.value.length; index++) {

      if (dt.value[index].Status == "In Progress" || dt.value[index].Status == "Completed") {
        isInProgress = true;
        break;
      }
      else {
        isInProgress = false;
      }
    }
    return isInProgress;

  }

  collapseHeaders(headerName: string, visibleCtrl: string) {
    this.columns.find((q) => q.name == headerName).childrens.filter((e) => !e.isStatic).forEach((w) => w.isVisible = !this[visibleCtrl]);
    this[visibleCtrl] = !this[visibleCtrl];
    this.updateTableProperties();
  }

  onChange(currentFilters: any, column: string) {
    switch (column) {
      case 'Projects':
        this.filters.ProjectName = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.ProjectName.push(element.Value);
          });
        }
        break;
      case 'StudyNames':
        this.filters.StudyName = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.StudyName.push(element.Value);
          });
        }
        break;
      case 'Plant':
        this.filters.Plant = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.Plant.push(element.Value);
          });
        }
        break;
      case 'PlantRuns':
        this.filters.RunNum = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.RunNum.push(element.Value);
          });
        }
        break;
      case 'Status':
        this.filters.Status = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.Status.push(element.Value);
          });
        }
        break;
      case 'CatalystDesignation':
        this.filters.CatalystDesignation = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.CatalystDesignation.push(element.Value);
          });
        }
        break;
      case 'CatalystFamily':
        this.filters.CatalystFamily = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.CatalystFamily.push(element.Value);
          });
        }
        break;
      case 'CatalystLeader':
        this.filters.CatalystLeader = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.CatalystLeader.push(element.Value);
          });
        }
        break;
      case 'Feed':
        this.filters.Feed = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.Feed.push(element.Value);
          });
        }
        break;
      case 'Requestor':
        this.filters.Requestor = [];
        if (null != currentFilters && currentFilters.value.length > 0) {
          currentFilters.value.forEach(element => {
            this.filters.Requestor.push(element.Value);
          });
        }
        break;
      default:
        break;
        
    }
 

    this.runs = this.filterRuns(this.masterRuns, this.filters, false);

    if (this.filters.Plant.length == 1) {
      this.reOrder = true;

      let test: any = this.columns["ReOrder"];
      this.updateTableProperties();
      this.runs.sort((a, b) => (parseInt(a.RunNum) > parseInt(b.RunNum)) ? 1 : -1);
      let tempRuns: any[] = Array.from(new Set(this.runs.filter((item: any) => item.Status === "Queued").map((item: any) => item.RunNum)));
      this.runsForReorder = [];
      tempRuns.forEach(element => {
        this.runsForReorder.push({ label: element, value: element });
      });
      this.runsForReorder.sort((a, b) => (a.value > b.value) ? 1 : -1);
    }
    else {
      this.sortRuns();
      this.updateTableProperties();
      this.reOrder = false;
    }
  }


  filterRuns(array, filters, isChild) {

    const getValue = value => (typeof value === 'string' ? value.toUpperCase() : value);
    const filterKeys = Object.keys(filters);
    return array.filter(item => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores an empty filter
        if (!filters[key].length) { return true };
        if (key.toLowerCase().includes("catalyst")) {
          if (item.CatalystTemplate.Beds.length != 0) {
            return item.CatalystTemplate.Beds.some(bed => {
              switch (key) {
                case "CatalystDesignation":
                  return filters[key].includes(bed.Catalyst.CatalystDesignation);
                case "CatalystFamily":
                  return filters[key].includes(bed.Catalyst.CatalystFamilyName);
                case "CatalystLeader":
                  return filters[key].includes(bed.Catalyst.CatalystLeaderName);
                default:
                  break;
              }
            });
          }
        } else
          if (key.toLowerCase().search("feed") != -1) {
            return filters[key].includes(item[key].Name);
          } else {
            return filters[key].some(filter => getValue(filter) == getValue(item[key]));
          }
      });
    });



  }

  updateTableProperties() {
    this.tableProps = this.manipulator.updateProperties(true);
  }

  showOverlay($event, plantFilter, sender) {
    const tableLeft = sender.el.nativeElement.getBoundingClientRect().left;
    const viewportOffset = $event.currentTarget.getBoundingClientRect();
    const left = viewportOffset.left;
    const top = viewportOffset.top;

    if ($event.currentTarget.innerText.indexOf("Status filter") !== -1) {
      plantFilter.style["position"] = "absolute";
      plantFilter.style["left"] = (left - tableLeft) + 40 + 'px';
      plantFilter.style["top"] = top - 90 + 'px';
      plantFilter.toggle($event, plantFilter);
    } else {
      plantFilter.style["position"] = "absolute";
      plantFilter.style["left"] = (left - tableLeft) + 40 + 'px';
      plantFilter.style["top"] = top + 40 + 'px';
      plantFilter.toggle($event, plantFilter);
    }

  }
  setInnerWidthHeightParameters() {
    // this.innerWidth = window.innerWidth;
    this.innerHeight = window.innerHeight * 0.61;
  }
  // mouseEnter($event, dropDown, sender, rowIndex)
  // {
  //   dropDown.show(dropDown.el.nativeElement);
  //   const tableLeft = sender.el.nativeElement.getBoundingClientRect().left;
  //   const viewportOffset = $event.clientX;
  //   dropDown.overlay.style["position"] = "absolute";
  //   dropDown.overlay.style["left"] = (viewportOffset - tableLeft) + 20 + 'px';
  //   dropDown.hide(dropDown.el.nativeElement);
  // }
  showRunValues($event, rowIndex: number) {
    debugger;
    this.currentVal = this.runs[rowIndex].RunNum;

  }
  showDDOverlay($event, dropDown, sender) {
    dropDown.show(dropDown.el.nativeElement);
    const tableLeft = sender.el.nativeElement.getBoundingClientRect().left;
    const viewportOffset = $event.element.offsetLeft;
    dropDown.overlay.style["position"] = "absolute";
    dropDown.overlay.style["left"] = (viewportOffset - tableLeft) + 20 + 'px';
    dropDown.overlay.toggleAttribute($event, dropDown.overlay);
    $event.stopPropagation();
  }
  onSelectType(event, dragIndex: number) {
    debugger;
    if (event) {
      this.previousVal = this.currentVal;
      this.currentVal = Number(event);
    }
    let dropIndex: any = Object.keys(this.runs).find(key => this.runs[key].Plant === this.filters.Plant[0] && this.runs[key].RunNum === this.currentVal);
    if (dragIndex != dropIndex) {


      this.runs[dropIndex].RunNum = this.previousVal;
      this.runs[dragIndex].RunNum = this.currentVal;
      this.service.reOrderPlantRuns({
        Runs: this.runs, DropIndex: dropIndex, DragIndex: dragIndex,
        Plant: this.filters.Plant[0], UserId: this.userId, IsDragged: false
      }).subscribe((data: any) => {

        if (data) {
          this.getStudies(false);
          this.alertMessage.displayMessage({ severity: Constants.severityInfo, summary: 'Success', detail: "successfully changed the order" });
        }
      });
    }
  }
  saveColumnsPref(event, columnsDialog: any) {
    debugger;
    this.onSaveColumnPref();
    columnsDialog.visible = false;
  }
  onSaveColumnPref() {
    this.service.saveColumnPreferences({ ColumnPreferences: JSON.stringify(this.columns), UserId: null, ModuleName: 'MINISQ' }).subscribe((data: any) => {
      this.alertMessage.displayMessage({ severity: Constants.severityInfo, summary: 'Success', detail: data });

    });
  }
  // navigateToRun(run: any) {
  //   debugger;
  //   this.metadata = new RunMetaData();
  //   this.metadata.Plant = run.Plant;
  //   this.metadata.RunId = run.RUN_ID;
  //   this.metadata.RunNum = run.RunNum;
  //   this.metadata.StartDate = run.StartDate;
  //   this.metadata.ZeroHOSTime = run.EndDate;
  //   this.metadata.EndTime = run.EndDate;
  //   this.metadata.RunStatus = run.Status;

  //   this.metadata.ModeType = run.Mode.ModeType;
  //   this.metadata.NetworkNumber = run.NetworkNUM;

  //   this.metadata.FeedId = run.Feed.ID;
  //   this.metadata.FeedDensityAtISCOTemp = run.Feed.DensityMsr;
  //   this.metadata.FeedCondition = run.Feed.HasDopant;
  //   this.metadata.FeedId = run.Feed.ID;

  //   // this.metadata.Technician1 = run.Requestor;
  //   // this.metadata.Technician2 = run.Requestor;
  //   this.metadata.ProjectMgr = run.Requestor;


  //   const runInformation: NavigationExtras = {
  //     // preserveFragment: true,
  //     // skipLocationChange: true,
  //     replaceUrl: true,
  //     queryParams: {
  //       runInfo: JSON.stringify(this.metadata)
  //     }
  //   };
  //   this.router.navigate(['/Run/RunSetup'], runInformation);
  // }
}
