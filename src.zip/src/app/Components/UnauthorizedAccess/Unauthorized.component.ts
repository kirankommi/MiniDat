import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import * as Constants from '../../Shared/globalconstants';
import { appService } from '../../Services/app.service';
import { UserModel } from '../../Models/UserModel';
import { AlertMessage } from '../../services/alertmessage.service';
import { UnauthorizedAccessService } from '../../Services/Unauthorized.service';

@Component({
    templateUrl: 'Unauthorized.component.html',
    providers: [AlertMessage, UnauthorizedAccessService]
})
export class UnauthorizedAccessComponent implements OnInit {

    UserRequested = new UserModel();
    IsAccountRequested: boolean = false;

  constructor(private router: Router, private appService: appService, private alertMessage: AlertMessage, private unauthorizedAccessService: UnauthorizedAccessService) { }

    ngOnInit() {
        this.appService.getSessionData()
            .subscribe((data: any) => {
                if (data != null) {
                    if (data.User != null && data.User != undefined) {
                        this.router.navigateByUrl('/dashboard');
                        return;
                    }
                }
            });
    }

    RequestApplicationAccess() {
        let emailRegexPattern = /^\S+@(([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6})$/;
        if (!this.UserRequested.EID || this.UserRequested.EID == "" || !this.UserRequested.FirstName || this.UserRequested.FirstName == "" ||
            !this.UserRequested.LastName || this.UserRequested.LastName == "" || !this.UserRequested.EmailId || this.UserRequested.EmailId == "") {
            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Invalid Input', detail: "All fields are mandatory !" })
            return false;
        }
        if (!emailRegexPattern.test(this.UserRequested.EmailId))
        {
            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Invalid EmailId', detail: "Emaild pattern is not recognized !" })
            return false;
        }

        this.UserRequested.EID = this.UserRequested.EID.toUpperCase();
        this.UserRequested.FirstName = this.UserRequested.FirstName.toUpperCase();
        this.UserRequested.LastName = this.UserRequested.LastName.toUpperCase();
        this.UserRequested.EmailId = this.UserRequested.EmailId.toLowerCase();

        //console.log(this.UserRequested);

        this.unauthorizedAccessService.SendNewUserNotificationToAdmins(this.UserRequested)
            .subscribe((data) => {
                this.IsAccountRequested = true;
                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Request sent successfully', detail: "Please wait till your MINIDAT account is setup" });
            },
            (err: any) => {
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Something went wrong !', detail: "Could not notify admin !" });
            });
    }
}
