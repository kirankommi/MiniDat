﻿/*
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 */
using System.Collections.Generic;

namespace MINIDAT.Model.Manage
{
    public class MenuAssignment
      {

        public string ParentID { get; set; }
        public string Header { get; set; }
        public string ID { get; set; }        
        public string Index { get; set; } 
       // public IList<MenuAssignment> Items { get; set; }
        private IList<MenuAssignment> _items = new List<MenuAssignment>();
        public IList<MenuAssignment> Items { get { return _items; } }
        public bool ReadOnly { get; set; }       
        public bool CanWrite { get; set; }

        public bool IsChecked { get; set; }

    }
}
