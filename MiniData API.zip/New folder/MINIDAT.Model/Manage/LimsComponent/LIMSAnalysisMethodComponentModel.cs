﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Manage.LimsComponent
{
    public class LIMSAnalysisMethodComponentModel
    {

        public string LIMSOperationName { get; set; }
        public string LIMSComponent { get; set; }
        public string FDMSComponent { get; set; }
        public string UOM { get; set; }
        public string UOMUnitName { get; set; }
        //lookup
        public string AnalysisTypeName { get; set; }
        public string ComponentType { get; set; }

        // public List<UOMList> UOMlist { get; set; }
        private IList<KeyValue> _uomlist = new List<KeyValue>();
        public IList<KeyValue> UOMlist { get { return _uomlist; } }
        //Pagination attributes
        public int TotalRecords { get; set; }
        public int CurrentPage { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
       // public List<KeyValue> UOMGroupList { get; set; }
        private IList<KeyValue> _uomGroupList = new List<KeyValue>();
        public IList<KeyValue> UOMGroupList { get { return _uomGroupList; } }      
        public int Precision { get; set; }
        public int LIMSOperationID { get; set; }
        public string AnalysisMethodName { get; set; }
        public string AnalysisMethodNumber { get; set; }
    }
    public class FDMSComponent
    {
        public string ComponentType { get; set; }
        public string ComponentLabel { get; set; }
        public int TotalRecords { get; set; }
        public int CurrentPage { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }
    public class LIMSAnalysisComponentSearchModel
    {
        public LIMSAnalysisMethodComponentModel LIMSAnalysisComponentFilter { get; set; }
        //  public List<LIMSAnalysisMethodComponentModel> LIMSAnalysisComponentList { get; set; }
        private IList<LIMSAnalysisMethodComponentModel> _limsAnalysisComponentList = new List<LIMSAnalysisMethodComponentModel>();
        public IList<LIMSAnalysisMethodComponentModel> LIMSAnalysisComponentList { get { return _limsAnalysisComponentList; } }

        public int RecordsFetched { get; set; }
    }
    public class UOMList
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string Default { get; set; }
    }
    public class GetLIMSAnalysisMethodComponentBindUOMModel {
        public string LIMSOperationName { get; set; }
        public string ComponentStandardName { get; set; }
        public string ComponentLIMSName { get; set; }

        public string UOMGroup { get; set; }
        public string Unit { get; set; }
        public int Precision { get; set; }
    }
}

