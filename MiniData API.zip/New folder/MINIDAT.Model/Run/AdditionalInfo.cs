﻿using MINIDAT.Model.Catalyst;
using System.Collections.Generic;
using System.Linq;

namespace MINIDAT.Model.Run
{
    public class AdditionalInfoModel
    {       
        public double? OffgasHeaviesWeight { get; set; }
        public string SelectedNormalizationFactor { get; set; }
        public string SelectedFeedSource { get; set; }
        public double? H2TMFSpec { get; set; }
        public double? PlantTCOffset { get; set; }
        public double? HPSControllerOffset { get; set; }        
    }

   
}
