﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, AdditionalInfoModel } from '../../../models/Run/RunModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { FlyoutExistsDataModel } from '../../../models/FlyoutExistsDataModel';
import { KeyValue } from '../../../Models/KeyValue';
import { RunDataService } from "../run.data.service";
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
    templateUrl: 'AdditionalInfo.component.html',
    selector: "additionalInfo",
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})

export class AdditionalInfoComponent implements OnInit {
    @Input()
    propertyType: string;
    setStyles: boolean;
    run: RunSetupModel;
    @Input()
    // run1: RunModel;
    @ViewChild('roleTable') dataTableComponent: any;
    IsallowedSave: boolean = true;
    LocalAccess: boolean = false;
    check: boolean = false;
    sortField: string;
    sortOrder: number;
    runSaved: string = "Run Additional Information Saved Successfully";
    plantsHITC: string[] = ["2005", "2006"];
    plantsUS: string[] = ["321", "322", "323", "324", "325", "326"];

    constructor(private runService: RunService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage,
        private confirmationService: ConfirmationService, public runDataService: RunDataService, private runComponent: RunComponent) {

    }

    ngOnInit() {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel)
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "9", Value: "Additional Info", Groupcd: 0 })
    }
  
    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }
    getRunAdditionalInformation(PlantCd: string, RunId: string) {
        debugger;
        this.runService.GetAdditionalInformation(PlantCd, RunId)
            .subscribe(
                (data: any) => {
                    debugger;
                    if ((data.SelectedFeedSource == null || data.SelectedFeedSource == Constants.Undefined)) {
                        this.run.AdditionalInfo.SelectedNormalizationFactor = "GC P64"; //Default for All Plants
                        this.run.AdditionalInfo.OffgasHeaviesWeight = 0.01; //Default Value in Kg for All Plants

                        if (this.plantsUS.includes(PlantCd.toString())) {
                            this.run.AdditionalInfo.SelectedFeedSource = "AVG";   //RVSD Plants default                    
                        }
                        else {
                            this.run.AdditionalInfo.SelectedFeedSource = "IPP";   //ITC Plants default
                        }
                        this.run.AdditionalInfo.H2TMFSpec = data.H2TMFSpec;
                        this.run.AdditionalInfo.PlantTCOffset = data.PlantTCOffset;
                        this.run.AdditionalInfo.HPSControllerOffset = data.HPSControllerOffset
                    }
                    else {
                        this.run.AdditionalInfo = data;
                    }
                },
                err => { }
            );
    }

  
    isDataValid() {
        debugger;
        if (this.run.MetaData.RunNum == null || this.run.AdditionalInfo.SelectedFeedSource == 'AAA' || this.run.AdditionalInfo.SelectedNormalizationFactor == 'DEFAULT'
            || (this.run.AdditionalInfo.HPSControllerOffset == null || this.run.AdditionalInfo.HPSControllerOffset == undefined)
            || (this.run.AdditionalInfo.PlantTCOffset == null || this.run.AdditionalInfo.PlantTCOffset == undefined)
            || (this.run.AdditionalInfo.OffgasHeaviesWeight == null || this.run.AdditionalInfo.OffgasHeaviesWeight == undefined)
            || (this.run.AdditionalInfo.H2TMFSpec == null || this.run.AdditionalInfo.H2TMFSpec == undefined)) {
            return false;
        }
        return true;
    }

    onReset() {
        debugger;
        this.getRunAdditionalInformation(this.run.MetaData.Plant, this.run.MetaData.RunId);
        this.runDataService.changeMessage(this.run);      
    }

    ngDoCheck() {
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000067" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }

    }

}
