﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleRepository.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Manage;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class RoleRepository : IRoleRepository
    {
        private IDatabase _db;
        public RoleRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="N", Value="Inactive"},
                    new KeyValue() {Key="Y", Value="Active"},
                };


        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Role"></param>
        /// <returns></returns>
        public RoleSearchModel GetRoleData(RoleModel Role)
        {
            try
            {
                RoleSearchModel rolearr = new RoleSearchModel();
                if (Role == null)
                {
                    return rolearr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("Search_Role_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Role_Cd", Role.RoleCode);
                    parameters.Add("proc_vr_Role_Nm", Role.RoleName);
                    parameters.Add("proc_vr_Role_Desc", Role.RoleDescription);
                    parameters.Add("proc_vr_Active_Ind", Role.StatusName == "Select" ? null : Role.StatusName);
                    parameters.Add("proc_bl_Master_Data_Ind", 0);
                    parameters.Add("proc_in_Page_Size_Num", Role.RecordsPerPage);
                    parameters.Add("proc_in_Current_Page_Num", Role.CurrentPage);
                    parameters.Add("proc_vr_Sort_Column_Nm", Role.SortColumn);
                    parameters.Add("proc_vr_Sort_Order_Nm", Role.SortOrder);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    rolearr.Roles.Clear();
                    while (reader.Read())
                    {
                        RoleModel newRole = new RoleModel()
                        {
                            RoleCode = reader["ROLE_CD"].ToString(),
                            RoleName = reader["ROLE_NM"].ToString(),
                            RoleDescription = reader["ROLE_DESC"].ToString(),
                            StatusCode = new KeyValue() { Key = reader["STATUS"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            CanDelete = reader["CAN_EDIT"].ToString()
                        };
                        rolearr.Roles.Add(newRole);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        rolearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }

                    reader.NextResult();
                    ApplicationModel appModel = new ApplicationModel();
                    // rolesearchModel.ApplicationList.Add(new ApplicationModel { ApplicationId = "3", ApplicationName = "FeedStock DAT" });
                    while (reader.Read())
                    {
                        appModel = new ApplicationModel
                        {
                            ApplicationId = Convert.ToString(reader["SRC_SYSTEM_ID"]),
                            ApplicationName = Convert.ToString(reader["SRC_SYSTEM_NM"])

                        };
                        //   roleList.Add(appModel);
                        rolearr.ApplicationList.Add(appModel);
                    }

                    rolearr.Status.Clear();
                    reader.Close();
                    ((List<KeyValue>)rolearr.Status).AddRange(statuses);
                    return rolearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Role"></param>
        /// <returns></returns>
        public string DeleteRoleData(RoleModel Role)
        {
            try
            {
                if (Role == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("Delete_Role_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Role_Cd", Role.RoleCode);
                    parameters.Add("proc_vr_src_system_id", Role.Appcode);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="Role"></param>
        /// <param name="userId"></param>

        public void SaveRoleData(RoleModel Role, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || Role == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("Insert_Role_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Role_Cd", Role.RoleCode);
                    parameters.Add("proc_vr_Role_Nm", Role.RoleName);
                    parameters.Add("proc_vr_Role_Desc", Role.RoleDescription);
                    parameters.Add("proc_vr_Active_Ind", Role.StatusCode == null ? null : Role.StatusCode.Key);
                    parameters.Add("proc_vr_Created_By_Id", Eid);
                    parameters.Add("proc_vr_src_system_id", Role.Appcode);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void Update(RoleModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(RoleModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<RoleModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(RoleModel _model)
        {
            throw new NotImplementedException();
        }

        public Dictionary<string, string> GetRoleDetailsForTechService()
        {
            Dictionary<string, string> roleValues = new Dictionary<string, string>();
            using (IDbCommand command = _db.CreateCommand("Select ARM.ROLE_CD,ARM.ROLE_NM,SS.SRC_SYSTEM_ID,SS.SRC_SYSTEM_NM,DM.DEPARTMENT_CD,DM.DEPARTMENT_NM from APPLICATION_ROLE_MSTR ARM,SRC_SYSTEM SS,DEPARTMENT_MSTR DM where ARM.ROLE_NM like '%TS Specialist%' and SS.SRC_SYSTEM_NM like '%FeedStock DAT%' and DM.DEPARTMENT_NM like 'Tech Services'", false))
            {
                IDataReader reader = null;
                reader = _db.ExecuteReader(command);
                while (reader.Read())
                {
                    roleValues.Add("ROLE_CD", reader["ROLE_CD"] != DBNull.Value ? Convert.ToString(reader["ROLE_CD"]) : string.Empty);
                    roleValues.Add("ROLE_NM", reader["ROLE_NM"] != DBNull.Value ? Convert.ToString(reader["ROLE_NM"]) : string.Empty);
                    roleValues.Add("APPLICATION_ID", reader["SRC_SYSTEM_ID"] != DBNull.Value ? Convert.ToString(reader["SRC_SYSTEM_ID"]) : string.Empty);
                    roleValues.Add("APPLICATION_NM", reader["SRC_SYSTEM_NM"] != DBNull.Value ? Convert.ToString(reader["SRC_SYSTEM_NM"]) : string.Empty);
                    roleValues.Add("DEPARTMENT_CD", reader["DEPARTMENT_CD"] != DBNull.Value ? Convert.ToString(reader["DEPARTMENT_CD"]) : string.Empty);
                    roleValues.Add("DEPARTMENT_NM", reader["DEPARTMENT_NM"] != DBNull.Value ? Convert.ToString(reader["DEPARTMENT_NM"]) : string.Empty);
                }
                reader.Close();
            }
            return roleValues;
        }
    }
}
