import { Component, OnInit } from '@angular/core';
import { RunService } from 'src/app/Services/RunServices/Run.service';
import { RunDataService } from '../run.data.service';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { ConfirmationService } from 'primeng/api';
import { RunModel } from 'src/app/models/Run/RunModel';
import * as Constants from '../../../Shared/globalconstants';
import { debug } from 'util';
import { isNumeric } from 'rxjs/util/isNumeric';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
  selector: 'run-recipe',
  templateUrl: './run-recipe.component.html',
  styleUrls: ['./run-recipe.component.css']
})
export class RunRecipeComponent implements OnInit {
  // run1: RunModel;
  run: RunSetupModel;
  recMasterData: any;
  cols: any = [];
  colsMaster: any = [];
  toolTip: string;
  runMode: any;
  recCols = [];
  runId: string;
  isRecAvailable: boolean = false;
  innerHeight: number = 0;
  constants: any = {};
  weightCheck: number = 2;
  weightChecksData: any;
  lineoutColumn = "Lineout";
  previousRowData: any;
  tempLO = "Temperature Lineout";
  weightCheckColumn = 'weight';
  lineout = "lineout";
  constructor(private runService: RunService, public runDataService: RunDataService, private alertMessage: AlertMessage, private runComponent: RunComponent) {
    this.constants = Constants;
  }

  ngOnInit() {
    debugger;
    this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);
    if (this.run.Recipe != null) {
      this.isRecAvailable = true;
      // this.weightCheck = null != this.run.RunModedata.WeightChecks ? this.run.RunModedata.WeightChecks : 2;
      // this.cols = this.run.Recipe.Cols;
      // this.recMasterData = this.run.Recipe.recMasterData;
      // this.colsMaster = this.run.Recipe.ColsMaster;
      // this.weightChecksData = this.run.Recipe.WeightChecksData;
      // this.recCols = this.run.Recipe.recCols;
      // if (this.run.RunModedata.ControlMethod == 1) {
      //   this.lineoutColumn = "NIR Lineout";
      // }
    }
    this.runComponent.exportData.selectedPopupList = [];
    this.runComponent.exportData.selectedPopupList.push({ Key: "11", Value: "Recipe", Groupcd: 0 });
  }
  ngAfterViewChecked() {
    if (this.run.Recipe != undefined) {
      let rec: any = [];
      this.run.Recipe.forEach(element => {
        let index = 0;
        let Headers: any = [];
        for (let key in element) {
          if (element.hasOwnProperty(key)) {
            if (index > 2) {
              Headers.push({ "Name": key, "Value": element[key], "ReceipeNumber": index - 2 });
            }
            index++;
          }
        }

        rec.push({ "Tag": element["Tag"], "Description": element["Description"], "Energized": element["Energized"], Headers });
      });
      this.run.RecipeInfo = rec;
    }
  }

  pushSPPRecipe() {


  }

  getToolTip(rowData: any, col: string, index: number) {
    let columnIndex = this.cols.findIndex(x => x == col);
    let inductionIndex = this.cols.findIndex(x => x == "Induction");
    switch (rowData.Description != undefined && rowData.Description.toLowerCase()) {
      case "fresh feed - lhsv":
        if (columnIndex > 3 && columnIndex <= inductionIndex) {
          this.toolTip = "LHSV = " + parseFloat(this.run.RecipeMaster[index][col] * 3600 + "").toFixed(2) + " hr-1";
        }
        else if (columnIndex > 3) {
          this.toolTip = "LHSV = " + parseFloat(this.run.RunModedata.LHSV * 3600 + "").toFixed(2) + " hr-1";
        }
        else {
          this.toolTip = "";
        }
        break;
      case "fresh h2 feed - scfb":
        if (columnIndex > 3 && columnIndex <= inductionIndex) {
          this.toolTip = "SCFB = " + parseFloat(this.run.RecipeMaster[index][col] + "").toFixed(2) + " SCFB";
        } else if (columnIndex > 3) {
          this.toolTip = "SCFB = " + this.run.RunModedata.SCFB + " SCFB";
        }
        else {
          this.toolTip = "";
        }
        break;
      case "fresh h2 feed - ghsv":
        if (columnIndex > 3) {
          this.toolTip = "GHSV = " + parseFloat(((rowData[col] * 3600) / this.run.MetaData.CatalystVolume) + "").toFixed(2) + " hr-1";
        }
        else {
          this.toolTip = "";
        }
        break;
      default:
        break;
    }
  }

  setInnerWidthHeightParameters() {
    this.innerHeight = window.innerHeight * 0.55;
  }

  increment(weightCheck: number, isClicked: boolean) {
    this.runComponent.increment(weightCheck, isClicked);
    this.run.Recipe.isSaved = false;
  }
  decrement(weightCheck: any) {
    this.runComponent.decrement(weightCheck);
    this.run.Recipe.isSaved = false;
  }
}
