﻿import { Component, Input } from '@angular/core';

@Component({
    //moduleId: module.id,
    selector: 'role-summary',
    templateUrl: 'rolesummary.component.html'    ,
    styleUrls: ['rolesummary.component.css'],
})
export class RoleSummary {
    @Input() treeData: any[];
    @Input() treeParent: any[];
    @Input() treeCompleteData: any[];
    @Input() level: number = 0;
    constructor() {
    }    
}