﻿export class ModeModel {
    ModeID: number;
    ModeNumber: string;
    Description: string;
    ModeType: string;
    ControlName: string;
    SulfidingType: string;
    Pressure: number;
    LHSV: number;
    SCFB: number;
    Conditions: number;
    CanEdit: string;   
    //ModeType: KeyValue;
    //ControlName: KeyValue;
    //SulfidingType: KeyValue;
    AppCode: string;
}

export class KeyValue {
    Key: string;
    Value: string;
}

export class ApplicationModel {
    ApplicationName: string;   
    ApplicationId: number;   
    IsChecked: boolean;
    IsallowedCheck: boolean;
}