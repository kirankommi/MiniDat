﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystLoadingRepository : ICRUDRepository<CatalytLoadingModel>
    {
        CatalytLoadingSearchModel GetLoadingTemplateData(CatalytLoadingModel loadingTemplate);
        string DeleteLoadingTemplateDataData(CatalytLoadingModel loadingTemplate);
        void SaveLoadingTemplateData(CatalytLoadingModel _loadingTemplate, string userId);
        List<Bed> GetReactorBedDetails(string templateID);

    }
}
