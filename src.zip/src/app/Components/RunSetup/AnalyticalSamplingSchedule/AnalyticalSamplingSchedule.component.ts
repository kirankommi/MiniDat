import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, AnalyticalInfoModel,ExportPopupSummary } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import { KeyValue } from '../../../Models/KeyValue';
import * as Constants from '../../../Shared/globalconstants';
import { LIMSComponentService } from '../../../services/limscomponent.service';
import { LimsComponentModel, LimsOpFlyoutModel, LimsComponentFlyoutModel } from '../../../models/LimsComponentModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';


@Component({
    selector: 'sampleSchedule',
    templateUrl: './AnalyticalSamplingSchedule.component.html',
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService, LIMSComponentService]
})
export class AnalyticalSamplingComponent implements OnInit {
    // run1: RunModel;
    run: RunSetupModel;
    streamCols: KeyValue[];
    constants: any = {};
    addIconPath = Constants.addIcon;
    deleteIconPathEn = Constants.deleteIconEn;
    LimsOpList: LimsComponentModel[];
     limsOperationCols: any[] = [];
    LimsComponentData: LimsComponentModel;
    count: number = 0;
    runSaved: string = "Run - Analytical Schedule Information Saved Successfully";
   
    constructor(private nirService: RunService, public runDataService: RunDataService,
        private limsComponentService: LIMSComponentService, private messageService: messageModalUtility, 
        private alertMessage: AlertMessage, private runComponent: RunComponent) {
        this.constants = Constants;
    }
    ngOnInit() {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);

        // if (this.run.lstAnalyticalSamples == null || this.run.lstAnalyticalSamples == undefined || this.run.lstAnalyticalSamples.length == 0) {
        //     this.run.lstAnalyticalSamples = null;
        //     this.getAnalyticalSamplesInformation(this.run.Plant, this.run.RunId);
        // }

        // this.getLimsCostVolume();
        this.fillFlyoutColumns();
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "5", Value: "Analytical Sampling Schedule", Groupcd: 0 })
        this.resetRowId();
    }

    getLimsCostVolume() {
        let limsOperations: any[] = [];

        if (this.run.lstAnalyticalSamples != null && this.run.lstAnalyticalSamples != undefined) {
            this.run.lstAnalyticalSamples.forEach(element => {
                limsOperations.push({ "Value": element.LIMSOPerationName });
            });
        }
        if (limsOperations.length > 0) {
            this.nirService.GetLIMSInfo(limsOperations).subscribe((limsData: any) => {
                debugger;

                this.run.lstAnalyticalSamples.forEach(element => {
                    element.SampleCost = limsData.find(x => (x.LimsOperationName == element.LIMSOPerationName)).Cost;
                    element.SampleVolumeinCC = limsData.find(x => (x.LimsOperationName == element.LIMSOPerationName)).Volume;

                });
                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Cost & Volume updated successfully' });
            },
                err => { this.alertMessage.displayMessage({ severity: Constants.Error, summary: 'Failed to update Cost & Volume' }); }
            );
        }
    }
    fillFlyoutColumns() {
        this.streamCols = [];
        this.LimsComponentData = new LimsComponentModel();
        debugger;
        this.getFlyoutLIMSOperation();
    }
    getFlyoutLIMSOperation() {
        debugger;

        this.limsComponentService.getLimsOperationListForMiniDAT(this.LimsComponentData)
            .subscribe(
                (data: any) => {
                    this.LimsOpList = data.filter(x => 
                           (x.AnalysisTypeName == "Product Sim Dist") || (x.AnalysisTypeName == "Offline GC") || (x.AnalysisTypeName == "Product Physical Property") || (x.AnalysisTypeName == "Online GC")
                    );
                    
              
                    this.limsOperationCols.push({ Key: "AnalysisTypeName", Value: "Analysis Type" });
                    this.limsOperationCols.push({ Key: "LIMSOperationName", Value: "LIMS Operation" });
                },
                err => { }
            );
    }

    getAnalyticalSamplesInformation(PlantCd: string, RunId: string) {
        this.nirService.GetAnalyticalSampleInformation(PlantCd, RunId)
            .subscribe(
                (data: any) => {
                    debugger;
                    this.run.lstAnalyticalSamples = data;
                    if (this.run.lstAnalyticalSamples[0].DataSetType == 'DEFAULT') {
                        // let count = this.run.lstAnalyticalSamples.filter(x => (x.SampleCost != undefined && x.SampleVolumeinCC != undefined));
                        //     if (count.length == 0) {
                        this.getLimsCostVolume();
                        //  }
                    }

                },
                err => { }
            );
    }
    onReset() {
        this.getAnalyticalSamplesInformation(this.run.MetaData.Plant, this.run.MetaData.RunId);
        this.runDataService.changeMessage(this.run);      
    }
    updateDiluentSelection(event, index: any) {
        debugger;
        this.run.lstAnalyticalSamples[index].LIMSOPerationName = event.LIMSOperationName;
        this.run.lstAnalyticalSamples[index].LIMSOPerationId = event.LIMSOperationID;
        this.run.lstAnalyticalSamples[index].MethodNumber = event.AnalysisMethodNumber;
        let workItem: any[] = [];
        workItem.push({ "Value": this.run.lstAnalyticalSamples[index].LIMSOPerationName });

        this.nirService.GetLIMSInfo(workItem).subscribe((data: any) => {
            debugger;

            debugger;
            if (data.length > 0) {
                this.run.lstAnalyticalSamples[index].SampleCost = data[0].Cost;
                this.run.lstAnalyticalSamples[index].SampleVolumeinCC = data[0].Volume;
            }
            else {
                this.run.lstAnalyticalSamples[index].SampleCost = "";
                this.run.lstAnalyticalSamples[index].SampleVolumeinCC = "";
            }


        })
    }
    AddNewRowatbottom() {
        debugger;
        this.run.lstAnalyticalSamples.push({ RowId: this.run.lstAnalyticalSamples.length + 1, StreamId: 0, StreamName: null, LIMSOPerationId: 0, LIMSOPerationName: null, MethodNumber: null, SampleVolumeinCC: null, SampleCost: null, FrequencyName: 'AAA', DataSetType: 'DEFAULT' });
    }
    onDeleteRow(event: any, index: any, rowId: any) {
        debugger;
        this.run.lstAnalyticalSamples = this.run.lstAnalyticalSamples.filter((i: any) => i.RowId != rowId);
        this.resetRowId();
        this.runDataService.changeMessage(this.run);
    }
    resetRowId() {

        if (this.run.lstAnalyticalSamples != null && this.run.lstAnalyticalSamples.length > 0) {
            var maxRowId = 0;
            for (var i = 0; i < this.run.lstAnalyticalSamples.length; i++) {
                this.run.lstAnalyticalSamples[i].RowId = maxRowId;
                maxRowId = i + 1;

            }
            this.count = maxRowId;
        }
    }


    isDataValid(): boolean {
        debugger;
        let status: boolean = true;
        if (this.run.lstAnalyticalSamples.length > 0) {
            this.run.lstAnalyticalSamples.forEach(element => {
                if (element.StreamId == 0) {
                    status = false;
                }
                else if (element.FrequencyName == undefined || element.FrequencyName =="AAA") {
                    status = false;
                }
                else if (element.LIMSOPerationName == undefined) {
                    status = false;
                }

            });
            return status;
        }
    }
    refreshLimsData() {
        this.getLimsCostVolume();
    }
}

