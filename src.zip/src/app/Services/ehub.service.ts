import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions} from '@angular/http';
import { Observable, of, from } from 'rxjs';
export var headers = new Headers({ 'Content-Type': 'application/json' });
@Injectable({
  providedIn: 'root'
})

export class EhubService {
    baseurl: string = "http://10.77.14.41:4000/api/csat";
    
    constructor(private http: Http,) { }

    public getData(urlParam: any) {
        var url = this.baseurl;
        return this.http.post(url,urlParam);
          
    }

    public postData(urlparam: any)
    {
        debugger;
        var headers = new Headers({ 'Content-Type': 'application/json' });
        var optionsSpec = { withCredentials: false, headers: headers, observe: "response" };
        let options = new RequestOptions(optionsSpec);
        return this.http.post(this.baseurl, urlparam, options)       
    }
}
