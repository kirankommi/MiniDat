﻿export class CatalystFamilyModel {
    CatalystFamilyID: number;
    CommercialName: string;
    ProgramName: string;
    ApplicationName: number;
    CatalystType: number;
    StatusName: string;
    PieceDensityMinSpec: number;
    PieceDensityMaxSpec: number;
    LOIMinSpec: number;
    LOIMaxSpec: number;
    SulfurMinSpec: number;
    SulfurMaxSpec: number;
    SDSNumber: number;
    FamilyIndicator: any;  
    CanEdit: string;      
    AppCode: string;
    CatalystApplicatonName: string;
    CatalystTypeName: string;
    StatusCode: KeyValue;
    CatalystApplicaton: KeyValue;
    CatalystTypecd: KeyValue;
    FamilyIndicatorcd: KeyValue;
    public IsInitialLoad: boolean;
}

export class KeyValue {
    Key: string;
    Value: string;
    Groupcd: number;
}

export class ApplicationModel {
    ApplicationName: string;   
    ApplicationId: number;   
    IsChecked: boolean;
    IsallowedCheck: boolean;
}