﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleController.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Manage Role - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Catalyst;
using MINIDAT.Model.Catalyst;
using MINIDAT.Model;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

namespace MINIDAT.WebAPI.Controllers
{
    public class CatalystAliasSSController : AppController
    {
        ICatalystAliasSSRepository _catalystAliasSSRepository;       
        public CatalystAliasSSController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage CatalystAliasSS" }));
            _catalystAliasSSRepository = new CatalystAliasSSRepository(new MINIDATDatabase());
        }
        /// <summary>
        /// search the roles
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SearchCatalystAliasSSdata")]
        public CatalystAliasSSSearchModel GetData([FromBody] CatalystAliasSSModel catalystAliasSS)
        {            
            var tbpsrModel = _catalystAliasSSRepository.GetCatalystAliasSSData(catalystAliasSS);
            return tbpsrModel;
        }
        /// <summary>
        /// save the role after modifications
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>

        [HttpPost, ActionName("SaveCatalystAliasSSInformation")]
        public HttpResponseMessage SaveModeInformation([FromBody] CatalystAliasSSModel catalystAliasSS)
        {
            if (catalystAliasSS != null)
            {
                try
                {
                    ICatalystAliasSSRepository _catalystAliasSSRepository = new CatalystAliasSSRepository(new MINIDATDatabase());
                    _catalystAliasSSRepository.SaveCatalystAliasSSData(catalystAliasSS, User.Identity.Name);
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                    
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        /// <summary>
        /// remove the role
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>

        [HttpPost, ActionName("DeleteCatalystAliasSSInformation")]
        public HttpResponseMessage DeleteModeInformation([FromBody] CatalystAliasSSModel catalystAliasSS)
        {
            if (catalystAliasSS != null)
            {
                try
                {
                    ICatalystAliasSSRepository _catalystAliasSSRepository = new CatalystAliasSSRepository(new MINIDATDatabase());
                    _catalystAliasSSRepository.DeleteCatalystAliasSSData(catalystAliasSS);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);                  
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        
    }
   
}
