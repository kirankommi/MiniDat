﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Dynamic;
using MINIDAT.DataAccess.Interfaces;
using Newtonsoft.Json;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using MINIDAT.DataAccess;
using MINIDAT.Model.Manage.Mode;

namespace MINIDAT.WebAPI.Controllers
{
    public class ReciepeController : ApiController
    {
        IReciepesRepository _recRepository;
        public ReciepeController()
        {
            Model.LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Mode Template: Reciepes" }));
            _recRepository = new ReciepeRepository(new MINIDATDatabase());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet, ActionName("GetReciepesData")]
        public HttpResponseMessage GetReciepesData(string templateId)
        {
            ReciepeRepository _repository = new ReciepeRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _repository.getReciepesTemplateData(templateId));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get receipes data");
            }
        }
    }
}
