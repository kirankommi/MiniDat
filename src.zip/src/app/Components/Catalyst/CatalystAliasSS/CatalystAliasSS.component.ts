﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystAliasSSService } from '../../../Services/CatalystServices/CatalystAliasSS.service';
import { CatalystAliasSSModel, KeyValue } from '../../../models/Catalyst/CatalystAliasSSModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'CatalystAliasSS.component.html',
    providers: [CatalystAliasSSService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystAliasSSComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystAliasSS: CatalystAliasSSModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    catalystAliasSSList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    shapes: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    catalystAliasSSSaved: string = "Catalyst Alias SS Details Saved Successfully";
    catalystAliasSSDeleted: string = "Catalyst Alias SS Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private catalystAliasSSService: CatalystAliasSSService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {       
        this.catalystAliasSS = new CatalystAliasSSModel();
        this.catalystAliasSS.CatalystAliasSSID = null;
        this.catalystAliasSS.CatalystAliasSSName = null;
        this.catalystAliasSS.Size = null;
        this.catalystAliasSS.Shape = null;
        this.getcatalystAliasSSsList();
        this.title = Constants.ManageCatalystAliasSS;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystAliasSS.CatalystAliasSSID = event.data.CatalystAliasSSID;
        this.catalystAliasSS.CatalystAliasSSName = event.data.CatalystAliasSSName;         
        this.catalystAliasSS.StatusName = event.data.StatusCode.Key;
        this.catalystAliasSS.Size = event.data.Sizecd.Key;
        this.catalystAliasSS.Shape = event.data.Shapecd.Key;
    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getcatalystAliasSSsList()
    {       
        this.catalystAliasSSService.getCatalystAliasSSInformation(this.catalystAliasSS)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystAliasSSList = data.LstcatalystAliasSSs;              
                this.Statuses = data.lstStatus;
                this.sizes = data.lstSizes;
                this.shapes = data.lstShapes;       
                this.totalRecords = data.RecordsFetched; 
                debugger;             
                if (this.catalystAliasSS.StatusName == undefined || this.catalystAliasSS.StatusName == null)
                { this.catalystAliasSS.StatusName = Constants.Select; }    
                if (this.catalystAliasSS.Size == undefined || this.catalystAliasSS.Size == null)
                { this.catalystAliasSS.Size = '0'; }   //Default value- Select 
                if (this.catalystAliasSS.Shape == undefined || this.catalystAliasSS.Shape == null)
                { this.catalystAliasSS.Shape = '0'; }   //Default value- Select               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystAliasSS()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.catalystAliasSSService.saveCatalystAliasSSInformation(this.catalystAliasSS)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystAliasSSSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(catalystAliasSS: CatalystAliasSSModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteCatalystAliasSSInfo(catalystAliasSS);}
        });
    }

    deleteCatalystAliasSSInfo(catalystAliasSS: CatalystAliasSSModel)
    {
        debugger;     
        this.catalystAliasSSService.deleteCatalystAliasSS(catalystAliasSS)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystAliasSSDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }   

    onReset() {
        debugger;
        this.catalystAliasSS = new CatalystAliasSSModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.catalystAliasSS.CatalystAliasSSName = null;   
        this.catalystAliasSS.Size = null;
        this.catalystAliasSS.Shape = null;    
        this.getcatalystAliasSSsList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.catalystAliasSS == null || !this.catalystAliasSS.CatalystAliasSSName || this.catalystAliasSS.StatusName == "Select"
            || this.catalystAliasSS.Size == "0"
            || this.catalystAliasSS.Shape == "0")
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {       
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {                   
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000024" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
