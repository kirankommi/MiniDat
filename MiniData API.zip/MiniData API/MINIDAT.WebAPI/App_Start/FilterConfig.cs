﻿using System.Web;
using System.Web.Mvc;

namespace MINIDAT.WebAPI
{
    public static class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            if (filters == null) throw new System.ArgumentNullException("filters");
            filters.Add(new HandleErrorAttribute());
        }
    }
}
