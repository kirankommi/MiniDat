﻿

import { KeyValue } from '../../models/AnalysisMethodModel';

export class MissingOperatorsViewModel {
    constructor() {
        this.errors = [];
    }
    public AnalysisMethodId: string;
    public LIMSOperation: string;
    public methodName: string;
    public methodNumber: string;
    public UOMGroup: string;
    public Source: Array<AnalysisSource>;
    public methodDescription: string;

    public isModified: boolean;
    public isSelected: boolean;
    public errors: KeyValue[];
}

export class AnalysisSource {
    SourceName: string;
    SourceCode: string;
}

export class MissingComponentViewModel extends MissingOperatorsViewModel {
    public ComponentName: string;
    public UOM: string;
    public UOMUnit: string;
    public Precision: string;
    public StandardComponentName: any;
}

export class filteredMissingComponentGroup {
    Operation: string;
    Components: MissingComponentViewModel[];
    expanded: boolean;
} 