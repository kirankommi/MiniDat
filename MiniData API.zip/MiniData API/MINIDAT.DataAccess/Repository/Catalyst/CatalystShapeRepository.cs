﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystShape.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystShapeRepository : ICatalystShapeRepository
    {
        private IDatabase _db;
        public CatalystShapeRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystShapeSearchModel GetCatalystShapeData(CatalystShapeModel catalystShape)
        {
            try
            {
                CatalystShapeSearchModel catalystShapearr = new CatalystShapeSearchModel();
                if (catalystShape == null)
                {
                    return catalystShapearr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystShape_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalyst_Shape", string.IsNullOrEmpty(Convert.ToString(catalystShape.CatalystShape)) ? (object)null : catalystShape.CatalystShape);                  
                    parameters.Add("proc_nm_Assumed_Void_Fraction_Msr", string.IsNullOrEmpty(Convert.ToString(catalystShape.AssumedVoidFraction)) ? (object)null : catalystShape.AssumedVoidFraction);
                    parameters.Add("proc_nm_Crushed_Void_Fraction_Msr", string.IsNullOrEmpty(Convert.ToString(catalystShape.CrushedVoidFraction)) ? (object)null : catalystShape.CrushedVoidFraction);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystShape.StatusName == "Select" ? null : catalystShape.StatusName) ? (object)null : catalystShape.StatusName);  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystShapearr.LstcatalystShapes.Clear();
                    while (reader.Read())
                    {
                        CatalystShapeModel _catalystShape = new CatalystShapeModel()
                        {
                            CatalystShapeID = Convert.ToInt32(reader["CATALYST_SHAPE_ID_SQ"]),
                            CatalystShape = Convert.ToString(reader["CATALYST_SHAPE_NM"]),
                            AssumedVoidFraction = (reader["ASSUMED_VOIDFRACTION_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["ASSUMED_VOIDFRACTION_MSR"]),
                            CrushedVoidFraction = (reader["CRUSHED_FRACTION_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["CRUSHED_FRACTION_MSR"]),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() }
                        };
                        catalystShapearr.LstcatalystShapes.Add(_catalystShape);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystShapearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystShapearr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystShapearr.lstStatus).AddRange(statuses);                  
                    return catalystShapearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystShapeData(CatalystShapeModel catalystShape)
        {
            try
            {
                if (catalystShape == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystShape_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystShape_ID", string.IsNullOrEmpty(Convert.ToString(catalystShape.CatalystShapeID)) ? (object)null : catalystShape.CatalystShapeID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystShapeData(CatalystShapeModel _catalystShape, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystShape == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystShape_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystShape_Id", _catalystShape.CatalystShapeID);
                    parameters.Add("proc_vr_Catalyst_Shape_Nm", _catalystShape.CatalystShape);
                    parameters.Add("proc_vr_Assumed_Void_Fraction_Msr", _catalystShape.AssumedVoidFraction);
                    parameters.Add("proc_vr_Crushed_Void_Fraction_Msr", _catalystShape.CrushedVoidFraction);                  
                    parameters.Add("proc_vr_Status_Nm", _catalystShape.StatusName);                                    
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystShapeModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystShapeModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystShapeModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystShapeModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
