import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import * as  Constants from '../Shared/globalconstants';
import { AlertMessage } from './alertmessage.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { AppErrorMessages } from '../Shared/AppErrorMessages';
import { AppSuccessMessages } from '../Shared/AppSuccessMessages';
import { AppWarningMessages } from '../Shared/AppWarningMessages';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { FileModel } from '../Models/file.model';
import { KeyValue } from '../Models/usermodel';
@Injectable({
  providedIn: 'root'
})
export class HttpActionService {
  appErrorMessages: AppErrorMessages;
  private alertMessage: AlertMessage;
  constructor(private http: Http, private httpc: HttpClient) { }

  private handleError(error: any): Promise<any> {
    var appErr = new AppErrorMessages();
    var message = appErr.getErrorMessage(JSON.parse(error._body).Message);
    if (!message.Id) {
      message.Error = error;// need to test         
      message = appErr.getErrorMessage("UnKnownError");
      message.Details = error;
    }
    let msg: any = {};
    msg.severity = Constants.severityError;
    msg.detail = message.Details;
    msg.summary = message.Title;
    msg.closable = true;
    msg.life = 10000;
    //TBD
    //Constants.Msgs = [];
    Constants.ClearMsgs();
    Constants.Msgs.push(msg);
    return Promise.reject(message);
  }


  private displayErrorMessage1(id: string) {
    let msg: any = {};
    var appErrorMessage = new AppErrorMessages();
    var message = appErrorMessage.getErrorMessage(id)
    if (message) {
      msg.severity = Constants.severityError;
      msg.detail = message.Details;
      msg.summary = message.Title;
      //TBD
      //Constants.Msgs = [];
      Constants.ClearMsgs();
      Constants.Msgs.push(msg);
    }
  }

  post(data: any, actionUrl: string) {
    //TBD
    //Constants.IsLoading = true;
    Constants.SetLoading(true);
    let options = new RequestOptions(Constants.options);
    return this.http.post(Constants.apiBaseUrl + actionUrl, data, options)
      .map((res: Response) => {
        return res.json()
      })
      .catch(this.handleError)
      .finally(() => {
        //TBD
        //Constants.IsLoading = false
        Constants.SetLoading(false);
      });
  }
  postc(data: any, actionUrl: string) {

    Constants.SetLoading(true);
    var headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    //var options=
    var params = new HttpParams();
    var opt = { headers: headers, params: params, withCredentials: true }
    //let options = new RequestOptions(Constants.options);
    return this.httpc.post(Constants.apiBaseUrl + actionUrl, data, opt)
      .map((res: Response) => {
        return res.json()
      })
      .catch(this.handleError)
      .finally(() => {

        Constants.SetLoading(false);
      });
  }
  postSpecial(data: any, actionUrl: string) {
    //TBD
    //Constants.IsLoading = true;
    Constants.SetLoading(true);
    var headers = new Headers({ 'Content-Type': 'application/json' });
    var optionsSpec = { withCredentials: true, headers: headers, observe: "response" };
    let options = new RequestOptions(optionsSpec);
    return this.http.post(Constants.apiBaseUrl + actionUrl, data, options)
      .catch(this.handleError)
      .finally(() => {
        //TBD
        //Constants.IsLoading = false
        Constants.SetLoading(false);
      });
  }

  get(actionUrl: string, options: any) {
    //TBD      
    Constants.SetLoading(true);
    return this.http.get(Constants.apiBaseUrl + actionUrl, options)
      .map((res: Response) => res.json())
      .catch(this.handleError)
      .finally(() => {
        //TBD                
        Constants.SetLoading(false);
      });
  }

  getc(actionUrl: string, options: any) {
    //TBD

    Constants.SetLoading(true);
    return this.httpc.get(Constants.apiBaseUrl + actionUrl)
      .map((res: Response) => res.json())
      .catch(this.handleError)
      .finally(() => {
        //TBD                
        Constants.SetLoading(false);
      });
  }
  getFeed(actionUrl: string, options: any) {
    //TBD
    debugger;
    Constants.SetLoading(true);
    return this.http.get(Constants.feedstockBaseUrl + actionUrl, options)
      .map((res: Response) => res.json())
      .catch(this.handleError)
      .finally(() => {
        //TBD                
        Constants.SetLoading(false);
      });
  }
  postFeed(data: any, actionUrl: string) {
    //TBD
    //Constants.IsLoading = true;
    Constants.SetLoading(true);
    let options = new RequestOptions(Constants.options);
    return this.http.post(Constants.feedstockBaseUrl + actionUrl, data, options)
      .map((res: Response) => {
        return res.json()
      })
      .catch(this.handleError)
      .finally(() => {
        //TBD
        //Constants.IsLoading = false
        Constants.SetLoading(false);
      });
  }

  postFiles(files: FileModel[], url: string, data: KeyValue[]) {
    Constants.SetLoading(true);
    let formData: FormData = new FormData();
    let metaData: any[] = [];
    files.forEach((q, i) => {
      q.FileId = i;
      formData.append(i.toString(), q.FileData);
      let { FileData, ...fileInfo } = q;
      metaData.push(fileInfo);
    });
    formData.append('fileInfo', JSON.stringify(metaData));

    data.forEach((q) => {
      formData.append(q.Key, q.Value);
    });

    let options = new RequestOptions(Constants.options);
    return this.httpc.post(Constants.apiBaseUrl + url, formData, {
      withCredentials: true
    })
      .catch(this.handleError)
      .finally(() => {
        //TBD
        //Constants.IsLoading = false
        Constants.SetLoading(false);
      });;

    //formData.append()
  }
}
