﻿using System;
using MINIDAT.Model.DataViewerModel;
using System.Collections.Generic;
using MINIDAT.Framework.Common;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using System.Collections;
using System.Data;
using System.Dynamic;
using MINIDAT.DataAccess.Interfaces;

namespace MINIDAT.DataAccess.Repository.DataViewer
{
  public class DataViewerRepository : IDataViewerRepository
    {
        private IDatabase _db;
        public DataViewerRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<dynamic> getDataForDataViewer(string Plant, string Run, string Category, string User_Id)
        {
            //try
            //{
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_Dv_WS_Summary_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                //data = new DataViewerModel();
                //data.Plant = "321";
                //data.Run = 712;
                //data.Category = "Normalized Gas Yields";
                //data.User_Id = "h118265";
                    parameters.Add("@proc_vr_Plant_Cd", Plant);
                    parameters.Add("@proc_in_Run_Num", Int32.Parse(Run));
                    parameters.Add("@proc_vr_Category", Category);
                    parameters.Add("@proc_vr_User_Id", User_Id);

                    _db.CreateParameters(command, parameters);

                    using (reader = _db.ExecuteReader(command))
                    {
                        while (reader.Read())
                        {
                            yield return GetDynamicData(reader);
                        }
                    }
                reader.Close();
            }
           // }
            //catch (Exception ex)
            //{
            //    LogManager.Error(ex);
            //    throw;
            //}
        }




        private dynamic GetDynamicData(IDataReader reader)
        {
            var expandoObject = new ExpandoObject() as IDictionary<string, object>;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if(i == 0 || i == 2 || i > 4)
                {
                    expandoObject.Add(reader.GetName(i), reader[i]);
                }
                //if(reader[i].ToString()!= "VARIABLE_DECIMAL_PNT" || reader.GetName(i) != "UOM_LEVEL" || reader.GetName(i) != "PARAM_DISPLAY_ORDER_NUM" || reader.GetName(i) != "UOM_GROUP_NM")
                //{
                    
               // }
               
            }
            return expandoObject;
        }
        public DataViewerExport ExportMultipleCategories(string Plant, string Run, string cateogory, string User_Id)
        {
            try
            {
                DataViewerExport exportdata = new DataViewerExport();
                IDataReader reader = null;
                string[] categories;
                categories = cateogory.Split(',');
                using (IDbCommand command = _db.CreateCommand("[md].[Export_Dv_WC_Summary_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", Plant);
                    parameters.Add("@proc_in_Run_Num", Int32.Parse(Run));
                    parameters.Add("@category_List", cateogory);
                    parameters.Add("@proc_vr_User_Id", User_Id);

                    _db.CreateParameters(command, parameters);

                    using (reader = _db.ExecuteReader(command))
                    {
                        foreach (var category in categories)
                        {
                            List<dynamic> tableData = new List<dynamic>();
                            while (reader.Read())
                            {
                                tableData.Add(GetDynamicData_export(reader));
                            }
                            reader.NextResult();
                            switch (category)
                            {
                                case "Plant Calculations":
                                    exportdata.PlantCalculations = tableData;
                                    break;
                                case "Normalized Gas Yields":
                                    exportdata.NormalizedGasYields = tableData;
                                    break;
                                case "Gas Volumes":
                                    exportdata.GasVolumes = tableData;
                                    break;
                                case "Gas Weights":
                                    exportdata.GasWeights = tableData;
                                    break;
                                case "Weight Recovery":
                                    exportdata.WeightRecovery = tableData;
                                    break;
                                case "Liquid Weights":
                                    exportdata.LiquidWeights_LP690 = tableData;
                                    break;
                                case "Liquid Weights Percent":
                                    exportdata.LiquidWeights_percent = tableData;
                                    break;
                                case "Liquid Weights(Sim Dist)":
                                    exportdata.LiquidWeights_Simdist = tableData;
                                    break;
                                case "Normalized Liquid Weight":
                                    exportdata.NormalizedLiquidWeights = tableData;
                                    break;
                                case "Raw Product Weights":
                                    exportdata.RawProductWeights = tableData;
                                    break;
                                case "Raw Product Weight Percent":
                                    exportdata.RawProductWeights_percent = tableData;
                                    break;
                                case "Mass Balance Adjusted Prod Wt Percent":
                                    exportdata.MBAdjustedProductWt_percent = tableData;
                                    break;
                                case "Dopant Adjustment":
                                    exportdata.DopantAdjustments = tableData;
                                    break;
                                case "Dopant Adjusted Mb":
                                    exportdata.DAMassBalanceProductWt_perscent = tableData;
                                    break;
                                case "Product Ratios":
                                    exportdata.ProductRatios = tableData;
                                    break;
                                case "Feed Weight(Sim Dist)":
                                    exportdata.FeedWeights = tableData;
                                    break;
                                case "Feed Weight Percent(Sim Dist)":
                                    exportdata.FeedWeightsPercent = tableData;
                                    break;
                                case "Conversion Calculations":
                                    exportdata.ConversionCalculation = tableData;
                                    break;
                                case "Quality Calculations":
                                    exportdata.QualitCalculation = tableData;
                                    break;
                                case "LP Product Properties":
                                    exportdata.H2LPProductProperties = tableData;
                                    break;
                                case "H By NIR Yields":
                                    exportdata.H2ByNIR = tableData;
                                    break;
                                case "H By NMR Yields":
                                    exportdata.H2ByNMR = tableData;
                                    break;
                            }
                        }

                    }
                    reader.Close();
                }
                return exportdata;
            }
            catch(Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        private dynamic GetDynamicData_export(IDataReader reader)
        {
            var expandoObject = new ExpandoObject() as IDictionary<string, object>;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (i == 0 || i == 1 || i > 5)
                {
                    expandoObject.Add(reader.GetName(i), reader[i]);
                }
            }
            return expandoObject;
        }

    }
}
