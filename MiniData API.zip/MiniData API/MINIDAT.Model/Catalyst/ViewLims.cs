﻿using MINIDAT.Model.UOM;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace MINIDAT.Model.Catalyst
{ 
    public class SourceName
    {
        public string Name { get; set; }
        public string Id { get; set; }
        public bool IsUsed { get; set; }
    }

    public class LimsMasterResults
    {
        private IList<AnalysisMethod> _analysisMethods = new List<AnalysisMethod>();
        public IList<AnalysisMethod> AnalysisMethods { get { return this._analysisMethods; } }

        private IList<Validation> _validations = new List<Validation>();
        public IList<Validation> Validations { get { return this._validations; } }
    }

    public class Validation
    {
        public string ValidationCode { get; set; }
        public string ValidationName { get; set; }
    }
    public class AnalysisMethod
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public string LimsOperation { get; set; }
        public string UomGroup { get; set; }
        public string Description { get; set; }
        public string AnalysisCost { get; set; }
        public string AnalysisMethodSource { get; set; }

        //private IList<SourceName> sourceNames;
    }

    public class CatalystLimsResult
    {
        private Unit propertyDisplayUnit;
        public string Component { get; set; }
        public int ComponentId { get; set; }
        public int CatalystId { get; set; }
        [XmlIgnore]
        public UnitGroup PropertyUnitGroup { get; set; }

        [XmlIgnore]
        public Unit PropertyDisplayUnit
        {
            get
            {
                return propertyDisplayUnit;
            }
            set
            {
                propertyDisplayUnit = value;
                if (propertyDisplayUnit != null && LimsSampleValues != null)
                {
                    foreach (var sample in LimsSampleValues)
                    {
                        if (sample.IsUOMEnabled)
                        {
                            sample.TargetUnit = null;
                            sample.TargetValue = Convert.ToString(propertyDisplayUnit.convertToTargetunit(sample.BaseValue));
                            sample.TargetUnit = propertyDisplayUnit;
                        }
                    }
                }
            }

        }
        private IList<Sample> _limsSampleValues = new List<Sample>();
        public IList<Sample> LimsSampleValues { get { return this._limsSampleValues; } }
        public bool IsSumTotalRow { get; set; }
    }

    public class Sample : ICloneable
    {
        private string targetValue;

        public string LimsSampleId { get; set; }
        public int LimsID { get; set; }
        public int PPValueIdSQ { get; set; }
        public Validation SelectedValidation { get; set; }
        public int AnalysisMethodId { get; set; }
        [XmlIgnore]
        public Unit TargetUnit { get; set; }
        public double? BaseValue { get; set; }
        public string Precision { get; set; }
        public string PPValueText { get; set; }
        public bool IsBasePPValueText { get; set; }
        public string TargetValue
        {
            get
            {
                return targetValue;
            }
            set
            {
                double dValue;
                if (double.TryParse(value, out dValue))
                {
                    targetValue = dValue.ToString(Precision);
                    if (TargetUnit != null)
                    {
                        BaseValue = TargetUnit.convertToBaseUnit(dValue);
                    }

                    PPValueText = null;
                    IsBasePPValueText = false;
                    IsUOMEnabled = true;

                }
                else if ((BaseValue == null || BaseValue == 0.0) && PPValueText != null)
                {
                    targetValue = value;
                    IsBasePPValueText = true;
                    IsUOMEnabled = false;
                }
                else if (BaseValue != null && PPValueText == null)
                {
                    targetValue = value;
                    IsBasePPValueText = true;
                    BaseValue = null;
                    IsUOMEnabled = false;
                }
                else
                {
                    targetValue = null;
                    BaseValue = null;

                    PPValueText = null;
                    IsBasePPValueText = false;
                    IsUOMEnabled = true;
                }
            }
        }
        [XmlIgnore]
        public bool IsUOMEnabled { get; set; } // Indicates whether the target value is from Property Value Quantity column or Property Value Text column.. True for Property Value Quantity column

        private bool _isOverflow;
        public bool IsOverflow
        {
            get { return _isOverflow; }
            set
            {
                _isOverflow = value;
            }
        }
        public Sample()
        {
            Precision = "0.00000000";
        }

        public object Clone()
        {
            return MemberwiseClone();
        }
    }

    public class LimsValidation
    {
        public string LimsSampleId { get; set; }
        public int LimsID { get; set; }
        public Validation SelectedValidation { get; set; }

    }

    public class UpdateLimsModel
    {
        public int CatalystId { get; set; }
        public string MethodSource { get; set; }
        private IList<LimsSample> _sampleList = new List<LimsSample>();
        public IList<LimsSample> SampleList { get { return this._sampleList; } }
    }

    public class LimsSample
    {
        public int CatalystId { get; set; }
        public int MethodId { get; set; }
        public string MethodName { get; set; }
        public string MethodSource { get; set; }
        public string SampleId { get; set; }
        public string ValidationCode { get; set; }
        public string ComponentName { get; set; }
    }
}
