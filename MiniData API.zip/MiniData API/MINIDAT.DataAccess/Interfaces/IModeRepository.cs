﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IModeRepository : ICRUDRepository<ModeModel>
    {
        ModeSearchModel GetModeData(ModeModel Mode);
        string DeleteModeData(ModeModel Mode);
        void SaveModeData(ModeModel Mode, string userId);
        ModeSearchModel GetPlantsData(ModeModel Plant);

    }
}
