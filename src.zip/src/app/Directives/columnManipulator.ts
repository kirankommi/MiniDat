
export class columnManipulator {
  columns: customColumn[];
  rowCount: number;
  previousColumn: customColumn;
  resultModel: any = {};

  constructor(_columns: customColumn[]) {
    this.columns = _columns;
  }

  updateProperties(isMinisQ: boolean) {
    this.resultModel = {};
    this.setRowCount();
    this.columns.forEach((q) => this.updateRowSpans(q, 0));
    this.columns.forEach((q) => this.updateColumnSpan(q));
    this.columns.forEach((q) => this.makeAModel(q, isMinisQ));
    return this.resultModel;
  }

  makeAModel(column: customColumn, isMinisQ: boolean) {
    if (isMinisQ) {
      this.resultModel[column.name] = {};
      this.resultModel[column.name]["rowSpan"] = column.rowSpan;
      this.resultModel[column.name]["colSpan"] = column.colSpan;
      this.resultModel[column.name]["isVisible"] = column.isVisible;
      this.resultModel[column.name]["isFrozen"] = column.isFrozen;
      if ((['ReOrder', 'Project'].includes(column.name))) {
        this.resultModel[column.name]["style"] = column.style;
        this.resultModel[column.name]["left"] = column.left;
        this.previousColumn = column;
      } else
        if (column.isVisible && (['Study', 'Plant #', 'Run #', 'Estimated / Actual Start Date', 'Estimated / Actual Complition Date'
          , 'Status','Requestor','Network','NIR Flag'].includes(column.name))) {
          this.resultModel[column.name]["style"] = column.style;
          this.resultModel[column.name]["left"] = this.resultModel[this.previousColumn.name].left + this.resultModel[this.previousColumn.name].colWidth;
          this.previousColumn = column;
        }
        else {
          this.resultModel[column.name]["style"] = "";
        }
      this.resultModel[column.name]["colWidth"] = column.colWidth;
      if (column.childrens) {
        column.childrens.forEach((q) => this.makeAModel(q, true));
      }
    } else {
      this.resultModel[column.name] = {};
      this.resultModel[column.name]["rowSpan"] = column.rowSpan;
      this.resultModel[column.name]["colSpan"] = column.colSpan;
      this.resultModel[column.name]["isVisible"] = column.isVisible;
      this.resultModel[column.name]["isFrozen"] = column.isFrozen;
      if (column.childrens) {
        column.childrens.forEach((q) => this.makeAModel(q, false));
      }
    }
  }

  updateColumnSpan(colmn: customColumn) {
    if (colmn.childrens && colmn.childrens.length > 0) {
      let validCols = colmn.childrens.filter((q) => q.isVisible).length;
      colmn.colSpan = validCols;
      colmn.childrens.forEach((q) => { this.updateColumnSpan(q); });
    }
    else {
      colmn.colSpan = 1;
    }
  }

  updateRowSpans(colmn: customColumn, ht: number) {
    colmn.rowSpan = this.rowCount - ht;
    if (colmn.childrens && colmn.childrens.length > 0) {
      colmn.childrens.forEach((q) => {
        this.updateRowSpans(q, ht + 1);
      });
    }
  }

  setRowCount() {
    let eachNodeHeight: number[] = [];
    this.columns.forEach((q) => {
      eachNodeHeight.push(this.findHight(q));
    });
    this.rowCount = Math.max.apply(Math, eachNodeHeight);
  }

  findHight(cus: customColumn): number {
    if (cus.childrens && cus.childrens.length > 0) {
      let mxAry: number[] = [];
      cus.childrens.filter((w) => w.isVisible).forEach((q) => {
        mxAry.push(1 + this.findHight(q));
      })
      return Math.max.apply(Math, mxAry);
    }
    else {
      return 1;
    }
  }
}

export class customColumn {
  displayName: string;
  name: string;
  isVisible?: boolean;
  isFrozen?: boolean;
  rowSpan?: number;
  colSpan?: number;
  isStatic?: boolean;
  style?: string;
  left?: number;
  colWidth?: number;
  childrens?: customColumn[] = [];
}
