﻿using MINIDAT.Model.DOE;
using MINIDAT.Model.MINISQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MasterData = MINIDAT.Model.MINISQ.MasterData;
using Study = MINIDAT.Model.MINISQ.Study;

namespace MINIDAT.DataAccess.Interfaces
{
    interface IMINISQRepository
    {
        MasterData GetMasterData(string userId);
        Study GetStudiesData();
        bool ReOrderRuns(ReOrderedRuns runs);
        string SaveColPreferences(ColumnsPreferences columnPref);
    }
}
