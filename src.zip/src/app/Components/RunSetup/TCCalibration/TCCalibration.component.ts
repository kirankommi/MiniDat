import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import * as Constants from '../../../Shared/globalconstants';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';


@Component({
    selector: 'tcCalibration',
    templateUrl: 'TCCalibration.component.html',
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})
export class TCCalibrationComponent implements OnInit {
    // run1: RunModel;
    run: RunSetupModel;        

    oldValue: number = 0;
    IsVisible: boolean = false;
    constructor(private runService: RunService, private alertMessage: AlertMessage, public runDataService: RunDataService, private runComponent: RunComponent) { }
    runSaved: string = "Run TC Calibration Details Saved Successfully";
    replaceTC: string = "One or more thermocouples is more than 9 months old, replace thermocouples soon!";

    ngOnInit()
    {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel)
        this.updateInformation();
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "10", Value: "TC Calibration", Groupcd: 0 });
    }
    updateInformation()
    {
        this.run.lstTC_Calibrations.map((x, i) => {
            if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date') {
                if (x.CalibrationDate != null && x.CalibrationDate != undefined) {
                    x.CalibrationDate = new Date(x.CalibrationDate);
                }
                if (!this.IsVisible)
                    this.CalculateMonthsdiff(x.CalibrationDate, new Date());
            }
        });
    }
    captureOldValue(event) {
        this.oldValue = Number(event.target.value);
    }



    updateValue(event: any, value: any, rowId: any, unit: any, index: any)
    {
        debugger;
        if (event.target.value == "")
        {
            this.run.lstTC_Calibrations[index].Value = null;
        }
        else
        {
            let currentvalue = Number(event.target.value);
            if (this.oldValue != currentvalue) {
                if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
                    this.run.lstTC_Calibrations[index].Value = unit.Slope / (currentvalue + unit.Intercept);
                }
                else {
                    this.run.lstTC_Calibrations[index].Value = currentvalue * unit.Slope + unit.Intercept;
                }
            }
        }
        
    }
    ngOnDestroy()
    {
        debugger;
        if (this.run.lstTC_Calibrations != null && this.run.lstTC_Calibrations != undefined)
        {
            this.run.lstTC_Calibrations.map((x, i) => {
                if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date') {
                    if (x.CalibrationDate != null && x.CalibrationDate != undefined) {
                        x.CalibrationDate = new Date(x.CalibrationDate);
                    }
                    if (!this.IsVisible)
                    this.CalculateMonthsdiff(x.CalibrationDate, new Date());
                }
            });
        }
        if (this.IsVisible)
        {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.replaceTC });
        }
    }
    getTCCalibrationData(PlantCd: string, RunId: string) {
        debugger;
        this.runService.GetTCCalibrationInformation(PlantCd, RunId)
            .subscribe(
                (data: any) => {
                    debugger;
                    this.run.lstTC_Calibrations = data;
                    this.run.lstTC_Calibrations.map((x, i) => {
                        if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date') {
                            if (x.CalibrationDate != null && x.CalibrationDate != undefined) {
                                x.CalibrationDate = new Date(x.CalibrationDate);
                            }
                            if (!this.IsVisible)
                                this.CalculateMonthsdiff(x.CalibrationDate, new Date());
                        }
                    });
                },
                err => { }
            );
    }
    CalculateMonthsdiff(date1: Date, date2: Date) {
        debugger;
        if (date1 != null) {

            var difference = (date2.getDate() - date1.getDate()) / 30 +
                date2.getMonth() - date1.getMonth() +
                (12 * (date2.getFullYear() - date1.getFullYear()));

            if (difference > 9) {
                this.IsVisible = true;
            }
        }

    }
    SaveRunInformation() {
        debugger;
        let response: any;
        this.IsVisible = false;
        //CalibrationchangeDate
        //this.run.lstTC_Calibrations.map((x, i) => {
        //    if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date')
        //    {
        //        //x.CalibrationchangeDate = new Date(x.CalibrationchangeDate).toLocaleString();
        //        x.CalibrationchangeDate = new Date(x.CalibrationDate).toLocaleString();
        //    }
        //});
        //x.CalibrationchangeDate = new date
        if (this.isDataValid()) {
            // this.runService.SaveRunDetails(this.run1)
            //     .subscribe(
            //     (data: any) => {
            //         debugger;
            //         if (data == Constants.Success) {
            //             this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.runSaved });
            //         }
            //     },
            //     err => { }
            //     );
            this.run.lstTC_Calibrations.map((x, i) => {
                if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date') {
                    //x.CalibrationDate = new Date(x.CalibrationDate);
                    if (!this.IsVisible)
                        this.CalculateMonthsdiff(x.CalibrationDate, new Date());
                }
            })
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        };
    }
    isDataValid()
    {
        debugger;       
       let tcCalibration = this.run.lstTC_Calibrations.filter((x: any) => (x.Value == null&&!x.ParameterName.includes("Date")));
        if (tcCalibration.length > 0)
        {
            return false;
        }
        return true;
    }
    onReset() {
        debugger;
        this.IsVisible = false;
        this.getTCCalibrationData(this.run.MetaData.Plant, this.run.MetaData.RunId);
        this.runDataService.changeMessage(this.run);      
    }
}

