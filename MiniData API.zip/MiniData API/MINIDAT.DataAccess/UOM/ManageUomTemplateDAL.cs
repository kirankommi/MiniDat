﻿using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.UOM;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace MINIDAT.DataAccess.UOM
{
    public class ManageUomTemplateDAL
    {

        #region GetUomTemplateInfo

        /// <summary>
        /// Retrieve the Template info from the database and return it as a collection.
        /// </summary>
        /// <param name="template">UOMTemplate</param>
        /// <returns>ObservableCollection<UOMTemplate></returns>
        public ObservableCollection<UOMTemplate> GetUomTemplateInfo(UOMTemplate template)
        {
            try
            {
                #region setting up DBCommand with parameters
                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                using (DbCommand command = db.GetStoredProcCommand("Search_UOM_Template_Name_Sp"))
                {
                    if (template != null)
                    {
                        if (!string.IsNullOrEmpty(template.TemplateName) && !string.IsNullOrEmpty(template.TemplateName.Trim()))
                        {
                            db.AddInParameter(command, "proc_vr_Template_NM", DbType.String, template.TemplateName.Trim());
                        }
                        else
                        {
                            db.AddInParameter(command, "proc_vr_Template_NM", DbType.String, String.Empty);
                        }
                    }

                    //if (PageInfo != null)
                    //{
                    //    db.AddInParameter(command, "proc_in_Page_Size_Num", DbType.Int32, PageInfo.PageSize);
                    //    db.AddInParameter(command, "proc_in_Current_Page_Num", DbType.Int32, (PageInfo.CurrentPage - 1));
                    //    db.AddInParameter(command, "proc_vr_Sort_Column_Nm", DbType.String, PageInfo.SortProperty);
                    //    db.AddInParameter(command, "proc_vr_Sort_Order_Nm", DbType.String, PageInfo.SortDirection.ToString().ToUpper());
                    //    db.AddOutParameter(command, "proc_in_Rec_Cnt", DbType.Int32, 8);
                    //}

                    ObservableCollection<UOMTemplate> uomTemplateList = new ObservableCollection<UOMTemplate>();

                    using (IDataReader objSqlDr = db.ExecuteReader(command))
                    {
                        if (objSqlDr != null)
                        {
                            while (objSqlDr.Read())
                            {
                                UOMTemplate TemplateRecord = new UOMTemplate
                                {
                                    TemplateId = Convert.ToInt32(objSqlDr["UOM_TEMPLATE_ID_SQ"]),
                                    TemplateName = Convert.ToString(objSqlDr["UOM_TEMPLATE_NM"]),
                                };
                                uomTemplateList.Add(TemplateRecord);
                            }
                        }
                    }
                    //PageInfo.Records = uomTemplateList.Count;
                    //PageInfo.TotalRecords = Convert.ToInt32(db.GetParameterValue(command, "proc_in_Rec_Cnt"));

                    return uomTemplateList;
                }
                #endregion
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion GetUomTemplateInfo

        #region DeleteUomTemplate

        /// <summary>
        /// Delete the template from the database.
        /// </summary>
        /// <param name="template">UOMTemplate to be deleted</param>
        /// <returns>true or false</returns>
        public bool DeleteUomTemplate(UOMTemplate template)
        {
            int errorCode = 1;
            try
            {
                if (template != null)
                {
                    Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                    #region Define DBCommand and delete record
                    using (DbCommand command = db.GetStoredProcCommand("Delete_Uom_Template_Sp"))
                    {
                        db.AddInParameter(command, "proc_vr_Uom_Template_Id", DbType.Int32, template.TemplateId);
                        errorCode = db.ExecuteNonQuery(command);

                        if (errorCode == 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                return false;
                #endregion
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion DeleteUomTemplate

        #region SaveUomTemplate

        /// <summary>
        /// Save a new template in the database
        /// Update the existing Template in the database
        /// </summary>
        /// <param name="template">New template/Updated Existing Template</param>
        /// <returns>true or false</returns>
        public bool SaveUomTemplate(UOMTemplate template, string CurrentUserEid)
        {
            try
            {
                #region Define dbcommand and populate parameters
                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                using (DbCommand command = db.GetStoredProcCommand("Insert_Update_Uom_Template_Sp"))
                {

                    if (template != null)
                    {
                        db.AddInParameter(command, "proc_vr_Uom_Template_Nm", DbType.String, template.TemplateName.Trim());
                        if (template.TemplateId == 0)
                        {
                            db.AddInParameter(command, "proc_vr_Uom_Template_Id", DbType.Int32, null);
                        }
                        else
                        {
                            db.AddInParameter(command, "proc_vr_Uom_Template_Id", DbType.Int32, template.TemplateId);
                        }
                    }

                    db.AddInParameter(command, "proc_dt_Created_By_User_Id", DbType.String, CurrentUserEid);

                    #region Execute and return values
                    int intErorCode = db.ExecuteNonQuery(command);

                    if (intErorCode == 0)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                    #endregion
                }
                #endregion
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion SaveUomTemplate
    }
}
