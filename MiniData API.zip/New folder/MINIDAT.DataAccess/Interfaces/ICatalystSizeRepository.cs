﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystSizeRepository : ICRUDRepository<CatalystSizeModel>
    {
        CatalystSizeSearchModel GetCatalystSizeData(CatalystSizeModel catalystType);
        string DeleteCatalystSizeData(CatalystSizeModel catalystType);
        void SaveCatalystSizeData(CatalystSizeModel _catalystType, string userId); 

    }
}
