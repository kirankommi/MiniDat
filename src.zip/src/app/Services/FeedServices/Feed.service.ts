﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { FeedModel, KeyValue } from '../../Models/Feed/CreateFeed';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class FeedService
{
    private getFeeddata = "/Feed/SearchFeedInformation/";
    private saveFeeddata = "/Feed/SaveFeedInformation/";
    private deleteFeeddata = "/Feed/DeleteFeedInformation/";  
    private getFeedstockdata = "/Feed/GetFeeds/";
    private getFeedstockAnalyticaldata = "/Feed/ExposeFeedAndAnalyticalData/";

    constructor(private httpaction: HttpActionService) { }

    getFeedInformatin(feed: FeedModel)
    {  
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(feed, this.getFeeddata);
    }

    saveFeedInformation(feed: FeedModel)
    {
        return this.httpaction.post(feed, this.saveFeeddata);
    }

    deleteFeed(feed: FeedModel)
    {
        debugger;
        return this.httpaction.post(feed, this.deleteFeeddata);
    }
    getFeedStockFeeds(feed: FeedModel)
    {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('FeedID', feed.FeedId);
        let options = new RequestOptions(Constants.options)
        return this.httpaction.getFeed(this.getFeedstockdata, options)
    }
    getFeedAnalyticalData(feed: FeedModel,feedIDs: any)
    {        
        return this.httpaction.postFeed(feedIDs, this.getFeedstockAnalyticaldata);
    }  
}
