﻿using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.UOM;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace MINIDAT.DataAccess.UOM
{
    public class SetDefaultTemplateDAL
    {

        #region GetTemplates
        /// <summary>
        /// Method to get the Template List
        /// </summary>
        /// <returns>List of Templates</returns>
        public ObservableCollection<UOMTemplate> GetTemplates(string userId, out int currentTemplateId)
        {
            try
            {
                ObservableCollection<UOMTemplate> templates = new ObservableCollection<UOMTemplate>();
                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                DbCommand command = db.GetStoredProcCommand("Get_Template_List_Sp");
                db.AddInParameter(command, "@proc_var_User_Id", DbType.String, userId);



                //#region Parameter Collection

                //ParameterCollection objParameters = new ParameterCollection();
                //objParameters.add("CurrentUser", userId);

                //#endregion Parameter Collection

                //#region Create & execute the command
                ////Get DAL Component
                //IDatabaseHelper dbHelper = DataLayerFactory.getDatabaseHelper();
                //CommandBuilder commandBuilder = DataLayerFactory.getCommandBuilder();

                ////Create the database command
                //DatabaseCommand command = commandBuilder.getCommand("Get_Template_List", objParameters);


                //Execute the command against database					
                using (IDataReader reader = db.ExecuteReader(command))
                {

                    if (reader.Read())
                    {
                        currentTemplateId = Convert.ToInt32(reader["UOM_TEMPLATE_ID"]);
                    }
                    else
                    {
                        currentTemplateId = 0;
                    }


                    //read the next data table
                    reader.NextResult();

                    while (reader.Read())
                    {
                        templates.Add(new UOMTemplate
                        {
                            TemplateName = Convert.ToString(reader["UOM_TEMPLATE_NM"]),
                            TemplateId = (Int32)(reader["UOM_TEMPLATE_ID_SQ"])

                        });
                    }

                    return templates;
                }
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion


        #region UpdateTemplateId
        /// <summary>
        /// Method to set the default template
        /// </summary>       
        public bool UpdateDefaultTemplate(string userId, int templateId)
        {
            bool ret = false;
            //try
            //{
            Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
            DbCommand command = db.GetStoredProcCommand("Update_Default_TemplateId_Sp");
            db.AddInParameter(command, "proc_var_User_Id", DbType.String, userId);
            db.AddInParameter(command, "proc_in_Template_Id", DbType.String, templateId);

            using (IDataReader reader = db.ExecuteReader(command))
            {
            }
            ret = true;
            //}
            //catch (Exception ex)
            //{
            //    LogManager.Error(ex);
            //    throw ex;
            //}
            return ret;
        }
        #endregion
    }
}
