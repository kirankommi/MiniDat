﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model;
using MINIDAT.Model.TestCreation;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers.TestCreationControllers
{
    public class ProductPhysicalPropertiesController : AppController
    {
        [HttpPost, ActionName("GetDropdownData")]
        public HttpResponseMessage GetDropdownData([FromBody] ProductPhysicalPropertiesInput input)
        {
            ProductPhysicalPropertiesRepository _productPhysicalPropertiesRepository = new ProductPhysicalPropertiesRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _productPhysicalPropertiesRepository.getDropdownData(input));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                //need to change
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }


        [HttpPost, ActionName("GetUIData")]
        public HttpResponseMessage GetUIData(ProductPhysicalPropertiesInput input)
        {
            ProductPhysicalPropertiesRepository _productPhysicalPropertiesRepository = new ProductPhysicalPropertiesRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _productPhysicalPropertiesRepository.getUIDataRepo(input, User.Identity.Name, Model.Session.UserSession.Instance.UnitGroups));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                //need to change
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }


        [HttpPost, ActionName("SavePhysicalProperties")]
        public HttpResponseMessage SavePhysicalProperties(SaveProductPhysicalPropertiesInput data)
        {
            try
            {
                ProductPhysicalPropertiesRepository _productPhysicalPropertiesRepository = new ProductPhysicalPropertiesRepository(new MINIDATDatabase());
                _productPhysicalPropertiesRepository.savePhysicalPropertiesRepo(data, User.Identity.Name);
                return Request.CreateResponse(HttpStatusCode.OK, "Success");
            }
            catch (SqlException ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


    }
}
