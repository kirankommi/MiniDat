﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.UOM
{
    public class UomVariable
    {
        /// <summary>
        /// Gets or sets the unit group CD.
        /// </summary>
        /// <value>The unit group CD.</value>
        public string UnitGroupCD { get; set; }
        /// <summary>
        /// Gets or sets the name of the unit group.
        /// </summary>
        /// <value>The name of the unit group.</value>
        public string UnitGroupName { get; set; }
        /// <summary>
        /// Gets or sets the default unit ID.
        /// </summary>
        /// <value>The default unit ID.</value>
        public int DefaultUnitID { get; set; }
        /// <summary>
        /// Gets or sets the default name of the unit.
        /// </summary>
        /// <value>The default name of the unit.</value>
        public string DefaultUnitName { get; set; }
        /// <summary>
        /// Gets or sets the precision.
        /// </summary>
        /// <value>The precision.</value>
        public int? Precision { get; set; }
        /// <summary>
        /// Gets or sets the name of the varaibale.
        /// </summary>
        /// <value>The name of the varaibale.</value>
        public string VariableName { get; set; }
        public string CategoryName { get; set; }

        public string BaseUnitName { get; set; }

        public string DisplayName { get; set; }
        /// <summary>
    }
}
