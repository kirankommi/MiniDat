﻿using MINIDAT.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Search
{
    public class CrudeSearchCriteria:ICriteria
    {
        public int? CrudeIDSQ { get; set; }
        public string UOPCrudeID { get; set; }
        public string CrudeName { get; set; }
        public string CrudeDescription { get; set; }
        public int? SampleYear { get; set; }
        public int? CrudeLocationID { get; set; }
        public string Country { get; set; }
        public string Region { get; set; }
        public int? CrudeTypeID { get; set; }
        public int? ChemicalClassID { get; set; }
        public float? APIMSR { get; set; }
        public float? SulfurMSR { get; set; }
        public string SulfurType { get; set; }
        public string ActiveIndicator { get; set; }
        public double? SpecificGravity { get; set; }
    }
}
