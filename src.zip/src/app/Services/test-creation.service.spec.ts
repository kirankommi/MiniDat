import { TestBed, inject } from '@angular/core/testing';

import { TestCreationService } from './test-creation.service';

describe('TestCreationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TestCreationService]
    });
  });

  it('should be created', inject([TestCreationService], (service: TestCreationService) => {
    expect(service).toBeTruthy();
  }));
});
