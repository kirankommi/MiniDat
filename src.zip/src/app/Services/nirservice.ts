import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { HttpActionService } from "./httpaction.service";
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class NIRService {
    private getNIRdata = "/NIR/GetNIRData/";
    constructor(private httpaction: HttpActionService) { }
    getNIRInformation(templateId: any) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateId', templateId);     
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getNIRdata, options);
    }

}