import { Component, OnInit, Input, DebugElement } from '@angular/core';
import { ReciepeService } from '../../../../Services/reciepeservice';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-reciepes',
  templateUrl: './Reciepes.component.html',
  providers: [ReciepeService, AlertMessage, HttpActionService, ConfirmationService]
})
export class ReciepesComponent implements OnInit {
  recData: any;
  cols: any = [];
  recCols = [];
  sub: any;
  templateId: number;
  frozenCols: any[]=[];
  scrollableCols: any[]=[];
  mode: any;
  innerHeight: number = 0;

  constructor(private recService: ReciepeService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.setInnerWidthHeightParameters();
    this.sub = this.route.params.subscribe(params => {
      this.templateId = params['field'];
    });
 
    this.getReciepesData();
  }

  getReciepesData() {
    this.recService.getReciepeInformation(this.templateId)
      .subscribe(
        (data: any) => {
          this.recData = data.filter(d => d.MODE_ID_SQ != this.templateId);
          this.mode = data.filter(d => d.MODE_ID_SQ == this.templateId);

          // let recCount= this.mode[0]["CONDITION"] * this.mode[0]["NUM_0F_WC"];
          // let columns: any=[];
          // columns = Object.keys(this.recData[0]);

          //   for(let element of columns) {
          //     this.cols.push(element);
          //     if(element == 'Weight Check ' + recCount) break;
          //  }
          this.cols = Object.keys(this.recData[0]);
          this.cols.splice(2, 0, 'UOM');
          for (let index = 0; index < 3; index++) {
            this.frozenCols.push(this.cols[index])
            
          }
          for (let index = 3; index < this.cols.length; index++) {
            this.scrollableCols.push(this.cols[index])
            
          }
          this.generateRCP();
        },
        err => { }
      );
  }
  setInnerWidthHeightParameters() {
    this.innerHeight = window.innerHeight * 0.55;
  }
  getUnit(vCol: any) {
    console.log(vCol);
    return 'hello';
  }
  generateRCP() {
    // let recCount= (this.mode[0]["CONDITION"] * this.mode[0]["NUM_0F_WC"]) ;
    let recCount = this.cols.length;

    for (let index = 1; index <= recCount; index++) {
      if (index < 4) {
        this.recCols.push("");
      }
      else {
        this.recCols.push("RCP #" + (index - 3));
      }
    }
  }

}
