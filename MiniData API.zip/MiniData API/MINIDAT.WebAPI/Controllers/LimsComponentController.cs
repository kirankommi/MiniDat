﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	LimsComponentController.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	22 May 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using MINIDAT.Model.Manage.LimsComponent;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class LimsComponentController : AppController
    {
        public LimsComponentController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage LIMS Component" }));
        }
        ILimsComponentRepository _limsComponentFactory = new LimsComponentRepository(new MINIDATDatabase());
        /// <summary>
        /// Gete Lims Component Data
        /// </summary>
        /// <param name="limsAnalysisMethod"></param>
        /// <returns></returns>
        [HttpGet, ActionName("GetLIMSAnalysisMethodComponentData")]
        public LIMSAnalysisComponentSearchModel GetLIMSAnalysisComponentData([FromUri] LIMSAnalysisMethodComponentModel limsAnalysisMethod)
        {
            if (limsAnalysisMethod != null)
            {
                // var limsAnalysisMethodDB = new LIMSAnalysisMethodDataAccess(); 
                //   var limsComponentList = limsAnalysisMethodDB.GetLIMSAnalysisComponentData(limsAnalysisMethod);
                limsAnalysisMethod.FDMSComponent = System.Web.HttpUtility.UrlDecode(limsAnalysisMethod.FDMSComponent);
                limsAnalysisMethod.LIMSComponent = System.Web.HttpUtility.UrlDecode(limsAnalysisMethod.LIMSComponent);
                limsAnalysisMethod.LIMSOperationName= System.Web.HttpUtility.UrlDecode(limsAnalysisMethod.LIMSOperationName);

                IList<LIMSAnalysisMethodComponentModel> limsComponentList = _limsComponentFactory.GetLIMSAnalysisComponentData(limsAnalysisMethod, User.Identity.Name);
                var test = new LIMSAnalysisComponentSearchModel();
                test.LIMSAnalysisComponentFilter = limsAnalysisMethod;
                test.LIMSAnalysisComponentList.Clear();
                ((List<LIMSAnalysisMethodComponentModel>)test.LIMSAnalysisComponentList).AddRange(limsComponentList);
                return test;
            }
            else
            {
                return null;
            }
        }

        [HttpGet, ActionName("GetLIMSAnalysisMethodComponentBindUOM")]
        public IList<GetLIMSAnalysisMethodComponentBindUOMModel> GetLIMSAnalysisMethodComponentBindUOM([FromUri] LIMSAnalysisMethodComponentModel limsAnalysisMethod)
        {
            if (limsAnalysisMethod != null)
            { 

                IList<GetLIMSAnalysisMethodComponentBindUOMModel> limsComponentList = _limsComponentFactory.GetLIMSAnalysisMethodComponentBindUOM( User.Identity.Name);
                 return limsComponentList;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Save lims component data
        /// </summary>
        /// <param name="LIMSComponent"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SaveLIMSAnalysisMethodComponent"), HttpOptions,]
        public HttpResponseMessage SaveComponent([FromBody] LIMSAnalysisMethodComponentModel LIMSComponent)
        {
            string msg = "Success";
            if (Request.Method.Method == "POST" && LIMSComponent != null)
            {

                try
                {
                    //Call the Save function here.
                    // new LIMSAnalysisMethodDataAccess().SaveLIMSComponent(LIMSComponent, User.Identity.Name);
                    _limsComponentFactory.SaveLIMSComponent(LIMSComponent, User.Identity.Name);
                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, msg);

        }
        /// <summary>
        /// delete lims component 
        /// </summary>
        /// <param name="LIMSMethod"></param>
        /// <returns></returns>
        [HttpPost, ActionName("DeleteComponentData"), HttpOptions,]
        public HttpResponseMessage DeleteComponent([FromBody] LIMSAnalysisMethodComponentModel LIMSMethod)
        {
            if (Request.Method.Method == "POST" && LIMSMethod != null)
            {

                try
                {
                    //Call the Save function here.
                    // new LIMSAnalysisMethodDataAccess().DeleteLIMSComponent(LIMSMethod);
                    _limsComponentFactory.DeleteLIMSComponent(LIMSMethod);

                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }

       
        [HttpGet, ActionName("Limsoperation")]
        //public HttpResponseMessage GetOperation(LIMSAnalysisMethodComponentModel filter)
        public IList<LIMSAnalysisMethodComponentModel> GetOperation([FromUri] LIMSAnalysisMethodComponentModel filter)
        {
            if (filter != null)
            {
                IList<LIMSAnalysisMethodComponentModel> limsOperation = _limsComponentFactory.GetOperations(filter);
                return limsOperation;
                // return this.Request.CreateResponse(System.Net.HttpStatusCode.OK, new { list = new LookUPDataAccess().GetOperations(filter), TotalRecords = filter.TotalRecords, UOMGroupList = filter.UOMGroupList });
            }
            else {
                return null;
            }

        }
        [HttpGet, ActionName("MINIDTRunLIMSOperations")]
        //public HttpResponseMessage GetOperation(LIMSAnalysisMethodComponentModel filter)
        public IList<LIMSAnalysisMethodComponentModel> GetLIMSOperationsList([FromUri] LIMSAnalysisMethodComponentModel filter)
        {
            if (filter != null)
            {
                IList<LIMSAnalysisMethodComponentModel> limsOperation = _limsComponentFactory.GetLIMSOperationsList(filter);
                return limsOperation;
                // return this.Request.CreateResponse(System.Net.HttpStatusCode.OK, new { list = new LookUPDataAccess().GetOperations(filter), TotalRecords = filter.TotalRecords, UOMGroupList = filter.UOMGroupList });
            }
            else
            {
                return null;
            }

        }

        [HttpGet, ActionName("Limscomponent")]
        //public HttpResponseMessage GetOperation(LIMSAnalysisMethodComponentModel filter)
        public IList<FDMSComponent> GetComponent([FromUri] FDMSComponent filter)
        {
            if (filter != null)
            {
                IList<FDMSComponent> limsOperation = _limsComponentFactory.GetComponent(filter);
                return limsOperation;
                // return this.Request.CreateResponse(System.Net.HttpStatusCode.OK, new { list = new LookUPDataAccess().GetOperations(filter), TotalRecords = filter.TotalRecords, UOMGroupList = filter.UOMGroupList });
            }
            else
            {
                return null;
            }

        }
        
    }
}
