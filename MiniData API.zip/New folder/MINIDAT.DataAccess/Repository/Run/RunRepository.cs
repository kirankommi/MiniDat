﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using MINIDAT.Model.Run;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Globalization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace MINIDAT.DataAccess.Repository.Project
{
    public class RunRepository : IRunRepository
    {

        private IDatabase _db;
        public RunRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public List<NIRModel> GetNIRModelInformation(string Plant_cd, int ModeId)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<NIRModel> listNIRModel = new List<NIRModel>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.GetNIRSpecMasterData"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);                   
                    parameters.Add("proc_in_Mode_Id", ModeId);                   

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);                    
                    while (objSqlDr.Read())
                    {
                        NIRModel objNIRModel = new NIRModel();
                        objNIRModel.Parameter = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objNIRModel.Value = Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objNIRModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);                        
                        listNIRModel.Add(objNIRModel);
                    }
                }              
                return listNIRModel;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<ProcessSpecModel> GetProcessSpecInformation(string Plant_cd, string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<ProcessSpecModel> lstProcessSpec = new List<ProcessSpecModel>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.[GetProcessSpecData]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);

                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        ProcessSpecModel objProcessSpecModel= new ProcessSpecModel();
                        objProcessSpecModel.ParameterId = Convert.ToInt32(objSqlDr["PROCESS_SPEC_PARAMETER_ID"]);
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.RecordSet = Convert.ToString(objSqlDr["RECORDSET"]);
                        objProcessSpecModel.IsEditable = ((Convert.ToString(objSqlDr["MODIFY_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.IsModeVariable = ((Convert.ToString(objSqlDr["MODE_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.DisplayOrder = Convert.ToInt32(objSqlDr["DISPLAY_ORDER_NUM"]);
                        lstProcessSpec.Add(objProcessSpecModel);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        ProcessSpecModel objProcessSpecModel = new ProcessSpecModel();
                        objProcessSpecModel.ParameterId = Convert.ToInt32(objSqlDr["PROCESS_SPEC_PARAMETER_ID"]);
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.RecordSet = Convert.ToString(objSqlDr["RECORDSET"]);
                        objProcessSpecModel.IsEditable = ((Convert.ToString(objSqlDr["MODIFY_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.IsModeVariable = ((Convert.ToString(objSqlDr["MODE_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.DisplayOrder = Convert.ToInt32(objSqlDr["DISPLAY_ORDER_NUM"]);
                        lstProcessSpec.Add(objProcessSpecModel);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        ProcessSpecModel objProcessSpecModel = new ProcessSpecModel();
                        objProcessSpecModel.ParameterId = Convert.ToInt32(objSqlDr["PROCESS_SPEC_PARAMETER_ID"]);
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.RecordSet = Convert.ToString(objSqlDr["RECORDSET"]);
                        objProcessSpecModel.IsEditable = ((Convert.ToString(objSqlDr["MODIFY_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.IsModeVariable = ((Convert.ToString(objSqlDr["MODE_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.DisplayOrder = Convert.ToInt32(objSqlDr["DISPLAY_ORDER_NUM"]);
                        lstProcessSpec.Add(objProcessSpecModel);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        ProcessSpecModel objProcessSpecModel = new ProcessSpecModel();
                        objProcessSpecModel.ParameterId = Convert.ToInt32(objSqlDr["PROCESS_SPEC_PARAMETER_ID"]);
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.RecordSet = Convert.ToString(objSqlDr["RECORDSET"]);
                        objProcessSpecModel.IsEditable = ((Convert.ToString(objSqlDr["MODIFY_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.IsModeVariable = ((Convert.ToString(objSqlDr["MODE_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.DisplayOrder = Convert.ToInt32(objSqlDr["DISPLAY_ORDER_NUM"]);
                        lstProcessSpec.Add(objProcessSpecModel);
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        ProcessSpecModel objProcessSpecModel = new ProcessSpecModel();
                        objProcessSpecModel.ParameterId = Convert.ToInt32(objSqlDr["PROCESS_SPEC_PARAMETER_ID"]);
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.RecordSet = Convert.ToString(objSqlDr["RECORDSET"]);
                        objProcessSpecModel.IsEditable = ((Convert.ToString(objSqlDr["MODIFY_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.IsModeVariable = ((Convert.ToString(objSqlDr["MODE_IND"]) == "Y") ? true : false);
                        objProcessSpecModel.DisplayOrder = Convert.ToInt32(objSqlDr["DISPLAY_ORDER_NUM"]);
                        lstProcessSpec.Add(objProcessSpecModel);
                    }

                }
                return lstProcessSpec;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<AnalyticalInfoModel> GetAnalyticalSampleInformation(string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<AnalyticalInfoModel> lstAnalyticalSamples = new List<AnalyticalInfoModel>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.[GetRunAnalyticalInfo]"))
                {
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        AnalyticalInfoModel objAnalyticalSampleInfo = new AnalyticalInfoModel();
                        objAnalyticalSampleInfo.StreamId = Convert.ToInt32(objSqlDr["STREAM_ID"]);
                        objAnalyticalSampleInfo.StreamName = Convert.ToString(objSqlDr["STREAM_NM"]);
                        objAnalyticalSampleInfo.LIMSOPerationId = Convert.ToInt32(objSqlDr["LIMS_OPERATION_ID"]);
                        objAnalyticalSampleInfo.LIMSOPerationName = Convert.ToString(objSqlDr["LIMS_OPERATION_NM"]);
                        objAnalyticalSampleInfo.MethodNumber = Convert.ToString(objSqlDr["ANALYSIS_METHOD_NUM"]);
                        objAnalyticalSampleInfo.SampleVolumeinCC = Convert.ToString(objSqlDr["SAMPLE_VOLUME_MSR"]);
                        objAnalyticalSampleInfo.SampleCost = Convert.ToDouble(objSqlDr["SAMPLE_COST_MSR"]);
                        objAnalyticalSampleInfo.FrequencyName = Convert.ToString(objSqlDr["FREQENCY_NM"]); 
                        lstAnalyticalSamples.Add(objAnalyticalSampleInfo);
                    }
                }
                return lstAnalyticalSamples;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<BoilingPointModel> GetRunCutBoilingPointsInfo(string Plantcd,string runID, string ModeType)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<BoilingPointModel> listRunCutBolingPoints = new List<BoilingPointModel>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.[GetRunCutBoilingPointsInfo]"))
                {                   
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plantcd)) ? (object)null : Plantcd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);
                    parameters.Add("proc_vr_Mode_Type_cd", string.IsNullOrEmpty(Convert.ToString(ModeType)) ? (object)null : ModeType);
                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                            BoilingPointModel objRunboilingPoint = new BoilingPointModel();
                            objRunboilingPoint.InitialBoilingPoint = Convert.ToDouble(objSqlDr["IBP_MSR"]);
                            objRunboilingPoint.EndBoilingPoint = Convert.ToDouble(objSqlDr["END_POINT_MSR"]);
                            objRunboilingPoint.YieldCutLabel = Convert.ToString(objSqlDr["YIELD_CUT_LABEL_TXT"]);
                            objRunboilingPoint.RowId = Convert.ToInt32(objSqlDr["ROW_NUM"]);
                            listRunCutBolingPoints.Add(objRunboilingPoint);
                    }
                }
                return listRunCutBolingPoints;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<AnalyticalInfoModel> GetAnalyticalSamplingInfo(string Plant_cd, string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<AnalyticalInfoModel> listAnalyticalSamples = new List<AnalyticalInfoModel>();
                IDataReader objSqlDr = null;               
                using (IDbCommand command = _db.CreateCommand("md.GetRunAnalyticalInfo"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);

                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        AnalyticalInfoModel objanalyticalInfo = new AnalyticalInfoModel();
                        objanalyticalInfo.RowId = Convert.ToInt32(objSqlDr["RowId"]);
                        objanalyticalInfo.StreamName = Convert.ToString(objSqlDr["STREAM_NM"]);
                        objanalyticalInfo.StreamId = Convert.ToInt32(objSqlDr["STREAM_ID"]);
                        objanalyticalInfo.LIMSOPerationId = Convert.ToInt32(objSqlDr["LIMS_OPERATION_ID"]);
                        objanalyticalInfo.LIMSOPerationName = Convert.ToString(objSqlDr["LIMS_OPERATION_NM"]);
                        objanalyticalInfo.MethodNumber = Convert.ToString(objSqlDr["ANALYSIS_METHOD_NUM"]);
                        objanalyticalInfo.SampleCost = (objSqlDr["SAMPLE_COST_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["SAMPLE_COST_MSR"]);
                        objanalyticalInfo.SampleVolumeinCC = Convert.ToString(objSqlDr["SAMPLE_VOLUME_MSR"]);
                        objanalyticalInfo.FrequencyName = Convert.ToString(objSqlDr["FREQENCY_NM"]);
                        objanalyticalInfo.DataSetType = Convert.ToString(objSqlDr["DATASET"]);
                        listAnalyticalSamples.Add(objanalyticalInfo);
                    }
                }
                return listAnalyticalSamples;
                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public FeedModel GetFeedInfo(string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                FeedModel objFeed = new FeedModel();
                IDataReader objSqlDr = null;                
                return objFeed;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public GeneralInfoModel GetGeneralInfo(string Plant_cd,string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                GeneralInfoModel objGeneralInfo = new GeneralInfoModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.GetGeneralInformation"))
                {

                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID); 
                                      
                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        objGeneralInfo.Technician1 = Convert.ToString(objSqlDr["TECHNICIAN1_NM"]);
                        objGeneralInfo.Technician1EID = Convert.ToString(objSqlDr["TECH1_EID"]);
                        objGeneralInfo.Technician2 = Convert.ToString(objSqlDr["TECHNICIAN2_NM"]);
                        objGeneralInfo.Technician2EID = Convert.ToString(objSqlDr["TECH2_EID"]);
                        objGeneralInfo.RunDescription = Convert.ToString(objSqlDr["RUN_DESCRIPTION"]);
                    }
                }                               
                return objGeneralInfo;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public RunSetUpMetaData GetRunMetaData(string Plant_cd, string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                RunSetUpMetaData objRun = new RunSetUpMetaData();
                objRun.Plant = Convert.ToInt32(Plant_cd);
                objRun.RunId = Convert.ToInt32(runID);
                objRun.lstDoeCataystinfo = new List<Model.DOE.DOEBed>();

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.Get_RunSetup_MetaData_Sp"))
                {

                    IDictionary parameters = new Dictionary<string, object>();
                    //parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    //Run Metadata
                    while (objSqlDr.Read())
                    {
                        objRun.RunNum = Convert.ToInt32(objSqlDr["RunNum"]);
                        objRun.StartDate = DBNull.Value != objSqlDr["StartDate"] ? Convert.ToDateTime(objSqlDr["StartDate"]) : default(DateTime?);
                        objRun.ZeroHOSTime = DBNull.Value != objSqlDr["ZERO_HOS_TM"] ? Convert.ToDateTime(objSqlDr["ZERO_HOS_TM"]): default(DateTime?);
                        objRun.PlantLocation = Convert.ToString(objSqlDr["LOCATION_NM"]);
                        objRun.EndTime = objSqlDr["EndDate"] != DBNull.Value ? Convert.ToDateTime(objSqlDr["EndDate"]): default(DateTime?);
                        objRun.RunStatus = Convert.ToString(objSqlDr["STATUS"]);
                        objRun.ProjectMgr = Convert.ToString(objSqlDr["Manager"]);
                        objRun.NetworkNumber = Convert.ToString(objSqlDr["NetworkNUM"]);
                        objRun.NIRModelID = Convert.ToString(objSqlDr["ModelId"]);
                        objRun.NIRNetConv_High = (objSqlDr["NetCoverHigh"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["NetCoverHigh"]);
                        objRun.NIRNetConv_Low = (objSqlDr["NetCoverLow"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["NetCoverLow"]);
                    }

                    //Mode Metadata
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        objRun.ModeId = DBNull.Value != objSqlDr["MODE_ID"] ? Convert.ToInt32(objSqlDr["MODE_ID"]) : default(int?);
                        objRun.ModeType = Convert.ToString(objSqlDr["ModeType"]);
                        objRun.ModeLHSV = (objSqlDr["LHSV"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["LHSV"]);
                        objRun.ModeSCFB = (objSqlDr["SCFB"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["SCFB"]);
                        objRun.ModePressure = (objSqlDr["PRESSURE"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PRESSURE"]);
                        objRun.SulfidingType = (objSqlDr["SULFIDING_TYPE_ID"] == DBNull.Value) ? (Int32?)null : Convert.ToInt32(objSqlDr["SULFIDING_TYPE_ID"]);
                    }

                    //Feed Metadata
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        objRun.FeedId = DBNull.Value != objSqlDr["ID"] ? Convert.ToInt32(objSqlDr["ID"]) : default(int?);
                        objRun.FeedDensity = objSqlDr["DENSITY_MSR"].FormatDouble();
                        objRun.FeedCondition = Convert.ToBoolean(objSqlDr["HasDopant"]);
                    }

                    //Catalyst Volume
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        objRun.CatalystVolume = objSqlDr["CATALYST_VOLUME"].FormatDouble();
                    }

                    //FeedISCO if it is a riverside plant
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        objRun.FeedISCOTemp = objSqlDr["DENSITY_MSR"].FormatDouble();
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        Model.DOE.DOEBed objcatalystbed = new Model.DOE.DOEBed();
                        objcatalystbed.BedNumber = Convert.ToInt32(objSqlDr["BED_NUM"]);
                        objcatalystbed.CatalystVolume = Convert.ToDecimal(objSqlDr["CATALYST_VOLUME_MSR"]);
                        objcatalystbed.Split = Convert.ToInt32(objSqlDr["SPLIT_NM"]);
                        objcatalystbed.DiluentDesignation = Convert.ToString(objSqlDr["DILUENT_NM"]);
                        objcatalystbed.DiluentVolume = Convert.ToDecimal(objSqlDr["DILUENT_VOLUME_MSR"]);
                        objcatalystbed.DiluentID = Convert.ToInt32(objSqlDr["DILUENT_ID"]);
                        objcatalystbed.Catalyst = new Model.Catalyst.CatalystLite();
                        objcatalystbed.Catalyst.CatalystId = Convert.ToInt32(objSqlDr["CATALYST_ID"]);
                        objcatalystbed.Catalyst.CatalystDesignation = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]);
                        objRun.lstDoeCataystinfo.Add(objcatalystbed);
                    }

                   
                }
                return objRun;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public void SaveRunInformation(RunModel run,string userId)
        { 
            try
            {
                if (string.IsNullOrEmpty(userId) || run == null)
                {
                    return;
                }
                if (run.AdditionalInfo.SelectedFeedSource == null)
                {
                    run.AdditionalInfo.SelectedFeedSource = "AAA";
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                string xmlData = Serializer.ConvertToXML<RunModel>(run);
                IDbCommand command = _db.CreateCommand("[md].Insert_Update_Run_Information");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();                    
                    parameters.Add("proc_run_xml", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);                  
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            //throw new NotImplementedException();
        }
        public void SaveRunFeedInformation(GeneralInfoModel feed)
        {
            string xmlData = Serializer.ConvertToXML<GeneralInfoModel>(feed);
            throw new NotImplementedException();
        }
        public RunMasterDataModel GetRunMasterDetails(string Plant_cd, string Mode_Type)
        {
            try
            {
                #region setting up DBCommand with parameters
                RunMasterDataModel mstr = new RunMasterDataModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.GetTechnicianList"))
                {

                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Mode_Type", string.IsNullOrEmpty(Convert.ToString(Mode_Type)) ? (object)null : Mode_Type);


                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);

                    mstr.Technicians = new List<KeyValue>();   
                    while (objSqlDr.Read())
                    {
                        KeyValue objtechnician = new KeyValue();
                        objtechnician.Key = Convert.ToString(objSqlDr["EMPLOYEE_ID"]);
                        objtechnician.Value = Convert.ToString(objSqlDr["TECHNICIAN"]);
                        mstr.Technicians.Add(objtechnician);
                    }

                    objSqlDr.NextResult();
                    mstr.lstStreams = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objstream = new KeyValue();
                        objstream.Key = Convert.ToString(objSqlDr["SIZE_CD"]);
                        objstream.Value = Convert.ToString(objSqlDr["SIZE_NM"]);
                        mstr.lstStreams.Add(objstream);                  
                    }

                    objSqlDr.NextResult();
                    mstr.LstAnalysisMethods = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objanalysisMethod = new KeyValue();
                        objanalysisMethod.Key = Convert.ToString(objSqlDr["SHAPE_CD"]);
                        objanalysisMethod.Value = Convert.ToString(objSqlDr["SHAPE_NM"]);
                        mstr.LstAnalysisMethods.Add(objanalysisMethod);
                    }

                    objSqlDr.NextResult();
                    mstr.LstLoadingDensiyTypes = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objloadingDensiyType = new KeyValue();
                        objloadingDensiyType.Key = Convert.ToString(objSqlDr["LOAD_DENSITY_TYPE_CD"]);
                        objloadingDensiyType.Value = Convert.ToString(objSqlDr["LOAD_DENSITY_TYPE_NM"]);
                        mstr.LstLoadingDensiyTypes.Add(objloadingDensiyType);
                    }

                    objSqlDr.NextResult();
                    mstr.LstNormalizationFactors = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objFactorName = new KeyValue();
                        objFactorName.Key = Convert.ToString(objSqlDr["FACTOR_CD"]);
                        objFactorName.Value = Convert.ToString(objSqlDr["FACTOR_NM"]);
                        mstr.LstNormalizationFactors.Add(objFactorName);
                    }

                    objSqlDr.NextResult();
                    mstr.LstFeedSource = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objloadingDensityType = new KeyValue();
                        objloadingDensityType.Key = Convert.ToString(objSqlDr["SOURCE_CD"]);
                        objloadingDensityType.Value = Convert.ToString(objSqlDr["SOURCE_NM"]);
                        mstr.LstFeedSource.Add(objloadingDensityType);
                    }

                    objSqlDr.NextResult();
                    mstr.LstStdBoilingPoints = new List<BoilingPointModel>();
                    while (objSqlDr.Read())
                    {
                        BoilingPointModel objStdboilingPoint = new BoilingPointModel();
                        objStdboilingPoint.RowId = Convert.ToInt32(objSqlDr["ROW_NUM"]);
                        objStdboilingPoint.InitialBoilingPoint = Convert.ToDouble(objSqlDr["IBP_MSR"]);
                        objStdboilingPoint.EndBoilingPoint = Convert.ToDouble(objSqlDr["END_POINT_MSR"]);
                        objStdboilingPoint.YieldCutLabel = Convert.ToString(objSqlDr["YIELD_CUT_LABEL_TXT"]);
                        mstr.LstStdBoilingPoints.Add(objStdboilingPoint);
                    }
                    objSqlDr.NextResult();
                    mstr.LstStreams = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objStream = new KeyValue();
                        objStream.Key = Convert.ToString(objSqlDr["STREAM_ID_SQ"]);
                        objStream.Value = Convert.ToString(objSqlDr["STREAM_NM"]);
                        mstr.LstStreams.Add(objStream);
                    }
                    objSqlDr.NextResult();
                    mstr.LstFrequency = new List<KeyValue>();
                    while (objSqlDr.Read())
                    {
                        KeyValue objFrequency = new KeyValue();
                        objFrequency.Key = Convert.ToString(objSqlDr["FREQ_CD"]);
                        objFrequency.Value = Convert.ToString(objSqlDr["FREQ_NM"]);
                        mstr.LstFrequency.Add(objFrequency);
                    }

                    objSqlDr.NextResult();
                    mstr.lstFlyoutFeeds = new List<Model.Manage.FeedInfo>();
                    while (objSqlDr.Read())
                    {
                        mstr.lstFlyoutFeeds.Add(new Model.Manage.FeedInfo()
                        {
                            ID = Convert.ToInt32(objSqlDr["FEED_ID_SQ"]),
                            Name = Convert.ToString(objSqlDr["FEED_NM"]),
                            Desc = Convert.ToString(objSqlDr["FEED_DESC"]),
                            BookNum = Convert.ToString(objSqlDr["FEED_BOOK_NUM"]),
                            UOPNum = Convert.ToString(objSqlDr["FEED_UOP_NUM"])                           
                        });
                    }
                }
                return mstr;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public RunCatalystSearchModel GetRunCatalystDetails(string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                RunCatalystSearchModel mstr = new RunCatalystSearchModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.Get_RunCatalyst_Infromation"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);
                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);              
                    while (objSqlDr.Read())
                    {
                        RunCatalyst cat = new RunCatalyst
                        {
                            CatalystIdSQ = Convert.ToInt32(objSqlDr["CATALYST_ID"]),
                            CatalystId = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]),
                            CatalystDescription = Convert.ToString(objSqlDr["CATALYST_DESC"]),                           
                            CatalystFamilyName = Convert.ToString(objSqlDr["FAMILY_NAME"]),
                            CatalystShape = Convert.ToString(objSqlDr["CATALYST_SHAPE_NM"]),
                            CatalystSize = Convert.ToString(objSqlDr["CATALYST_SIZE_CD"]),
                            Crushed = Convert.ToString(objSqlDr["GROUND_IND"]) == "Y" ? "Yes" : "No",
                            CalculatedBedDensity = (objSqlDr["APPARENT_BED_DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["APPARENT_BED_DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["APPARENT_BED_DENSITY_MSR"]),
                            VibratedBedDensity = (objSqlDr["VIBRATED_BED_DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["VIBRATED_BED_DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["VIBRATED_BED_DENSITY_MSR"]),
                            CustomBedDensity = (objSqlDr["CUSTOM_DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["CUSTOM_DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["CUSTOM_DENSITY_MSR"]),                          
                            PieceDensity = (objSqlDr["PIECE_DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["PIECE_DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["PIECE_DENSITY_MSR"]),                           
                            Voidfraction = (objSqlDr["VOID_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VOID_FRACTION_MSR"]),
                            LoadingDensityType = new KeyValue() { Key = objSqlDr["LOAD_DENSITY_TYPE_NM"].ToString(), Value = objSqlDr["LOAD_DENSITY_TYPE_NM"].ToString() },
                            LoadingDensityTypeName = Convert.ToString(objSqlDr["LOAD_DENSITY_TYPE_NM"])

                        };
                        mstr.LstCatalysts.Add(cat);
                    }

                    objSqlDr.NextResult();                 
                    while (objSqlDr.Read())
                    {
                        BedDetails bed = new BedDetails()
                        {
                            BedNumber = Convert.ToInt32(objSqlDr["BED_NUM"]),
                            CatalystId = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]),                            
                            Split = Convert.ToInt32(objSqlDr["SPLIT_NM"]),
                            DiluentDesignation = Convert.ToString(objSqlDr["DILUENT_NM"]),
                            DiluentVolume = (objSqlDr["DILUENT_VOLUME_MSR"] == DBNull.Value) ? (double?)null : Math.Round(Convert.ToDouble(objSqlDr["DILUENT_VOLUME_MSR"]),2),
                            CatalystVolume = (objSqlDr["CATALYST_VOLUME_MSR"] == DBNull.Value) ? (double?)null : Math.Round(Convert.ToDouble(objSqlDr["CATALYST_VOLUME_MSR"]),2)                         
                        };
                        mstr.LstBeds.Add(bed);
                    }
                }
                return mstr;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<TC_Calibration> GetTCCalibrationInformation(string Plant_cd, string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<TC_Calibration> listTCCalibration = new List<TC_Calibration>();
                IDataReader objSqlDr = null;               
                using (IDbCommand command = _db.CreateCommand("md.Get_Run_TC_Spec_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_in_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);
                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        TC_Calibration objTCCalibration = new TC_Calibration();
                        objTCCalibration.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objTCCalibration.Value = (objSqlDr["PARAM_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAM_VALUE_MSR"]);
                        objTCCalibration.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objTCCalibration.ParameterType = Convert.ToString(objSqlDr["PARAMETER_TYPE"]);
                        objTCCalibration.OffSetNum = (objSqlDr["OFFSET_NUM"] == DBNull.Value) ? (Int32?)null : Convert.ToInt32(objSqlDr["OFFSET_NUM"]);
                        //objTCCalibration.CalibrationchangeDate = Convert.ToString(objSqlDr["PARAM_VALUE_TXT"]);
                        objTCCalibration.CalibrationDate = (objSqlDr["PARAM_VALUE_TXT"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(objSqlDr["PARAM_VALUE_TXT"]);
                        listTCCalibration.Add(objTCCalibration);                  
                    }
                }
                return listTCCalibration;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<TMF_Calibration> GetTMFCalibrationInformation(string Plant_cd, string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<TMF_Calibration> lstTMFCalibration = new List<TMF_Calibration>();
                IDataReader objSqlDr = null;                
                using (IDbCommand command = _db.CreateCommand("md.GetTMFCalibrationInformation"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);
                    _db.CreateParameters(command, parameters);

                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        TMF_Calibration objTMFCalibration = new TMF_Calibration();
                        objTMFCalibration.Parameter = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objTMFCalibration.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objTMFCalibration.ParameterUOM = Convert.ToString(objSqlDr["PARAMETER_NM"]);                        
                        lstTMFCalibration.Add(objTMFCalibration);
                    }
                }
                return lstTMFCalibration;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public AdditionalInfoModel GetAdditionalInfo(string Plant_cd, string runID)
        {            
            try
            {
                #region setting up DBCommand with parameters
                AdditionalInfoModel objAdditionalInfo = new AdditionalInfoModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.GetRunAdditionalInformation"))
                {

                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_plant_cd", string.IsNullOrEmpty(Convert.ToString(Plant_cd)) ? (object)null : Plant_cd);
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        objAdditionalInfo.SelectedNormalizationFactor = Convert.ToString(objSqlDr["NORMALIZATION_FACTOR"]);
                        objAdditionalInfo.H2TMFSpec = (objSqlDr["H2_TMF_PV_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["H2_TMF_PV_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["H2_TMF_PV_MSR"]);
                        objAdditionalInfo.SelectedFeedSource = Convert.ToString(objSqlDr["FEED_CALCULATION_SOURCE_CD"]);
                        objAdditionalInfo.HPSControllerOffset = (objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"]); 
                        objAdditionalInfo.OffgasHeaviesWeight = (objSqlDr["OFFGAS_HEAVIES_WT_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["OFFGAS_HEAVIES_WT_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["OFFGAS_HEAVIES_WT_MSR"]);
                        objAdditionalInfo.PlantTCOffset = (objSqlDr["PLANT_TC_OFFSET_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["PLANT_TC_OFFSET_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["PLANT_TC_OFFSET_MSR"]);
                    }
                }
                return objAdditionalInfo;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public FeedModel GetSavedRunFeedDetails(string runID)
        {
            try
            {
                #region setting up DBCommand with parameters
                FeedModel objRunFeed = new FeedModel();
                objRunFeed.Blendcomponents = new List<FeedBlend>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.Get_SavedRunFeed_Infromation"))
                {
                    IDictionary parameters = new Dictionary<string, object>();                   
                    parameters.Add("proc_vr_Run_Id", string.IsNullOrEmpty(Convert.ToString(runID)) ? (object)null : runID);
                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        objRunFeed.API = (objSqlDr["API_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["API_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["API_MSR"]);
                        objRunFeed.UOPNumber = Convert.ToString(objSqlDr["UOP_NUM"]);
                        objRunFeed.Name = Convert.ToString(objSqlDr["FEED_NM"]);
                        objRunFeed.FeedID = Convert.ToInt32(objSqlDr["FEED_ID"]);
                        objRunFeed.RelativeDensity = (objSqlDr["RELATIVE_DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["RELATIVE_DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["RELATIVE_DENSITY_MSR"]);
                        objRunFeed.H2InFeed = (objSqlDr["H2_IN_FEED_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["H2_IN_FEED_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["H2_IN_FEED_MSR"]);
                        objRunFeed.SulfurInSweetFeed = (objSqlDr["S_IN_SWEETFEED"] == DBNull.Value || Convert.ToDouble(objSqlDr["S_IN_SWEETFEED"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["S_IN_SWEETFEED"]);
                        objRunFeed.NitrogenInSweetFeed = (objSqlDr["N_IN_SWEETFEED"] == DBNull.Value || Convert.ToDouble(objSqlDr["N_IN_SWEETFEED"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["N_IN_SWEETFEED"]);
                        objRunFeed.SulfurInFeedBlend = (objSqlDr["S_IN_FEEDBLEND"] == DBNull.Value || Convert.ToDouble(objSqlDr["S_IN_FEEDBLEND"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["S_IN_FEEDBLEND"]);
                        objRunFeed.NitrogenInFeedBlend = (objSqlDr["N_IN_FEEDBLEND"] == DBNull.Value || Convert.ToDouble(objSqlDr["N_IN_FEEDBLEND"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["N_IN_FEEDBLEND"]);
                        objRunFeed.Density = (objSqlDr["DENSITY_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["DENSITY_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["DENSITY_MSR"]);                    
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        FeedBlend Objblend = new FeedBlend()
                        {
                            ComponentName = Convert.ToString(objSqlDr["COMPONENT_NM"]),
                            UOPNumber = Convert.ToString(objSqlDr["UOP_NUM"]),
                            Amountadded = (objSqlDr["WEIGHT_MSR"] == DBNull.Value || Convert.ToDecimal(objSqlDr["WEIGHT_MSR"]) == 0) ? (decimal?)null : Convert.ToDecimal(objSqlDr["WEIGHT_MSR"]),
                            Weightpct = (objSqlDr["WEIGHT_PERCENT"] == DBNull.Value || Convert.ToDecimal(objSqlDr["WEIGHT_PERCENT"]) == 0) ? (decimal?)null : Convert.ToDecimal(objSqlDr["WEIGHT_PERCENT"])
                        };
                        objRunFeed.Blendcomponents.Add(Objblend);
                    }
                }
                return objRunFeed;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<dynamic> getReciepesTemplateData(string runId)
        {
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_Recipe_RunSetup_Values_sp]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("@runid", runId);

                _db.CreateParameters(command, parameters);

                using (reader = _db.ExecuteReader(command))
                {
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<dynamic> getModeMasterData(string mode)
        {
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_RECIEPE_ModeTemplateValues_sp]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("@mode", mode);

                _db.CreateParameters(command, parameters);

                using (reader = _db.ExecuteReader(command))
                {
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }
                }
            }
        }

        private dynamic GetDynamicData(IDataReader reader)
        {
            var expandoObject = new ExpandoObject() as IDictionary<string, object>;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                expandoObject.Add(reader.GetName(i), reader[i]);
            }
            return expandoObject;
        }

        public void SaveWeightChecks(RunMode runMode,string userId)
        {
            try
            {
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                #region setting up DBCommand with parameters
                IDbCommand command = _db.CreateCommand("[md].[Save_WeightCheck_Value_RunSetup_sp]");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_weightCheck", runMode.WeightChecks);
                    parameters.Add("@proc_vr_runid", runMode.RunId);
                    parameters.Add("@proc_vr_current_User_Id", userId);
                    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public void SaveRecipeData(dynamic recipe, string userId, int runId)
        {
            try
            {
                if (recipe != null)
                {
                    string validString = Convert.ToString(recipe);
                    IDbCommand command = _db.CreateCommand("[md].InsertUpdateRunReceipe_Sp");
                    using (command)
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("@proc_in_Run_Id", runId);
                        parameters.Add("@proc_Json_Run_Mode_Receipe", string.IsNullOrEmpty(validString) ? (object)null : validString);

                        parameters.Add("@proc_Created_By_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw ex;
            }

        }

        public RunExport GetExportData(string userId, int runId)
        {
            try
            {
                RunExport runModelObj = new RunExport();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("md.ExportRunSetUp_Sp"))
                {
                    FeedExport objRunFeed = new FeedExport();
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Created_By_User_Id", string.IsNullOrEmpty(Convert.ToString(userId)) ? (object)null : userId);
                    parameters.Add("proc_in_Run_Id", runId);

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        runModelObj.GeneralInfo.FeedCondition = Convert.ToString(objSqlDr["FEED_CONDITION"]);
                    }
                    objSqlDr.NextResult();
                    //Boiling Point Data
                    while (objSqlDr.Read())
                    {
                        BoilingPointExport bp = new BoilingPointExport();
                        bp.InitialBoilingPoint = (objSqlDr["IBP_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["IBP_MSR"]);
                        bp.EndBoilingPoint = (objSqlDr["END_POINT_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["END_POINT_MSR"]);
                        bp.YieldCutLabel = Convert.ToString(objSqlDr["YIELD_CUT_LABEL_TXT"]);
                        bp.InitialBoilingPointUOM = Convert.ToString(objSqlDr["IBP_UNIT_NM"]);
                        bp.EndBoilingPointUOM = Convert.ToString(objSqlDr["END_POINT_UNIT_NM"]);
                        runModelObj.lstRunCutBoilingPoints.Add(bp);
                    }
                    objSqlDr.NextResult();
                    //Catalyst and Bed Details
                    while (objSqlDr.Read())
                    {
                        RunCatalystModelExport cat = new RunCatalystModelExport();
                        cat.CatalystId = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]);
                        cat.CatalystFamilyName = Convert.ToString(objSqlDr["FAMILY_NAME"]);
                        cat.pieceDensityValue = (objSqlDr["PIECE_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PIECE_DENSITY_MSR"]);
                        cat.pieceDensityUOM = Convert.ToString(objSqlDr["PIECE_DENSITY_UOM"]);
                        cat.CatalystSize = Convert.ToString(objSqlDr["CATALYST_SIZE_CD"]);
                        cat.Crushed = Convert.ToString(objSqlDr["IS_CRUSHED"]) == "Y" ? "Yes" : "No";
                        cat.CatalystShape = Convert.ToString(objSqlDr["CATALYST_SHAPE_NM"]);
                        cat.Voidfraction = (objSqlDr["VOID_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VOID_FRACTION_MSR"]);
                        cat.LoadingDensityTypeName = Convert.ToString(objSqlDr["LOAD_DENSITY_TYPE_NM"]);
                        cat.vibrated_bed_density_value = (objSqlDr["VIBRATED_BED_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VIBRATED_BED_DENSITY_MSR"]);
                        cat.vibrated_bed_density_UOM = Convert.ToString(objSqlDr["VIBRATED_BED_DENSITY_UOM"]);
                        cat.CalculatedBedDensity = (objSqlDr["APPARENT_BED_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["APPARENT_BED_DENSITY_MSR"]);
                        cat.Calculated_Bed_Density_UOM = Convert.ToString(objSqlDr["APPARENT_BED_DENSITY_UOM"]);
                        cat.CustomBedDensity = (objSqlDr["CUSTOM_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["CUSTOM_DENSITY_MSR"]);
                        cat.Custom_bed_density_uom = Convert.ToString(objSqlDr["CUSTOM_DENSITY_UOM"]);
                        cat.CatalystDescription = Convert.ToString(objSqlDr["CATALYST_DESC"]);
                        cat.LoadDensityValue = (double?)null;
                        cat.LoadDensityUOM = null;
                        runModelObj.Cataysts.Add(cat);

                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        BedDetailsExport bed = new BedDetailsExport();
                        bed.BedNumber = Convert.ToInt16(objSqlDr["BED_NUM"]);
                        bed.CatalystId = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]);
                        bed.CatalystVolume = (objSqlDr["CATALYST_VOLUME_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["CATALYST_VOLUME_MSR"]);
                        bed.Split = Convert.ToInt32(objSqlDr["SPLIT_NM"]);
                        bed.DiluentDesignation = Convert.ToString(objSqlDr["DILUENT_NM"]);
                        bed.DiluentVolume = (objSqlDr["DILUENT_VOLUME_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["DILUENT_VOLUME_MSR"]);
                        runModelObj.Beds.Add(bed);
                    }
                    objSqlDr.NextResult();
                    //Feed
                    while (objSqlDr.Read())
                    {

                        objRunFeed.UOPNumber = Convert.ToString(objSqlDr["UOP_NUM"]);
                        objRunFeed.Name = Convert.ToString(objSqlDr["FEED_NM"]);
                        objRunFeed.API = (objSqlDr["API_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["API_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["API_MSR"]);
                        objRunFeed.API_UOM = Convert.ToString(objSqlDr["API_UOM"]);
                        objRunFeed.H2InFeed = (objSqlDr["H2_IN_FEED_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["H2_IN_FEED_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["H2_IN_FEED_MSR"]);
                        objRunFeed.H2InFeed_UOM = Convert.ToString(objSqlDr["H2_IN_FEED_UOM"]);
                        objRunFeed.SulfurInSweetFeed = (objSqlDr["S_IN_SWEETFEED"] == DBNull.Value || Convert.ToDouble(objSqlDr["S_IN_SWEETFEED"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["S_IN_SWEETFEED"]);
                        objRunFeed.SulfurInSweetFeed_UOM = Convert.ToString(objSqlDr["S_IN_SWEETFEED_UOM"]);
                        objRunFeed.NitrogenInSweetFeed = (objSqlDr["N_IN_SWEETFEED"] == DBNull.Value || Convert.ToDouble(objSqlDr["N_IN_SWEETFEED"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["N_IN_SWEETFEED"]);
                        objRunFeed.NitrogenInSweetFeed_UOM = Convert.ToString(objSqlDr["N_IN_SWEETFEED_UOM"]);
                        objRunFeed.SulfurInFeedBlend = (objSqlDr["S_IN_FEEDBLEND"] == DBNull.Value || Convert.ToDouble(objSqlDr["S_IN_FEEDBLEND"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["S_IN_FEEDBLEND"]);
                        objRunFeed.SulfurInFeedBlend_UOM = Convert.ToString(objSqlDr["S_IN_FEEDBLEND_UOM"]);
                        objRunFeed.NitrogenInFeedBlend = (objSqlDr["N_IN_FEEDBLEND"] == DBNull.Value || Convert.ToDouble(objSqlDr["N_IN_FEEDBLEND"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["N_IN_FEEDBLEND"]);
                        objRunFeed.NitrogenInFeedBlend_UOM = Convert.ToString(objSqlDr["N_IN_FEEDBLEND_UOM"]);
                        runModelObj.FeedInfo = objRunFeed;
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        FeedBlendExport Objblend = new FeedBlendExport()
                        {
                            ComponentName = Convert.ToString(objSqlDr["COMPONENT_NM"]),
                            UOPNumber = Convert.ToString(objSqlDr["UOP_NUM"]),
                            Amountadded = (objSqlDr["WEIGHT_MSR"] == DBNull.Value || Convert.ToDecimal(objSqlDr["WEIGHT_MSR"]) == 0) ? (decimal?)null : Convert.ToDecimal(objSqlDr["WEIGHT_MSR"]),
                            Weightpct = (objSqlDr["WEIGHT_PERCENT"] == DBNull.Value || Convert.ToDecimal(objSqlDr["WEIGHT_PERCENT"]) == 0) ? (decimal?)null : Convert.ToDecimal(objSqlDr["WEIGHT_PERCENT"])
                        };
                        objRunFeed.Blendcomponents.Add(Objblend);
                        runModelObj.FeedInfo.Blendcomponents = objRunFeed.Blendcomponents;
                    }
                    //Analytical Sample
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        AnalyticalInfoModelExport objAnalyticalSampleInfo = new AnalyticalInfoModelExport();
                        objAnalyticalSampleInfo.StreamName = Convert.ToString(objSqlDr["STREAM_NM"]);
                        objAnalyticalSampleInfo.LIMSOPerationName = Convert.ToString(objSqlDr["LIMS_OPERATION_NM"]);
                        objAnalyticalSampleInfo.MethodNumber = Convert.ToString(objSqlDr["ANALYSIS_METHOD_NUM"]);
                        objAnalyticalSampleInfo.SampleVolumeinCC = Convert.ToString(objSqlDr["SAMPLE_VOLUME_MSR"]);
                        objAnalyticalSampleInfo.SampleCost = Convert.ToDouble(objSqlDr["SAMPLE_COST_MSR"]);
                        objAnalyticalSampleInfo.FrequencyName = Convert.ToString(objSqlDr["FREQENCY_NM"]);
                        runModelObj.lstAnalyticalSamples.Add(objAnalyticalSampleInfo);
                    }
                    //NIR Specs
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        NIRModelExport objNIRModel = new NIRModelExport();
                        objNIRModel.Parameter = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objNIRModel.Value = Convert.ToString(objSqlDr["VALUE"]);
                        objNIRModel.ParameterUOM = Convert.ToString(objSqlDr["UOM"]);
                        runModelObj.lstNIRSpec.Add(objNIRModel);
                    }
                    //Process Specs
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        ProcessSpecsInfoExport objProcessSpecModel = new ProcessSpecsInfoExport();
                        objProcessSpecModel.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objProcessSpecModel.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objProcessSpecModel.ParameterUOM = Convert.ToString(objSqlDr["UOM"]);
                        objProcessSpecModel.Range = (objSqlDr["PARAMETER_RANGE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAMETER_RANGE_MSR"]);
                        runModelObj.lstProcessSpec.Add(objProcessSpecModel);
                    }
                    //TMF & Mass Flow Calibration Meter
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        TMF_Calibration objTMFCalibration = new TMF_Calibration();
                        objTMFCalibration.Parameter = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objTMFCalibration.Value = (objSqlDr["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VALUE_MSR"]);
                        objTMFCalibration.ParameterUOM = Convert.ToString(objSqlDr["UOM"]);
                        runModelObj.lstTMF_Calibrations.Add(objTMFCalibration);
                    }
                    //Additional Info
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        AdditionalInfoExport objAdditionalInfo = new AdditionalInfoExport();
                        objAdditionalInfo.SelectedNormalizationFactor = Convert.ToString(objSqlDr["NORMALIZATION_FACTOR"]);
                        objAdditionalInfo.H2TMFSpec = (objSqlDr["H2_TMF_PV_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["H2_TMF_PV_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["H2_TMF_PV_MSR"]);
                        objAdditionalInfo.SelectedFeedSource = Convert.ToString(objSqlDr["FEED_CALCULATION_SOURCE_NM"]);
                        objAdditionalInfo.HPSControllerOffset = (objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["HPS_PRSR_CTRL_OFFSET_MSR"]);
                        objAdditionalInfo.OffgasHeaviesWeight = (objSqlDr["OFFGAS_HEAVIES_WT_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["OFFGAS_HEAVIES_WT_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["OFFGAS_HEAVIES_WT_MSR"]);
                        objAdditionalInfo.PlantTCOffset = (objSqlDr["PLANT_TC_OFFSET_MSR"] == DBNull.Value || Convert.ToDouble(objSqlDr["PLANT_TC_OFFSET_MSR"]) == 0) ? (double?)null : Convert.ToDouble(objSqlDr["PLANT_TC_OFFSET_MSR"]);
                        objAdditionalInfo.OffgasHeaviesWeight_UOM = Convert.ToString(objSqlDr["OFFGAS_HEAVIES_WT_UOM"]);
                        objAdditionalInfo.H2TMFSpec_UOM = Convert.ToString(objSqlDr["H2_TMF_PV_UOM"]);
                        objAdditionalInfo.PlantTCOffset_UOM = Convert.ToString(objSqlDr["PLANT_TC_OFFSET_UOM"]);
                        objAdditionalInfo.HPSControllerOffset_UOM = Convert.ToString(objSqlDr["HPS_PRSR_CTRL_OFFSET_UOM"]);
                        runModelObj.AdditionalInfo = objAdditionalInfo;
                    }
                    //TC Calibration
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        TC_Calibration_Export objTCCalibration = new TC_Calibration_Export();
                        objTCCalibration.ParameterName = Convert.ToString(objSqlDr["PARAMETER_NM"]);
                        objTCCalibration.Value = (objSqlDr["PARAM_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PARAM_VALUE_MSR"]);
                        objTCCalibration.ParameterUOM = Convert.ToString(objSqlDr["PARAM_UOM"]);
                        objTCCalibration.CalibrationDate = (objSqlDr["PARAM_VALUE_TXT"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(objSqlDr["PARAM_VALUE_TXT"]);
                        runModelObj.lstTC_Calibrations.Add(objTCCalibration);
                    }

                }
                return runModelObj;
            }
            catch(Exception e)
            {
                LogManager.Error(e);
                throw e;
            }
        }
        public IEnumerable<dynamic> getReciepes(string userId,int runId)
        {
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand("md.ExportRunSetUp_Sp"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_vr_Created_By_User_Id", string.IsNullOrEmpty(Convert.ToString(userId)) ? (object)null : userId);
                parameters.Add("proc_in_Run_Id", runId);
                _db.CreateParameters(command, parameters);
                //reader = _db.ExecuteReader(command);


                using (reader = _db.ExecuteReader(command))
                {
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    reader.NextResult();
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }
                    //reader.NextResult();
                    //while (reader.Read())
                    //{
                    //    yield return GetDynamicData(reader);
                    //}
                }
            }
        }
    }
}
