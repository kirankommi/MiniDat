﻿export class FeedModel
{
    UOPNumber: string;
    Name: string;   
    API: number;
    Density: number;
    RelativeDensity: number;
    H2InFeed: number;
    SulfurInSweetFeed: number;
    NitrogenInSweetFeed: number;
    SulfurInFeedBlend: number;
    NitrogenInFeedBlend: number;
    Blendcomponents: FeedBlend[];
    StatusCode: KeyValue;   
    StatusName: string; 
    FeedId: string;
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}

export class FeedBlend
{
    ComponentId: string;   
    ComponentName: string;
    Amountadded: number;
    //Component: string;
    Weightpct: number; 
    UOPNumber: string; 
}
