﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IDiluentRepository : ICRUDRepository<DiluentModel>
    {
        DiluentSearchModel GetDiluentData(DiluentModel diluent);
        string DeleteDiluentData(DiluentModel diluent);
        void SaveDiluentData(DiluentModel _diluent, string userId);
        DiluentSearchModel GetActivediluents(DiluentModel diluent);

    }
}
