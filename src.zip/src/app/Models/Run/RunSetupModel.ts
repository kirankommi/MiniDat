import { ProcessSpecModel, NIRModel, AnalyticalInfoModel, BoilingPointModel, FeedModel, GeneralInfoModel, RunModeData, ExportPopupSummary, RunCatalyst, BedDetails, AdditionalInfoModel, TC_Calibration, TMF_Calibration, KeyValue, MetaData } from "./RunModel";
import { FeedInfo } from "../NIRModelTemplateModel";

export class RunSetupModel {
    public lstNIRSpec: NIRModel[];
    public lstProcessSpec: ProcessSpecModel[];
    public lstAnalyticalSamples: AnalyticalInfoModel[];
    public lstRunCutBoilingPoints: BoilingPointModel[];
    public MetaData: MetaData;
    public MasterData: MasterData;
    public FeedInfo: FeedModel;
    public GeneralInfo: GeneralInfoModel;
    public RecipeMaster: any;
    public Recipe: any;
    public RecipeInfo: any;
    public ModeMaster: any;
    public RunModedata: RunModeData;
    public NIRTemp: any=[];
    public PopUpSummary: ExportPopupSummary; 
    public Cataysts: RunCatalyst[];
    public Beds: BedDetails[];
    public isInitial: boolean = true;

    public AdditionalInfo: AdditionalInfoModel;
    public lstTC_Calibrations: TC_Calibration[];
    public lstTMF_Calibrations: TMF_Calibration[];

    public selectedPopupList: KeyValue[];

    // *******************  Master Data**************************//
    
    // *******************  Master Data**************************//
}
export class MasterData{
    public lstStreams: KeyValue[];
    public LstAnalysisMethods: KeyValue[];
    public LstLoadingDensiyTypes: KeyValue[];
    public LstNormalizationFactors: KeyValue[];
    public LstFeedSource: KeyValue[];
    public LstStdBoilingPoints: BoilingPointModel[];
    public LstStreams: KeyValue[];
    public LstFrequency: KeyValue[];
    public lstDoeCataystinfo: any[];
    public lstFlyoutFeeds: FeedInfo[];
    public lstFlyoutTechnicians: any;
    public localDependentsInfo: any;
}