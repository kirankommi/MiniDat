﻿using System.Collections.Generic;

namespace MINIDAT.Model.Manage
{
    public class NIRModelTemplateModel
    {
        public int? NIRModelType { get; set; }
        public string ModelTypeName { get; set; }
        public int? ConversionType { get; set; }
        public FeedInfo Feeds { get; set; }
        public KeyValue ModelTypecd { get; set; }
        public KeyValue ConversionTypecd { get; set; }
        public string ConversionTypeName { get; set; }
        public decimal? ConversionCutPoint { get; set; }
        public decimal? Low { get; set; }
        public decimal? High { get; set; }
        public decimal? SigmaError { get; set; }
        public KeyValue StatusCode { get; set; }

        //Search Parameters
        public string StatusName { get; set; }
        public string ModelID { get; set; }
        public KeyValue plantsTestedCode { get; set; }
        public int? plantsTestedKey { get; set; }
        public List<KeyValue> selectedplants { get; set; }
        public string[] lstFeedNames { get; set; }
        public int[] lstFeedIds { get; set; }
        public string plantsSelectedlist { get; set; }
        public string feedSelectedList { get; set; }
        public string ActiveInd { get; set; }
        public int NIRModelSQID { get; set; }
        public string selectedPlantKeyList { get; set; }
        public string[] selectedplantsKeys { get; set; }
        public string selectedPlantsCodeList { get; set; }
        public string[] selectedPlantsCode { get; set; }
        public string DateLastRun_MinisQueue { get; set; }
        public bool IsInitialLoad { get; set; }
        //public string indicator { get; set; }


    }
    public class FeedInfo
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public bool HasDopant { get; set; }
        public string BookNum { get; set; }
        public string UOPNum { get; set; }
        public double? DensityMsr { get; set; }
    }
    public class NIRModelTemplateSearchModel
    {
        private IList<KeyValue> _modelTypes = new List<KeyValue>();
        public IList<KeyValue> lstModelTypes { get { return _modelTypes; } }

        private List<FeedInfo> feed = new List<FeedInfo>();
        public List<FeedInfo> Feeds { get { return feed; } }

        private IList<KeyValue> _conversionTypes = new List<KeyValue>();
        public IList<KeyValue> lstConversionTypes { get { return _conversionTypes; } }

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> Status { get { return status; } }

        private IList<KeyValue> plantnumber = new List<KeyValue>();
        public IList<KeyValue> lstPlantsTested { get { return plantnumber; } }

        private IList<NIRModelTemplateModel> _lstNIRModelTemplateModel = new List<NIRModelTemplateModel>();
        public IList<NIRModelTemplateModel> LstNIRModelTemplateModel { get { return _lstNIRModelTemplateModel; } }
        public string DateLastRun { get; set; }
        public int RecordsFetched { get; set; }

    }
}
