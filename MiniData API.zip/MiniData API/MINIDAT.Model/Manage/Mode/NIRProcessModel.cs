﻿using MINIDAT.Model.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Manage.Mode
{
    public class NIRProcessModel
    {
        public string ConversionCutPoint { get; set; }
        public List<NIRSpecModel> lstNIRSpecModel { get; set; }
        public List<ProcessSpecModel> lstProcessSpecModel { get; set; }
    }
}
