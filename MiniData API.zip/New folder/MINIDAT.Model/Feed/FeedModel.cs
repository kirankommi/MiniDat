﻿using System.Collections.Generic;

namespace MINIDAT.Model.Feed
{
    public class FeedModel
    {
        public int? FeedID { get; set; }
        public string StatusName { get; set; }
        public string Name { get; set; }
        public decimal? H2InFeed { get; set; }
        public decimal? Density { get; set; }
        public decimal? API { get; set; }
        public decimal? RelativeDensity { get; set; }
        public decimal? SulfurInSweetFeed { get; set; }
        public decimal? NitrogenInSweetFeed { get; set; }
        public decimal? SulfurInFeedBlend { get; set; }
        public decimal? NitrogenInFeedBlend { get; set; }
        public KeyValue StatusCode { get; set; }
        public List<Blendcomponent> lstfeedblends { get; set; }
        public string isExists { get; set; }

    }
    public class FeedSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<FeedModel> _lstfeeds = new List<FeedModel>();
        public IList<FeedModel> Lstfeeds { get { return _lstfeeds; } }

        public int RecordsFetched { get; set; }

    }
    public class Blendcomponent
    {
        public int ComponentId { get; set; }
        public string ComponentName { get; set; }
        public decimal Amountadded { get; set; }      
        public decimal Weightpct { get; set; }
        public string UOPNumber { get; set; }
    }
}
