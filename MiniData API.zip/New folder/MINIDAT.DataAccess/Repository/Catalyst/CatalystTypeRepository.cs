﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystType.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystTypeRepository : ICatalystTypeRepository
    {
        private IDatabase _db;
        public CatalystTypeRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystTypeSearchModel GetCatalystTypeData(CatalystTypeModel catalystType)
        {
            try
            {
                CatalystTypeSearchModel catalystTypearr = new CatalystTypeSearchModel();
                if (catalystType == null)
                {
                    return catalystTypearr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystType_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystType", string.IsNullOrEmpty(Convert.ToString(catalystType.CatalystType)) ? (object)null : catalystType.CatalystType);                  
                    parameters.Add("proc_vr_description", string.IsNullOrEmpty(Convert.ToString(catalystType.Description)) ? (object)null : catalystType.Description);                 
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystType.StatusName == "Select" ? null : catalystType.StatusName) ? (object)null : catalystType.StatusName);  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystTypearr.LstcatalystTypes.Clear();
                    while (reader.Read())
                    {
                        CatalystTypeModel _catalystType = new CatalystTypeModel()
                        {
                            CatalystTypeID = Convert.ToInt32(reader["CATALYST_TYPE_ID_SQ"]),                         
                            Description = reader["CATALYST_TYPE_DESC"].ToString(),
                            CatalystType = reader["CATALYST_TYPE_NM"].ToString(),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() }
                        };
                        catalystTypearr.LstcatalystTypes.Add(_catalystType);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystTypearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystTypearr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystTypearr.lstStatus).AddRange(statuses);                  
                    return catalystTypearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystTypeData(CatalystTypeModel catalystType)
        {
            try
            {
                if (catalystType == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystType_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystType_ID", string.IsNullOrEmpty(Convert.ToString(catalystType.CatalystTypeID)) ? (object)null : catalystType.CatalystTypeID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystTypeData(CatalystTypeModel _catalystType, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystType == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystType_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystType_Id", _catalystType.CatalystTypeID);
                    parameters.Add("proc_vr_catalystType", _catalystType.CatalystType);
                    parameters.Add("proc_vr_description", _catalystType.Description);                  
                    parameters.Add("proc_vr_Status_Nm", _catalystType.StatusName);                                    
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystTypeModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystTypeModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystTypeModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystTypeModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
