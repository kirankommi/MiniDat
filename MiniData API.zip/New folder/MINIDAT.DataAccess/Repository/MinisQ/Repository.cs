﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.DOE;
using MINIDAT.Model.MINISQ;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using MasterData = MINIDAT.Model.MINISQ.MasterData;
using Study = MINIDAT.Model.MINISQ.Study;

namespace MINIDAT.DataAccess.Repository.MinisQ
{
    public class Repository : IMINISQRepository
    {
        private IDatabase _db;
        public Repository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public MasterData GetMasterData(string userId)
        {
            MasterData MD = new MasterData();
            IDataReader objSqlDr = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_MINISQ_MasterData]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_var_UserID", userId);
                _db.CreateParameters(command, parameters);
                objSqlDr = _db.ExecuteReader(command);

                while (objSqlDr.Read())
                {
                    MD.Projects.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["PROJECT_ID_SQ"]),
                        Value = Convert.ToString(objSqlDr["PROJECT_NM"])
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.StudyNames.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["STUDY_ID_SQ"]),
                        Value = Convert.ToString(objSqlDr["STUDY_NM"])
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.Plants.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["PLANT_KEY"]),
                        Value = Convert.ToString(objSqlDr["PLANT_CD"])
                    });
                }

                objSqlDr.NextResult();
                int tempKey = 1;
                while (objSqlDr.Read())
                {
                    MD.Runs.Add(new KeyValue()
                    {
                        Key = Convert.ToString(tempKey),
                        Value = Convert.ToString(objSqlDr["RUN_NUM"])
                    });
                    tempKey++;
                }


                objSqlDr.NextResult();
                tempKey = 1;
                while (objSqlDr.Read())
                {
                    MD.Status.Add(new KeyValue()
                    {
                        Key = Convert.ToString(tempKey),
                        Value = Convert.ToString(objSqlDr["STATUS_NM"])
                    });
                    tempKey++;
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.CatalystDesignation.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["CATALYST_ID_SQ"]),
                        Value = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"])
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.CatalystFamily.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["CATALYST_FAMILY_ID_SQ"]),
                        Value = Convert.ToString(objSqlDr["CatalystFamilyName"])
                    });
                }
                objSqlDr.NextResult();
                tempKey = 1;
                while (objSqlDr.Read())
                {
                    MD.CatalystLeader.Add(new KeyValue()
                    {
                        Key = Convert.ToString(tempKey),
                        Value = Convert.ToString(objSqlDr["CatalystLeaderName"])
                    });
                    tempKey++;
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.FeedStock.Add(new KeyValue()
                    {
                        Key = Convert.ToString(objSqlDr["FEED_ID_SQ"]),
                        Value = Convert.ToString(objSqlDr["FeedName"])
                    });
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    MD.ColumnPref = Convert.ToString(objSqlDr["PREFERENCE"]);
                }

                objSqlDr.NextResult();
                tempKey = 1;
                while (objSqlDr.Read())
                {
                    MD.Specialist.Add(new KeyValue()
                    {
                        Key = Convert.ToString(tempKey),
                        Value = Convert.ToString(objSqlDr["MGR_SPCL_ID"])
                    });
                    tempKey++;
                }
                command.Connection.Close();
            }

            return MD;
        }

        public Study GetStudiesData()
        {
            IDataReader rdr = null;
            Study sd = new Study();

            using (IDbCommand cmd = _db.CreateCommand("[md].[Get_MINISQ_Studies_Information]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);

                //Runs 
                Dictionary<int, List<DOEBed>> bedList = new Dictionary<int, List<DOEBed>>();
                Dictionary<int, List<double?>> conversions = new Dictionary<int, List<double?>>();
                Dictionary<int, FeedInfo> FeedInfos = new Dictionary<int, FeedInfo>();
                Dictionary<int, ModeInfo> modeInfos = new Dictionary<int, ModeInfo>();
                //rdr.NextResult();
                sd.Runs = new List<Run>();
                while (rdr.Read())
                {
                    Run rn = new Run();
                    rn.ProjectName = Convert.ToString(rdr["ProjectName"]);
                    rn.StudyName = Convert.ToString(rdr["StudyName"]);
                    rn.DOEID = Convert.ToInt32(rdr["DOEID"]);
                    rn.Plant = Convert.ToString(rdr["Plant"]);
                    rn.RunNum = Convert.ToInt32(rdr["RunNum"]);
                    rn.NetworkNUM = Convert.ToString(rdr["NetworkNUM"]);
                    //rn.NW1 = Convert.ToString(rdr["UOP_NW_NUM1"]);
                    //rn.NW2 = Convert.ToString(rdr["UOP_NW_NUM2"]);
                    //rn.NW3 = Convert.ToString(rdr["UOP_NW_NUM3"]);
                    rn.StartDate = Convert.ToString(rdr["StartDate"]);
                    rn.EndDate = Convert.ToString(rdr["EndDate"]);
                    rn.Status = getStatus(Convert.ToString(rdr["STATUS"]));
                    rn.StudyId = Convert.ToInt32(rdr["StudyId"]);
                    rn.Requestor = Convert.ToString(rdr["Requestor"]);
                    rn.DOERun = Convert.ToInt32(rdr["DOERun"]);
                    rn.RUN_ID = Convert.ToInt32(rdr["RUN_ID"]);
                    rn.NIRFlagInd = Convert.ToString(rdr["NIRFlag"]);

                    sd.Runs.Add(rn);
                    bedList.Add(rn.RUN_ID.Value, new List<DOEBed>());
                    conversions.Add(rn.RUN_ID.Value, new List<double?>());
                    FeedInfos.Add(rn.RUN_ID.Value, new FeedInfo());
                    modeInfos.Add(rn.RUN_ID.Value, new ModeInfo());
                }

                //Catalyst Template Info
                rdr.NextResult();
                while (rdr.Read())
                {
                    CatalystInfo catalystInfo = new CatalystInfo();
                    catalystInfo.TemplateID = Convert.ToInt32(rdr["TemplateID"]);
                    catalystInfo.TemplateName = Convert.ToString(rdr["TemplateName"]);
                    catalystInfo.LoadingSubmitted = Convert.ToString(rdr["LoadingSubmitted"]);
                    catalystInfo.RxLoaded = Convert.ToString(rdr["RxLoaded"]);
                    sd[Convert.ToInt32(rdr["RUN_ID"])].CatalystTemplate = catalystInfo;
                }


                //Beds
                rdr.NextResult();
                while (rdr.Read())
                {
                    DOEBed bed = new DOEBed();
                    bed.BedNumber = Convert.ToInt32(rdr["BedNumber"]);
                    bed.CatalystVolume = Convert.ToDecimal(rdr["CatalystVolume"]);
                    bed.Split = Convert.ToInt32(rdr["SPIT"]);
                    bed.DiluentDesignation = Convert.ToString(rdr["DiluentDesignation"]);
                    bed.DiluentVolume = Convert.ToDecimal(rdr["DiluentVolume"]);
                    bed.DiluentID = Convert.ToInt32(rdr["DiluentID"]);
                    bed.Catalyst = new Model.Catalyst.CatalystLite();
                    bed.Catalyst.CatalystId = Convert.ToInt32(rdr["CatalystId"]);
                    bed.Catalyst.CatalystDesignation = Convert.ToString(rdr["CatalystDesignation"]);
                    bed.Catalyst.CatalystFamilyName = Convert.ToString(rdr["CatalystFamilyName"]);
                    bed.Catalyst.CatalystTypeName = Convert.ToString(rdr["CatalystTypeName"]);
                    bed.Catalyst.AnalyticalStatusName = Convert.ToString(rdr["AnalyticalStatusName"]);
                    bed.Catalyst.BulkLocationInd = Convert.ToString(rdr["BulkLocationInd"]);
                    bed.Catalyst.CatalystLeaderName = Convert.ToString(rdr["CatalystLeaderName"]);
                    bedList[Convert.ToInt32(rdr["RUN_ID"])].Add(bed);
                }

                //Mode Info
                rdr.NextResult();
                while (rdr.Read())
                {
                    ModeInfo mode = new ModeInfo();
                    mode.ModeNumber = Convert.ToString(rdr["ModeNumber"]);
                    mode.Description = Convert.ToString(rdr["Description"]);
                    mode.ModeType = Convert.ToString(rdr["ModeType"]);
                    mode.SulfidingType = Convert.ToString(rdr["SulfidingType"]);
                    mode.ControlName = Convert.ToString(rdr["ControlName"]);
                    mode.Pressure = rdr["Pressure"].FormatDouble();
                    mode.LHSV = rdr["LHSV"].FormatDouble();
                    mode.SCFB = rdr["SCFB"].FormatDouble();
                    mode.SoakTime = rdr["DURATION_MSR"].FormatDouble();
                    mode.Conditions = Convert.ToInt16(rdr["Conditions"]);
                    mode.Sort = rdr["SORT"].FormatDouble();
                    modeInfos[Convert.ToInt32(rdr["RUN_ID"])] = mode;
                    mode.ModeID = DBNull.Value != rdr["MODE_ID"] ? Convert.ToInt16(rdr["MODE_ID"]) : default(int?);
                }

                //Conversion
                rdr.NextResult();
                while (rdr.Read())
                {
                    conversions[Convert.ToInt32(rdr["RUN_ID"])].Add(rdr["CONVERSION_MSR"].FormatDouble());
                }

                //FeedInfo
                rdr.NextResult();
                while (rdr.Read())
                {
                    FeedInfo fd = new FeedInfo();
                    fd.ID = Convert.ToInt32(rdr["ID"]);
                    fd.Name = Convert.ToString(rdr["Name"]);
                    fd.Desc = Convert.ToString(rdr["Desc"]);
                    fd.HasDopant = Convert.ToBoolean(rdr["HasDopant"]);
                    FeedInfos[Convert.ToInt32(rdr["RUN_ID"])] = fd;

                }

                //Associating the beds & Conversions to the Run catalyst template object
                foreach (var run in sd.Runs)
                {
                    run.Feed = FeedInfos[run.RUN_ID.Value];
                    run.Mode = modeInfos[run.RUN_ID.Value];
                    run.Mode.Conversion = conversions[run.RUN_ID.Value];
                    run.CatalystTemplate.Beds = bedList[run.RUN_ID.Value];
                }
                cmd.Connection.Close();
            }
            return sd;
        }
        public string getStatus(string status)
        {
            //string tempStatus = String.Empty;
            switch (status.ToLower())
            {
                case "rncmp":
                    return "Completed";
                case "rninp":
                    return "In Progress";
                case "rnq":
                    return "Queued";
                default:
                    return String.Empty;
            }
           
        }

        public bool ReOrderRuns(ReOrderedRuns runs)
        {
            try
            {
                int? runNum, temp;
                if (runs.IsDragged)
                {
                    if (0 != runs.DropIndex && 0 != runs.DragIndex)
                    {
                        if (runs.DropIndex < runs.DragIndex)
                        {
                            runNum = runs.Runs[runs.DropIndex - 1 ?? 0].RunNum;
                            temp = 0 != runs.DropIndex ? runs.DropIndex - 1 : 0;
                        }
                        else
                        {
                            runNum = runs.Runs[runs.DragIndex - 1 ?? 0].RunNum;
                            temp = runs.DragIndex - 1 ?? 0;
                        }
                    }
                    else
                    {
                        runNum = runs.Runs.Min(r => r.RunNum);
                        temp = 0;
                    }

                    for (int i = temp ?? 0; i < runs.Runs.Count; i++)
                    {
                        if (runs.Runs[i].Status == "In Progress" || runs.Runs[i].Status == "Completed")
                        {
                            runNum++;
                        }
                        else
                        {
                            runs.Runs[i].RunNum = runNum;
                            runs.Runs[i].StartDate = 0 != i ? Convert.ToDateTime(runs.Runs[i - 1].EndDate).AddHours(18).ToString() : Convert.ToDateTime(runs.Runs[i].EndDate).AddHours(18).ToString();
                            runs.Runs[i].EndDate = runs.Runs[i].StartDate != String.Empty ? Convert.ToDateTime(runs.Runs[i].StartDate).AddMinutes(runs.Runs[i].Mode.SoakTime ?? 0).ToString() : String.Empty;
                            runNum++;
                        }


                    }
                }
                else
                {
                    for (int i = (runs.DropIndex ?? 0) > (runs.DragIndex ?? 0) ? (runs.DragIndex??0) : (runs.DropIndex??0) ; i < runs.Runs.Count; i++)
                    {
                        runs.Runs[i].StartDate = 0 != i ? Convert.ToDateTime(runs.Runs[i - 1].EndDate).AddHours(18).ToString() : Convert.ToDateTime(runs.Runs[i].EndDate).AddHours(18).ToString();

                        runs.Runs[i].EndDate = runs.Runs[i].StartDate != String.Empty ? Convert.ToDateTime(runs.Runs[i].StartDate).AddMinutes(runs.Runs[i].Mode.SoakTime ?? 0).ToString() : String.Empty;

                    }
                    foreach (var item in runs.Runs)
                    {
                        item.StartDate = Convert.ToDateTime(item.StartDate).ToString();
                        item.EndDate = Convert.ToDateTime(item.EndDate).ToString();
                    }
                }
                
                IDataReader rdr = null;

                #region Serializing the List as XML
                XmlSerializer serializer = new XmlSerializer(runs.Runs.GetType());
                StringBuilder strBuilder = new StringBuilder();
                using (StringWriter strWriter = new StringWriter(strBuilder))
                {
                    serializer.Serialize(strWriter, runs.Runs);
                }
                #endregion
                using (IDbCommand cmd = _db.CreateCommand("md.MINISQ_ReOrder_Runs_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_xml_runs_Detail", strBuilder.ToString());
                    parameters.Add("proc_Plant_Id", runs.Plant);
                    parameters.Add("proc_vr_Ordered_By_User_Id", runs.UserId);
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }


        }

        public string SaveColPreferences(ColumnsPreferences columnPref)
        {
            IDataReader rdr = null;

            using (IDbCommand cmd = _db.CreateCommand("md.Insert_Update_MinisQ_Column_Preferences_sp"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_vr_ColumnPreferences", columnPref.ColumnPreferences.ToString());
                parameters.Add("CREATED_BY_USER_ID", columnPref.UserId);
                parameters.Add("proc_vr_ModuleName", columnPref.ModuleName);
                _db.CreateParameters(cmd, parameters);
                rdr = _db.ExecuteReader(cmd);
                return "Saved Successfully";
            }
        }
    }
}
