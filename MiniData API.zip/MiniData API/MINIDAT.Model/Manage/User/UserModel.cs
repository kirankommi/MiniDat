﻿using MINIDAT.Models.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model
{
    public class UserModel : ModelBase, IModel
    {
        public UserModel(IValidationLogic<ModelBase> objValid) : base(objValid)
        {
        }
        public UserModel()
        {

        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Initial { get; set; }
        public string EmailId { get; set; }
        public string DisplayName { get; set; }
        public KeyValue DepartmentCode { get; set; }
        public KeyValue RoleCode { get; set; }
        public KeyValue StatusCode { get; set; }
        public string EID { get; set; }
        public string OldUserId { get; set; }
        public string Phone { get; set; }
        public string UOMTemplateId { get; set; }
        //added
        public string ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public string RoleCd { get; set; }
        private IList<UserModel> _userRoleDetails = new List<UserModel>();
        public IList<UserModel> UserRoleDetails { get { return _userRoleDetails; } }


        //Search Parameters
        public string RoleName { get; set; }
        public string StatusName { get; set; }
        public string DepartmentName { get; set; }

        //Pagination Parameters
        public int TotalRecords { get; set; }
        public int CurrentPage { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }


        public override ValidationResult Validate(IValidationLogic<ModelBase> obj)
        {
            base.Validate(obj);
            return this.ValidationResult;
        }

    }
    public class UserSearchModel
    {
        public string RecordsFetched { get; set; }
        private IList<KeyValue> _roles = new List<KeyValue>();
        public IList<KeyValue> Roles { get { return _roles; } }

        //added
        private IList<KeyValue> _applications = new List<KeyValue>();
        public IList<KeyValue> Applications { get { return _applications; } }

        private IList<KeyValue> _status = new List<KeyValue>();
        public IList<KeyValue> Status { get { return _status; } }

        private IList<KeyValue> _departments = new List<KeyValue>();
        public IList<KeyValue> Departments { get { return _departments; } }

        private IList<UserModel> _users = new List<UserModel>();
        public IList<UserModel> Users { get { return _users; } }
    }
    public class UserApplicationRoleModel
    {
    }
}
