﻿using MINIDAT.Models.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IDatabase
    {
        IDbCommand CreateCommand(string sql, bool isStoredProcedure);
        IDbCommand CreateCommand(string sql);
        void CreateParameters(IDbCommand cmd, IDictionary parameterMapping);
        IDataReader ExecuteReader(IDbCommand cmd);
        IList<T> ExecuteReaderToList<T>(IDbCommand cmd) where T:IModel, new();
        DataSet ExecuteDataSet(IDbCommand cmd);
        object ExecuteScalar(IDbCommand cmd);
        int ExecuteNonQuery(IDbCommand cmd);
    }
}
