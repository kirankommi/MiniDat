import { Component, Input, Output, OnInit, EventEmitter } from "@angular/core";
import { doeMediatorService } from '../../services/doeservices/doemediator.service';
import { TemplateService } from '../../services/catalystservices/catalystloading.service';
import { CatalystLoading } from "src/app/models/Catalyst/CatalystLoadingModel";
import { CatalystService } from "../../services/catalystservices/catalyst.service";
import { debug } from "util";
import { AlertMessage } from '../../Services/alertmessage.service';
import { KeyValue } from '../../Models/KeyValue';
import * as  Constants from '../../Shared/globalconstants';


@Component({
  templateUrl: "catalystTemplate.component.html",
  selector: "catalyst-template-selector",
  providers: [TemplateService, CatalystService]
})
export class catalystTemplateComponent implements OnInit {
  CatalystTemplates: any[] = [];
  defaultTemplate: any = { TemplateID: 0, TemplateName: "Select" };
  selectedTemplate: any;
  catalystList: any = [];
  catalystFlyoutcolumns: any[] = [
    { Key: "CatalystDesignation", Value: "Designation" },
    { Key: "CatalystFamilyName", Value: "Family" },
    { Key: "CatalystTypeName", Value: "Type" }];

  @Input() savedTemplate: any = {};
  @Output() selectedTemplateEvent = new EventEmitter();
  @Input()
  projectName: string = "";
  @Input()
  studyName: string = "";

  constructor(public doeService: doeMediatorService, public templateService: TemplateService, public catService: CatalystService, private alertMessage: AlertMessage) {
  }

  ngOnInit() {
    this.selectedTemplate = this.savedTemplate.TemplateID ? JSON.parse(JSON.stringify(this.savedTemplate)) : this.defaultTemplate;
    if (this.doeService.masterData.CatalystTemplates) {
      this.CatalystTemplates = [this.defaultTemplate, ...this.doeService.masterData.CatalystTemplates];
    }
    else {
      this.templateService.searchLoadingTemplates(new CatalystLoading()).subscribe((data) => {
        this.doeService.masterData.CatalystTemplates = data.LstTemplates;
        this.CatalystTemplates = [this.defaultTemplate, ...data.LstTemplates];
      });
    }
    this.catService.GetCatalystLite().subscribe((data) => {
      this.catalystList = data;
    })
  }

  reset() {
    if (this.savedTemplate.TemplateID == 0) {
      this.selectedTemplate = this.defaultTemplate;
    }
    else {
      this.selectedTemplate = JSON.parse(JSON.stringify(this.savedTemplate));
    }
  }

  cancel() {
    this.selectedTemplateEvent.emit({ TemplateID: 0, TemplateName: "Select" });
  }

  addToRun() {
    debugger;
    if (this.selectedTemplate.Beds && this.selectedTemplate.Beds.length > 0 && this.selectedTemplate.Beds.filter(q => q.Catalyst && q.Catalyst.CatalystDesignation != undefined).length == this.selectedTemplate.Beds.length) {
      this.selectedTemplateEvent.emit(this.selectedTemplate);
    }
    else {
      this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Current Run Information', detail: "Catalyst Field cannot be empty" });
    }
  }

  onCatalystSelected(event, bed) {
    if (bed.BedNumber == 1) {
      this.selectedTemplate.Beds.forEach(q => q.Catalyst = { ...event });
    }
    else {
      bed.Catalyst = { ...event };
    }
  }

  onTemplateSelect(obj: any) {
    let templateID = this.CatalystTemplates[obj.selectedIndex].TemplateID;
    if (templateID == this.savedTemplate.TemplateID) {
      this.selectedTemplate = this.savedTemplate;
    }
    else {
      this.selectedTemplate.TemplateID = templateID;
      this.selectedTemplate.TemplateName = this.CatalystTemplates[obj.selectedIndex].TemplateName;
      this.templateService.GetReactorBedDetails(templateID)
        .subscribe(
          (data: any) => {
            this.selectedTemplate.Beds = data.map((q) => { q.Catalyst = {}; return q; });
          });
    }
  }


}
