import { Component, OnInit, Input } from '@angular/core';
import { Message } from 'primeng/primeng';
import { appService } from '../Services/app.service';
import * as Constants from '../Shared/globalconstants';

@Component({
    //moduleId: module.id,
    selector: 'fdms-head',
    templateUrl: 'header.html'
})

export class HeaderDirective implements OnInit {
    @Input() title: string;
    @Input() userName: string;
    @Input() userEmail: string;
    @Input() menuData: any;
    _toggleSideMenu: boolean = false;
    signedUserName: string;
    signedUserInitial: string;

    IsUnauthorizedAccess: boolean = true;

    constructor(private appService: appService) {
        this.IsUnauthorizedAccess = Constants.IsUnauthorizedAccess;

        //console.log(this.IsUnauthorizedAccess);
    }

    toggleSideMenu() {
        if (this._toggleSideMenu) {
            document.getElementById('fdms-container').style.marginLeft = '270px';
        }
        else {
            document.getElementById('fdms-container').style.marginLeft = '0px';
        }
        this._toggleSideMenu = !this._toggleSideMenu;

        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 1000);
    }
    ngOnInit() {      
        let firstName: string = "", lastName: string = "";
        this.appService.getSessionData()
            .subscribe((data: any) => {
                if (data != null) {
                    if (data.User != null && data.User != undefined) {
                        this.IsUnauthorizedAccess = false;
                        if (data.User.FirstName != null) firstName = data.User.FirstName;
                        if (data.User.LastName != null) lastName = data.User.LastName;
                        this.signedUserName = firstName + " " + lastName;
                        this.signedUserInitial = firstName.substring(0, 1) + lastName.substring(0, 1);
                    }
                    else {
                        document.getElementById('fdms-container').style.marginLeft = '0px';
                    }
                }
            });
    }
}
