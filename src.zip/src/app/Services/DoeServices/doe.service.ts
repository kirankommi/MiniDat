import { Injectable } from '@angular/core';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import { RequestOptions, URLSearchParams } from '@angular/http';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { KeyValue } from '../../Models/usermodel';


@Injectable()
export class doeService {
  private masterDataUrl: string = "/DOE/GetMasterData";
  private poolmasterDataUrl: string = "/DOE/DOEPoolMaster";
  private saveDOEUrl: string = "/DOE/SaveDoe";
  private getColumnPreferencesUrl: string = "/DOE/GetColumnPreferences";
  private saveColumnPreferencesUrl: string = "/DOE/SaveColumnPreferences";
  private getDOEUrl: string = "/DOE/DOEDetail";
  private searchDOEUrl: string = "/DOE/SearchDoe";
  private deleteDOEUrl: string = "/DOE/DeleteDOE";
  private uploadFileDOEUrl: string = "/DOE/UploadFiles";
  private downloadFileUrl: string = "/DOE/DownloadFile";
  private studyDocsUrl: string = "/DOE/GetStudyFiles";
  private GetAllDocumentsUrl: string = "/DOE/GetAllDocuments";

  constructor(private httpAction: HttpActionService) {

  }

  getMasterData() {
    return this.httpAction.get(this.masterDataUrl, Constants.options);
  }
  getColumnPreferences() {
    return this.httpAction.get(this.getColumnPreferencesUrl , Constants.options);
  }
  getPoolMasterData() {
    return this.httpAction.get(this.poolmasterDataUrl, Constants.options);
  }

  getDOEInformation(studyID) {
    debugger;
    let params: URLSearchParams = new URLSearchParams();
    params.set('studyID', studyID);
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.getDOEUrl, options);
  }

  save(postData: any) {
    debugger;
    return this.httpAction.post(postData, this.saveDOEUrl);
  }
  saveColumnPreferences(columns: any) {
    debugger;
    return this.httpAction.post(columns, this.saveColumnPreferencesUrl);
  }
  search(postData: any) {
    return this.httpAction.post(postData, this.searchDOEUrl);
  }

  deleteDOE(studyID) {
    return this.httpAction.post(studyID, this.deleteDOEUrl);
  }

  uploadFiles(files: any, data: KeyValue[]) {
    return this.httpAction.postFiles(files, this.uploadFileDOEUrl, data);
  }


  DownloadFile(fileId: number, studyID: number) {
    let params: URLSearchParams = new URLSearchParams();
    params.set('fileId', fileId.toString());
    params.set('studyID', studyID.toString());
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.downloadFileUrl, options);
  }


  onDownloadStudyDoc(studyID: number, Study: string) {
    let params: URLSearchParams = new URLSearchParams();
    params.set('studyID', studyID.toString());
    params.set('studyName', Study);
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.studyDocsUrl, options);
  }

  GetAllDocuments() {
    let params: URLSearchParams = new URLSearchParams();
    // params.set('projectId', projectId);
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.GetAllDocumentsUrl, options);
  }
}
