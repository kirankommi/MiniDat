﻿
import { KeyValue } from '../KeyValue';

export class CatalystLoading implements ReactorModel
{
    public ReactorInternalDia: number;
    public BedLength: number;
    public BedVolume: number;   

    //Loading Template
    public TemplateID: number; 
    public TemplateName: string;
    public TemplateDescription: string;   
    public StatusName: string;    
    public StatusCode: KeyValue[]; 
    public InternalDia: number;  
    public Beds: Bed[];   
    public LoadingType :string;
}

export class ReactorModel
{
    public ReactorInternalDia: number;
    public BedLength: number;
    public BedVolume: number;   

}

export class Bed {
    RowId: number;
    TemplateID: number; 
    BedNumber: number;
    CatalystVolume: number;
    Split: number;
    DiluentDesignation: string;
    DiluentID: number;
    DiluentVolume: number;  
}

