﻿using MINIDAT.Model.Catalyst;
using MINIDAT.Model.UOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystRepository
    {
        CatalystMasterDataModel GetCatalystDetails();
        int SaveCatalyst(CatalystModel catalyst);
        List<CatalystModel> SearchCatalystDetails(CatalystModel project);
        bool DeleteCatalyst(int catalystId);
        List<CatalystLimsSample> GetCatalystSampleIds(int catalystId);

        List<CatalystLite> GetCatalystLite();

        IList<CatalystLimsResult> GetCatalystPhyPropertyResults(int? CatalystId, int AnalysisMethodId, IList<UnitGroup> unitGroups, IList<UomVariable> uomVariables, IList<Validation> validationList);
        int UpdateLimsResult(UpdateLimsModel methodDetails, string userId);
        LimsMasterResults GetCatalystAnalysisMethods(int? catalystId);
    }
}
