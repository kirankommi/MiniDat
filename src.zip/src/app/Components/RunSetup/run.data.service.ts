import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { RunModel } from '../../models/Run/RunModel';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Injectable()
export class RunDataService {

    run1: RunModel = new RunModel();
    run: RunSetupModel = new RunSetupModel();
    private messageSource = new BehaviorSubject(this.run);

    currentMessage = this.messageSource.asObservable();

    constructor() { }
  
    changeMessage(runObj: RunSetupModel) {
        this.messageSource.next(runObj)
    }

}
