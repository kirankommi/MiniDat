﻿export class CatalystAliasSSModel
{
    CatalystAliasSSID: number;
    CatalystAliasSSName: string;  
    StatusName: string;  
    StatusCode: KeyValue; 
    Shape: string;
    Size: string; 
    Shapecd: KeyValue;
    Sizecd: KeyValue;   
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
