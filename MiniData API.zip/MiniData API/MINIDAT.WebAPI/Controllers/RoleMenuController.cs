﻿
/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	RoleMenuController.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	19 May 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using MINIDAT.Model.Manage;
using MINIDAT.Model.Session;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml;

namespace MINIDAT.WebAPI.Controllers
{
    public class RoleMenuController : AppController
    {
        private Dictionary<MenuAssignment, string> privilegesList = new Dictionary<MenuAssignment, string>();
        IRoleMenuRepository _roleMenuFactory = new RoleMenuRepository(new MINIDATDatabase());
        [HttpGet, ActionName("GetRoles")]
      //  public IList<RoleModel> Get()
      public RoleSearchModel Get()
        {

            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage Role Menu" }));
            var roles = _roleMenuFactory.GetRoles(null);
            return roles;
        }

        [HttpGet, ActionName("GetPrivilegesbyRoles")]
        public MenuAssignment GetPrivileges(string roleCode,string appCode)
        {
            var menus = new MenuAssignment();
            try
            {
                if (roleCode != "Select" && appCode != "Select")
                {
                    //privilegesList = new RoleMenuAssignmentDAL().GetMenuByRole(roleCode);
                    privilegesList = _roleMenuFactory.GetMenuByRole(roleCode,appCode);
                    if (privilegesList != null && privilegesList.Count > 0)
                    {
                        //clear the menu items
                        menus.Items.Clear();

                        //get the root node;
                        MenuAssignment item = privilegesList.Keys.FirstOrDefault();
                        item.Items.Clear();

                        //add the child items
                        AddChildren(item);
                        menus.Items.Add(item);
                    }
                }
                else
                {
                    menus.Items.Clear();
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            return menus;
        }

        private void AddChildren(MenuAssignment item)
        {
            //get the all the children from menu dictionary
            var items = from t in privilegesList
                        where t.Value == item.ID
                        orderby t.Value
                        select t.Key;

            if (items.Count() > 0)
            {
                //add every child to parent node
                foreach (MenuAssignment child in items)
                {
                    child.ParentID = item.ID;
                    child.Items.Clear();
                    item.Items.Add(child);
                    AddChildren(child);
                    if (child.IsChecked)
                    {
                        //update its parent status
                        UpdateParent(child);
                    }
                }
            }
        }

        private void UpdateParent(MenuAssignment item)
        {
            MenuAssignment parent;
            if (item != null)
            {
                var parentItems = from p in privilegesList.Keys
                                  where item.ParentID == p.ID
                                  select p;


                if (parentItems != null && parentItems.Count() > 0)
                {
                    //change status of parent item
                    parent = parentItems.FirstOrDefault();
                    parent.IsChecked = CheckParentSelection(parent);
                    UpdateParent(parentItems.FirstOrDefault());
                }
            }

        }

        private bool CheckParentSelection(MenuAssignment item)
        {
            bool parentCheked = false;
            if (item != null)
            {
                if (item.Items != null)
                {
                    foreach (MenuAssignment child in item.Items)
                    {
                        //if any child is selected then parent should select
                        if (child.IsChecked)
                        {
                            parentCheked = true;
                            return parentCheked;
                        }
                    }
                }
            }
            return parentCheked;
        }

        [HttpPost, HttpOptions, ActionName("SaveRolePrivileges")]
        public HttpResponseMessage SaveRoleMenuAssignment([FromBody]MenuAssignment menus, [FromUri]string roleCode) 
        {
            try
            {
                if (menus != null && menus.Items != null && menus.Items.Count > 0 && roleCode != null)
                {
                    MenuAssignment root = menus.Items[0] as MenuAssignment;
                    string[] res = roleCode.Split(';');
                    //get the menu in xml format
                    string menuXMl = CreateMenuXML(root);

                    //save the changes 
                    int result = _roleMenuFactory.SaveRoleMenu(res[0], res[1], menuXMl, UserSession.Instance.User.EID);
                    SetSession(true);
                    if (result > 0)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, "Success");
                    }
                  
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            return Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Request Failed");
        }

        /// <summary>
        /// create menu items in xml format
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        private string CreateMenuXML(MenuAssignment root)
        {
            //intialize the xml writer
            using (System.IO.StringWriter writer = new System.IO.StringWriter())
            {
                XmlWriter xmlWriter = XmlWriter.Create(writer);
                //check the root node of menu
                if (root != null)
                {
                    //write the xml document
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("RoleMenuItems");
                    WriteMenuElement(xmlWriter, root);
                    xmlWriter.WriteFullEndElement();//RoleMenuItems
                    xmlWriter.Flush();
                }
                return writer.ToString();
            }
        }

        /// <summary>
        /// write menu item to xml
        /// </summary>
        /// <param name="xmlWriter"></param>
        /// <param name="node"></param>
        private void WriteMenuElement(XmlWriter xmlWriter, MenuAssignment node)
        {
            //node is selected

            xmlWriter.WriteStartElement("MenuItem");

            //write Id
            xmlWriter.WriteStartElement("Id");
            xmlWriter.WriteValue(node.ID);
            xmlWriter.WriteFullEndElement();//end Id

            //write selection
            xmlWriter.WriteStartElement("IsChecked");
            xmlWriter.WriteValue(node.IsChecked);
            xmlWriter.WriteFullEndElement();//end IsChecked

            //write can read status
            xmlWriter.WriteStartElement("ReadOnly");
            xmlWriter.WriteValue(node.ReadOnly);
            xmlWriter.WriteFullEndElement();//end ReadOnly

            //write can edit status
            xmlWriter.WriteStartElement("CanWrite");
            xmlWriter.WriteValue(node.CanWrite);
            xmlWriter.WriteFullEndElement();//end CanWrite

            xmlWriter.WriteFullEndElement();//Menu Item

            //check for children selection
            if (node.Items != null)
            {
                foreach (MenuAssignment child in node.Items)
                {
                    WriteMenuElement(xmlWriter, child);
                }
            }

        }
    }
}
