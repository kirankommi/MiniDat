﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleController.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Manage Role - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Feed;
using MINIDAT.Model.Feed;
using MINIDAT.Model;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

namespace MINIDAT.WebAPI.Controllers
{
    public class FeedController : AppController
    {
        IFeedRepository _feedRepository;       
        public FeedController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage Feed" }));
            _feedRepository = new FeedRepository(new MINIDATDatabase());
        }
        /// <summary>
        /// search the roles
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SearchFeedInformation")]
        public FeedSearchModel GetData([FromBody] FeedModel feed)
        {
            //RoleRepository _roleRepository = new RoleRepository(new FDMSDatabase());
            var tbpsrModel = _feedRepository.GetFeedData(feed);
            return tbpsrModel;
        }
      
        [HttpPost, ActionName("SaveFeedInformation")]
        public HttpResponseMessage SaveFeedInformation([FromBody] FeedModel feed)
        {
            if (feed != null)
            {
                try
                {
                    IFeedRepository _feedRepository = new FeedRepository(new MINIDATDatabase());
                    _feedRepository.SaveFeedData(feed, User.Identity.Name);
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        /// <summary>
        /// remove the role
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>

        [HttpPost, ActionName("DeleteFeedInformation")]
        public HttpResponseMessage DeleteFeedInformation([FromBody] FeedModel feed)
        {
            if (feed != null)
            {
                try
                {
                    IFeedRepository _feedRepository = new FeedRepository(new MINIDATDatabase());
                    _feedRepository.DeleteFeedData(feed);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }

    }
   
}
