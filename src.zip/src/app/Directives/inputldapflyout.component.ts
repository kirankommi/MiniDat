﻿import { Component, OnInit, Input, ElementRef, Renderer, EventEmitter, Output } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { AppComponent } from '../app.component';
import { TooltipModule } from 'primeng/primeng'; 
@Component({
    //moduleId: module.id,
    selector: 'ldap-input-flyout',
    templateUrl: 'inputldapflyout.component.html',
    animations: [
        trigger('slideInOut', [
            state('in', style({
                transform: 'translate3d(0, 0, 0)'
            })),
            state('out', style({
                transform: 'translate3d(100%, 0, 0)'
            })),
            transition('in => out', animate('400ms ease-in-out')),
            transition('out => in', animate('400ms ease-in-out'))
        ]),
    ],
})

export class InputLDAPFlyoutComponent implements OnInit {
    //@Input() flyoutdata: any = [];
    //@Input() flyouttempdata: any = [];
    @Input() inputValue: string;
    @Input() fTitle: string;
    @Input() pHolder: string;
    @Input() colList: string[];
    @Input() eventSource: string;
    @Input() isNotSearchable: boolean;
    @Input() isEditable: boolean = false;
    @Input() canShowFlyout: boolean = false;
    @Output() inputEvent = new EventEmitter();
    @Output() inputTextChange = new EventEmitter();
    @Input() canToggelFlyoutOnMouseEnter: boolean = false;
    flyoutState: string = 'out';
    @Input() datalist: any[]; 
    constructor(private appComponent: AppComponent) {

    }

    ngOnInit() {
    }

    toggleFlyoutOnMouseEnter() {
       
        if (this.canToggelFlyoutOnMouseEnter) {
            if (!this.isNotSearchable) {
                this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
                this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
            }
        }
    }
    toggleFlyout() {
        if (!this.isNotSearchable) {
            this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
            this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
        }
    }
    onCellChanage(event: any) {
        this.inputEvent.emit({ "CellChange": true, "Value": event});
    }
    onRowSelect(event: any) {
        this.flyoutState = 'out';
        this.appComponent.isOverlay = false;
        if (event == "Close") {

        }
        else {
            this.inputEvent.emit(event);
        }
    }
}