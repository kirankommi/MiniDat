﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.MINISQ
{
    public class MasterData
    {
        public class PlantRun
        {
            public int PlantKey;
            public string PlantNm;
            public int RunNum;
        }
        public List<KeyValue> Projects = new List<KeyValue>();
        public List<KeyValue> StudyNames = new List<KeyValue>();
        public List<KeyValue> Plants = new List<KeyValue>();
        public List<KeyValue> Runs = new List<KeyValue>();
        public List<PlantRun> PlantRuns = new List<PlantRun>();
        public List<KeyValue> Status = new List<KeyValue>();
        public List<KeyValue> CatalystDesignation = new List<KeyValue>();
        public List<KeyValue> CatalystFamily = new List<KeyValue>();
        public List<KeyValue> CatalystLeader = new List<KeyValue>();
        public List<KeyValue> FeedStock = new List<KeyValue>();
        public List<KeyValue> Specialist = new List<KeyValue>();
        public string ColumnPref { get; set; }
    }


}
