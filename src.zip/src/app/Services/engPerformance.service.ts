import { Injectable, ReflectiveInjector } from '@angular/core';
import { HttpActionService } from './httpaction.service';
import 'rxjs/add/operator/toPromise';
import * as  Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';

@Injectable({
    providedIn: 'root'
})
export class engPerformanceService {
    stdToolsUrl: string = "/innovation ";


    constructor(private httpaction: HttpActionService) {

    }

    GetstdTools() {
        return this.httpaction.get(this.stdToolsUrl, Constants.options);
    }
}
