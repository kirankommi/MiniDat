import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { UserModel } from '../Models/usermodel';
import { HttpActionService } from './httpaction.service';
import * as Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class UserService {
    private getUser = "/User/SearchUserData/";
    private saveUser = "/User/SaveUserData/";
    private deleteUser = "/User/DeleteUserData/";

    constructor(private httpaction: HttpActionService) { }

    getUsers(userData: UserModel) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('EID', userData.EID);
        params.set('FirstName', userData.FirstName);
        params.set('LastName', userData.LastName);
        params.set('Phone', userData.Phone);
        params.set('EmailId', userData.EmailId);
        params.set('DepartmentName', userData.DepartmentName);
        // params.set('AppRoleName', userData.AppRoleName);
        params.set('StatusName', userData.StatusName);
        params.set('RoleName', userData.RoleName);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getUser, options);
    }

    saveUserData(userData: UserModel) {
        return this.httpaction.post(userData, this.saveUser);
    }

    deleteUserData(userData: UserModel) {
        return this.httpaction.post(userData, this.deleteUser);
    }
}

