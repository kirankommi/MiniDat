﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICRUDRepository<T>:IRepository
    {
        void Update(T _model);
        void Add(T _model);
        IList<T> List(ICriteria _criteria);
        bool Delete(T _model);
    }
}
