import { Component, Directive, OnInit, ViewChild, ElementRef, AfterViewInit, Input, Output, EventEmitter, HostListener, DoCheck, ViewEncapsulation } from "@angular/core";
import { max } from "rxjs/operators";
import { doeService } from "../../services/doeservices/doe.service";
import { trigger, transition, animate, style } from '@angular/animations';
import { doeMediatorService } from '../../services/doeservices/doemediator.service';
import * as  Constants from '../../Shared/globalconstants';
import { AppComponent } from '../..//app.component';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertMessage } from '../../Services/alertmessage.service';
import { errorModel } from './errorModel';
import { columnManipulator, customColumn } from '../../Directives/columnManipulator';
import * as  DoeConstants from './doeConstants';
import { sharedService } from '../../Services/shared.Service';
import { Message } from "@angular/compiler/src/i18n/i18n_ast";
import { messageModalUtility } from "src/app/Shared/message-modal.utility";
import { ActivatedRoute, Router } from "@angular/router";
import { jsonpCallbackContext } from "@angular/common/http/src/module";
import { analyzeAndValidateNgModules } from "@angular/compiler";

@Component({
  templateUrl: "currentRunInfo.component.html",
  selector: "current-Run-Info",
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateX(-100%)' }),
        animate('200ms ease-in', style({ transform: 'translateX(0%)' }))
      ]),
      transition(':leave', [
        //animate('200ms ease-in', style({ transform: 'translateX(-100%)' }))
      ])
    ])
  ],
  styleUrls: ["currentRunInfostyle.css"],
  providers: [NgbModalConfig, NgbModal],
  encapsulation: ViewEncapsulation.None

})
export class currentRunInfoComponent implements OnInit, AfterViewInit {
  runs: any[] = [];
  plantsHITC: any[] = ["2005", "2006"];
  plantsUS: any[] = ["321", "322", "323", "324", "325", "326"];
  manipulator: columnManipulator;
  tableProps: any;
  catalystCollapseCtrl: boolean = true;
  modeCollapseCtrl: boolean = true;
  feedCollapseCtrl: boolean = true;
  SettingsIconUrl: string = Constants.settingsIcon;
  DeleteIconUrl: string = Constants.deleteIconPath;
  CopyIconUrl: string = Constants.copyIconPath;
  PasteIconUrl: string = Constants.pasteIconPath;
  selectedDoeRun: any;
  selectedMinisRun: any;
  currentRunCatTemplate: any = {};
  isCopied: boolean = false;
  copiedRun: any = {};
  deleteRuns: number[] = [];
  masterData: any = {};
  catSelectorVisibility: boolean = false;
  runsVisibility: boolean = true;
  NetConvdisplay: boolean = false;
  columns: customColumn[] = DoeConstants.columns;
  userPreferences: customColumn[] = [];
  public error: errorModel = new errorModel();
  @Input()
  projectName: string = "";
  @Input()
  studyName: string = "";
  @Input()
  Project: any = {};

  ngOnInit() {
    this.mS.onRuoteIntialized.subscribe((data) => {
      // debugger;

      this.sub = this.route.params.subscribe(params => {
        this.doeRun = params['doeRun'];
      });
      if (this.doeRun != undefined && this.doeRun != null) {
        let selectedRow: any = Object.keys(data.runs).find(key => data.runs[key].DOERun === parseInt(this.doeRun));
      this.selectedMinisRun = [data.runs[selectedRow]];
      }
      
      if (data != "create" && data.runs) {
        this.runs = data.runs.map(q => {
          let t = { Plant: "Select", CatalystTemplate: {}, Mode: {}, Feed: {}, ...q };
          return t;
        });
      } else {
        this.runs = [];
      }
    });

  }
  
  

  sub: any;
  doeRun: any;
  modeFlyoutcolumns: any[] = [
    { Key: "ModeNumber", Value: "Mode #" },
    { Key: "ModeType", Value: "Mode" },
    { Key: "ControlName", Value: "Control" },
    { Key: "SulfidingType", Value: "Sulfiding" }];

  feedFlyoutcolumns: any[] = [
    { Key: "UOPNum", Value: "UOP #" },
    // { Key: "BookNum", Value: "Book #" },
    { Key: "Name", Value: "Name" },
    { Key: "DensityMsr", Value: "Feed Density at ISCO OP temperature (g/cc)" },

  ];

  @ViewChild('doeTable') elementView: ElementRef;

  constructor(public mS: doeMediatorService, private router: Router,  private appComponent: AppComponent, config: NgbModalConfig, private modalService: NgbModal, public alertMessage: AlertMessage,
    public sharedService: sharedService, public service: doeService, private messageService: messageModalUtility, private route: ActivatedRoute) {
    this.manipulator = new columnManipulator(this.columns);
    this.tableProps = this.manipulator.updateProperties(false);
    this.mS.getDOEInformation = this.getSaveData.bind(this);
    // customize default values of modals used by this component tree
    config.backdrop = 'static';
    config.keyboard = false;
  }
  

  updateConversionArray(run) {
    try {
      run.Mode.Conversion = Array(run.Mode.Conditions).fill(null);
    }
    catch (error) {
      return "";
    }
  }
  onSaveColumns() {
    this.service.saveColumnPreferences({ ColumnPreferences: JSON.stringify(this.columns) }).subscribe((data: any) => { });
  }
  onPlantChange(run, eve) {
    let oldValue = run.Plant;
    run.Plant = eve.target.value;
    if (run.Plant != "Select") {
      // debugger;
      let location = this.mS.masterData.PlantList.filter(q => q.Key == run.Plant)[0].Location;
      run.NetworkNUM = location == "HITC" ? "3" : "1";

      if (parseInt(run.RunNum) == 0 || isNaN(run.RunNum)) {
        if (run.OldPlantDetails && run.OldPlantDetails.Plant == run.Plant) {
          run.RunNum = run.OldPlantDetails.RunNum;
          run.StartDate = run.OldPlantDetails.StartDate;
          run.EndDate = run.OldPlantDetails.EndDate;
        }
      } else {
        run.OldPlantDetails = { Plant: oldValue, RunNum: run.RunNum, StartDate: run.StartDate, EndDate: run.EndDate };
        run.RunNum = 0;
        run.StartDate = "";
        run.EndDate = "";
      }
    }
  }

  selectCatalystTemplate(doeRun: any) {
    debugger;

    this.selectedDoeRun = doeRun;
    this.currentRunCatTemplate = doeRun.CatalystTemplate;
    this.runsVisibility = false;
    this.catSelectorVisibility = true;
  }

  onCatalystSelected($event) {
    debugger;
    if ($event.TemplateID && $event.TemplateID != 0)
      this.selectedDoeRun.CatalystTemplate = $event;
    this.runsVisibility = true;
    this.catSelectorVisibility = false;
  }

  concatStrings(ary: any[], prop: string) {
    try {
      return ary.map(q => q.Catalyst[prop]).join("|");
    }
    catch (error) {
      return "";
    }
  }

  updateTempConversion(run: any, content) {
    if (run && run.Mode && run.Mode.Conversion && run.Mode.Conversion.length > 0) {
      this.selectedDoeRun = run;
      this.NetConvdisplay = true;

      this.modalService.open(content, {
        centered: true, backdrop: true, windowClass: "custom-Modal"
      });
    }
  }

  copyRun(run: any) {
    this.isCopied = true;
    this.copiedRun = { ...run };
  }

  pasteRun(run) {
    this.isCopied = false;
    run.CatalystTemplate = JSON.parse(JSON.stringify({ ... this.copiedRun.CatalystTemplate }));
    run.Mode = JSON.parse(JSON.stringify({ ...this.copiedRun.Mode }));
    run.Feed = { ...this.copiedRun.Feed };
  }


  ngAfterViewInit(): void {

  }

  onFeedSelected($event, run) {
    let plant = [];
    plant = this.mS.masterData.PlantList.filter(p => p.Key === run.Plant);
    if ($event.DensityMsr == null && (this.plantsHITC.includes(plant[0].Name))) {
      this.messageService.show(Constants.Confirm, Constants.ConfirmISCOHITC, Constants.Confirm).then(result => {
        result = result == Constants.ConfirmTrue; //casting string to boolean
        if (result) {
          run.Feed = $event;
          run.Feed.HasDopant = false;
        }
      });

    } else if ($event.DensityMsr != null && (this.plantsUS.includes(plant[0].Name))) {
      this.messageService.show(Constants.Confirm, Constants.ConfirmISCOUS, Constants.Confirm).then(result => {
        result = result == Constants.ConfirmTrue; //casting string to boolean
        if (result) {
          run.Feed = $event;
          run.Feed.HasDopant = false;
        }
      });
    }
    else if (plant[0].Name != "Select") {
      run.Feed = $event;
      run.Feed.HasDopant = false;
    }
    //this.updateFlushRequired();
  }

  onModeSelected($event, run) {
    debugger;
    run.Mode = { ...$event };
    this.selectedDoeRun = run;
    run.Mode.Conversion = Array($event.Conditions).fill(null);
  }

  updateTableProperties() {
    // debugger;
    this.tableProps = this.manipulator.updateProperties(false);
  }
  goToMinisQ(event)
  {
    this.router.navigateByUrl('/minisq/queue');
  }
  collapseHeaders(headerName: string, visibleCtrl: string) {
    this.columns.find((q) => q.name == headerName).childrens.filter((e) => !e.isStatic).forEach((w) => w.isVisible = !this[visibleCtrl]);
    this[visibleCtrl] = !this[visibleCtrl];
    this.updateTableProperties();
  }

  addRun() {
    if (this.runs.length == 0) {
      this.runs.push({ DOERun: 1, Plant: "Select", CatalystTemplate: {}, Mode: {}, Feed: {}, Status:"Queued" });
    } else {
      this.runs.push({ DOERun: Math.max.apply(Math, this.runs.map(w => w.DOERun)) + 1, Plant: "Select", CatalystTemplate: {}, Mode: {}, Feed: {}, Status:"Queued" });
    }
  }

  arrayTwo(n: number): string[] {
    return Array(n).fill(0).map((x, i) => i.toString());
  }

  validate(): boolean {
    this.error = new errorModel();
    if (this.runs) {
      this.error.Fields = {};
      this.runs.forEach((q, i) => {
        this.error.Fields[q.DOERun] = {};
        if (!q.Plant || q.Plant == "Select") {
          this.error.Messages = this.error.Messages + "Select the plant for Run" + q.DOERun + " \n";
          this.error.Count++;
          this.error.Fields[q.DOERun]["Plant"] = true;
        }
        if (!q.Mode.ModeNumber) {
          this.error.Messages = this.error.Messages + "Select the Mode for Run" + q.DOERun + " \n";
          this.error.Count++;
          this.error.Fields[q.DOERun]["Mode"] = true;
        }
      });
      if (this.error.Count > 0) {
        this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Current Run Information', detail: this.error.Messages, life: 90000 });
        return false;
      }
    }
    return true;
  }

  deleteRun(doeRunID, doeRunNum) {
    this.runs.splice(this.runs.findIndex(q => q.DOERun == doeRunNum), 1);
    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'DOE Run# ' + doeRunNum + ' deleted successfully. Please click save to retain the changes.', detail: this.error.Messages, life: 90000 });
    if (!isNaN(doeRunID)) {
      this.deleteRuns.push(doeRunID);
    }
  }

  getSaveData() {
    return new Promise((resolve, reject) => {
      if (this.validate()) {
        return resolve({ Runs: this.runs, DeleteIds: this.deleteRuns.join(",") });
      }
      return resolve("error");
    });
  }
  saveColumnsInfo(event) {
    // this.onSaveColumns();
  }
 
}
