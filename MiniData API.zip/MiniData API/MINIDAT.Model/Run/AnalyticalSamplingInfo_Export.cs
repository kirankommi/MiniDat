﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class AnalyticalInfoModelExport
    {
        public string StreamName { get; set; }
        public string LIMSOPerationName { get; set; }
        public string MethodNumber { get; set; }
        public string SampleVolumeinCC { get; set; }
        public double? SampleCost { get; set; }
        public string FrequencyName { get; set; }
    }
}
