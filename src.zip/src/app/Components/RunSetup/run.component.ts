import { Component, OnInit, ElementRef } from '@angular/core';
import { uploadHandler } from '../../Directives/filebrowse/filebrowse.component';
import { Observable } from "rxjs";
import { FileModel } from '../../Models/file.model';
import { ProjectService } from '../../Services/ProjectServices/project.service';
import { RunDataService } from "./run.data.service";
import { RunModel, GeneralInfoModel, AdditionalInfoModel, FeedModel, ExportPopupSummary, KeyValue, NIRModel } from '../../models/Run/RunModel';
import { ActivatedRoute } from '@angular/router';
import * as Constants from '../../../app/Shared/globalconstants';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RunService } from '../../Services/RunServices/Run.service';
import { AlertMessage } from '../../services/alertmessage.service';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';
import { isNumeric } from 'rxjs/util/isNumeric';
import { FeedService } from '../../Services/FeedServices/Feed.service';

@Component({
  selector: 'app-run',
  templateUrl: './run.component.html',
  styleUrls: ['./run.component.css'],
  providers: [NgbModalConfig, NgbModal, FeedService]
})
export class RunComponent implements OnInit {
  run1: RunModel = new RunModel();
  exportData: RunModel = new RunModel();
  templateName: any = "general";
  run: RunSetupModel;
  plantCode: string;
  runNum: string;
  runId: string;
  sub: any;
  containerHeight: number;
  goBackIconPath: string;
  constants: any = {};
  routerLinkVariable = "../../../../../PlantData/TestCreation"
  //Export Popup
  popupSummary: ExportPopupSummary = new ExportPopupSummary();
  ExportSuccess: string = "Exported Data successfully"
  popuplist: any;
  plantsHITC: string[] = ["2005", "2006"];
  plantsUS: string[] = ["321", "322", "323", "324", "325", "326"];
  cols: any;
  colsMaster: string[];
  weightCheck: number = 2;
  weightChecksData: any;
  recCols = [];
  lineoutColumn = "Lineout";
  previousRowData: any;
  tempLO = "Temperature Lineout";
  weightCheckColumn = 'weight';
  lineout = "lineout";
  recMasterData: any;
  lstFeedIDs: any = [];
  lstFeeds: any;
  lstParentFeeds: any;
  lstBledDopants: any;
  lstAnalysisMethods: any;
  blendList: any;
  blendTotalWeight: number;
  blendweightpct: number;
  weightedNitrogenAmt: number;
  weightedSufurAmt: number;
  parentFeedsWeight: number;
  feedstockLink: string;
  //selectedPopupList : KeyValue[];

  constructor(private feedService: FeedService, private projectService: ProjectService, private route: ActivatedRoute, public el: ElementRef, public runDataService: RunDataService,
    config: NgbModalConfig, private runService: RunService, private alertMessage: AlertMessage) {

    this.goBackIconPath = Constants.goBackIconPath;
    this.constants = Constants;
    this.popuplist = [
      { Key: "1", Value: "General Info", Groupcd: 0 },
      { Key: "2", Value: "Boiling Point", Groupcd: 0 },
      { Key: "3", Value: "Catalyst", Groupcd: 0 },
      { Key: "4", Value: "Feed", Groupcd: 0 },
      { Key: "5", Value: "Analytical Sampling Schedule", Groupcd: 0 },
      { Key: "6", Value: "NIR Specs", Groupcd: 0 },
      { Key: "7", Value: "TMS & Mass Flow Meter Calibration", Groupcd: 0 },
      { Key: "8", Value: "Process Specification", Groupcd: 0 },
      { Key: "9", Value: "Additional Info", Groupcd: 0 },
      { Key: "10", Value: "TC Calibration", Groupcd: 0 },
      { Key: "11", Value: "Recipe", Groupcd: 0 },
    ]
  }

  ngOnInit() {
    this.resizeMe();
    this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);
    this.sub = this.route.params.subscribe(params => {
      this.popupSummary.isGeneralInfo = false;
      this.popupSummary.isBoilingPoint = false;
      this.popupSummary.isCatalyst = false;
      this.popupSummary.isFeed = false;
      this.popupSummary.isAnalyticalSample = false;
      this.popupSummary.isNIRSpecs = false;
      this.popupSummary.isTMS = false;
      this.popupSummary.isProcessSpec = false;
      this.popupSummary.isAdditionalInfo = false;
      this.popupSummary.isTCCaliration = false;
      this.popupSummary.isRecipe = false;

      this.plantCode = params['plant'];
      this.runNum = params['runNum'];
      this.runId = params['run'];
    });
    // if (this.runId != this.run1.RunId) {
    // this.run.GeneralInfo = new GeneralInfoModel;
    // this.run.Cataysts = [];
    // this.run.Beds = [];
    // this.run.AdditionalInfo = new AdditionalInfoModel;
    // this.run.lstTC_Calibrations = [];
    // this.run.lstTMF_Calibrations = [];
    // this.run.lstAnalyticalSamples = [];
    // this.run.FeedInfo = new FeedModel;
    // this.run.lstRunCutBoilingPoints = [];
    // this.run.PopUpSummary = new ExportPopupSummary;
    // this.run.lstNIRSpec = [];
    // this.run.Recipe = null;
    // this.run.lstProcessSpec = [];
    // this.exportData.selectedPopupList = [];
    // }
  }
  ngOnDestroy() {
    this.run.isInitial = true;
  }
  saveRunSetup() {

    let response: any;
    this.beforeSaveRecipe();
    if (this.isDataValid()) {
      this.runService.SaveRunSetupDetails(this.run)
        .subscribe(
          (data: any) => {

            if (data == Constants.Success) {
              // this.onReset()
              this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Success', detail: "Saved Successfully" });

              // this.IsSaved = true;
            }
          },
          err => { }
        );
    }
    else {
      this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
    }
  }
  isDataValid(): boolean {
    if (!this.isGeneralInfoValid()) {
      return false;
    }
    if (!this.isBoilingPointsValid()) {
      return false;
    }
    if (!this.isAnalyticalSampleValid()) {
      return false;
    }
    if (!this.isTMFCalibrationValid()) {
      return false;
    }
    if (!this.isProcessSpecValid()) {
      return false;
    }
    if (!this.isAdditionalInfoValid()) {
      return false;
    }
    if (!this.isTCCalibrationValid()) {
      return false;
    }

    return true;
  }
  isGeneralInfoValid(): boolean {
    if (this.run.GeneralInfo.Technician1 == "" || this.run.GeneralInfo.Technician1 == null || this.run.GeneralInfo.Technician1 == undefined) { this.run.GeneralInfo.Technician1EID = null };
    if (this.run.GeneralInfo.Technician2 == "" || this.run.GeneralInfo.Technician2 == null || this.run.GeneralInfo.Technician2 == undefined) { this.run.GeneralInfo.Technician2EID = null };
    if (this.run.MetaData.RunNum == null) {
      return false;
    }
    return true;
  }
  isBoilingPointsValid(): boolean {

    return true;
  }
  isAnalyticalSampleValid(): boolean {
    let status: boolean = true;
    if (this.run.lstAnalyticalSamples.length > 0) {
      this.run.lstAnalyticalSamples.forEach(element => {
        if (element.StreamId == 0) {
          status = false;
        }
        else if (element.FrequencyName == undefined || element.FrequencyName == "AAA") {
          status = false;
        }
        else if (element.LIMSOPerationName == undefined) {
          status = false;
        }

      });
      return status;
    }
  }
  isTMFCalibrationValid(): boolean {
    if (this.run.MetaData.RunNum == null || this.run.lstTMF_Calibrations[0].Value == null || this.run.lstTMF_Calibrations[0].Value == Constants.Undefined
      || this.run.lstTMF_Calibrations[1].Value == null || this.run.lstTMF_Calibrations[1].Value == Constants.Undefined
    ) {
      return false;
    }
    return true;
  }
  isProcessSpecValid(): boolean {
    debugger;

    if (this.run.MetaData.RunNum == null || this.run.MetaData.RunId == null) {
      return false;
    }
    if (this.run.lstProcessSpec.filter(x => (x.Value == null || x.Value == undefined)).filter(y => (y.ParameterName == 'Top Block Offset Low'
      || y.ParameterName == 'Top Block Offset High' || y.ParameterName == 'Feed Rate Filter (stdev)'
      || y.ParameterName == 'HPS Pressure RCP OP-High'
      || y.ParameterName == 'HPS Pressure RCP OP-Low')).length > 0) {
      return false;
    }
    return true;
  }
  isAdditionalInfoValid(): boolean {
    if (this.run.MetaData.RunNum == null || this.run.AdditionalInfo.SelectedFeedSource == 'AAA' || this.run.AdditionalInfo.SelectedNormalizationFactor == 'DEFAULT'
      || (this.run.AdditionalInfo.HPSControllerOffset == null || this.run.AdditionalInfo.HPSControllerOffset == undefined)
      || (this.run.AdditionalInfo.PlantTCOffset == null || this.run.AdditionalInfo.PlantTCOffset == undefined)
      || (this.run.AdditionalInfo.OffgasHeaviesWeight == null || this.run.AdditionalInfo.OffgasHeaviesWeight == undefined)
      || (this.run.AdditionalInfo.H2TMFSpec == null || this.run.AdditionalInfo.H2TMFSpec == undefined)) {
      return false;
    }
    return true;
  }
  isTCCalibrationValid(): boolean {
    let tcCalibration = this.run.lstTC_Calibrations.filter((x: any) => (x.Value == null && !x.ParameterName.includes("Date")));
    if (tcCalibration.length > 0) {
      return false;
    }
    return true;
  }
  onResize(event) {
    this.resizeMe();
  }
  getIconPath() {
    return this.goBackIconPath;
  }
  resizeMe() {

    this.containerHeight = (window.innerHeight - 218);
    //let table = this.el.nativeElement.querySelector('#row-pane');
    //table.style.height = height;

  }
  showOverlay($event, exportFilter, runSetUpHeader) {

    exportFilter.style["position"] = "absolute";
    exportFilter.style["top"] = runSetUpHeader.offsetHeight - 4 + 'px';
    exportFilter.style["left"] = runSetUpHeader.offsetLeft - 220 + 'px';
    exportFilter.style["height"] = 545 + 'px';
    exportFilter.toggle($event, exportFilter);
  }
  exportToexcel(exportPopup_layout) {

    this.popupSummary.isGeneralInfo = false;
    this.popupSummary.isBoilingPoint = false;
    this.popupSummary.isCatalyst = false;
    this.popupSummary.isFeed = false;
    this.popupSummary.isAnalyticalSample = false;
    this.popupSummary.isNIRSpecs = false;
    this.popupSummary.isTMS = false;
    this.popupSummary.isProcessSpec = false;
    this.popupSummary.isAdditionalInfo = false;
    this.popupSummary.isTCCaliration = false;
    this.popupSummary.isRecipe = false;
    //parameters
    this.exportData.Plant = this.run.MetaData.Plant;
    this.exportData.RunId = this.run.MetaData.RunId;
    this.exportData.RunNum = this.run.MetaData.RunNum
    //popup summary
    this.exportData.selectedPopupList.forEach(element => {
      if (element.Value == "General Info") {
        this.popupSummary.isGeneralInfo = true;
        this.exportData.GeneralInfo = this.run.GeneralInfo;
        this.exportData.StartDate = this.run1.StartDate;
        this.exportData.EndDate = this.run1.EndDate;
        this.exportData.ZeroHOSTime = this.run1.ZeroHOSTime;
      }
      else if (element.Value == "Boiling Point") {
        this.popupSummary.isBoilingPoint = true;
      }
      else if (element.Value == "Catalyst") {
        this.popupSummary.isCatalyst = true;
      }
      else if (element.Value == "Feed") {
        this.popupSummary.isFeed = true;
      }
      else if (element.Value == "Analytical Sampling Schedule") {
        this.popupSummary.isAnalyticalSample = true;
      }
      else if (element.Value == "NIR Specs") {
        this.popupSummary.isNIRSpecs = true;
      }
      else if (element.Value == "TMS & Mass Flow Meter Calibration") {
        this.popupSummary.isTMS = true;
      }
      else if (element.Value == "Process Specification") {
        this.popupSummary.isProcessSpec = true;
      }
      else if (element.Value == "Additional Info") {
        this.popupSummary.isAdditionalInfo = true;
      }
      else if (element.Value == "TC Calibration") {
        this.popupSummary.isTCCaliration = true;
      }
      else if (element.Value == "Recipe") {
        this.popupSummary.isRecipe = true;
      }
    });
    this.exportData.PopUpSummary = this.popupSummary;
    console.log(this.exportData.PopUpSummary);
    exportPopup_layout.visible = false;
    this.runService.GetExportData(this.exportData)
      .subscribe(
        (data: any) => {

          if (data != null) {
            let DocumentName = "P" + this.exportData.Plant + "_R" + this.exportData.RunNum + ".xlsx";
            var byteCharacters = atob(data);
            var byteNumbers = new Array(byteCharacters.length);
            for (var i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            var blob = new Blob([byteArray], { type: "" });
            var ua = window.navigator.userAgent;
            var msie = ua.indexOf("MSIE ");
            var chrome = ua.indexOf("Chrome");

            if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
              window.navigator.msSaveOrOpenBlob(blob, DocumentName);
            }
            else {
              var objectUrl = URL.createObjectURL(blob);
              var link = document.createElement("A");
              link.setAttribute("href", objectUrl);
              link.setAttribute("download", DocumentName);
              link.setAttribute("target", "_blank");
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }
            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.ExportSuccess });
          }
          else {
            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Results are missing for the selected analysis." });
          }
        },
        // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      );
  }
  close() {
    this.resetpopup();
  }
  resetpopup() {
    this.exportData.selectedPopupList = [];
    this.popupSummary.isGeneralInfo = false;
    this.popupSummary.isBoilingPoint = false;
    this.popupSummary.isCatalyst = false;
    this.popupSummary.isFeed = false;
    this.popupSummary.isAnalyticalSample = false;
    this.popupSummary.isNIRSpecs = false;
    this.popupSummary.isTMS = false;
    this.popupSummary.isProcessSpec = false;
    this.popupSummary.isAdditionalInfo = false;
    this.popupSummary.isTCCaliration = false;
    this.popupSummary.isRecipe = false;

  }
  processRunBoilingPoints() {
    if (this.run.lstRunCutBoilingPoints == null || this.run.lstRunCutBoilingPoints == undefined || this.run.lstRunCutBoilingPoints.length == 0) {
      this.run.lstRunCutBoilingPoints = JSON.parse(JSON.stringify(this.run.MasterData.LstStdBoilingPoints));
    }
    else {
      this.run.lstRunCutBoilingPoints = this.run.lstRunCutBoilingPoints;
    }
  }
  processNIRSpecs() {
    let tempList: NIRModel[] = [];
    if (this.run.lstNIRSpec.length > 0) {
      for (var i = 0; i < this.run.lstNIRSpec.length; i++) {
        if (this.run.lstNIRSpec[i].Parameter == 'Model ID') {
          tempList.push({
            ParameterId: this.run.lstNIRSpec[i].ParameterId, Parameter: this.run.lstNIRSpec[i].Parameter, Value: null, ParameterUOM: "NA", DefaultUnit: "", NIRModelID: this.run.MetaData.NIRModelID,
            ValueText: this.run.lstNIRSpec[i].ValueText
          });
        }
        else if (this.run.lstNIRSpec[i].Parameter == 'NIR Low Target - Conversion') {
          tempList.push({
            ParameterId: this.run.lstNIRSpec[i].ParameterId, Parameter: this.run.lstNIRSpec[i].Parameter, Value: this.run.MetaData.LowTgtConversion, ParameterUOM: this.run.lstNIRSpec[i].ParameterUOM, DefaultUnit: this.run.lstNIRSpec[i].DefaultUnit, NIRModelID: this.run.MetaData.NIRModelID
            , ValueText: this.run.lstNIRSpec[i].ValueText
          });
        }
        else if (this.run.lstNIRSpec[i].Parameter == 'NIR High Target - Conversion') {
          tempList.push({
            ParameterId: this.run.lstNIRSpec[i].ParameterId, Parameter: this.run.lstNIRSpec[i].Parameter, Value: this.run.MetaData.HighTgtConversion, ParameterUOM: this.run.lstNIRSpec[i].ParameterUOM, DefaultUnit: this.run.lstNIRSpec[i].DefaultUnit, NIRModelID: this.run.MetaData.NIRModelID
            , ValueText: this.run.lstNIRSpec[i].ValueText
          });
        }
        else {
          tempList.push({
            ParameterId: this.run.lstNIRSpec[i].ParameterId, Parameter: this.run.lstNIRSpec[i].Parameter, Value: this.run.lstNIRSpec[i].Value, ParameterUOM: this.run.lstNIRSpec[i].ParameterUOM,
            DefaultUnit: this.run.lstNIRSpec[i].DefaultUnit, NIRModelID: "NOT RELEVANT", ValueText: this.run.lstNIRSpec[i].ValueText
          });
        }

      }
    }
    this.run.lstNIRSpec = tempList;
  }
  processAdditionalInfo() {
    if ((this.run.AdditionalInfo.SelectedFeedSource == null || this.run.AdditionalInfo.SelectedFeedSource == Constants.Undefined)) {
      this.run.AdditionalInfo.SelectedNormalizationFactor = "GC P64"; //Default for All Plants
      this.run.AdditionalInfo.OffgasHeaviesWeight = 0.01; //Default Value in Kg for All Plants

      if (this.plantsUS.includes(this.run.MetaData.Plant.toString())) {
        this.run.AdditionalInfo.SelectedFeedSource = "AVG";   //RVSD Plants default                    
      }
      else {
        this.run.AdditionalInfo.SelectedFeedSource = "IPP";   //ITC Plants default
      }

    }
  }
  setProcessSpecDefaultValues() {
    let TMFIntercept;
    let TMFSlope;
    this.run.lstProcessSpec.map((x, i) => {
      if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Top Block Offset Low') {
        x.Value = 269.15;
      }
      if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Top Block Offset High') {
        x.Value = 271.65;
      }
      if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Feed Rate Filter (stdev)') {
        x.Value = 2;
      }
      if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'HPS Pressure RCP OP-High') {
        x.Value = .80;
      }
      if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'HPS Pressure RCP OP-Low') {

        x.Value = .20;
      }
      if (x.RecordSet == 'SAVED' && x.ParameterName == 'Feed (Sulfiding)') {
        x.ValueText = this.run.MasterData.lstFlyoutFeeds.filter((y: any) => y.ID == x.Value)[0] == undefined ? null : this.run.MasterData.lstFlyoutFeeds.filter((y: any) => y.ID == x.Value)[0].Name;
      }
    });
    if (this.run.lstTMF_Calibrations == null || this.run.lstTMF_Calibrations == undefined || this.run.lstTMF_Calibrations.length == 0) {
      TMFIntercept = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0].Value;
      TMFSlope = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0].Value;
    }
    else {
      TMFIntercept = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0].Value;
      TMFSlope = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0].Value;
    }
    this.run.lstProcessSpec.map((x, i) => {
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Catalyst') {
        for (i = 0; i < this.run.MetaData.lstDoeCataystinfo.length; i++) {
          if (i == 0) {
            x.ValueText = this.run.MetaData.lstDoeCataystinfo[i].Catalyst.CatalystDesignation;
          }
          else {
            x.ValueText += " /" + this.run.MetaData.lstDoeCataystinfo[i].Catalyst.CatalystDesignation;
          }


        }
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Feed UOP#') {
        x.ValueText = this.run.FeedInfo.UOPNumber;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Catalyst Volume') {
        for (i = 0; i < this.run.MetaData.lstDoeCataystinfo.length; i++) {
          if (i == 0) {
            x.ValueText = this.run.MetaData.lstDoeCataystinfo[i].CatalystVolume;
          }
          else {
            x.ValueText += " /" + this.run.MetaData.lstDoeCataystinfo[i].CatalystVolume;
          }
        }
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'LHSV') {

        x.Value = this.run.MetaData.ModeLHSV;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2/HC') {

        x.Value = this.run.MetaData.ModeSCFB;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2 TMF % Output PV') {

        let scfh = (this.run.MetaData.ModeSCFB * this.run.MetaData.CatalystVolume * this.run.MetaData.ModeLHSV * 42 * 28316.85) / 3785;
        scfh = (scfh * 127132.8002); //Conversion factor for converting M3/Sec value to  SCFH
        x.Value = ((scfh - (TMFIntercept * 100)) / (TMFSlope * 100)) / 100;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2 TMF % Output PV (HITC)') {

        let scfh = (this.run.MetaData.ModeSCFB * this.run.MetaData.CatalystVolume * this.run.MetaData.ModeLHSV * 42 * 28316.85) / 3785;
        scfh = (scfh * 127132.8002); //Conversion factor for converting  M3/Sec value to  SCFH
        x.Value = ((scfh - (TMFIntercept * 100)) / (TMFSlope * 100) / 100);
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Plant Pressure, HPS') {

        x.Value = this.run.MetaData.ModePressure;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Feed Rate') {
        let feedrate;

        if (this.run.FeedInfo.RelativeDensity != undefined && this.run.FeedInfo.RelativeDensity != null) {
          feedrate = this.run.MetaData.ModeLHSV * this.run.MetaData.CatalystVolume * this.run.FeedInfo.RelativeDensity;
        }
        else {
          feedrate = null;
        }
        x.Value = feedrate;
      }
      if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'ISCO Feed Rate (HITC)') {

        let Iscofeedrate;
        if (this.run.FeedInfo.RelativeDensity != undefined && this.run.FeedInfo.RelativeDensity != null) {
          Iscofeedrate = (this.run.MetaData.ModeLHSV * this.run.MetaData.CatalystVolume * this.run.FeedInfo.RelativeDensity / this.run.MetaData.FeedISCOTemp);
        }
        else {
          Iscofeedrate = null;
        }
        x.Value = Iscofeedrate;
      }
    });
    this.runDataService.changeMessage(this.run);
  }
  processTCCalibrationInformation() {
    this.run.lstTC_Calibrations.map((x, i) => {
      if (x.ParameterName == 'TC Top Change Date' || x.ParameterName == 'TC Bottom Change Date') {
        if (x.CalibrationDate != null && x.CalibrationDate != undefined) {
          x.CalibrationDate = new Date(x.CalibrationDate);
        }
      }
    });
  }
  processRecipeData() {

    if (this.run.RecipeInfo != undefined && this.run.RecipeInfo.length > 18) {
      this.run.Recipe = this.run.RecipeInfo.filter(d => d.ModeId != this.run.MetaData.ModeId);

      this.run.RecipeMaster = JSON.parse(JSON.stringify({ ...this.run.Recipe }));
      this.run.RunModedata = this.run.RecipeInfo.filter(d => d.ModeId == this.run.MetaData.ModeId)[0];
      this.weightCheck = null != this.run.RunModedata.WeightChecks ? this.run.RunModedata.WeightChecks : 2;
      let temps = this.run.RecipeInfo.filter(d => d.ModeId == this.run.MetaData.ModeId);
      let index = 1;
      this.run.NIRTemp = [];
      temps.forEach(element => {
        this.run.NIRTemp.push(element.NIRTemps);
        index++;
      });

      if (this.run.RunModedata.ControlMethod == 1) {
        this.lineoutColumn = "NIR Lineout";
        // this.getModeMasterData(true);
      }
      this.getModeMasterData(true);
      this.updateColumns();
      this.generateRCP();
      this.updateLineOutData();
      this.run.Recipe.Cols = this.cols;

      if (this.run.RunModedata != undefined) {
        this.run.Recipe.map((x, index) => {
          this.updateModeValues(x, this.run.RunModedata, true);
        });
      }

      this.increment(this.weightCheck - 1, true);
      this.updateWeightCheckDataAfterGridLoad();

      this.run.Recipe.ColsMaster = this.colsMaster;
      this.run.Recipe.WeightChecksData = this.weightChecksData;
      this.runDataService.changeMessage(this.run);
    }
  }
  updateLineOutData() {
    if (this.run.RunModedata.ControlMethod == 2) {
      if (this.run.RunModedata.Condition > 4) {
        let weighChecks = this.weightCheck * this.run.RunModedata.Condition;
        for (let index = 9; index <= weighChecks; index++) {
          this.updateWeightChecks(index);
        }
        for (let index = 4; index <= this.run.RunModedata.Condition; index++) {
          this.run.Recipe.map(x => {

            this.cols.forEach(element => {
              if (element == this.lineoutColumn + " " + index) {
                x[this.lineoutColumn + " " + index] = x[this.lineoutColumn + " " + (index - 1)];

              }
            });
          });
        }
      }
    } else if (this.run.RunModedata.ControlMethod == 1) {

      this.updateWeightCheckDataAfterGridLoad();
      if (this.run.RunModedata != undefined) {
        this.run.Recipe.map((x, index) => {
          this.updateModeValues(x, this.run.RunModedata, false);
        });
      }
    }
  }
  updateWeightCheckDataAfterGridLoad() {

    if (this.run.RunModedata.Condition > 1) {
      let weighChecks = this.weightCheck * this.run.RunModedata.Condition;
      for (let index = 5; index <= weighChecks; index++) {
        this.updateWeightChecks(index);
      }
      for (let index = 3; index <= this.run.RunModedata.Condition; index++) {
        this.run.Recipe.map(x => {

          this.cols.forEach(element => {
            if (element == this.lineoutColumn + " " + index) {
              x[this.lineoutColumn + " " + index] = x[this.lineoutColumn + " " + (index - 1)];

            }
          });
        });
      }
    }
  }
  updateColumns() {
    this.cols = this.colsMaster = Object.keys(this.run.Recipe[1]);

    this.cols.splice(2, 0, 'UOM');
    this.run.Recipe.Cols = this.cols;

    let lineOuts = this.cols.filter(item => item.includes(this.lineoutColumn));

    if (lineOuts.length != this.run.RunModedata.Condition) {
      debugger;
      this.AddRemoveWeightCheckColumns(this.weightCheck);
    }
    this.generateRCP();
    if (this.run.RunModedata != undefined) {
      this.run.Recipe.map((x, index) => {
        this.updateModeValues(x, this.run.RunModedata, false);
      });
    }
    this.run.Recipe.colsMaster = this.colsMaster;
    this.runDataService.changeMessage(this.run);
  }

  AddRemoveWeightCheckColumns(weightCheck: any) {
    let nirIndex = this.cols.indexOf(this.lineoutColumn + " 1");

    this.cols.splice(nirIndex, this.cols.length);
    let weightCheckIndex = 1;
    let length = this.run.RunModedata.Condition;

    for (let columnIndex = 1; columnIndex <= length; columnIndex++) {
      this.cols.splice(this.cols.length, 0, this.lineoutColumn + " " + columnIndex);
      for (let index = 1; index <= this.weightCheck; index++) {
        this.cols.splice(this.cols.length, 0, "Weight Check " + weightCheckIndex);
        weightCheckIndex++;
      }
    }
  }

  updateModeValues(x: any, rec: any, isInitial: boolean) {
    switch (x.Description != undefined && x.Description.toLowerCase()) {
      case "plant pressure":
        this.cols.forEach(element => {
          if (x[element] != undefined && x[element].toString().toLowerCase() == "per q/mode") {
            x[element] = rec.Pressure;
          }
        });
        break;
      case "fresh feed - lhsv":
        this.cols.forEach(element => {
          if (x[element] != undefined && x[element].toString().toLowerCase() == "per q/mode") {
            if (this.run.MetaData.PlantLocation != 'HITC') {
              x[element] = rec.LHSV * this.run.MetaData.CatalystVolume * (this.run.FeedInfo.RelativeDensity);
            }
            else {
              x[element] = rec.LHSV * this.run.MetaData.CatalystVolume * (this.run.FeedInfo.RelativeDensity) / (this.run.MetaData.FeedISCOTemp);
            }
          }
          else if (x[element] != undefined && isInitial && isNumeric(x[element]) && !(element.toLowerCase().includes(this.lineout)) && !(element.toLowerCase().includes(this.weightCheckColumn))) {
            if (this.run.MetaData.PlantLocation != 'HITC') {
              x[element] = (x[element] * this.run.MetaData.CatalystVolume * (this.run.FeedInfo.RelativeDensity));
            }
            else {
              x[element] = (x[element] * this.run.MetaData.CatalystVolume * this.run.FeedInfo.RelativeDensity / this.run.MetaData.FeedISCOTemp);

            }
          }
        });
        break;
      case "fresh h2 feed - scfb":
        this.cols.forEach(element => {
          if (x[element] != undefined && x[element].toString().toLowerCase() == "per q/mode") {
            x[element] = (rec.SCFB * this.run.MetaData.CatalystVolume * rec.LHSV * 42 * 28316.85) / 3785;
          }
          else if (isInitial && x[element] != undefined && isNumeric(x[element]) && !(element.toLowerCase().includes(this.lineout)) && !(element.toLowerCase().includes(this.weightCheckColumn))) {
            if (this.run.MetaData.PlantLocation != 'HITC') {
              x[element] = (x[element] * this.run.MetaData.CatalystVolume * (this.previousRowData[element] / this.run.MetaData.CatalystVolume / (this.run.FeedInfo.RelativeDensity)) * 42 * 28316.85) / 3785;

            }
            else {
              x[element] = (x[element] * this.run.MetaData.CatalystVolume * (this.previousRowData[element] / this.run.MetaData.CatalystVolume / this.run.FeedInfo.RelativeDensity * this.run.MetaData.FeedISCOTemp) * 42 * 28316.85) / 3785;
            }
          }
        });
        break;
      case "fresh h2 feed - ghsv":
        this.cols.forEach(element => {
          if (x[element] != undefined && (x[element].toString().toLowerCase() == "per q/mode" || x[element] == 0.534444)) {
            x[element] = (1924 / 3600) * this.run.MetaData.CatalystVolume;
          }

        });
        break;
      case "nir ctrl set point":
        let index = 0;
        let nirColumns = this.cols.filter(x => x.includes(this.lineoutColumn));

        this.cols.forEach(element => {
          if (rec.ControlMethod == 1) {
            if (element == this.tempLO || element.includes(this.lineoutColumn) || element.includes("Weight Check")) {
              x[element] = this.run.NIRTemp[index];
              if (element == "Weight Check " + this.weightCheck) {
                index++;
              }
            }
          }
        });
        break;
      default:
        break;
    }

    this.previousRowData = x;
  }
  updateWeightChecks(weightCheckId: number) {
    let weightCheckName = "Weight Check ";

    switch (weightCheckId % 6) {
      case 1:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 1];

        })
        break;
      case 2:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 2];

        });
        break;
      case 3:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 3];

        });
        break;
      case 4:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 4];

        });
        break;
      case 5:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 5];

        });
        break;
      case 0:
        this.run.Recipe.map(x => {

          x[weightCheckName + weightCheckId] = x[weightCheckName + 6];

        });
        break;
      default:
        break;

    }
    if (this.run.RunModedata.ControlMethod == 1) {
      this.run.Recipe.map(x => {
        if (x.Description == "NIR ON") {
          x[weightCheckName + weightCheckId] = "ON";
          x[weightCheckName + weightCheckId] = "ON";
        }
      })
    }
  }
  decrement(weightCheck: any) {
    if (weightCheck > 1) {
      this.weightCheck = weightCheck - 1;
      this.AddRemoveWeightCheckColumns(weightCheck);
      this.generateRCP();
    }
    this.run.Recipe.map((x, index) => {
      this.updateModeValues(x, this.run.RunModedata, false);
    });
    this.saveWeightChecks();
    this.run.Recipe.WeightCheck = this.weightCheck;

    this.run.Recipe.isSaved = false;
    this.runDataService.changeMessage(this.run);
  }
  generateRCP() {
    this.recCols = [];
    let recCount = this.cols.length;
    for (let index = 1; index <= recCount; index++) {
      if (index < 5) {
        this.recCols.push("");
      }
      else {
        this.recCols.push("RCP #" + (index - 4));
      }
    }
    this.run.Recipe.recCols = this.recCols;
    this.runDataService.changeMessage(this.run);
  }
  increment(weightCheck: number, isClicked: boolean) {
    this.weightCheck = weightCheck + 1;
    let weighChecks = this.weightCheck * this.run.RunModedata.Condition;
    if (this.run.RunModedata.ControlMethod == 2) {
      if (this.weightCheck >= 3) {

        for (let index = 7; index <= weighChecks; index++) {
          this.updateWeightChecks(index);
        }
      }
    }
    else if (this.run.RunModedata.ControlMethod == 1 && this.recMasterData == undefined) {
      this.getModeMasterData(false);

    }
    this.AddRemoveWeightCheckColumns(this.weightCheck);
    this.run.Recipe.map((x, index) => {
      this.updateModeValues(x, this.run.RunModedata, false);
    });
    if (this.run.RunModedata.ControlMethod == 1) {
      this.run.Recipe.map(x => {
        if (x.Description == "NIR ON") {
          x["Weight Check 5"] = "ON";
          x["Weight Check 6"] = "ON";
        }
      })
    }
    this.generateRCP();
    this.updateLineOutData();
    if (isClicked) {
      this.saveWeightChecks();
    }
    this.run.Recipe.isSaved = false;
    this.run.Recipe.WeightCheck = this.weightCheck;
    this.runDataService.changeMessage(this.run);
  }
  saveWeightChecks() {
    this.run.RunModedata.WeightChecks = this.weightCheck;
    this.runService.SaveWeightChecks(this.run.RunModedata)
      .subscribe(
        (data: any) => {

        },
        err => { }
      );
  }
  updateAllInfo() {
    debugger;
    this.weightChecksData = this.recMasterData;
    if (this.weightChecksData != null && this.weightChecksData != undefined) {
      const allowed = ['Lineout 1', 'Weight Check 1', 'Weight Check 2', 'Lineout 2', 'Weight Check 3', 'Weight Check 4', 'Lineout 3', 'Weight Check 5', 'Weight Check 6'];
      this.weightChecksData.forEach(element => {
        Object.keys(element)
          .filter(key => !allowed.includes(key))
          .forEach(key => delete element[key]);
      });
      if (Object.keys(this.weightChecksData[0]).length < 1) {
        this.weightChecksData.splice(0, 1);
  
      }
      debugger;
      for (let index = 0; index < this.run.Recipe.length; index++) {
        this.run.Recipe[index]["Weight Check 5"] = this.weightChecksData[index]["Weight Check 5"] != undefined ? this.weightChecksData[index]["Weight Check 5"] : "";
        this.run.Recipe[index]["Weight Check 6"] = this.weightChecksData[index]["Weight Check 6"] != undefined ? this.weightChecksData[index]["Weight Check 6"] : "";
        this.run.Recipe[index][this.lineoutColumn + " 3"] = this.weightChecksData[index][this.lineoutColumn + " 3"] != undefined ? this.weightChecksData[index][this.lineoutColumn + " 3"] : "";
      }
  
  
      this.cols = Object.keys(this.run.Recipe[1]);
      this.cols.splice(2, 0, 'UOM');
      this.run.Recipe.Cols = this.cols;
      if (this.weightCheck > 3) {
        let weighChecks = this.weightCheck * this.run.RunModedata.Condition;
        for (let index = 5; index <= weighChecks; index++) {
          this.updateWeightChecks(index);
        }
      }
      this.run.Recipe.weightChecksData = this.weightChecksData;
    }
    
    this.runDataService.changeMessage(this.run);
  }
  processFeedInfo() {
    debugger;
    if ((this.run.MetaData.RunStatus == 'RNQ' || this.run.MetaData.RunStatus == 'RNINP') && this.run.FeedInfo.FeedID != null) {
      this.getRunFeedInformationFromService(this.run.FeedInfo.FeedID);   //Fetch the Latest data always from Feedstock until Run status is complete and Save the data automatically to Database. 
    }
    else if (this.run.MetaData.RunStatus == 'RNCMP') //RNCMP - Completed - Once Run Status changed to complete/ Run Stage is on conditions get the saved data
    {
      // if (this.run.FeedInfo.Blendcomponents != null && this.run.FeedInfo.Blendcomponents.length > 0) {
      //   for (var i = 0; i < this.run.FeedInfo.Blendcomponents.length; i++) {

      //     this.blendTotalWeight = this.blendTotalWeight + (this.run.FeedInfo.Blendcomponents[i].Amountadded);
      //     this.blendweightpct = this.blendweightpct + (this.run.FeedInfo.Blendcomponents[i].Weightpct);
      //   }
      // }
      // this.blendweightpct = Math.round(this.blendweightpct);
      // //For summary purpose
      // this.run.FeedInfo.TotalBlendWeight = this.blendTotalWeight;
      // this.run.FeedInfo.TotalBlendWeightpct = this.blendweightpct;
      this.getSavedRunFeedInfomration(this.run.MetaData.RunId);
    }
  }
  getRunFeedInformationFromService(feedId: any) {
    this.lstFeedIDs = [];
    this.lstFeedIDs.push(feedId);
    this.run.FeedInfo.Blendcomponents = [];
    this.run.FeedInfo.DopantStoichiometry = [];

    this.feedService.getFeedAnalyticalData(this.run.FeedInfo, this.lstFeedIDs)
      .subscribe(
        (data: any) => {
          debugger;
          this.lstParentFeeds = data[0].parentChildFeeds.ParentFeeds;
          this.lstBledDopants = data[0].parentChildFeeds.FeedDopants;
          this.lstAnalysisMethods = data[0].AnalysisMethods;

          this.run.FeedInfo.UOPNumber = data[0].UOP;
          this.run.FeedInfo.Name = data[0].FeedName;
          this.run.FeedInfo.AnalysisMethods = data[0].AnalysisMethods;
          this.run.FeedInfo.FeedId = data[0].FeedID;

          this.blendTotalWeight = 0;
          this.blendweightpct = 0;
          this.weightedNitrogenAmt = 0;
          this.weightedSufurAmt = 0;
          this.parentFeedsWeight = 0;


          if (this.lstParentFeeds != null && this.lstParentFeeds.length > 0) {
            for (var i = 0; i < this.lstParentFeeds.length; i++) {

              this.run.FeedInfo.Blendcomponents.push({ ComponentId: this.lstParentFeeds[i].ParentFeedId, ComponentName: this.lstParentFeeds[i].ParentFeedName, Amountadded: this.lstParentFeeds[i].AmountInGrams, Weightpct: this.lstParentFeeds[i].WeightPercent, UOPNumber: this.lstParentFeeds[i].ParentUOPNo });
              this.blendTotalWeight = this.blendTotalWeight + (this.lstParentFeeds[i].AmountInGrams);
              this.blendweightpct = this.blendweightpct + (this.lstParentFeeds[i].WeightPercent);

              if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null) {
                this.weightedNitrogenAmt = null;

              }
              else {
                this.weightedNitrogenAmt = this.weightedNitrogenAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED));
              }
              if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null) {
                this.weightedSufurAmt = null;

              }
              else {
                this.weightedSufurAmt = this.weightedSufurAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Sulfur_IN_SWEET_FEED));
              }
              this.parentFeedsWeight = this.parentFeedsWeight + this.lstParentFeeds[i].AmountInGrams;
            }
          }

          if (this.lstBledDopants != null && this.lstBledDopants.length > 0) {
            for (var i = 0; i < this.lstBledDopants.length; i++) {

              this.run.FeedInfo.Blendcomponents.push({ ComponentId: this.lstBledDopants[i].ParentFeedId, ComponentName: this.lstBledDopants[i].DopantType, Amountadded: this.lstBledDopants[i].WEIGHT_MSR, Weightpct: this.lstBledDopants[i].WEIGHT_PERCENTAGE, UOPNumber: this.lstBledDopants[i].DopantUOPNum });
              this.blendTotalWeight = this.blendTotalWeight + (this.lstBledDopants[i].WEIGHT_MSR);
              this.blendweightpct = this.blendweightpct + (this.lstBledDopants[i].WEIGHT_PERCENTAGE);

              //Add Dopant Stoichiometry data
              for (var j = 0; j < this.lstBledDopants[i].DopantStiochiometryGCData.length; j++) {

                this.run.FeedInfo.DopantStoichiometry.push({
                  COMPONENT_NAME: this.lstBledDopants[i].DopantStiochiometryGCData[j].COMPONENT_NAME,
                  COMP_MASS_H2S_COMP_MSR: this.lstBledDopants[i].DopantStiochiometryGCData[j].COMP_MASS_H2S_COMP_MSR,
                  COMP_MASS_SN_COMP_MSR: this.lstBledDopants[i].DopantStiochiometryGCData[j].COMP_MASS_SN_COMP_MSR,
                  DOPANT_TYPE: this.lstBledDopants[i].DopantStiochiometryGCData[j].DOPANT_TYPE, FEED_ADJUSTMNT_FACTOR_MSR: this.lstBledDopants[i].DopantStiochiometryGCData[j].FEED_ADJUSTMNT_FACTOR_MSR
                });
              }
            }

          }
          this.blendweightpct = Math.round(this.blendweightpct);
          debugger;
          this.run.FeedInfo.API = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue);
          this.run.FeedInfo.RelativeDensity = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue);

          this.run.FeedInfo.NitrogenInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0].ComponentAverageValue);
          this.run.FeedInfo.SulfurInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0].ComponentAverageValue);
          this.run.FeedInfo.H2InFeed = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0].ComponentAverageValue);

          this.run.FeedInfo.NitrogenInSweetFeed = (this.weightedNitrogenAmt == null ? null : (this.weightedNitrogenAmt / this.parentFeedsWeight));
          this.run.FeedInfo.SulfurInSweetFeed = (this.weightedSufurAmt == null ? null : (this.weightedSufurAmt / this.parentFeedsWeight));

          //For summary purpose
          this.run.FeedInfo.TotalBlendWeight = this.blendTotalWeight;
          this.run.FeedInfo.TotalBlendWeightpct = this.blendweightpct;
          this.runDataService.changeMessage(this.run);
          this.setProcessSpecDefaultValues();
          this.processRecipeData();

        },
        err => { }
      );

  }
  getSavedRunFeedInfomration(RunId: any) {

    this.blendTotalWeight = 0;
    this.blendweightpct = 0;
    this.runService.GetSavedRunFeedInfomration(RunId)
      .subscribe(
        (data: any) => {
          debugger;
          if (data.UOPNumber != null) // Means Saved data not exist for the Feed in DB . Need to call Service
          {
            this.run.FeedInfo.UOPNumber = data.UOPNumber;
            this.run.FeedInfo.Name = data.Name;
            this.run.FeedInfo.API = data.API;
            this.run.FeedInfo.FeedId = data.FeedID;
            this.run.FeedInfo.Density = data.Density;
            this.run.FeedInfo.H2InFeed = data.H2InFeed;
            this.run.FeedInfo.RelativeDensity = data.RelativeDensity;
            this.run.FeedInfo.SulfurInSweetFeed = data.SulfurInSweetFeed;
            this.run.FeedInfo.NitrogenInSweetFeed = data.NitrogenInSweetFeed;
            this.run.FeedInfo.SulfurInFeedBlend = data.SulfurInFeedBlend;
            this.run.FeedInfo.NitrogenInFeedBlend = data.NitrogenInFeedBlend;

            this.run.FeedInfo.Blendcomponents = data.Blendcomponents;
            if (this.run.FeedInfo.Blendcomponents != null && this.run.FeedInfo.Blendcomponents.length > 0) {
              for (var i = 0; i < this.run.FeedInfo.Blendcomponents.length; i++) {

                this.blendTotalWeight = this.blendTotalWeight + (this.run.FeedInfo.Blendcomponents[i].Amountadded);
                this.blendweightpct = this.blendweightpct + (this.run.FeedInfo.Blendcomponents[i].Weightpct);
              }
            }
            this.blendweightpct = Math.round(this.blendweightpct);
            //For summary purpose
            this.run.FeedInfo.TotalBlendWeight = this.blendTotalWeight;
            this.run.FeedInfo.TotalBlendWeightpct = this.blendweightpct;
            this.runDataService.changeMessage(this.run);
            this.processRecipeData();
            this.setProcessSpecDefaultValues();
          }
          else {
            this.getRunFeedInformationFromService(this.run.FeedInfo.FeedId);
          }

        },
        err => { }
      );
  }

  getModeMasterData(isInitial: boolean) {
    let mode = '4';
    if (this.run.RunModedata.SulfidingType != undefined && this.run.RunModedata.SulfidingType == 1) {
      mode = '3';
    } else {
      mode = '4';
    }
    if (isInitial) {


      this.runService.GetModeMasterData(mode)
        .subscribe(
          (data: any) => {
            debugger
            if (data != undefined && data.length > 1) {
              this.recMasterData = data;
              this.recMasterData.splice(0, 1);
              this.run.Recipe.recMasterData = this.recMasterData = data;
              if (isInitial) {
                // this.run.Recipe.recMasterData = this.recMasterData;

                for (let index = 0; index < this.run.Recipe.length; index++) {
                  this.run.Recipe[index]["Weight Check 5"] = this.recMasterData[index]["Weight Check 5"] != undefined ? this.recMasterData[index]["Weight Check 5"] : "";
                  this.run.Recipe[index]["Weight Check 6"] = this.recMasterData[index]["Weight Check 6"] != undefined ? this.recMasterData[index]["Weight Check 6"] : "";
                }
                this.increment(this.weightCheck - 1, false);
              }
            }

          },
          err => { }
        );
    }

    // this.run.Recipe.recMasterData = this.recMasterData;
    if (!isInitial) {
      this.updateAllInfo();
    }
    this.run.Recipe.recMasterData = this.recMasterData;
    this.runDataService.changeMessage(this.run);
  }
  beforeSaveRecipe() {
    if (this.run.Recipe != undefined) {
      let rec: any = [];
      this.run.Recipe.forEach(element => {
        let index = 0;
        let Headers: any = [];
        for (let key in element) {
          if (element.hasOwnProperty(key)) {
            if (index > 2) {
              Headers.push({ "Name": key, "Value": element[key], "ReceipeNumber": index - 2 });
            }
            index++;
          }
        }

        rec.push({ "Tag": element["Tag"], "Description": element["Description"], "Energized": element["Energized"], Headers });
      });
      this.run.RecipeInfo = rec;
    }
  }
}
