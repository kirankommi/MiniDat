﻿using MINIDAT.DataAccess.Common;
using MINIDAT.Framework.Common;
using MINIDAT.Model.UOM;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using MINIDAT.Model;
using MINIDAT.Model.Session;

namespace MINIDAT.DataAccess.UOM
{
    public class UnitGroupDAL
    {

        #region Private Members
        //DatabaseCommand cmd = null;
        //IDatabaseHelper objDbHelper = null;
        //CommandBuilder objCmdBuilder = null;
        SqlDataReader objSqlDr = null;
        UnitGroup group = new UnitGroup();
        #endregion

        /// <summary>
        /// Gets the name of the unit group by.
        /// </summary>
        /// <param name="unitGroupName">Name of the unit group.</param>
        /// <returns></returns>
        public UnitGroup GetUnitGroupByName(string unitGroupName)
        {
            try
            {
                UnitGroup unitGroup = new UnitGroup();
                unitGroup.UnitGroupName = unitGroupName;
                //load the unit group by name from appcache
                ((List<Unit>)unitGroup.Units).AddRange(LoadUnitListByGroupName(unitGroupName));
                //get the base unit from app cache
                unitGroup.BaseUnit = GetBaseUnit(unitGroupName); ;
                return unitGroup;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }



        /// <summary>
        /// Loads the name of the unit list by group.
        /// </summary>
        /// <param name="unitGroupName">Name of the unit group.</param>
        /// <returns></returns>
        public IList<Unit> LoadUnitListByGroupName(string unitGroupName)
        {
            try
            {
                IList<Unit> units = new List<Unit>();

                if (AppCache.IsUnitGroupsLoaded && !String.IsNullOrEmpty(unitGroupName))
                {
                    group = (from c in AppCache.UnitGroups where c.UnitGroupName.ToUpper() == unitGroupName.ToUpper() select c).FirstOrDefault();
                    if (group != null)
                    {
                        units = group.Units.ToList();
                    }
                    else
                    {
                        throw new ArgumentException("Invalid unitGroupName");
                    }
                }

                return units;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets the base unit.
        /// </summary>
        /// <param name="unitGroupName">Name of the unit group.</param>
        /// <returns></returns>
        public Unit GetBaseUnit(string unitGroupName)
        {
            try
            {
                Unit baseUnit = new Unit();
                if (group != null && !String.IsNullOrEmpty(unitGroupName))
                {
                    if (group.BaseUnit != null)
                    {

                        baseUnit = group.BaseUnit;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid unitGroupName");
                    }
                }

                return baseUnit;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        private ObservableCollection<Unit> units = new ObservableCollection<Unit>();
        public ObservableCollection<Unit> Units { get { return units; } }

        public List<FunctionUOMCategoryModel> GetFunctionUOM(string appId)
        {
            List<FunctionUOMCategoryModel> functionUoms = new List<FunctionUOMCategoryModel>();
            Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
            DbCommand command = db.GetStoredProcCommand("Get_Function_UOMCategory_sp");

            db.AddInParameter(command, "proc_vr_src_system_ID", DbType.String, appId);

            IDataReader reader = db.ExecuteReader(command);

            while (reader.Read())
            {
                functionUoms.Add(new FunctionUOMCategoryModel()
                {
                    PageDescription=Convert.ToString(reader["PAGE_DESC"]),
                    ApplicationFunctionCode = Convert.ToString(reader["FUNCTION_CD"]),
                    UOMCategory = Convert.ToString(reader["VARIABLE_CATEGORY_NM"])
                });
            }
            return functionUoms;
        }

        /// <summary>
        /// Get units 
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<Unit> GetUnits()
        {
            return Units;
        }
        /// <summary>
        /// Gets all unit group.
        /// </summary>
        /// <param name="EID">The EID.</param>
        /// <returns></returns>
        public ObservableCollection<Unit> GetAllUnit()
        {
            try
            {
                ObservableCollection<Unit> Units = new ObservableCollection<Unit>();

                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                DbCommand command = db.GetStoredProcCommand("Get_Unit_Of_Measure_SP");

                IDataReader reader = db.ExecuteReader(command);

                Units.Add(new Unit() { DisplayText = "Select" });
                //if (reader.NextResult())// units master list
                //{
                while (reader.Read())
                    Units.Add(new Unit()
                    {
                        UnitName = reader["UOM_UNIT_NM"].ToString(),
                        DisplayText = reader["UOM_UNIT_DISPLAY_NM"].ToString()
                    });
                //}
                return Units;
            }
            catch (Exception ex)
            {
                // LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets all unit group.
        /// </summary>
        /// <param name="EID">The EID.</param>
        /// <returns></returns>
        public IList<UnitGroup> GetAllUnitGroup()
        {
            try
            {
                IList<UnitGroup> groups = new List<UnitGroup>();

                string tempGroupCD = string.Empty;
                int groupIndex = 1;

                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                DbCommand command = db.GetStoredProcCommand("Get_Unit_Of_Measure_SP");

                using (IDataReader objSqlDr = db.ExecuteReader(command))
                { // unit type master list

                    groups.Add(new UnitGroup() { UnitGroupCD = "-- Select --", UnitGroupName = "-- Select --" });
                    while (objSqlDr.Read())
                    {
                        if (string.IsNullOrEmpty(tempGroupCD))
                        {
                            groups.Add(new UnitGroup());
                            tempGroupCD = Convert.ToString(objSqlDr["UOM_GROUP_CD"]);
                            groups[groupIndex].UnitGroupCD = tempGroupCD;
                            groups[groupIndex].UnitGroupName = Convert.ToString(objSqlDr["UOM_GROUP_NM"]);

                        }
                        else if (Convert.ToString(objSqlDr["UOM_GROUP_CD"]) != tempGroupCD)
                        {
                            tempGroupCD = Convert.ToString(objSqlDr["UOM_GROUP_CD"]);
                            groupIndex++;
                            groups.Add(new UnitGroup());
                            groups[groupIndex].UnitGroupCD = tempGroupCD;
                            groups[groupIndex].UnitGroupName = Convert.ToString(objSqlDr["UOM_GROUP_NM"]);

                        }

                        if (groups[groupIndex].Units == null)
                        {
                            groups[groupIndex].Units.Clear();
                        }

                        Unit unit = new Unit
                        {
                            UnitName = Convert.ToString(objSqlDr["UOM_UNIT_NM"]),
                            DisplayText = Convert.ToString(objSqlDr["UOM_UNIT_DISPLAY_NM"]),
                            Intercept = Convert.ToDouble(objSqlDr["INTERCEPT_VALUE_CS"]),
                            Slope = Convert.ToDouble(objSqlDr["SLOPE_VALUE_CS"]),
                            UnitId = Convert.ToInt32(objSqlDr["UOM_ID_SQ"]),
                            IsDefaultUnit = Convert.ToString(objSqlDr["DEFAULT_UNIT_IND"]) == "Y" ? true : false
                        };

                        if (Convert.ToString(objSqlDr["BASE_UNIT_IND"]) == "Y")
                        {
                            groups[groupIndex].BaseUnit = unit;
                        }

                        groups[groupIndex].Units.Add(unit);
                    }
                }
                return groups;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        public List<UomVariable> GetUomVaraibles(string categories,string UserID)
        {
            try
            {
                IList<UomVariable> uomVariables = new List<UomVariable>();

                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                using (DbCommand command = db.GetStoredProcCommand("Get_UOM_Variable_byCategory_sp"))
                {
                    db.AddInParameter(command, "proc_vr_categories", DbType.String, categories);
                    db.AddInParameter(command, "proc_vr_src_sysid", DbType.Int16, ApplicationSettings.AppId);
                    db.AddInParameter(command, "proc_vr_emp_id", DbType.String, UserID);
                    //Execute the command against database					
                    using (IDataReader objSqlDr = db.ExecuteReader(command))
                    {

                        while (objSqlDr.Read())
                        {
                            uomVariables.Add(new UomVariable
                            {
                                UnitGroupCD = Convert.ToString(objSqlDr["UOM_GROUP_CD"]),
                                UnitGroupName = Convert.ToString(objSqlDr["UOM_GROUP_NM"]),
                                DefaultUnitName = Convert.ToString(objSqlDr["DEFAULT_UNIT"]),
                                BaseUnitName=Convert.ToString(objSqlDr["BASE_UNIT"]),
                                Precision = Convert.ToInt32(objSqlDr["PRECISION"]),
                                VariableName = Convert.ToString(objSqlDr["UOM_VARIABLE_NM"]),
                                CategoryName=Convert.ToString(objSqlDr["VARIABLE_CATEGORY_NM"])
                            });
                        }
                    }
                }
                return uomVariables.ToList();
            }
            catch (Exception ex)
            {
                // LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets the uom varaibles.
        /// </summary>
        /// <param name="functionName">Name of the function.</param>
        /// <param name="eid">The eid.</param>
        public IList<UomVariable> GetUomVaraibles(int templateID)
        {
            try
            {
                IList<UomVariable> uomVariables = new List<UomVariable>();

                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                using (DbCommand command = db.GetStoredProcCommand("Get_Variables_Sp"))
                {
                    db.AddInParameter(command, "proc_vr_templateid", DbType.String, templateID);
                    //Execute the command against database					
                    using (IDataReader objSqlDr = db.ExecuteReader(command))
                    {

                        while (objSqlDr.Read())
                        {
                            uomVariables.Add(new UomVariable
                            {
                                UnitGroupCD = Convert.ToString(objSqlDr["UOM_GROUP_CD"]),
                                UnitGroupName = Convert.ToString(objSqlDr["UOM_GROUP_NM"]),
                                DefaultUnitID = Convert.ToInt32(objSqlDr["DEFAULT_UOM_ID"]),
                                DefaultUnitName = Convert.ToString(objSqlDr["UOM_UNIT_NM"]),
                                Precision = Convert.ToInt32(objSqlDr["PRECISION"]),
                                VariableName = Convert.ToString(objSqlDr["UOM_GROUP_NM"]),
                                DisplayName = Convert.ToString((objSqlDr["UOM_UNIT_DISPLAY_NM"]))
                            });
                        }
                    }
                }
                return uomVariables.ToList();
            }
            catch (Exception ex)
            {
                // LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets the precision.
        /// </summary>
        /// <param name="precision">The precision.</param>
        /// <returns></returns>
        public string GetPrecision(int? precision)
        {
            try
            {
                StringBuilder strPrecision = new StringBuilder("0.000000");

                if (precision != null && precision > 0)
                {
                    strPrecision.Clear();
                    strPrecision.Append("0.");
                    int max = Convert.ToInt32(precision);
                    for (int i = max; i > 0; i--)
                    {
                        strPrecision.Append("0");
                    }
                }

                return strPrecision.ToString();
            }
            catch (Exception ex)
            {
                // LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets the display unit.
        /// </summary>
        /// <param name="unitName">Name of the unit.</param>
        /// <param name="uomGroupCD">The uom group CD.</param>
        /// <returns></returns>
        public Unit GetDisplayUnit(string unitName, string uomGroupName)
        {
            try
            {
                Unit displayUnit = new Unit();
                UnitGroup groupData = new UnitGroup();

                if (AppCache.IsUnitGroupsLoaded)
                {
                    groupData = (from c in AppCache.UnitGroups where c.UnitGroupName == uomGroupName select c).FirstOrDefault();
                    if (groupData != null)
                    {
                        //chk for unit name
                        displayUnit = (from c in groupData.Units where c.UnitName == unitName select c).FirstOrDefault();
                        if (displayUnit == null)
                        {
                            //chk for display name
                            displayUnit = (from c in groupData.Units where c.DisplayText == unitName select c).FirstOrDefault();
                        }
                    }
                }
                return displayUnit;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }
    }
}
