﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	LimsComponentRepository.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	05 june 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

using MINIDAT.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Manage.LimsComponent;
using System.Data;
using System.Collections;
using MINIDAT.Model;
using System.Data.SqlClient;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class LimsComponentRepository : ILimsComponentRepository
    {

        private IDatabase _db;
        public LimsComponentRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public IList<LIMSAnalysisMethodComponentModel> GetLIMSAnalysisComponentData(LIMSAnalysisMethodComponentModel limsAnalysisMethodFilter, string User)
        {
            IList<LIMSAnalysisMethodComponentModel> limsComponentList = new List<LIMSAnalysisMethodComponentModel>();

            try
            {

                using (IDbCommand command = _db.CreateCommand("Search_FDMS_Lims_Component_Sp"))
                {
                    if (limsAnalysisMethodFilter == null) throw new ArgumentNullException("limsAnalysisMethodFilter");
                    IDictionary parameters = new Dictionary<string, object>();
                    if (limsAnalysisMethodFilter.FDMSComponent != "undefined")
                    {
                        parameters.Add("@proc_vr_Comp_Nm", limsAnalysisMethodFilter.FDMSComponent);
                    }
                    if (limsAnalysisMethodFilter.LIMSOperationName != "undefined")
                    {
                        parameters.Add("@proc_vr_Lims_Oper_Nm", limsAnalysisMethodFilter.LIMSOperationName);
                    }
                    if (limsAnalysisMethodFilter.LIMSComponent != "undefined")
                    {
                        parameters.Add("@proc_vr_Lims_Comp_Nm", limsAnalysisMethodFilter.LIMSComponent);
                    }
                    parameters.Add("@proc_vr_Sort_Column_Nm", limsAnalysisMethodFilter.SortColumn);
                    parameters.Add("@proc_vr_Sort_Order_Nm", limsAnalysisMethodFilter.SortOrder);
                    parameters.Add("@proc_src_system_id" , ApplicationSettings.AppId);
                    parameters.Add("@proc_vr_Created_By_Id", Model.Session.UserSession.Instance.User.EID);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        //Populating datagrid
                        if (limsComponentList == null)
                        {
                            limsComponentList = new List<LIMSAnalysisMethodComponentModel>();
                        }
                        while (reader.Read())
                        {
                            limsComponentList.Add(new LIMSAnalysisMethodComponentModel
                            {
                                FDMSComponent = Convert.ToString(reader["COMPONENT_NM"]),
                                LIMSOperationName = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                                LIMSComponent = Convert.ToString(reader["LIMS_COMP_NM"]),
                                ComponentType = Convert.ToString(reader["COMP_TYPE_NM"]),
                                UOM = Convert.ToString(reader["UOM_GROUP_CD"]),
                                UOMUnitName = Convert.ToString(reader["UOM_Unit_NM"]),
                                Precision = Convert.ToInt32(reader["DECIMAL_PNT"]),
                                AnalysisTypeName = Convert.ToString(reader["ANALYSIS_TYPE_NM"])
                            });
                        }
                        reader.NextResult();
                        List<KeyValue> uomgrouplist = new List<KeyValue>();
                        uomgrouplist.Add(new KeyValue { Key = "Select", Value = "Select" });
                        while (reader.Read())
                        {

                            uomgrouplist.Add(new KeyValue
                            {
                                Key = Convert.ToString(reader["UOM_GROUP_CD"]),
                                Value = Convert.ToString(reader["UOM_GROUP_NM"])
                            });

                        }
                        //limsAnalysisMethodFilter.UOMGroupList = uomgrouplist;
                        ((List<KeyValue>)limsAnalysisMethodFilter.UOMGroupList).AddRange(uomgrouplist);
                        reader.NextResult();
                        IList<KeyValue> uomnamelist = new List<KeyValue>();
                        uomnamelist.Add(new KeyValue { Key = "Select", Value = "Select" });
                        while (reader.Read())
                        {

                            uomnamelist.Add(new KeyValue
                            {
                                Key = Convert.ToString(reader["UOM_GROUP_CD"]),
                                Value = Convert.ToString(reader["UOM_UNIT_NM"]),
                                Default = Convert.ToString(reader["DEFAULT_UNIT_IND"])
                            });

                        }
                        ((List<KeyValue>)limsAnalysisMethodFilter.UOMlist).AddRange(uomnamelist);
                    }
                    return limsComponentList;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public void SaveLIMSComponent(LIMSAnalysisMethodComponentModel LIMSComponent, string User)
        {
            int count = 0;
            string msg = "Success";
            try
            {
                using (IDbCommand command = _db.CreateCommand("Insert_Update_Lims_Component_Sp"))
                {
                    if (LIMSComponent == null) throw new ArgumentNullException("LIMSComponent");
                    if (User == null) throw new ArgumentNullException("User");
                    IDictionary parameters = new Dictionary<string, object>();


                    string EID = User.Substring(User.IndexOf("\\") + 1);
                    parameters.Add("@proc_vr_NAPHTHA_Comp_Nm", LIMSComponent.FDMSComponent);
                    parameters.Add("@proc_vr_Lims_Oper_Nm", LIMSComponent.LIMSOperationName);
                    parameters.Add("@proc_vr_Lims_Comp_Nm", LIMSComponent.LIMSComponent);
                    parameters.Add("@proc_vr_Default_UOM_Nm", LIMSComponent.UOMUnitName);
                    parameters.Add("@proc_vr_Precision", LIMSComponent.Precision);
                    parameters.Add("@proc_vr_Created_By_Id", EID);
                    parameters.Add("@proc_vr_Analysis_Type_Nm", LIMSComponent.AnalysisTypeName);
                    _db.CreateParameters(command, parameters);
                    count = _db.ExecuteNonQuery(command);
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public void DeleteLIMSComponent(LIMSAnalysisMethodComponentModel LIMSMethod)
        {
            try
            {
                if (LIMSMethod == null) throw new ArgumentNullException("LIMSMethod");
                using (IDbCommand command = _db.CreateCommand("Delete_Lims_Component_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Lims_Oper_Nm", LIMSMethod.LIMSOperationName);
                    parameters.Add("@proc_vr_Lims_Comp_Nm", LIMSMethod.LIMSComponent);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        //Flyout Methods
        public IList<LIMSAnalysisMethodComponentModel> GetOperations(LIMSAnalysisMethodComponentModel filter)
        {
            IList<LIMSAnalysisMethodComponentModel> limsOperationList = new List<LIMSAnalysisMethodComponentModel>();

            try
            {
                using (IDbCommand command = _db.CreateCommand("Search_FDMS_Lims_Operation_Sp"))
                {
                    if (filter == null) throw new ArgumentNullException("filter");
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Analysis_Type_Cd", filter.AnalysisTypeName);
                    parameters.Add("proc_vr_Analysis_Type_Nm", filter.ComponentType);
                    parameters.Add("proc_vr_Lims_Oper_Nm", filter.LIMSOperationName);
                    parameters.Add("proc_in_Page_Size_Num", 999);
                    parameters.Add("proc_in_Current_Page_Num", 1);
                    parameters.Add("proc_vr_Sort_Column_Nm", filter.SortColumn);
                    parameters.Add("proc_vr_Sort_Order_Nm", filter.SortOrder);
                    //  db.AddOutParameter(command, "proc_in_Rec_Cnt", DbType.Int32, 8);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        reader.NextResult();
                        //Populating datagrid variable
                        if (limsOperationList == null)
                        {
                            limsOperationList = new List<LIMSAnalysisMethodComponentModel>();
                        }

                        while (reader.Read())
                        {
                            limsOperationList.Add(new LIMSAnalysisMethodComponentModel
                            {
                                LIMSOperationName = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                                ComponentType = Convert.ToString(reader["COMP_TYPE_NM"]),
                                UOM = Convert.ToString(reader["UOM_GROUP_NM"]),
                                AnalysisTypeName = Convert.ToString(reader["ANALYSIS_TYPE_NM"]),

                            }
                            );
                        }
                        reader.NextResult();
                        while (reader.Read())
                        {

                            filter.TotalRecords = Convert.ToInt32(reader["TotalRecords"]);
                        }
                    }
                }
                // filter.TotalRecords = Convert.ToInt32(_db.GetParameterValue(command, "proc_in_Rec_Cnt"));
                return limsOperationList;

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw; //TODO: Error Logging Goes here
            }
        }

        public IList<LIMSAnalysisMethodComponentModel> GetLIMSOperationsList(LIMSAnalysisMethodComponentModel filter)
        {
            IList<LIMSAnalysisMethodComponentModel> limsOperationList = new List<LIMSAnalysisMethodComponentModel>();

            try
            {
                using (IDbCommand command = _db.CreateCommand("md.Get_Lims_Operations_For_RunAnalytical__Sp"))
                {
                    if (filter == null) throw new ArgumentNullException("filter");
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Analysis_Type_Cd", filter.AnalysisTypeName);
                    parameters.Add("proc_vr_Analysis_Type_Nm", filter.ComponentType);
                    parameters.Add("proc_vr_Lims_Oper_Nm", filter.LIMSOperationName);
                    parameters.Add("proc_in_Page_Size_Num", 999);
                    parameters.Add("proc_in_Current_Page_Num", 1);
                    parameters.Add("proc_vr_Sort_Column_Nm", filter.SortColumn);
                    parameters.Add("proc_vr_Sort_Order_Nm", filter.SortOrder);
                    //  db.AddOutParameter(command, "proc_in_Rec_Cnt", DbType.Int32, 8);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        //reader.NextResult();
                        //Populating datagrid variable
                        if (limsOperationList == null)
                        {
                            limsOperationList = new List<LIMSAnalysisMethodComponentModel>();
                        }

                        while (reader.Read())
                        {
                            limsOperationList.Add(new LIMSAnalysisMethodComponentModel
                            {
                                LIMSOperationName = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                                ComponentType = Convert.ToString(reader["COMP_TYPE_NM"]),                               
                                AnalysisTypeName = Convert.ToString(reader["ANALYSIS_TYPE_NM"]),
                                LIMSOperationID = Convert.ToInt32(reader["LIMS_OPERATION_ID_SQ"]),
                                AnalysisMethodName = Convert.ToString(reader["ANALYSIS_METHOD_NM"]),
                                AnalysisMethodNumber = Convert.ToString(reader["ANALYSIS_METHOD_NUM"])

                            }
                            );
                        }
                        reader.NextResult();
                        while (reader.Read())
                        {

                            filter.TotalRecords = Convert.ToInt32(reader["TotalRecords"]);
                        }
                    }
                }
                // filter.TotalRecords = Convert.ToInt32(_db.GetParameterValue(command, "proc_in_Rec_Cnt"));
                return limsOperationList;

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw; //TODO: Error Logging Goes here
            }
        }

        public IList<FDMSComponent> GetComponent(FDMSComponent filter)
        {

            List<FDMSComponent> adsdatComponentList = new List<FDMSComponent>();

            try
            {
                using (IDbCommand command = _db.CreateCommand("Search_FDMS_Component_Sp"))
                {
                    if (filter == null) throw new ArgumentNullException("filter");
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Comp_lbl_Nm", filter.ComponentLabel);
                    parameters.Add("proc_vr_Comp_Type_Nm", filter.ComponentType);
                    //parameters.Add("proc_in_Page_Size_Num", 999);
                    if (filter.RecordsPerPage == default(int))
                        parameters.Add("proc_in_Page_Size_Num", DBNull.Value);
                    else
                        parameters.Add("proc_in_Page_Size_Num", filter.RecordsPerPage);
                    parameters.Add("proc_in_Current_Page_Num", 1);
                    parameters.Add("proc_vr_Sort_Column_Nm", filter.SortColumn);
                    parameters.Add("proc_vr_Sort_Order_Nm", filter.SortOrder);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        reader.NextResult();
                        //Populating datagrid
                        if (adsdatComponentList == null)
                        {
                            adsdatComponentList = new List<FDMSComponent>();
                        }

                        while (reader.Read())
                        {

                            adsdatComponentList.Add(new FDMSComponent
                            {

                                ComponentType = Convert.ToString(reader["COMP_TYPE_NM"]),
                                ComponentLabel = Convert.ToString(reader["COMPONENT_NM"]),

                            });
                        }
                        reader.NextResult();
                        while (reader.Read())
                        {

                            filter.TotalRecords = Convert.ToInt32(reader["TotalRecords"]);
                        }
                    }
                    // filter.TotalRecords = Convert.ToInt32(db.GetParameterValue(command, "proc_in_Rec_Cnt"));
                    return adsdatComponentList;
                }
            }
            catch (Exception ex)
            {

                LogManager.Error(ex);
                throw; //TODO: Error Logging Goes here
            }
        }

        public bool CheckIsComponentExists(string name)
        {
            IDictionary parameters = new Dictionary<string, object>();
            try
            {
                using (IDbCommand cmd = _db.CreateCommand("CheckIsComponentExists_sp"))
                {
                    parameters.Add("name", name);
                    _db.CreateParameters(cmd, parameters);
                    var result = _db.ExecuteScalar(cmd);
                    return Convert.ToBoolean(result);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public IList<GetLIMSAnalysisMethodComponentBindUOMModel> GetLIMSAnalysisMethodComponentBindUOM(string User)
        {
            IList<GetLIMSAnalysisMethodComponentBindUOMModel> limsComponentList = new List<GetLIMSAnalysisMethodComponentBindUOMModel>();

            try
            {

                using (IDbCommand command = _db.CreateCommand("Get_FDMS_Lims_Component_UOM_Sp"))
                {
                 
                    IDictionary parameters = new Dictionary<string, object>();                  
                    parameters.Add("@proc_vr_Created_By_Id", Model.Session.UserSession.Instance.User.EID);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        //Populating datagrid
                        if (limsComponentList == null)
                        {
                            limsComponentList = new List<GetLIMSAnalysisMethodComponentBindUOMModel>();
                        }
                        while (reader.Read())
                        {
                            limsComponentList.Add(new GetLIMSAnalysisMethodComponentBindUOMModel
                            {
                                ComponentStandardName = Convert.ToString(reader["COMPONENT_NM"]),
                                ComponentLIMSName=Convert.ToString(reader["LIMS_COMP_NM"]),
                                LIMSOperationName = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                                //LIMSComponent = Convert.ToString(reader["LIMS_COMP_NM"]),                              
                                UOMGroup = Convert.ToString(reader["UOM_GROUP_CD"]),
                                Unit=Convert.ToString(reader["UOM_UNIT_NM"]),
                                Precision=Convert.ToInt16(reader["DECIMAL_PNT"])
                            });
                        } 
                    }
                    return limsComponentList;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
