import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { Chart } from 'chart.js';

@Component({
  selector: 'performance-tile',
  templateUrl: 'performanceTile.directive.html'
})

export class PerformanceTileDirective implements OnInit, AfterViewInit {
  threeDotIcon: string = "";
  increaseIcon: string = "";
  decreaseIcon: string = "";
  neutralIcon: string = "";
  @Input() data: performanceTileData = {};

  constructor() {
    this.threeDotIcon = 'assets/Images/menu.svg';
    this.increaseIcon = 'assets/Images/Group 1687.svg';
    this.decreaseIcon = 'assets/Images/Group 1688.svg';
    this.neutralIcon = 'assets/Images/Group 1682.svg';
  }

    ngAfterViewInit(): void {
        
    }
    ngOnInit(): void {

    }

}

export class performanceTileData {
  target?: string = "";
  value?: string = "";
  title?: string = "";
  status?: string = "increase";
  isLive?: boolean = false;
}
