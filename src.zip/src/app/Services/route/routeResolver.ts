import { Injectable } from '@angular/core'
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { appService } from '../app.service';
import * as Constants from '../../shared/globalconstants';
import { Observable } from 'rxjs';
import { reject } from 'q';

@Injectable({
  providedIn: 'root'
})
export class routeResolver implements Resolve<any> {
  constructor(private appService: appService) {

  }
  getPathWithOutQueryString(url: string) {
    return url.split('?')[0];
  }

  resolve(routeConfig: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    debugger;
    return new Promise((resolve, reject) => {
      this.appService.getSessionData().subscribe((data: any) => {
        let currentUrl = state.url.toLocaleLowerCase();
        let rootData: any = routeConfig.data;
        if (rootData && rootData.authMatch) {
          currentUrl = rootData.authMatch;
        } else if (routeConfig.children) {
          routeConfig.children.forEach((x: any) => {
            if (x.data && x.data.authMatch) {
              currentUrl = x.data.authMatch;
            }
          })
        }
        if (routeConfig.paramMap.keys && routeConfig.paramMap.keys.length > 0) {
          currentUrl = state.url.replace("/" + routeConfig.paramMap.keys.map(q => routeConfig.params[q]).join("/"), "");
        }
        let UOMCategories = data.Function_UOMs.filter(q => '/' + q.PageDescription.toLowerCase() == currentUrl.toLowerCase()).map(w => w.UOMCategory);
        this.appService.populateUOMS(UOMCategories).then((val) => {
          resolve();
        });
      });
    });
  }
}
