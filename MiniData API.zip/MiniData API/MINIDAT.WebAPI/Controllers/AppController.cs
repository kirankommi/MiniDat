﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web;
using MINIDAT.Model;
using MINIDAT.Model.Session;
using MINIDAT.DataAccess.UOM;
using MINIDAT.DataAccess.Home;
using MINIDAT.Model.UOM;
using MINIDAT.DataAccess.Common;
using MINIDAT.DataAccess;
using MINIDAT.Manage.UOMTemplate;
using Newtonsoft.Json;
using MINIDAT.Framework.Login;
using MINIDAT.Framework.Common;

namespace MINIDAT.WebAPI.Controllers
{
    public class AppController : ApiController
    {
        UserRepository _userFactory = new UserRepository(new MINIDATDatabase());
        /// <summary>
        /// Gets the user session.
        /// </summary>
        /// <returns></returns>
        [HttpGet, HttpOptions, ActionName("Get")]
        // [CacheOutput(ClientTimeSpan = 240)]
        public HttpResponseMessage GetUserSession()
        {
            try
            {
               
                return Request.CreateResponse(HttpStatusCode.OK, SetUserSession());
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public UserSession SetUserSession()
        {
            try
            {
                var session = new UserSession();
                session = SetSession(false);
                return session;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        protected UserSession SetSession(bool isDirty)
        {
            if (HttpContext.Current.Session["Instance"] != null && isDirty == false)
                return HttpContext.Current.Session["Instance"] as UserSession;

            string userId = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
            userId = "h388219";
            var users = _userFactory.GetUsersessionData(new UserModel() { EID = userId });
            UserSession session = new UserSession();
            if (users != null && users.Users != null && users.Users.Count == 1 && users.Users[0].StatusCode.Key == "UACT")
            {
                var loggedUser = users.Users[0];
                HomePageDataAccess DAL = new HomePageDataAccess();
                LogManager.Info(JsonConvert.SerializeObject(new { Category = "LoggedInUser", Value = loggedUser.EID }));
                session.Applications.Clear();
                session.AvailableApplications.Clear();
                session.UomAliases.Clear();
                ((List<KeyValue>)session.UomAliases).AddRange(users.UnitAliases);
                ((List<KeyValue>)session.Applications).AddRange(users.ApplicationModels);
                ((List<Application>)session.AvailableApplications).AddRange(users.AvailableApplications);
                session.AppRoles.Clear();
                ((List<KeyValue>)session.AppRoles).AddRange(users.UserApplicationRoles);
                AppCache.SetUnitGroups();
                var app = users.UserApplicationRoles.FirstOrDefault();
                session.User = (loggedUser != null) ? loggedUser : users.Users[0];
                session.User.DisplayName = session.User.FirstName + ", " + session.User.LastName;
                session.UnitGroups.Clear();
                ((List<UnitGroup>)session.UnitGroups).AddRange(AppCache.UnitGroups);
                ((List<UomVariable>)session.UomVariables).AddRange(new UnitGroupDAL().GetUomVaraibles(Convert.ToInt32(session.User.UOMTemplateId)));
                ((List<MenuModel>)session.Privileges).AddRange(new HomePageDataAccess().GetMenubyRole(app.Value));
                ((List<MenuModel>)session.Menu).AddRange(GetMenuByPrivileges(session.Privileges.ToList()));
                ((List<FunctionUOMCategoryModel>)session.Function_UOMs).AddRange(new UnitGroupDAL().GetFunctionUOM(ApplicationSettings.AppId));
                HttpContext.Current.Session["Instance"] = session;
            }
            else
            {
                LogManager.Info(JsonConvert.SerializeObject(new { Category = "UnAuthorizedAttempt", Value = userId }));
                //handle not a valid user
            }
            return session;
        }

        /// <summary>
        /// Gets the run uom variable data.
        /// </summary>
        /// <param name="CategoryName">Name of the category.</param>
        /// <returns></returns>
        [HttpGet, ActionName("UOMVariablesData")]
        public IList<UomVariable> GetUOMVariablesData(string categories)
        {
            try
            {
                return new UnitGroupDAL().GetUomVaraibles(categories, User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1));
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        private List<MenuModel> GetMenuByPrivileges(List<MenuModel> privileges)
        {
            try
            {
                var menu = new List<MenuModel>();
                if (privileges != null)
                {
                    menu = privileges.Where(x => x.ParentFunctionCode == "FUNC000001").OrderBy(x => x.FunctionOrder).ToList();
                    foreach (var item in menu)
                    {
                        List<MenuModel> subMenu = privileges.Where(x => x.ParentFunctionCode == item.FunctionCode).OrderBy(x => x.FunctionOrder).ToList();
                        item.SubMenu.Clear();
                        if (subMenu != null && subMenu.Count > 0)
                        {
                            // item.SubMenu = subMenu;
                            ((List<MenuModel>)item.SubMenu).AddRange(subMenu);
                        }
                    }
                }
                return menu;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpGet, ActionName("GetMatchingLDAPUser")]
        public IList<User> GetMatchingLDAPUser(string userNmae, string domainName)
        {

            try
            {
                if (string.IsNullOrEmpty(userNmae) || string.IsNullOrEmpty(domainName))
                {
                    List<User> matchingUsers = new List<User>();
                    return matchingUsers;
                }

                LDAPUtility ldap = new LDAPUtility();
                return ldap.GetMatchingUserInDomains(userNmae, domainName);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        [HttpGet, ActionName("GetAllDomainNames")]
        public IList<string> GetAllDomainNames()
        {

            try
            {
                LDAPUtility ldap = new LDAPUtility();
                return ldap.GetAllDomainNames();

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        [HttpGet]
        [ActionName("TestApi")]
        public string TestApi()
        {
            return User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);

        }

    }
}
