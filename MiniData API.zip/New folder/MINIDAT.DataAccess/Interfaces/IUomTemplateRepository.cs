﻿using MINIDAT.Manage.UOMTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IUomTemplateRepository: ICRUDRepository<UOMTemplateModel>
    {
        IList<Application> GetApplications();
        IList<TemplateVariable> GetVariableData(string templateID);
        void SaveTemplateData(UOMTemplateModel uomtemplate, string userId);
        void MakeDefault(UOMTemplateModel uomtemplate, string userId);
        void SaveVariables(UOMTemplateModel uomtemplate, IList<TemplateVariable> variables, string userId);
        void DeleteTemplateData(UOMTemplateModel uomtemplate);
        IList<UOMTemplateModel> GetTemplateData(UOMTemplateModel uomtemplate, string userId);
        IList<Module> GetModuleData(string templateID);
        IList<Variable> GetVariableData(string moduleID, string templateID);
        void SaveUOMVariables(UOMTemplateModel template, Module module, List<TemplateVariable> variables, string userId);
    }
}
