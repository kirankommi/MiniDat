﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           LIMSAnalysisMethodController.cs
Project Title:      FeedStockDAT
Created on:         25-May-2017
Requirements Tag:   Model for Managing LIMS Analysis method
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;


namespace MINIDAT.Model.Manage.LIMSAnalysisMethod
{
    public class LIMSAnalysisMethodModel
    {
        private IList<SourceName> _Chksources = new List<SourceName>();
        public IList<SourceName> CheckedSources { get { return _Chksources; } }
        public int Id { get; set; }
        public string MethodName { get; set; }
        public string MethodNumber { get; set; }
        public string MethodDescription { get; set; }
        public string LIMSOperation { get; set; }
        public KeyValue UOMGroup { get; set; }

        private IList<KeyValue> _uomlist = new List<KeyValue>();
        public IList<KeyValue> UOMList { get { return _uomlist; } }

        public string CheckedSourcesNames { get; set; }

        private IList<SourceName> _sources = new List<SourceName>();
        public IList<SourceName> Sources { get { return _sources; } }
        public string UOMSearch { get; set; }
        [XmlIgnore]
       // public IList<KeyValue> UOMList  = new List<KeyValue>();

        //Pagination attributes
        public int TotalRecords { get; set; }
        public int CurrentPage { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }
    }

    public class SourceName
    {
        public string Name { get; set; }
        public string Id { get; set; }
        public bool IsUsed { get; set; }
    }

    public class LIMSAnalysisMethodSearchModel
    {
        public int RecordsFetched { get; set; }

        private IList<LIMSAnalysisMethodModel> _methods = new List<LIMSAnalysisMethodModel>();
        public IList<LIMSAnalysisMethodModel> AnalysisMethod { get { return _methods; } }

        private IList<KeyValue> _uom = new List<KeyValue>();
        public IList<KeyValue> UOM { get { return _uom; } }

        private IList<SourceName> _sources = new List<SourceName>();
        public IList<SourceName> Sources { get { return _sources; } }
    }
}
