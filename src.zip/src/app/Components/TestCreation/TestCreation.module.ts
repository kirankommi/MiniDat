import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TestCreationComponent } from './TestCreation.component';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { WCResultSummaryComponent } from './wcresult-summary/wcresult-summary.component';
import { CalculateAllComponent } from './calculate-all/calculate-all.component';

const route: Routes = [
  {
    path: 'TestCreation',
    component: TestCreationComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'TestCreation/WCResultSummary/:plant/:run/:test',
    component: WCResultSummaryComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'TestCreation/CalculateAllWC/',
    component: CalculateAllComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  ];


@NgModule({
    imports: [
        sharedModule,
        RouterModule.forChild(route)
  ],
  declarations: [
      TestCreationComponent,
      WCResultSummaryComponent,
      CalculateAllComponent
  ]
})
export class TestCreationModule {

}
