﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DOE
{
    public class Run
    {
        public string ProjectName { get; set; }
        public string StudyName { get; set; }
        public int? StudyId { get; set; }
        public int? DOEID { get; set; }
        public string Plant { get; set; }
        public int? RunNum { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Requestor { get; set; }
        public string Status { get; set; }
        public int DOERun { get; set; }
        public string NetworkNUM { get; set; }
        public int? RUN_ID { get; set; }
        public int DisplayOrder { get; set; }
        public string NIRFlagInd { get; set; }
        public CatalystInfo CatalystTemplate { get; set; }
        public ModeInfo Mode { get; set; }
        public FeedInfo Feed { get; set; }

        public Run()
        {
            CatalystTemplate = new CatalystInfo();
            Mode = new ModeInfo();
            Feed = new FeedInfo();
        }
    }
}
