﻿export class CatalystStateModel
{
    CatalystStateID: number;
    CatalystState: string;  
    StatusName: string;  
    StatusCode: KeyValue;  
    SRIndicator: string;   
    SRIndicatorcd: KeyValue;   
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
