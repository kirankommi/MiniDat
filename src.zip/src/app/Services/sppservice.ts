import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { HttpActionService } from "./httpaction.service";
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class SPPService {
    private getSPPdata = "/SPP/GetSPPData/";
    constructor(private httpaction: HttpActionService) { }
    getSPPInformation(templateId: any) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateId', templateId);     
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getSPPdata,options);
    }
}