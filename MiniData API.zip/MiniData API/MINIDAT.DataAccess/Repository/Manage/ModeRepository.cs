﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleRepository.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Manage;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class ModeRepository : IModeRepository
    {
        private IDatabase _db;
        public ModeRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="N", Value="Inactive"},
                    new KeyValue() {Key="Y", Value="Active"},
                };


        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public ModeSearchModel GetModeData(ModeModel Mode)
        {
            try
            {
                ModeSearchModel modearr = new ModeSearchModel();
                if (Mode == null)
                {
                    return modearr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Search_Mode_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Mode_Num", string.IsNullOrEmpty(Convert.ToString(Mode.ModeNumber)) ? (object)null : Mode.ModeNumber);
                    parameters.Add("proc_vr_Mode_Type", string.IsNullOrEmpty(Mode.ModeType == "Select" ? null: Mode.ModeType) ? (object)null : Mode.ModeType);
                    parameters.Add("proc_vr_Mode_Desc", string.IsNullOrEmpty(Mode.Description) ? (object)null : Mode.Description);
                    parameters.Add("proc_in_control_type ", string.IsNullOrEmpty(Mode.ControlName == "Select" ? null : Mode.ControlName) ? (object)null : Mode.ControlName);
                    parameters.Add("proc_in_sulfiding_type", string.IsNullOrEmpty(Mode.SulfidingType == "Select" ? null : Mode.SulfidingType) ? (object)null : Mode.SulfidingType);
                    parameters.Add("proc_nm_Pressue_Value_Msr", Mode.Pressure);
                    parameters.Add("proc_nm_LHSV_Value_Msr", Mode.LHSV);
                    parameters.Add("proc_nm_SCFB_Value_Msr", Mode.SCFB);
                    parameters.Add("proc_vr_Conditions", Mode.Conditions);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    modearr.lstModes.Clear();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)modearr.lstModeTypes).Add(new KeyValue()
                        {
                            Key = reader["MODE_TYP"].ToString(),
                            Value = reader["MODE_TYP"].ToString()
                        });                        
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)modearr.lstControlNames).Add(new KeyValue()
                        {
                            Key = reader["CNTRL_TYP"].ToString(),
                            Value = reader["CNTRL_TYP"].ToString()
                        });
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)modearr.lstSulfidingTypes).Add(new KeyValue()
                        {
                            Key = reader["SLFDNG_TYP"].ToString(),
                            Value = reader["SLFDNG_TYP"].ToString()
                        });
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        ModeModel mode = new ModeModel()
                        {                           
                            ModeID = Convert.ToInt32(reader["MODE_ID_SQ"]),
                            ModeNumber = Convert.ToInt32(reader["MODE_NUM"]),
                            Description = reader["MODE_DESC"].ToString(),
                            ControlName = reader["CONTROL_METHOD_NM"].ToString(),
                            SulfidingType = reader["SULFIDING_TYPE_NM"].ToString(),
                            ModeType = reader["OBJECTIVE_NM"].ToString(),
                            LHSV = (reader["LHSV"]== DBNull.Value) ? 0:Convert.ToDecimal(reader["LHSV"]),
                            Pressure = (reader["PRESSURE"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["PRESSURE"]),
                            SCFB = (reader["SCFB"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["SCFB"]),
                            Conditions = Convert.ToInt32(reader["CONDITION"]),
                            CanEdit= reader["MODIFY_IND"].ToString()
                        };
                        modearr.lstModes.Add(mode);
                    }

                   reader.NextResult();
                    ApplicationModel appModel = new ApplicationModel();
                    // rolesearchModel.ApplicationList.Add(new ApplicationModel { ApplicationId = "3", ApplicationName = "FeedStock DAT" });
                    while (reader.Read())
                    {
                        appModel = new ApplicationModel
                        {
                            ApplicationId = Convert.ToString(reader["SRC_SYSTEM_ID"]),
                            ApplicationName = Convert.ToString(reader["SRC_SYSTEM_NM"])

                        };
                        //   roleList.Add(appModel);
                        modearr.ApplicationList.Add(appModel);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        modearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    modearr.Status.Clear();
                    reader.Close();
                    ((List<KeyValue>)modearr.Status).AddRange(statuses);
                    return modearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteModeData(ModeModel mode)
        {
            try
            {
                if (mode == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[md].Delete_Mode_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Mode_ID", string.IsNullOrEmpty(Convert.ToString(mode.ModeID)) ? (object)null : mode.ModeID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SaveModeData(ModeModel Mode, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || Mode == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[md].Insert_Update_Mode_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Mode_Id_Sq", Mode.ModeID);
                    parameters.Add("proc_vr_Mode_Number", Mode.ModeNumber);
                    parameters.Add("proc_vr_Mode_desc", Mode.Description);
                    parameters.Add("proc_vr_Objective_Id", Mode.ModeType);
                    parameters.Add("proc_vr_Control_Method_Id", Mode.ControlName);
                    parameters.Add("proc_vr_Sulfiding_Type_Id", Mode.SulfidingType);
                    parameters.Add("proc_nm_Pressue_Value_Msr", Mode.Pressure);
                    parameters.Add("proc_nm_LHSV_Value_Msr", Mode.LHSV);
                    parameters.Add("proc_nm_SCFB_Value_Msr", Mode.SCFB);
                    parameters.Add("proc_nm_Condition_Num", Mode.Conditions);
                    parameters.Add("proc_Modify_Ind", Mode.CanEdit);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// search role
        /// </summary>
        /// <param name="PITag"></param>
        /// <returns></returns>
        public ModeSearchModel GetPlantsData(ModeModel mode)

        {
            try
            {
                ModeSearchModel modearr = new ModeSearchModel();
                if (modearr == null)
                {
                    return modearr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[Search_Modes_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Mode_Num", mode.ModeNumber);
                    parameters.Add("proc_vr_Mode_Type", mode.ModeType);
                    parameters.Add("proc_vr_Mode_Desc", mode.Description);
                    parameters.Add("proc_in_control_type ", mode.ControlName);
                    parameters.Add("proc_in_sulfiding_type", mode.SulfidingType);
                    parameters.Add("proc_nm_Pressue_Value_Msr", mode.Pressure);
                    parameters.Add("proc_nm_LHSV_Value_Msr", mode.LHSV);
                    parameters.Add("proc_nm_SCFB_Value_Msr", mode.SCFB);
                    parameters.Add("proc_vr_Conditions", mode.Conditions);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    modearr.lstModes.Clear();
                   
                    while (reader.Read())
                    {
                        ModeModel newMode = new ModeModel()
                        {
                           
                            ModeID = Convert.ToInt32(reader["MODE_ID_SQ"]),
                            ModeNumber = Convert.ToInt32(reader["MODE_NM"]),
                            Description = reader["MODE_DESC"].ToString()
                        };
                        modearr.lstModes.Add(newMode);
                    }                   
                    return modearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        public void Update(ModeModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(ModeModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<ModeModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(ModeModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
