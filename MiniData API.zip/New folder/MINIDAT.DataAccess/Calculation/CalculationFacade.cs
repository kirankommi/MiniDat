﻿using Calculations;
using MINIDAT.Calculation.Modules;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model.Session;
using MINIDAT.Model.Test;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Calculation
{
    public class CalculationFacade
    {
        CalculationStatusReceiver objReceiver;
        TestCreation testModel;
        /// <summary>
        /// Initializes a new instance of the <see cref="CalculationFacade"/> class.
        /// </summary>
        /// <param name="objFacade">The obj facade.</param>
        /// <param name="objReceiver">The obj receiver.</param>
        public CalculationFacade(TestCreation objFacade, CalculationStatusReceiver objReceiver)
        {
            this.objReceiver = objReceiver;
            this.testModel = objFacade;
        }

        /// <summary>
        /// Executes the calculations.
        /// </summary>
        public void ExecuteCalculations(string strPlantCd, int? intRunId, int? intTestid, UserSession userSession)
        {
            try
            {
                ITestCreationRepository _testRepository = new TestCreationRepository(new MINIDATDatabase());
                ContentValues input = new ContentValues();
                TestCreationFacade test = new TestCreationFacade();
                if (!string.IsNullOrEmpty(strPlantCd) && null != intRunId && null != intTestid)
                {
                    input = test.GetWeightCheckInputs(strPlantCd, intRunId, intTestid);

                }
                // //MINIDatCalculationSet.WeightCheckCalculations(null).BeginCalculate(this);

                CalculationSetBuilder builder = new CalculationSetBuilder();
                DataSet weightCheckResultSummmary = new DataSet();
                builder.SetSharedContentValues(input, weightCheckResultSummmary);
                builder.AddParallelCalculations(new PlantCalculations(input, weightCheckResultSummmary),
                    new GasVolumesCalculations(input, weightCheckResultSummmary, userSession));
                builder.AddSequentialCalculations(
                new GasWeightsCalculations(input, weightCheckResultSummmary, userSession),
                new WeightRecoveryCalculations(input, weightCheckResultSummmary, userSession),
                new HosCalculations(input, weightCheckResultSummmary, userSession),
                new LiquidWt690Calculations(input, weightCheckResultSummmary),
                new LiquidWeightCalculations(input, weightCheckResultSummmary, userSession),
                new YieldCalculations(input, weightCheckResultSummmary),
                new DopantCalculations(input, weightCheckResultSummmary),
                new FeedWtSimDistCalculations(input, weightCheckResultSummmary, userSession));
                builder.AddParallelCalculations(new ConversionCalculations(input, weightCheckResultSummmary)
                    , new LpProductPropertiesCalculations(input, weightCheckResultSummmary)
                    );
                builder.AddSequentialCalculations(new QualityAssuranceCalculations(input, weightCheckResultSummmary));
                //Add other calculations
                builder.BeginCalculate(objReceiver);

            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }
    }
}
