﻿using MINIDAT.Model.Manage.LIMSAnalysisMethod;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ILimsResultTraceLogRepository
    {
       // IList<LimsResultTraceLog> GetAll(string type, string feedId);
        void SaveOperations(string data, string User);
        void SaveComponents(string data, string User);

        int getMissingOperationAndComponentCountByFeedId(string feedId);
    }
}
