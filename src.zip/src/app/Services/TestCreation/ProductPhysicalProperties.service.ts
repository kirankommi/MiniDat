import { Injectable } from '@angular/core';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { DataViewerModel } from 'src/app/Models/DataViewer/DataViewerModel';
import * as Constants from '../../Shared/globalconstants';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { ProductPhysicalPropertiesModel, ProductPhysicalPropertiesInputModel, ArrayOfProductPhysicalPropertyItemViewModel } from 'src/app/Models/TestCreation/ProductPhysicalPropertiesModel';

@Injectable()
export class ProductPhysicalPropertiesService {
    private getProductPhysicalPropertiesDropdownUrl = "/ProductPhysicalProperties/GetDropdownData";
    private getProductPhysicalPropertiesDataUrl = "/ProductPhysicalProperties/GetUIData";
    private saveProductPhysicalPropertiesDataUrl = "/ProductPhysicalProperties/SavePhysicalProperties";
    cachedDataForTable: ProductPhysicalPropertiesModel[] = [];
    constructor(private httpaction: HttpActionService) { }

    GetProductPhysicalPropertiesDropdownValues(input: ProductPhysicalPropertiesInputModel) {
        return this.httpaction.post(input, this.getProductPhysicalPropertiesDropdownUrl);
    }

    GetProductPhysicalPropertiesData(input: ProductPhysicalPropertiesInputModel) {
        // let params: URLSearchParams = new URLSearchParams();
        // params.set('input', stream);
        // let allVar= allVarChecked==true ?"true":"false"
        // params.set("allVar", allVar);
        // let options = new RequestOptions(Constants.getParamOptions(params));
        // return this.httpaction.get(this.getProductPhysicalPropertiesDataUrl, options);
        return this.httpaction.post(input, this.getProductPhysicalPropertiesDataUrl);
    }

    SaveProductPhysicalPropertiesData(data: ArrayOfProductPhysicalPropertyItemViewModel) {
        return this.httpaction.post(data, this.saveProductPhysicalPropertiesDataUrl);
    }

    CacheFetchedRecords(data: ProductPhysicalPropertiesModel[]) {
        this.cachedDataForTable = data.map(x => ({ ...x }));
        return this.cachedDataForTable;
    }
}