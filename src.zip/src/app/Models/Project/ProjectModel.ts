﻿
import { KeyValue } from '../KeyValue';

export class AccoladeProjectModel
{
    public DW_ProjectId: number;
    public AccoladeProjectCd: string;
    public ProjectName: string;
    public ProjectDesc: string;
    public CurrentPhaseNameCd: string;
    public CurrentPhasePriorityCd: string;        
    public UOPNetworkNumber1: string;
    public UOPNetworkNumber2: string;
    public UOPNetworkNumber3: string;
    public TechLead: string;
    public ProjectTypeId: number;
    public UOPSegmentId: number;
    public PTE: number;
    public CAS: number;
    public StatusCd: string;
    public isExists: string;
    public Gate2: string;
    public Gate3: string;
    public Gate4: string;
    public Gate5: string;
    public Gate6: string;
    public Gate7: string;
}
export class ProjectModel  {

    public ProjectId: number;    
    public ProjectCd: number;        
    public ProjectName: string;
    public Description: string;
    public NetworkNumber1: string;
    public NetworkNumber2: string;
    public NetworkNumber3: string;
    public TechnicalTeamLead: string;
    public PPPriorityCd: string;
    public StatusCd: string;
    public Attachments: [any];
    public ProjectFiles: FileImport[];
}


export class NPDProjectModel  implements ProjectModel
{
    public ProjectId: number;
    public ProjectCd: number;    
    public ProjectName: string;
    
    public Description: string;
    public NetworkNumber1: string;
    public NetworkNumber2: string;
    public NetworkNumber3: string;
    public TechnicalTeamLead: string;
    public PPPriorityCd: string;
    public PPPriorityName: string;
    public StatusCd: string;
    public StatusName: string;
    public Attachments: [any];
    public ProjectFiles: FileImport[];
    //NPD Model
    public DwProjectId: number;
    public AccoladeProjectCd: number;    
    public CurrentPhaseNameCd: string;
    public CurrentPhaseName: string;    
    public CurrentPhasePriorityCd: string;    
    public CurrentPhasePriorityName: string;
    public Gate2: string;
    public Gate3: string;
    public Gate4: string;
    public Gate5: string;
    public Gate6: string;    
    public Gate7: string;
    public ProjectTypeId: number;
    public UOPSegmentId: number;
    public SBU: string;
    public PTEPerc: string;
    public CASPerc: string;
    
}


export class CapabilityProjectModel implements ProjectModel {
    public ProjectId: number;
    public ProjectCd: number;    
    public ProjectName: string;    
    public Description: string;
    public NetworkNumber1: string;
    public NetworkNumber2: string;
    public NetworkNumber3: string;
    public TechnicalTeamLead: string;    
    public StatusCd: string;
    public Attachments: [any];
    public ProjectFiles: FileImport[];

    //Capability
    public CurrentPhasePriorityCd: string;  
    public UOPSegmentId: number;
    public DwProjectId: number;
    public AccoladeProjectCd: number;    
    public PTEPerc: string;
    public CASPerc: string;
    public PPPriorityCd: string;
    public PPPriorityName: string;      
    public ProjectTypeId: number;
}


export class CustomerProjectModel implements ProjectModel {
    public ProjectId: number;
    public ProjectCd: number;    
    public ProjectName: string;
    public Description: string;
    public NetworkNumber1: string;
    public NetworkNumber2: string;
    public NetworkNumber3: string;
    public TechnicalTeamLead: string;
    public PPPriorityCd: string;
    public StatusCd: string;
    public Attachments: [any];
    public ProjectFiles: FileImport[];

    //NPD Model
    public BusinessGroupCd: string;
    public BusinessGroupName: string;
    public SFDC: string;
    public BusinessJustificationCd: string;
    public BusinessObjectiveCd: string;    
    public ProjectTypeId: string;
    public ApplicationCd: string;

}

export class ProjectMasterDataModel
{
    public CurrentPhasePriorities: KeyValue[];
    public CurrentPhaseNames: KeyValue[];
    public UopSEGs: KeyValue[];
    public PTEs: KeyValue[];
    public CASs: KeyValue[];
    public PPPriorities: KeyValue[];
    public Status: KeyValue[];
    public BusinessGroup: KeyValue[];
    public BusinessJustification: KeyValue[];
    public BusinessObjective: KeyValue[];
    public Application: KeyValue[];

}

export class FileImport {
    UID?: number;
    RowId: number;
    ProjectId: number;
    FileId: number;
    FileName: string;
    FileSize: number;
    Description: string;
    FileData: any;
    ProgressId: string;
    isUploadStarted: boolean;
    isUploadCompleted: boolean;
}
