﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model.Test;
using MINIDAT.Model;
using MINIDAT.Model.Session;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using LIMSService.Interface;
using System.Threading.Tasks;
using System.Collections.Generic;
using PIAPIDataService.Models;
using LIMSService.Service;
using TestParameter = MINIDAT.Model.Test.TestParameter;
using LIMSTestParameter = LIMSService.Service.TestParameter;
using MINIDAT.Model.TestCreation;
using System.Linq;


namespace MINIDAT.WebAPI.Controllers.TestCreationControllers
{
    public class TestCreationController : AppController
    {
        ITestCreationRepository _testCreationRepository;
        public TestCreationController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Test Creation Repository" }));
            _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
        }
        [HttpGet, ActionName("GetTest")]
        public HttpResponseMessage GetTest()
        {
            TestCreationRepository _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _testCreationRepository.GetTest());

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }
        [HttpGet, ActionName("GetPlantsFlyout")]
        public HttpResponseMessage GetPlantsFlyout()
        {
            TestCreationRepository _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _testCreationRepository.GetPlantsFlyout());

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }
        [HttpGet, ActionName("GetRuns")]
        public HttpResponseMessage GetRunFlyout(string PlantCd)
        {
            TestCreationRepository _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _testCreationRepository.GetRunFlyout(PlantCd));

            }
            catch(SqlException sql)
            {
                LogManager.Error(sql);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.NullPlantCode.ToString());
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }
        [HttpPost, ActionName("SearchTestCreation")]
        public HttpResponseMessage SearchData(TestModel testData)
         {
            TestCreationRepository _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _testCreationRepository.SearchTest(testData));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }
        //new
        [HttpPost, ActionName("SaveTestInformation")]
        public HttpResponseMessage SaveTestInformation([FromBody] TestModel _test)
        {
            if (_test != null)
            {
                try
                {
                    ITestCreationRepository _testRepository = new TestCreationRepository(new MINIDATDatabase());
                    _testCreationRepository.SaveTestData(_test, User.Identity.Name);
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateResponse(HttpStatusCode.OK, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        [HttpPost, ActionName("deleteTestData")]
        public HttpResponseMessage DeleteTestInformation([FromBody] TestModel testmodel)
        {
            if (testmodel != null)
            {
                try
                {
                    ITestCreationRepository _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
                    _testCreationRepository.DeleteTest(testmodel);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        [HttpPost, ActionName("GetLimsInformation")]
        public async Task<HttpResponseMessage> GetLimsInformation(LIMSTestParameter param)
        {
            try
            {
                ITestParameter item = param;
                LIMSService.Service.LIMSServiceDataAccess daccess = new LIMSService.Service.LIMSServiceDataAccess(DATSource.MINDAT);
                using (LIMSService.Service.LIMSService client = new LIMSService.Service.LIMSService(daccess, DATSource.MINDAT))
                {
                   var testData = client.ImportTestData(param, true);
                    string strLabResult = Serializer.ConvertToXML(testData.LabResult);
                    string strGcResult = Serializer.ConvertToXML(testData.OnlineGCResult);
                    client.LogXML(testData.LabResult != null ? strLabResult : "Doesn't have lab result");
                    client.LogXML(testData.OnlineGCResult != null ? strGcResult : "Doesn't have online GC");
                }
               

                return Request.CreateResponse(HttpStatusCode.OK,"Success");
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        [HttpPost, ActionName("GetPIInformation")]
        public async Task<HttpResponseMessage> GetPIInformation(TestParameter param)
        {
            try
            {
                ITestCreationRepository _testRepository = new TestCreationRepository(new MINIDATDatabase());
                //ITestParameter item = param;
                PIAPIDataService.PiApiDataService client = new PIAPIDataService.PiApiDataService();
                var tags = JsonConvert.DeserializeObject<List<PITag>>(client.GetPITags(param.ServerName, param.Plant));
                List<string> tagsNames = new List<string>();

                tagsNames = new List<string>();
                tags.ForEach((tag) =>
                {
                    tagsNames.Add(tag.TagName);
                });
                PIData piData = JsonConvert.DeserializeObject<PIData>(client.GetPIData(param.ServerName,param.Plant, param.StartTime, param.EndTime, param.TimeZone, 60, tagNames: tags.Select(x => x.TagName).ToList()));
                Result result = new Result()
                {
                    HasError = piData.HasError,
                    ErrorDescription = piData.ErrorDescription,
                    Plant = param.Plant,
                    Data = piData
                };

                string strpiData = Serializer.ConvertToXML(result);
                _testCreationRepository.SavePIData(strpiData);
                if (!String.IsNullOrEmpty(strpiData))
                {
                    client.LogXML(strpiData != null ? strpiData : "Returned nothing");
                    return Request.CreateResponse(HttpStatusCode.OK, "Success");
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.OK, "Fail to get the data");

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost, ActionName("Calculate")]
        public HttpResponseMessage Calculate([FromBody] TestModel test)
        {
            try
            {
                if (null != test)
                {
                    ITestCreationRepository _testRepository = new TestCreationRepository(new MINIDATDatabase());
                    var userSession = SetUserSession();
                    _testCreationRepository.PerformCalculations(test, userSession);
                }

                return Request.CreateResponse(HttpStatusCode.OK, "Success");
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

    }
}
