﻿using System;
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model.DataViewerModel;
using MINIDAT.Model;
using System.Web.Mvc;
using MINIDAT.DataAccess.Repository.DataViewer;
using System.Net.Http;
using System.Net;
using NPOI.XSSF.UserModel;
using System.IO;
using NPOI.SS.UserModel;
using MINIDAT.WebAPI.Controllers.RunController;
using System.ComponentModel;
using NPOI.SS.Util;
using System.Data;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace MINIDAT.WebAPI.Controllers.DataViewerController
{
    public class DataViewerController : AppController
    {
        [HttpGet, ActionName("GetDataForDataViewer")]
        public HttpResponseMessage GetDataForDataViewer(string Plant, string Run, string Category, string User_Id)
        {
            DataViewerRepository _dataViewerRepository = new DataViewerRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _dataViewerRepository.getDataForDataViewer( Plant,  Run,  Category,  User_Id));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                //need to change
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }

        [HttpPost, ActionName("ExportDataViewer")]
        public Byte[] ExportDataViewer(DataViewerModel inputdata)
        {
            DataViewerRepository _dataViewerRepository = new DataViewerRepository(new MINIDATDatabase());
            RunController.RunController _runController = new RunController.RunController();
            try
            {
                string[] categories;
                categories = inputdata.Category.Split(',');
                XSSFWorkbook workbook = new XSSFWorkbook();
                int _rowIndex = 7;
                /////////////////
                // Export Data //
                /////////////////
                DataViewerExport DVExportData;
                DVExportData = _dataViewerRepository.ExportMultipleCategories(inputdata.Plant, inputdata.Run.ToString(), inputdata.Category, inputdata.User_Id);
                foreach(var cat in categories)
                {
                    List<dynamic> exportdata = new List<dynamic>();
                    inputdata.Category = cat;
                    ISheet sheet;
                    
                    switch (inputdata.Category)
                    {
                        case "Plant Calculations":
                            exportdata = DVExportData.PlantCalculations;
                            break;
                        case "Normalized Gas Yields":
                            exportdata = DVExportData.NormalizedGasYields;
                            break;
                        case "Gas Volumes":
                            exportdata = DVExportData.GasVolumes;
                            break;
                        case "Gas Weights":
                            exportdata = DVExportData.GasWeights;
                            break;
                        case "Weight Recovery":
                            exportdata = DVExportData.WeightRecovery;
                            break;
                        case "Liquid Weights":
                            exportdata = DVExportData.LiquidWeights_LP690;
                            inputdata.Category = "Liquid Weights (LP 690)";
                            break;
                        case "Liquid Weights Percent":
                            exportdata = DVExportData.LiquidWeights_percent;
                            inputdata.Category = "Liquid Weights %'s (Sim Dist)";
                            break;
                        case "Liquid Weights(Sim Dist)":
                            exportdata = DVExportData.LiquidWeights_Simdist;
                            break;
                        case "Normalized Liquid Weight":
                            exportdata = DVExportData.NormalizedLiquidWeights;
                            inputdata.Category = "Normalized Liquid Weights";
                            break;
                        case "Raw Product Weights":
                            exportdata = DVExportData.RawProductWeights;
                            break;
                        case "Raw Product Weight Percent":
                            exportdata = DVExportData.RawProductWeights_percent;
                            inputdata.Category = "Raw Product Wt %'s";
                            break;
                        case "Mass Balance Adjusted Prod Wt Percent":
                            exportdata = DVExportData.MBAdjustedProductWt_percent;
                            inputdata.Category = "MB Adjusted Product Wt %'s";
                            break;
                        case "Dopant Adjustment":
                            exportdata = DVExportData.DopantAdjustments;
                            inputdata.Category = "Dopant Adjustments";
                            break;
                        case "Dopant Adjusted Mb":
                            exportdata = DVExportData.DAMassBalanceProductWt_perscent;
                            inputdata.Category = "DA Mass Balance Product Wt %'s";
                            break;
                        case "Product Ratios":
                            exportdata = DVExportData.ProductRatios;
                            break;
                        case "Feed Weight(Sim Dist)":
                            exportdata = DVExportData.FeedWeights;
                            inputdata.Category = "Feed Weights (Sim Dist)";
                            break;
                        case "Feed Weight Percent(Sim Dist)":
                            exportdata = DVExportData.FeedWeightsPercent;
                            inputdata.Category = "Feed Weight %'s  (Sim Dist)";
                            break;
                        case "Conversion Calculations":
                            exportdata = DVExportData.ConversionCalculation;
                            inputdata.Category = "Conversion";
                            break;
                        case "Quality Calculations":
                            exportdata = DVExportData.QualitCalculation;
                            break;
                        case "LP Product Properties":
                            exportdata = DVExportData.H2LPProductProperties;
                            break;
                        case "H By NIR Yields":
                            exportdata = DVExportData.H2ByNIR;
                            break;
                        case "H By NMR Yields":
                            exportdata = DVExportData.H2ByNMR;
                            break;
                    }
                    sheet = CreateSheetsForExport(workbook, inputdata.Category, inputdata.Plant, inputdata.Run);
                    if (exportdata.Count > 0)
                    {
                        var json = JsonConvert.SerializeObject(exportdata);
                        DataTable dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
                        dt.Columns["PARAMETER_NM"].ColumnName = "Parameter";
                        dt.Columns["DEFAULT_UNIT_DISPLAY_NM"].ColumnName = "UOM";
                        string exportDataviewer = "DataViewer";
                        _rowIndex = _runController.AddDataToExcel2(dt, _rowIndex, inputdata.Category, workbook, sheet, exportDataviewer);
                        _rowIndex = 7;
                    }

                }
                using (MemoryStream output = new MemoryStream())
                {
                    workbook.Write(output);
                    return output.ToArray();
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
                //need to change
                // return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }

        public ISheet CreateSheetsForExport(XSSFWorkbook workbook, string sheetName, string plant, int run)
        {
            RunController.RunController _runController = new RunController.RunController();
            var normalStyle = _runController.setTableStyle(workbook);
            ISheet sheet1 = workbook.CreateSheet(sheetName);
            for (int i = 0; i < 20; i++)
            {
                sheet1.SetColumnWidth(i, 4000);
            }
            sheet1.SetColumnWidth(0, 6000);
            var _rowIndex = 0;

            var row = sheet1.CreateRow(_rowIndex++);
            _runController.SetTitle(sheet1, workbook, "Data Viewer");
            /////////////////Header Styling for table/////////////////////////////////////////
            var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
            headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.FillPattern = FillPattern.SolidForeground;
            headerStyle.WrapText = true;
            headerStyle.BorderTop = BorderStyle.Thin;
            headerStyle.BorderBottom = BorderStyle.Thin;
            headerStyle.BorderLeft = BorderStyle.Thin;
            headerStyle.BorderRight = BorderStyle.Thin;
            headerStyle.Alignment = HorizontalAlignment.Center;
            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 11;
            hFont.FontName = "Calibri";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            headerStyle.SetFont(hFont);
            //////////////////////////////////////////////////////////

            _rowIndex = _rowIndex + 3;
            row = sheet1.CreateRow(_rowIndex);
            row.SetCellValue(1, "Plant", headerStyle);
            row.SetCellValue(2, plant, normalStyle);
            row.SetCellValue(4, "Run", headerStyle);
            row.SetCellValue(5, run.ToString(), normalStyle);
            _rowIndex = _rowIndex + 3;
            row = sheet1.CreateRow(_rowIndex);

            return sheet1;
        }
    }

   
}