import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { UserModel } from '../Models/usermodel';
import { HttpActionService } from './httpaction.service';
import * as Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable({
    providedIn: 'root'
})
export class LDAPService {
    private GetMatchingLDAPUserUrl = "/App/GetMatchingLDAPUser/";
    private GetAllDomainNamesUrl = "/App/GetAllDomainNames/";
   

    constructor(private httpaction: HttpActionService) { }

    getUsers(userNmae: string, domainName:string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('userNmae', userNmae);     
        params.set('domainName', domainName);     
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetMatchingLDAPUserUrl, options);
    }


    GetAllDomainNames() {
        let params: URLSearchParams = new URLSearchParams();        
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAllDomainNamesUrl, options);
    }
    
}

