﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MINIDAT.Model.Project
{

    public class AccoladeProjectModel
    {

        public int DW_ProjectId { get; set; }
        public string AccoladeProjectCd { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDesc { get; set; }
        public string CurrentPhasePriorityCd { get; set; }
        public string CurrentPhaseNameCd { get; set; }
        
        public string UOPNetworkNumber1 { get; set; }
        public string UOPNetworkNumber2 { get; set; }
        public string UOPNetworkNumber3 { get; set; }
        public string TechLead { get; set; }
        public int ProjectTypeId { get; set; }

        public string UOPSegmentId { get; set; }
        public decimal PTE { get; set; }
        public decimal CAS { get; set; }
        public string StatusCd { get; set; }

        public string isExists { get; set; }
        public string Gate2 { get; set; }
        public string Gate3 { get; set; }
        public string Gate4 { get; set; }
        public string Gate5 { get; set; }
        public string Gate6 { get; set; }
        public string Gate7 { get; set; }

    }
    public class ProjectModel
    {

        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string Description { get; set; }
        public string NetworkNumber1 { get; set; }
        public string NetworkNumber2 { get; set; }
        public string NetworkNumber3 { get; set; }

        public string TechnicalTeamLead { get; set; }

        public string PPPriorityCd { get; set; }
        public string PPPriorityName { get; set; }
        
        public string StatusCd { get; set; }
        public string StatusName { get; set; }

        public int ProjectTypeId { get; set; }
        public List<FileImport> ProjectFiles { get; set; }

    }
    public class NPDProjectModel : ProjectModel
    {
        public string AccoladeProjectCd { get; set; }
        public int? DwProjectId { get; set; }
        public string CurrentPhasePriorityCd { get; set; }
        public string CurrentPhasePriorityName { get; set; }
        public string CurrentPhaseNameCd { get; set; }       
        public string CurrentPhaseName { get; set; }       
        public string Gate2 { get; set; }
        public string Gate3 { get; set; }
        public string Gate4 { get; set; }
        public string Gate5 { get; set; }
        public string Gate6 { get; set; }
        public string Gate7 { get; set; }      
        public int? UOPSegmentId { get; set; }
        public string UOPSegmentName { get; set; }
        public string SBU { get; set; }
        public double PTEPerc { get; set; }
        public double CASPerc { get; set; }
        public int ProjectTypeId { get; set; }
        

    }

    public class CapabilityProjectModel : ProjectModel
    {
        public string AccoladeProjectCd { get; set; }
        public string CurrentPhasePriorityCd { get; set; }
        public string CurrentPhasePriorityName { get; set; }
        public int? UOPSegmentId { get; set; }
        public int? DwProjectId { get; set; }

        public double PTEPerc { get; set; }
        public double CASPerc { get; set; }
        public string PPPriorityCd { get; set; }
        public string PPPriorityName { get; set; }
        public int ProjectTypeId { get; set; }

    }

    public class CustomerProjectModel : ProjectModel
    {
       

        public string BusinessGroupCd { get; set; }
        public string BusinessGroupName { get; set; }
        public string SFDC { get; set; }
        public string BusinessJustificationCd { get; set; }
        public string BusinessObjectiveCd { get; set; }
        public string ApplicationCd { get; set; }
        public int ProjectTypeId { get; set; }


    }
    public enum ProjectType
    {
        NPD,
        Capability_Exploratory,
        Custumer_Manufacture
    }

    public class ProjectMasterDataModel
    {

        public List<KeyValue> CurrentPhasePriorities { get; set; }
        public List<KeyValue> CurrentPhaseNames { get; set; }
        public List<KeyValue> UopSEGs { get; set; }
        public List<KeyValue> PTEs { get; set; }
        public List<KeyValue> CASs { get; set; }
        public List<KeyValue> PPPriorities { get; set; }
        public List<KeyValue> Status { get; set; }
        public List<KeyValue> BusinessGroup { get; set; }
        public List<KeyValue> BusinessJustification { get; set; }
        public List<KeyValue> BusinessObjective { get; set; }
        public List<KeyValue> Application { get; set; }

    }

    public class FileImport
    {
        public int? UID { get; set; }
        public int RowId { get; set; }
        public int ProjectId { get; set; }
        public int FileId { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string Description { get; set; }
        [XmlIgnore]
        public Object FileData { get; set; }
        private byte[] _data { get; set; }
        public byte[] getData()
        {
            return _data;
        }
        public void setData(byte[] fileContent)
        {
            _data = fileContent;
        }
        public string CreatedByUserID { get; set; }
        public string UpdatedByUserID { get; set; }
    }
}

