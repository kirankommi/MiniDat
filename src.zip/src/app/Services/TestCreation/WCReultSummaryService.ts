import { Injectable } from '@angular/core';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { DataViewerModel } from 'src/app/Models/DataViewer/DataViewerModel';

@Injectable({
  providedIn: 'root'
})
export class WCReultSummaryService {

  private GetWCResultSummary: string = "/WCResultSummary/GetDataForWCResultSummary";
  private ExportWCResultSummary: string = "/WCResultSummary/ExportWC";
  constructor(private httpAction: HttpActionService) { }

  GetDataForWCResultSummary(dataviewInput:DataViewerModel) {
    let params: URLSearchParams = new URLSearchParams();
    params.set('Category', dataviewInput.Category);
    params.set('Plant', dataviewInput.Plant);
    params.set('Test', dataviewInput.Test.toString());
    params.set('Run', dataviewInput.Run.toString());
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.GetWCResultSummary,options);
  }
  ExportWCData(dataviewInput:DataViewerModel){
    let params: URLSearchParams = new URLSearchParams();
    params.set('Category', dataviewInput.Category);
    params.set('Plant', dataviewInput.Plant);
    params.set('Test', dataviewInput.Test.toString());
    params.set('Run', dataviewInput.Run.toString());
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.post(dataviewInput,this.ExportWCResultSummary);
  }
}