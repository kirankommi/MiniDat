export class errorModel{
  public Messages: string;
  public Fields: any;
  public Count: number;
  constructor() {
    this.Messages = "";
    this.Fields = {};
    this.Count = 0;
  }
}
