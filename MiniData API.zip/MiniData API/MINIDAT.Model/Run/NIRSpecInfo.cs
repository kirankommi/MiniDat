﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class NIRModel
    {     
        public string Parameter { get; set; }
        public double? Value { get; set; }
        public string ParameterUOM { get; set; }
        public int ParameterId { get; set; }
        public string ValueText { get; set; }
        public string NIRModelID { get; set; }
        // public string DefaultUnit { get; set; }

    }
}
