﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { CatalystModel, CatalystMasterDataModel } from '../../Models/Catalyst/CatalystModel';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystService {
    
    private DeleteCatalystUrl = "/Catalyst/DeleteCatalyst/";
    private GetCatalystDetailsUrl = "/Catalyst/GetCatalystDetails/";
    private saveCatalystDetailsUrl = "/Catalyst/SaveCatalyst/"
    private searchCatalystDetailsUrl = "/Catalyst/SearchCatalystDetails/"
    private GetCatalystSampleIdsUrl = "/Catalyst/GetCatalystSampleIds/";
    private GetLimsSampleIdsByUserSampleUrl = "/Catalyst/GetLimsSampleIdsByUserSample/";
    private getUserSession = "/App/Get";
  private GetCatalystLiteUrl = "/Catalyst/GetCatalystLite";

    
    constructor(private httpaction: HttpActionService) { }

   
    DeleteCatalyst(catalystId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('catalystId', catalystId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.DeleteCatalystUrl, options);
    }


    GetCatalystDetails() {
        let params: URLSearchParams = new URLSearchParams();       
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetCatalystDetailsUrl,options);
    }

    SaveCatalystDetails(catalystModel: CatalystModel) {
        return this.httpaction.post(catalystModel, this.saveCatalystDetailsUrl);
  }

  GetCatalystLite() {
    return this.httpaction.get(this.GetCatalystLiteUrl, Constants.options);
    }

    SearchCatalystDetails(catalystModel: CatalystModel) {
        return this.httpaction.post(catalystModel, this.searchCatalystDetailsUrl);
    }
    GetCatalystSampleIds(catalystId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('catalystId', catalystId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetCatalystSampleIdsUrl, options);
    }
    GetLimsSampleIdsByUserSample(UOPNumber: string, catalystId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('UOPNumber', UOPNumber);
        params.set('catalystId', catalystId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetLimsSampleIdsByUserSampleUrl, options);
    }

    getSessionData() {
        
        //return this.httpaction.getFeed(this.getUserSession, Constants.options)
        //        .map((res: Response) => {
        //            debugger;
        //            let json = res.json();
        //            //TBD
        //            Constants.SetSession(json);
        //            return json;
        //        });                        
    }

    gettest()
    {
        
        //return this.httpaction.postFeed(JSON.stringify([5574]), "/Feed/ExposeFeedAndAnalyticalData")
        //    .map((res: Response) => {
        //        debugger;
        //        let json = res.json();
        //        //TBD
        //        Constants.SetSession(json);
        //        return json;
        //    });
    }
}
