﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class VersionController : ApiController
    {
        [HttpGet, ActionName("GetVersion")]
        public string GetVersion()
        {
            try { 
            string version = string.Empty;
            string description = string.Empty;
            description = GetAssemblyDescription(Assembly.GetAssembly(typeof(VersionController)));
            version = Assembly.GetAssembly(typeof(VersionController)).GetName().Version.ToString();
            return version + " " + description;
            }
            catch (Exception ex)
            {                
                throw;
            }
        }
        private string GetAssemblyDescription(Assembly assembly)
        {
            return assembly.GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false)
                .OfType<AssemblyDescriptionAttribute>().SingleOrDefault()?.Description;
        }
    }
}
