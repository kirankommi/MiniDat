﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           ICustomerLocation.cs
Project Title:      FeedStockDAT
Created on:         5-June-2017
Requirements Tag:   Interface for Managing Customer Location
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */





using MINIDAT.Model.Manage.CustomerLocation;
using MINIDAT.Models.Interfaces;

namespace MINIDAT.DataAccess.Interfaces
{
   public interface ICustomerLocationRepository : ICRUDRepository<CustomerLocationModel>
    {
        bool SaveCustomerData(CustomerLocationModel Customer, string userId);

        CustomerLocationSearchModel GetCustomerData(CustomerLocationModel Customer);
        CustomerLocationMasterModel GetMasterData();

        void CreateNewCustomer(CustomerLocationModel customer,string currentUser);

    }
}
