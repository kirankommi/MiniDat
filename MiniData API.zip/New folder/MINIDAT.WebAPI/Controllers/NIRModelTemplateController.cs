﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model.Manage;
using MINIDAT.Model;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace MINIDAT.WebAPI.Controllers
{
    public class NIRModelTemplateController : AppController
    {
        INIRModelTemplateRepository _nirModelTemplateRepository;
        public NIRModelTemplateController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage NIR Model Template" }));
            _nirModelTemplateRepository = new NIRModelTemplateRepository(new MINIDATDatabase());
        }
        /// <summary>
        /// search the roles
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>
        [HttpGet, ActionName("GetNIRModelTemplatedata")]
        public HttpResponseMessage GetData()
        {
            NIRModelTemplateRepository _nirModelRepository = new NIRModelTemplateRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _nirModelTemplateRepository.GetNIRModelTemplateData());

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }
        [HttpPost, ActionName("SearchNIRModelTemplatedata")]
        public HttpResponseMessage SearchData(NIRModelTemplateModel NIRModelTemplate)
        {
            NIRModelTemplateRepository _nirModelRepository = new NIRModelTemplateRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _nirModelTemplateRepository.SearchNIRTemplateData(NIRModelTemplate));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }

        [HttpPost, ActionName("SaveNIRModelTemplateData")]
        public HttpResponseMessage SaveNIRModelTemplateModel([FromBody] NIRModelTemplateModel nirModelTemplate)
        {
            if (nirModelTemplate != null)
            {
                try
                {
                    INIRModelTemplateRepository NIRTemplateRepository = new NIRModelTemplateRepository(new MINIDATDatabase());
                    NIRTemplateRepository.SaveNIRModelTemplate(nirModelTemplate, User.Identity.Name);
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        [HttpPost, ActionName("DeleteNIRModelTemplatedata")]
        public HttpResponseMessage DeleteNIRModelTemplate([FromBody] NIRModelTemplateModel nirModelTemplate)
        {
            if (nirModelTemplate != null)
            {
                try
                {
                    INIRModelTemplateRepository NIRTemplateRepository = new NIRModelTemplateRepository(new MINIDATDatabase());
                    NIRTemplateRepository.DeleteNIRModelTemplate(nirModelTemplate);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
    }
}