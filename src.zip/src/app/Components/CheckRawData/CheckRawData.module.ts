import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogSheetTimeComponent } from './log-sheet-time/log-sheet-time.component';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { CheckRawDataComponent } from './check-raw-data/check-raw-data.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {DialogModule} from 'primeng/dialog';
import { ProductPhysicalPropertiesComponent } from './product-physical-properties/product-physical-properties.component';

const route: Routes = [
  {
    path: 'LogSheetTime',
    component: LogSheetTimeComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'CheckRawData/:plant/:run/:test',
    component: CheckRawDataComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  ];


@NgModule({
    imports: [
        sharedModule,
        NgbModule.forRoot(),
        DialogModule,
        RouterModule.forChild(route)
  ],
  declarations: [
    LogSheetTimeComponent,
    CheckRawDataComponent,
    ProductPhysicalPropertiesComponent
  ]
})
export class checkRawDataModule {
  
}
