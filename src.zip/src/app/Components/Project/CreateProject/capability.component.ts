import { Component, OnInit, Input, Output, ViewChild} from '@angular/core';
import { ProjectModel, CapabilityProjectModel, ProjectMasterDataModel, AccoladeProjectModel, FileImport } from '../../../Models/Project/ProjectModel';
import { ProjectService } from '../../../Services/ProjectServices/project.service';
import { KeyValue } from '../../../Models/KeyValue';
import * as  Constants from '../../../Shared/globalconstants';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { AlertMessage } from '../../../services/alertmessage.service';
import { UploadService } from '../../../services/upload.service';
import { bulkUploadComponent } from '../../../Directives/bulkupload/bulkupload.component';
import { uploadHandler } from '../../../Directives/bulkupload/bulkupload.component';
import { Observable } from "rxjs";
import { appService } from '../../../Services/app.service';
@Component({
    templateUrl: 'capability.component.html',
    selector: 'capability',
    //moduleId: module.id,
    providers: [AlertMessage, UploadService],
    styles: [`
                .condition-type{margin-top:15px;}
                .search-across{background: #ececec;height: 40px;padding: 10px 0;border-bottom: solid 1px #ececec;}
                .condition-warn{color: #ce7b00;font-size: 13px;}
            `]
})
export class Capability implements OnInit {
       
    selectedRow: CapabilityProjectModel;
    public capProject: CapabilityProjectModel;
    public capProjects: CapabilityProjectModel[];
    public capMasterData: ProjectMasterDataModel;
    public projectMode: boolean = true;
    public conditionType: string = "Manual";   
    public myDatepicker: any;
    public bsConfig: any;
    public accoladeProjectModel: AccoladeProjectModel[];
    flyoutHeader: string = "Accolade Projects";
    flyoutTeamLeadHeader: string = "Technical Team Lead";
    pHolder: string = "Accolade Project Name";
    pHolderTeamLead: string = "Technical Team Lead";
    addIconPath = Constants.addIcon;
    uploadIconPath = Constants.uploadIcon;
    downloadIconPath = Constants.downloadIcon;
    detailsIconPathEn = Constants.detailsIconEn;
    detailsIconPathDis = Constants.detailsIconDis;
    deleteIconPathEn = Constants.deleteIconEn;
    deleteIconPathDis = Constants.deleteIconDis;
    ProjectListColumns: KeyValue[];
    npdSaved: string = "Capability/Exploratory Project Details Saved Successfully.";
    npdDeleted: string = "Capability/Exploratory Project Deleted Successfully.";
    npdUploadNoProject: string = "Please Select A Project To Attach File.";
    fileDeletedMsg: string = "File Deleted Successfully";
    fileSizeMsg: string = "File Size limit Exceeded";
    fileTypeMsg: string = "Selected File type is not Allowed";
    fileNameError: string = "File name cannot exceed 100 characters !";
    canEdit: boolean = false;
    check: boolean = false;
    fileImport: FileImport;
    count: number = 0;

    @ViewChild("uploadCtrl")
    uploadCtrl: bulkUploadComponent;
    phandler: uploadHandler;

    constructor(private projectService: ProjectService, private alertMessage: AlertMessage, private messageService: messageModalUtility, private uploadService: UploadService, public appservice: appService) {
        this.bsConfig = "{ containerClass: 'theme-dark-blue' }";
        this.phandler = new uploadHandler();
        this.phandler.downloadFile = this.onDownload.bind(this);
    }

    private reset() {
        this.conditionType = "Manual";
        this.projectMode = true;
        this.capProject = new CapabilityProjectModel();
        this.capProject.ProjectName = "";
        this.capProject.ProjectId = null;
        this.capProject.AccoladeProjectCd = null;
        this.capProject.CurrentPhasePriorityCd = "0";
        this.capProject.TechnicalTeamLead = "";
        this.capProject.NetworkNumber1 = "";
        this.capProject.NetworkNumber2 = "";
        this.capProject.NetworkNumber3 = "";
        this.capProject.StatusCd = "0";
        this.capProject.PPPriorityCd = "0";
        this.capProject.UOPSegmentId = 0;
        this.capProject.CASPerc = "-1";
        this.capProject.PTEPerc = "-1";        
        this.count = 0;
        this.fileImport = new FileImport();
        this.capProject.ProjectFiles = [];
        //this.addFile();
        this.searchCapProject();

    }
    resetRowId() {

        if (this.capProject.ProjectFiles != null && this.capProject.ProjectFiles.length > 0) {
            var maxRowId = 0;
            for (var i = 0; i < this.capProject.ProjectFiles.length; i++) {
                maxRowId = i + 1;
                this.capProject.ProjectFiles[i].RowId = maxRowId;
            }
            this.count = maxRowId;
        }
    }
    //addFile() {
    //    this.count++;
    //    this.capProject.ProjectFiles.push({ RowId: this.count, FileId: 0, ProjectId: this.capProject.ProjectId, FileName: "", FileSize: 0, Description: "", FileData: {}, ProgressId: ("bar" + 1), isUploadStarted: false, isUploadCompleted: false });
    //}
    ngOnInit() {

        this.reset();
        this.capMasterData = new ProjectMasterDataModel();
        this.capMasterData.CurrentPhaseNames = [];
        this.capMasterData.CurrentPhasePriorities = [];
        this.capMasterData.CASs = [];
        this.capMasterData.PTEs = [];
        this.fillFlyoutColumns();
        this.getAccoladeProjectlist();
        this.getMasterProjectlist();
        this.appservice.getSessionData().subscribe(q => {
            this.capProject.TechnicalTeamLead = q.User.DisplayName;
        }); 
    }
    //TODO
    ngDoCheck() {

        if (!this.check) {
            if (Constants.UserSessionData != Constants.Undefined) {
                if (Constants.UserPrivileges.length > 1) {
                    for (let i in Constants.UserPrivileges) {
                        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000011" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                            this.canEdit = true;
                            this.check = true;
                        }
                    }

                }
            }
        }
    }
    getMasterProjectlist() {

        this.projectService.GetProjectDetails("CAPEX")
            .subscribe(
            (data: any) => {

                this.capMasterData = data;
            });
    }
    getAccoladeProjectlist() {
        this.projectService.GetAccoladeProjects("CAPEX")
            .subscribe(
            (data: any) => {
                this.accoladeProjectModel = data;
            });

    }
    handleProjectModeChange(e) {

        this.projectMode = e.checked;
        if (e.checked) {
            this.conditionType = "Manual";
        }
        else {
            this.conditionType = "Accolade";
        }
    }
    fillFlyoutColumns() {
        this.ProjectListColumns = []

        this.ProjectListColumns.push({ Key: "ProjectName", Value: "Project Name" });
        this.ProjectListColumns.push({ Key: "ProjectDesc", Value: "Project Description" });
        this.ProjectListColumns.push({ Key: "AccoladeProjectCd", Value: "Accolade Project Code" });

    }

    updateLDAPSelection(event, condition) {

        if (event.CellChange) {
            this.capProject.TechnicalTeamLead = event.Value;
        }
        else {
            this.capProject.TechnicalTeamLead = event.DisplayName;
        }
    }
    updateProjectSelection(event, condition) {

        if (this.capProject.ProjectId > 0 && (this.capProject.DwProjectId == null || this.capProject.DwProjectId == 0)) {
            this.messageService.show(Constants.Confirm, "Do you want to switch from manual to Accolade?", Constants.Confirm).then(result => {
                result = result == Constants.ConfirmTrue; //casting string to boolean
                if (result) { this.updateProject(event, condition); }
                else {
                    this.projectMode = true;
                    this.conditionType = "Manual";
                }
            });
        }
        else {
            this.updateProject(event, condition);
        }


    }
    updateProject(event, condition) {
        this.capProject.DwProjectId = event.DW_ProjectId;
        this.capProject.AccoladeProjectCd = event.AccoladeProjectCd;
        this.capProject.ProjectName = event.ProjectName;
        this.capProject.Description = event.ProjectDesc;        
        this.capProject.CurrentPhasePriorityCd = event.CurrentPhasePriorityCd

        this.capProject.NetworkNumber1 = event.UOPNetworkNumber1
        this.capProject.NetworkNumber2 = event.UOPNetworkNumber2
        this.capProject.NetworkNumber3 = event.UOPNetworkNumber3
        this.capProject.TechnicalTeamLead = event.TechLead
        this.capProject.ProjectTypeId = event.ProjectTypeId
        this.capProject.UOPSegmentId = event.UOPSegmentId
        this.capProject.PTEPerc = event.PTE
        this.capProject.CASPerc = event.CAS        
    }
    validateCapProject() {
        if (this.conditionType == "Manual") {
            return this.validateManualProject();
        }
        else {
            return this.validateAccoladeProject();
        }
    }
    validateAccoladeProject() {
        if (this.capProject) {
            var message = "";
            if (!this.capProject.ProjectName) {
                if (message) message = message + " \n";
                message = message + "Project Name is required.";
            }
            if (this.capProject.PPPriorityCd == "0") {
                if (message) message = message + " \n";
                message = message + "PP Priority is required.";
            }
            if (this.capProject.StatusCd == "0") {
                if (message) message = message + " \n";
                message = message + "Status is required.";
            }
            if (message) {
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: message })
                return false;
            }
            else {
                return true;
            }
        }
        else {

            return false;
        }
    }
    validateManualProject() {
        if (this.capProject) {
            var message = "";
            if (!this.capProject.ProjectName) {
                if (message) message = message + "\n";
                message = message + "Project Name is required.";
            }
            if (this.capProject.CurrentPhasePriorityCd == "0") {
                if (message) message = message + "\n";
                message = message + "Current Phase Priority is required.";
            }
            if (!this.capProject.TechnicalTeamLead) {
                if (message) message = message + "\n";
                message = message + "Technical TeamLead Name is required.";
            }
            if (!this.capProject.NetworkNumber1 && !this.capProject.NetworkNumber2 && !this.capProject.NetworkNumber3) {
                if (message) message = message + "\n";
                message = message + "Either Network #1 or Network #2 and Network #3 are required.";

            }
            else if (this.capProject.NetworkNumber1) { }
            else if (!this.capProject.NetworkNumber2 || !this.capProject.NetworkNumber3) {
                if (message) message = message + "\n";
                message = message + "Both Network #2 and Network #3 are required.";
            }
            if (this.capProject.UOPSegmentId == 0) {
                if (message) message = message + "\n";
                message = message + "UOP SEG is required.";
            }
           
            if (this.capProject.PPPriorityCd == "0") {
                if (message) message = message + "\n";
                message = message + "PP Priority is required.";
            }

            if (this.capProject.CASPerc == "-1" || this.capProject.PTEPerc == "-1") {
                if (message) message = message + "\n";
                message = message + "SBU is required.";
            }
            if (!this.capProject.Description) {
                if (message) message = message + "\n";
                message = message + "Project Description is required.";
            }
            if (this.capProject.StatusCd == "0") {
                if (message) message = message + "\n";
                message = message + "Status is required.";
            }
            if (message) {
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: message })
                return false;
            }
            else {
                return true;
            }
        } else {

            return false;
        }
    }
    saveCapProject() {

        if (this.validateCapProject()) {
            this.projectService.saveCapProjectDetails(this.capProject)
                .subscribe(
                (data: any) => {
                    let files = this.uploadCtrl.getSaveData();
                    let metaData: KeyValue[] = [];
                    metaData.push({ Key: "ProjectID", Value: data });
                    metaData.push({ Key: "DeleteIds", Value: files.deleteIds });
                    this.projectService.uploadFiles(files.files, metaData).subscribe((uploadSuccess: any) => {
                        
                        if (uploadSuccess == "Uploaded") {
                            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Save Project', detail: this.npdSaved });
                            //this.alertMessage.displaySuccessMessage("DOESave");

                        } else {
                            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'UploadFailed', detail: uploadSuccess });
                        }
                    });

                    if (this.conditionType == "Accolade") {
                        this.getAccoladeProjectlist();
                    }
                    this.reset();
                    
                });
        }
    }

    find() {
        this.searchCapProject();
    }
    searchCapProject() {
        this.projectService.searchCapProjectDetails(this.capProject).subscribe((data: any) => {
            this.capProjects = data;
        });
    }
    onRowSelect(event) {

        if (this.selectedRow) {
            this.capProject = this.selectedRow;
            //load attached files 
            this.capProject.ProjectFiles = [];
            this.count = 0;
            if (this.capProject && this.capProject.ProjectId > 0) {
                this.uploadService.GetProjectAllDocuments(this.capProject.ProjectId)
                    .subscribe(
                    (data: any) => {

                        if (data && data.length > 0) {
                            for (var i = 0; i < data.length; i++) {
                                this.capProject.ProjectFiles.push({ UID: data[i].UID,RowId: data[i].RowId, FileId: data[i].FileId, ProjectId: this.capProject.ProjectId, FileName: data[i].FileName, FileSize: 0, Description: data[i].Description, FileData: data[i].FileData, ProgressId: ("bar" + 1), isUploadStarted: true, isUploadCompleted: true });
                                this.count = data[i].RowId;
                            }
                        }
                        else {
                           // this.AddFile();
                        }

                    });
            }

            if (this.capProject.AccoladeProjectCd) {
                this.projectMode = false;
                this.conditionType = "Accolade";
            }
            else {
                this.projectMode = true;
                this.conditionType = "Manual";
            }
        }
    }

    onDelete(project: CapabilityProjectModel) {

        if (project && project.ProjectId > 0) {
            this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
                result = result == Constants.ConfirmTrue; //casting string to boolean
                if (result) { this.deleteProject(project); }
            });
        }

    }


    deleteProject(project: CapabilityProjectModel) {

        this.projectService.DeleteProject(project.ProjectId.toString())
            .subscribe(
            (data: any) => {
                if (this.conditionType == "Accolade") {
                    this.getAccoladeProjectlist();
                }
                this.reset();

                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Delete Project', detail: this.npdDeleted });
            });

    }
    onSBUChange(event, condition) {

        if (this.conditionType == "Manual" && condition == "PTE") {
            if (event == "0") {
                this.capProject.CASPerc = "100";
            }
            if (event == "25") {
                this.capProject.CASPerc = "75";
            }
            if (event == "50") {
                this.capProject.CASPerc = "50";
            }
            if (event == "75") {
                this.capProject.CASPerc = "25";
            }
            if (event == "100") {
                this.capProject.CASPerc = "0";
            }
        }

        if (this.conditionType == "Manual" && condition == "CAS") {

            if (event == "0") {
                this.capProject.PTEPerc = "100";
            }
            if (event == "25") {
                this.capProject.PTEPerc = "75";
            }
            if (event == "50") {
                this.capProject.PTEPerc = "50";
            }
            if (event == "75") {
                this.capProject.PTEPerc = "25";
            }
            if (event == "100") {
                this.capProject.PTEPerc = "0";
            }
        }
    }


    onUpload(event: any, id: any) {

        let file = this.capProject.ProjectFiles.filter((i: FileImport) => i.RowId == id)[0];
        var files = event.srcElement.files;
        if (files.length > 0 && file != undefined && file != null && this.capProject.ProjectId) {
            if (this.ValidateFile(event.srcElement.files[0].name, event.srcElement.files[0].size)) {
                setTimeout(() => {
                    file.ProjectId = this.capProject.ProjectId;
                    file.FileSize = event.srcElement.files[0].size;
                    file.FileName = event.srcElement.files[0].name;
                    file.isUploadStarted = true;
                    let postData = { ProjectId: this.capProject.ProjectId, Description: file.Description };
                    this.uploadService.UploadFile(postData, files, file.ProgressId)
                        .subscribe((data: any) => {
                            if (data != undefined && data != null) {
                                file.FileId = data;
                                file.isUploadCompleted = true;
                            }
                            else {
                                file.FileName = "";
                                file.isUploadStarted = false;
                            }
                        },
                        (err: any) => {
                            file.isUploadStarted = false;
                        });
                }, 200);

            }
        }
        else {

            if (this.capProject.ProjectId == 0 || this.capProject.ProjectId == null) {
                //show error message to select the file
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Attach File', detail: this.npdUploadNoProject });
            }
        }
    }

    ValidateFile(fileName: string, fileSize: number) {
        let isValidType = false;
        let isValidSize = false;
        if (fileName != undefined && fileName != null && fileName.trim() != '') {
            //var type = fileName.split('.')[fileName.split('.').length - 1];
            var type = fileName.split('.')[fileName.split('.').length - 1].toLowerCase();
            if (type == "jpg" || type == "jpeg" || type == "png" || type == "doc" || type == "docx" || type == "xls" || type == "xlsx" || type == "pdf" || type == "ppt" || type == "pptx") {
                isValidType = true;
            }
            else {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.fileTypeMsg })
            }
            if (fileName.length > 100) {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.fileNameError })
                return false;
            }
            if (fileSize / 1048576 <= 6) {
                isValidSize = true;
            }
            else {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.fileSizeMsg })
            }
        }
        return isValidType && isValidSize;
    }

    onDeleteFile(event: any, fileId: any, feedId: any, rowId: any) {

        let file = this.capProject.ProjectFiles.filter((i: FileImport) => i.FileId == fileId)[0];
        if (file != undefined && file != null) {
            if (file.FileId > 0) {
                this.messageService.show("Delete File", Constants.ConfirmMsg, Constants.Confirm).then((result) => {
                    result = result == Constants.ConfirmTrue; //casting string to boolean
                    if (result) { this.DeleteFile(file); }

                });
            }
            else {
                this.capProject.ProjectFiles = this.capProject.ProjectFiles.filter((i: any) => i.RowId != rowId);
                this.resetRowId();
            }
        }
        if (this.capProject.ProjectFiles.length <= 0) {
            this.count = 0;
            //this.AddFile();
        }
    }

    DeleteFile(file: FileImport) {
        let isFileDeleted = false;
        this.uploadService.DeleteFile(file)
            .subscribe((data: any) => {
                if (data != undefined && data != null) {
                    if (data == 1) {
                        isFileDeleted = true;
                        if (this.capProject.ProjectFiles != null) {
                            this.capProject.ProjectFiles = this.capProject.ProjectFiles.filter((i: any) => i.FileId != file.FileId);
                            this.resetRowId();
                        }
                        if (this.capProject.ProjectFiles.length <= 0) {
                           // this.AddFile();
                        }
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.fileDeletedMsg });
                    }
                }
                if (!isFileDeleted) {
                    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "File has Not Deleted" })
                }
            },
            (err: any) => {

            });
    }

    onDownload(fileId: number): Observable<any> {    
        if (this.capProject.ProjectId > 0) {
            return this.uploadService.DownloadFile(fileId, this.capProject.ProjectId);
        }
    }

    //onDownload(event: any, feedId: any, fileId: any) {

    //    this.uploadService.DownloadFile(fileId, feedId)
    //        .subscribe((data: any) => {
    //            if (data != undefined && data != null) {
    //                this.DownloadFile(data.FileData, data.FileName, data.ContentType);
    //            }
    //        },
    //        (err: any) => {
    //            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
    //        });
    //}


    DownloadFile(fileData: any, fileName: string, contentType: any) {
        var byteCharacters = atob(fileData);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: "" });
        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");
        var chrome = ua.indexOf("Chrome");

        if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
            window.navigator.msSaveOrOpenBlob(blob, fileName);
        }
        else {
            var objectUrl = URL.createObjectURL(blob);
            //console.log("objectUrl  :   " + objectUrl);
            var link = document.createElement("A");
            link.setAttribute("href", objectUrl);
            //link.setAttribute("download", fileName + "." + contentType);
            link.setAttribute("download", fileName);
            link.setAttribute("target", "_blank");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    //AddFile() {
    //    this.count++;
    //    this.capProject.ProjectFiles.push({ RowId: this.count, FileId: 0, ProjectId: this.capProject.ProjectId, FileName: "", FileSize: 0, Description: "", FileData: {}, ProgressId: ("bar" + this.count), isUploadStarted: false, isUploadCompleted: false });
    //}
   
}


