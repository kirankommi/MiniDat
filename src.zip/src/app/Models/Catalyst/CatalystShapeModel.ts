﻿export class CatalystShapeModel {
    CatalystShapeID: number;
    CatalystShape: string;  
    StatusName: string;
    AssumedVoidFraction: number; 
    CrushedVoidFraction: number; 
    StatusCode: KeyValue;  
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
