import { Component, OnInit, ViewChild, ElementRef, Renderer } from '@angular/core';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { AnalysisMethodModel, KeyValue, SourceName } from '../../../models/AnalysisMethodModel';
import { AnalysisMethodService } from '../../../services/analysiaMethod';
import { HttpActionService } from '../../../services/httpaction.service';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    templateUrl: 'AnalysisMethod.component.html',
    providers: [AnalysisMethodService, AlertMessage, HttpActionService, ConfirmationService]
})

export class AnalysisMethodComponent implements OnInit {
    title: string;
    MethodList: any;
    totalRecords: number;
    MethodData: AnalysisMethodModel;
    UOMGroup: KeyValue[];
    sourceNameList: SourceName[];
    sortField: string;
    sortOrder: number;
    sourceList: any[];
    IsallowedSave: boolean=false;
    setStyles: boolean;
    isCollapsed = false;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    roleSaved: string = "Analysis Method Details Saved Successfully";
    roleDeleted: string = "Analysis Method Details Deleted Successfully";

    @ViewChild('roleTable') dataTableComponent: any;

    ngOnInit() {
        debugger;
        this.MethodData = new AnalysisMethodModel();
        this.getMethods();
        this.MethodData.UOMGroupName = Constants.Select;
        this.title = Constants.ManageAnalysisMethod;
        this.sourceList = [];
    }
    constructor(private analysimethodService: AnalysisMethodService, public el: ElementRef, public renderer: Renderer,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divRole > p-datatable > div > div.ui-datatable-scrollable-body');
            let parentDiv = this.el.nativeElement.querySelector('#roleGrid');
            if (datatable != null && datatable != Constants.Undefined && parentDiv != null && parentDiv != Constants.Undefined && parentDiv.offsetHeight > 0) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';   // (parentDiv.offsetHeight * 80 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse() {
        let parentDiv = this.el.nativeElement.querySelector('#roleGrid');
        let datatable = this.el.nativeElement.querySelector('#divRole > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';   // (parentDiv.offsetHeight * 80 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any) {
        this.sourceList = [];
        this.MethodData.CheckedSources = [];
        this.sourceNameList.forEach((x: any) => { x.IsUsed = false });
        this.MethodData.MethodName = event.data.MethodName;
        this.MethodData.MethodNumber = event.data.MethodNumber;
        this.MethodData.MethodDescription = event.data.MethodDescription;
        this.MethodData.LIMSOperation = event.data.LIMSOperation;
        this.MethodData.Id = event.data.Id;
        this.MethodData.UOMGroupName = event.data.UOMGroup.Key != "" ? event.data.UOMGroup.Key : Constants.Select;
        for (var j = 0; j < event.data.Sources.length; j++) {
            let res = this.sourceNameList.filter((x: any) => x.Id == event.data.Sources[j].Id)[0];
            if (res != null) {
                res.IsUsed = true;
                this.MethodData.CheckedSources.push({ Name: res.Name, Id: res.Id, IsUsed: res.IsUsed })
            }
        }
        this.sourceList = this.MethodData.CheckedSources;
    }

    onRowUnselect($event: any) {

    }

    getMethods(isFind?:boolean) {

        this.MethodData.CheckedSources = this.sourceList;
        this.MethodData.UOMSearch = this.MethodData.UOMGroupName;
        this.analysimethodService.getMethods(this.MethodData)
            .subscribe(
            (data: any) => {
                this.MethodList = data.AnalysisMethod;
                if(!isFind){
                    this.sourceNameList = data.Sources;
                }
                this.UOMGroup = data.UOM;
                this.totalRecords = data.RecordsFetched;
            },
            err =>{}
            //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    saveMethod() { 
        let response: any;
        if (this.isDataValid()) {
            this.MethodData.UOMGroup = this.UOMGroup.filter(x => x.Key == this.MethodData.UOMGroupName)[0];
            // this.MethodData.CheckedSources = this.sourceList;
            this.analysimethodService.saveMethodData(this.MethodData)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.roleSaved });
                    }
                },
                (err: any) => { }
                //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    updateSelection(src: any) {
        var idx = -1;
        if (this.sourceList.length > 0) {
            for (var i = 0; i < this.sourceList.length; i++) {
                if (this.sourceList[i].Id == src.Id) {
                    idx = i;
                }

            }
            // is currently selected
            if (idx > -1) {
                this.sourceList.splice(idx, 1);
            }

            // is newly selected
            else {
                this.sourceList.push(src);
            }
        }
        else {
            this.sourceList.push(src);
        }

        this.MethodData.CheckedSources = this.sourceList;
    }

    onDelete(methodData: AnalysisMethodModel) {
        this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteRole(methodData); }
        });
    }

    deleteRole(methodData: AnalysisMethodModel)
    {
        debugger;
        this.analysimethodService.deleteMethodData(methodData)
            .subscribe(
            (data: any) =>
            {
                debugger;
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.roleDeleted });
                }
                else
                {
                    debugger;
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            (err: any)=>{}
            //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onReset() {
        this.MethodData = new AnalysisMethodModel();
        this.sourceList = [];
        this.MethodData.UOMGroupName = Constants.Select;
        // this.dataTableComponent.reset();
        this.getMethods();

    }

    isDataValid()
    {
        debugger;
        if (this.MethodData == null || !this.MethodData.MethodName || !this.MethodData.MethodNumber || !this.MethodData.LIMSOperation || this.MethodData.CheckedSources.length<=0 || this.MethodData.UOMGroupName == "Select") {
            return false;
        }
        return true;
    }

    getDelPath(roleCode: string) {
        return this.deleteIconPath;
    }

    ngDoCheck() {
        if (Constants.UserSessionData != Constants.Undefined) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    if (Constants.UserPrivileges[i].Action.toUpperCase() == "MANAGE/LIMSANALYSISMETHOD" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                        this.IsallowedSave = true;
                    }
                }
            }
        }
    }
}
