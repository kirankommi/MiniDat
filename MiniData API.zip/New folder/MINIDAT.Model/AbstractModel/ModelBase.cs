﻿using MINIDAT.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MINIDAT.Model
{
    public abstract class ModelBase : IModel
    {
        private IValidationLogic<ModelBase> validation = null;
        protected ModelBase(IValidationLogic<ModelBase> obj)
        {
            validation = obj;
        }
        protected ModelBase()
        { }
        public ValidationResult ValidationResult { get; set; }
        public virtual ValidationResult Validate(IValidationLogic<ModelBase> obj)
        {
            validation = obj;
            if (validation != null)
            {
                validation.Validate(this);
                if (!ValidationResult.IsValid) throw new ArgumentException(ValidationResult.Message.ToString());
            }
            return ValidationResult;
        }

        public void CreateModelFromReader(IDataRecord _record)
        {
            throw new NotImplementedException();
        }

        public ValidationResult Validate()
        {
            throw new NotImplementedException();
        }
    }
}
