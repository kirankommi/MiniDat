import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { RunComponent } from './run.component';
import { RunFeedComponent } from './Run-Feed/RunFeed.component';
import { GeneralInfoComponent } from './GeneralInfo/GeneralInfo.component';
import { NIRSpecsComponent } from './NIRSpecs/NIRSpecs.component';
import { ProcessSpecsComponent } from './ProcessSpecs/ProcessSpecs.component';
import { AnalyticalSamplingComponent } from './AnalyticalSamplingSchedule/AnalyticalSamplingSchedule.component';
import { RunDataService } from "./run.data.service";
import { RunCatalystComponent } from './Run-Catalyst/RunCatalyst.component';
import { TCCalibrationComponent } from './TCCalibration/TCCalibration.component';
import { TMFCalibrationComponent } from './TMFCalibration/TMFCalibration.component';
import { AdditionalInfoComponent } from './AdditionalInfo/AdditionalInfo.component';
import { RunSummaryComponent } from './RunSummary/RunSummary.component';
import { RunBoilingPointComponent } from './Run-BoilingPoint/RunBoilingPoints.component';
import { RunRecipeComponent } from './run-recipe/run-recipe.component';

const route: Routes = [
    {
        path: 'RunSetup',
        component: RunComponent,
        resolve: {
            UOM: routeResolver
        }
    },
    {
      path: 'RunSetup/:run/:plant/:runNum',
      component: RunComponent,
      resolve: {
        UOM: routeResolver
      }
    },
];


@NgModule({
  imports: [sharedModule, RouterModule.forChild(route)],
  declarations: [RunComponent, RunFeedComponent, GeneralInfoComponent, NIRSpecsComponent, ProcessSpecsComponent, AnalyticalSamplingComponent, RunCatalystComponent,
      TCCalibrationComponent, TMFCalibrationComponent, AdditionalInfoComponent, RunSummaryComponent,
      RunBoilingPointComponent,
      RunRecipeComponent],
  providers: [RunDataService]
})
export class runModule {

}
