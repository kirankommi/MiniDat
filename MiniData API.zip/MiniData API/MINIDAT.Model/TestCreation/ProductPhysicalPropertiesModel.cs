﻿using MINIDAT.Model.UOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
    public class ProductPhysicalPropertiesModel
    {
        public int StreamId { get; set; }
        public int SampleId { get; set; }
        public int PropertyId { get; set; }
        public string PropertyLabel { get; set; }
        public int AnalysisMethodId { get; set; }
        public string AnalysisMethodName { get; set; }
        public string AnalysisMethodNumber { get; set; }

        public string LIMSOperation { get; set; }
        public string LIMSOperationId { get; set; }
        public Unit UOM { get; set; }
        public UnitGroup UOMlist { get; set; }
        public string Precision { get; set; }
        //public string UOMGroupNumber { get; set; }
        public double? BaseValue { get; set; }
        public string TargetValue { get; set; }
        public string Text { get; set; }
        public string ValidationIndicator { get; set; }



    }

    public class ProductPhysicalPropertiesDropdownModel
    {
        public List<Streams> StreamList { get; set; }
        public List<ValidationIndicator> ValidationIndicatorList { get; set; }
    }

    public class ProductPhysicalPropertiesInput
    {
        public string PlantCd { get; set; }
        public int RunId { get; set; }
        public int TestId { get; set; }
        public string UserName { get; set; }
        public string StreamId { get; set; }

        public bool AllVariableChecked { get; set; }
    }

    public class Streams
    {
        public string StreamId { get; set; }

        public string StreamName { get; set; }
        public string SortOrder { get; set; }
    }
    public class ValidationIndicator
    {
        public string ValidationId { get; set; }
        public string ValidationName { get; set; }

    }

    public class ProductPhysicalPropertyItemViewModel
    {
        public string PropertyId { get; set; }
        public string LimsOperationId { get; set; }
        public string PropertyLabel { get; set; }
        public string SampleId { get; set; }
        public string BaseValue { get; set; }
        public string Text { get; set; }
        public string ValidationFlag { get; set; }
    }
    public class SaveProductPhysicalPropertiesInput
    {
        public string PlantCd { get; set; }
        public int RunId { get; set; }
        public int TestId { get; set; }
        public string StreamId { get; set; }
        public List<ProductPhysicalPropertyItemViewModel> ArrayOfProductPhysicalPropertyItemViewModel { get; set; }

    }
    //public class ArrayOfProductPhysicalPropertyItemViewModel
    //{
    //    public List<ProductPhysicalPropertiesModel> ProductPhysicalPropertyItemViewModel { get; set; }
    //}

}