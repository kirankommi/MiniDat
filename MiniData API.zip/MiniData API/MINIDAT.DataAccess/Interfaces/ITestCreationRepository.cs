﻿using Calculations;
using MINIDAT.Model.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Manage;
using System.Data;
using MINIDAT.Model.Session;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ITestCreationRepository
    {
        void SaveCalculationResults(string strPlantCd, int? intRunId, int? intTestId, string strCalcResults, string userId);
        //int SaveTest(TestModel Test, string userId);
        bool InsertLogSheetPeriodReading(string strPlant, int? RunId, int? TestId);
        ContentValues GetWeightCheckInputs(string PlantCd, int? RunId, int? TestId);

        TestSearchModel GetTest();
        List<RunFlyoutModel> GetRunFlyout(string plantcd);
        TestSearchModel GetPlantsFlyout();
        
        TestSearchModel SearchTest(TestModel TestModel);
        void SaveTestData(TestModel _test, string userId);//new
        string DeleteTest(TestModel testmodel);

        string SavePIData(string piData);

        string PerformCalculations(TestModel testModel, UserSession userSession);
        DataSet GetDataSet(string cmdName, string PlantCd, string RunId, string TestId);
    }
}
