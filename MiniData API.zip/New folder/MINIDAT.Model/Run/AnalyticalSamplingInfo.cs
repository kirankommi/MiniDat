﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class AnalyticalInfoModel
    {
        public string StreamName { get; set; }
        public int StreamId { get; set; }
        public int LIMSOPerationId { get; set; }
        public string LIMSOPerationName { get; set; }
        public string MethodNumber { get; set; }
        public string SampleVolumeinCC { get; set; }
        public double? SampleCost { get; set; }
        public string FrequencyName { get; set; }
        public int RowId { get; set; }
        public string DataSetType { get; set; }
    }
}
