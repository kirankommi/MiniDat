﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
    public class CalculateAllModel
    {
        public string Plant { get; set; }
        public int Run { get; set; }
        public string User_Id { get; set; }
        public List<wctable> wclist {get;set;}
    }
    public class wctable
    {
        public int wc_number { get; set; }
        public string status { get; set; }
        public string remarks { get; set; }
    }
}
