﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleRepository.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystFamilyRepository : ICatalystFamilyRepository
    {
        private IDatabase _db;
        public CatalystFamilyRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };


        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystFamilySearchModel GetCatalystFamilyData(CatalystFamilyModel catalystFamily)
        {
            try
            {
                CatalystFamilySearchModel catalystFamilyarr = new CatalystFamilySearchModel();
                if (catalystFamily == null)
                {
                    return catalystFamilyarr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystFamily_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_commercial_Name", string.IsNullOrEmpty(Convert.ToString(catalystFamily.CommercialName)) ? (object)null : catalystFamily.CommercialName);
                    parameters.Add("proc_vr_program_Name", string.IsNullOrEmpty(Convert.ToString(catalystFamily.ProgramName)) ? (object)null : catalystFamily.ProgramName);
                    parameters.Add("proc_in_application", (catalystFamily.ApplicationName == 0?null: catalystFamily.ApplicationName));
                    parameters.Add("proc_in_type",  (catalystFamily.CatalystType == 0 ? null : catalystFamily.CatalystType)); ;
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystFamily.StatusName == "Select" ? null : catalystFamily.StatusName) ? (object)null : catalystFamily.StatusName);                   
                    parameters.Add("proc_nm_Piece_denisty_Max_Msr", catalystFamily.PieceDensityMaxSpec);
                    parameters.Add("proc_nm_Piece_denisty_Min_Msr", catalystFamily.PieceDensityMinSpec);
                    parameters.Add("proc_nm_LOI_Max_Msr", catalystFamily.LOIMaxSpec);
                    parameters.Add("proc_nm_LOI_Min_Msr", catalystFamily.LOIMinSpec);
                    parameters.Add("proc_nm_sulfur_Max_Msr", catalystFamily.SulfurMaxSpec);
                    parameters.Add("proc_nm_sulfur_Min_Msr", catalystFamily.SulfurMinSpec);
                    parameters.Add("proc_vr_SDS_Num", string.IsNullOrEmpty(Convert.ToString(catalystFamily.SDSNumber)) ? (object)null : catalystFamily.SDSNumber);
                    parameters.Add("proc_vr_Family_Indicator", catalystFamily.FamilyIndicator);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);
                    parameters.Add("proc_var_is_init_load", catalystFamily.IsInitialLoad);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystFamilyarr.LstcatalystFamily.Clear();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)catalystFamilyarr.lstCatalystTypes).Add(new KeyValue()
                        {
                            Key = reader["CATALYST_TYPE_ID_SQ"].ToString(),
                            Value = reader["CATALYST_TYPE"].ToString()
                        });
                    }
                    reader.NextResult();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)catalystFamilyarr.lstCatalystApplications).Add(new KeyValue()
                        {
                            Key = reader["CATALYST_APPLICATION_ID_SQ"].ToString(),
                            Value = reader["CATALYST_APPLN_NM"].ToString(),
                            Groupcd = Convert.ToInt32(reader["CATALYST_TYPE_ID"])
                        });
                    }                  

                    reader.NextResult();
                    while (reader.Read())
                    {
                        CatalystFamilyModel _catalystFamily = new CatalystFamilyModel()
                        {
                            CatalystFamilyID = Convert.ToInt32(reader["CATALYST_FAMILY_ID_SQ"]),
                            ProgramName = reader["PROGRAM_FAMILY_NM"].ToString(),
                            CommercialName = reader["COMMERCIAL_FAMILY_NM"].ToString(),                         
                            CatalystApplicaton = new KeyValue() { Key = (reader["CATALYST_APPLICATION_ID"]==DBNull.Value)?"0": reader["CATALYST_APPLICATION_ID"].ToString(), Value = reader["CATALYST_APPLICATION_NM"].ToString(), Groupcd = Convert.ToInt32(reader["CATALYST_TYPE_ID"])},                          
                            CatalystTypecd = new KeyValue() { Key = reader["CATALYST_TYPE_ID"].ToString(), Value = reader["CATALYST_TYPE_NM"].ToString() },                          
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            PieceDensityMinSpec = (reader["PD_AR_MIN_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["PD_AR_MIN_MSR"]),
                            PieceDensityMaxSpec = (reader["PD_AR_MAX_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["PD_AR_MAX_MSR"]),
                            LOIMinSpec = (reader["LOI_MIN_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["LOI_MIN_MSR"]),
                            LOIMaxSpec = (reader["LOI_MAX_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["LOI_MAX_MSR"]),
                            SulfurMinSpec = (reader["SULFUR_MIN_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["SULFUR_MIN_MSR"]),
                            SulfurMaxSpec = (reader["SULFUR_MAX_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["SULFUR_MAX_MSR"]),
                            SDSNumber = reader["SDS_NUM"].ToString(),
                            FamilyIndicator = Convert.ToString(reader["CATALYST_FAMILY_IND"]),
                            FamilyIndicatorcd = new KeyValue() { Key = reader["CATALYST_FAMILY_IND"].ToString(), Value = reader["CATALYST_FAMILY_IND_NM"].ToString() }
                        };
                        catalystFamilyarr.LstcatalystFamily.Add(_catalystFamily);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystFamilyarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystFamilyarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystFamilyarr.lstStatus).AddRange(statuses);
                    return catalystFamilyarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystFamilyData(CatalystFamilyModel catalystFamily)
        {
            try
            {
                if (catalystFamily == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystFamily_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_CatalystFamily_ID", string.IsNullOrEmpty(Convert.ToString(catalystFamily.CatalystFamilyID)) ? (object)null : catalystFamily.CatalystFamilyID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SaveCatalystFamilyData(CatalystFamilyModel _catalystFamily, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystFamily == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystFamily_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_CatalystFamily_Id", _catalystFamily.CatalystFamilyID);
                    parameters.Add("proc_vr_commercial_Name", _catalystFamily.CommercialName);
                    parameters.Add("proc_vr_program_Name", _catalystFamily.ProgramName);
                    parameters.Add("proc_vr_Application_Nm", (_catalystFamily.ApplicationName==0)?null: _catalystFamily.ApplicationName);
                    parameters.Add("proc_vr_family_Type_Id", _catalystFamily.CatalystType);
                    parameters.Add("proc_vr_Status_Nm", _catalystFamily.StatusName);
                    parameters.Add("proc_nm_Piece_denisty_Max_Msr", _catalystFamily.PieceDensityMaxSpec);
                    parameters.Add("proc_nm_Piece_denisty_Min_Msr", _catalystFamily.PieceDensityMinSpec);
                    parameters.Add("proc_nm_LOI_Max_Msr", _catalystFamily.LOIMaxSpec);
                    parameters.Add("proc_nm_LOI_Min_Msr", _catalystFamily.LOIMinSpec);
                    parameters.Add("proc_nm_sulfur_Max_Msr", _catalystFamily.SulfurMaxSpec);
                    parameters.Add("proc_nm_sulfur_Min_Msr", _catalystFamily.SulfurMinSpec);
                    parameters.Add("proc_nm_SDS_Num", _catalystFamily.SDSNumber);
                    parameters.Add("proc_commercial_Ind", _catalystFamily.FamilyIndicator);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystFamilyModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystFamilyModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystFamilyModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystFamilyModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
