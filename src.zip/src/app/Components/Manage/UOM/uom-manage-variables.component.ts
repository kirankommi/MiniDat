﻿import { Component } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UomService } from '../../../services/uom.service';
import { TemplateData, TemplateVariable, Group, VariableCategory, UomTemplate, Module } from '../../../models/uomtemplate';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { HttpActionService } from '../../../services/httpaction.service';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { AppComponent } from '../../../app.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
    //moduleId: module.id,
    templateUrl: 'uom-manage-variables.component.html',
    providers: [
        UomService, messageModalUtility, AlertMessage, HttpActionService
    ],
    styles: ['.modal-dialog.modal-lg { top: 770px; }'] 

})
export class UomManageVariablesComponent {
    templateData: TemplateData;
    title: string = "Manage Variables";
    variablesSaved: string = "UOM Variables Updated Successfully";
    isDataSaved: boolean = false;  
    templateID: number;   
    templateName: string; 
    templateVariables: TemplateVariable[];
   public variableCategoryList: any;
    selectedCategory: string 
    uomdata: any;

    constructor(private route: ActivatedRoute,public activeModal: NgbActiveModal, 
        private uomService: UomService, private router: Router,
        private messageService: messageModalUtility, private alertMessage: AlertMessage) {
        
    }

    public ngOnInit()
    {
        debugger;
        this.templateData = new TemplateData();
        this.templateData.Template = new UomTemplate();
        this.templateData.module = new Module();

        this.readParameters().then((data) =>
        {
            var self = this;
            //this.getUomVariables(this.templateID);
                   
            this.title = this.title + " - " + [this.templateName]
            this.getUOMVariableCategories(this.templateID);    
        });
    }

    readParameters() {
        debugger;
        let promise = new Promise((resolve: any, reject: any) => {
            this.route.params.subscribe((params: any) => {
                debugger;
                this.templateID = +params['TemplateID'];
                this.templateName = params['TemplateName'];

                this.templateData.Template.TemplateID = this.templateID.toString();
                this.templateData.Template.TemplateName = this.templateName;
                this.templateData.Template.ApplicationId = 5;
                //this.templateID = +params['Templateid']; // (+) converts string 'id' to a number            
                resolve();
            });
        });
        return promise;
    }

    getUomVariables(templateId: any) {
        debugger;

        this.uomService.getTemplateVariables(templateId)
            .subscribe(
            (data: any) => {
                this.templateData.Variables = data;               
            },
            err => { }            
            );
    }

    getUOMVariableCategories(templateId: any)
    {
        debugger;
        this.variableCategoryList = [];
        this.selectedCategory = "";
        this.uomService.GetVariableCategories(templateId)
            .subscribe(
            (data: any) => {
                this.variableCategoryList = data;
                debugger;
                //this.selectedCategory = data[1][0];
                this.selectedCategory = Constants.Select;
                this.onVariableCategorychange();
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
        debugger;
    }
    onVariableCategorychange()
    {
        debugger;
        this.uomService.GetVariablesPerModules(this.templateID.toString(), this.selectedCategory)
            .subscribe(
            (data: any) => {
                debugger;
                //this.templateVariables = data;
                this.templateData.Variables = data;               
            },
            err => { }          
            );
    }

    getSHeight() {
        return (window.innerHeight * 60 / 100) - 64 + "px";
    }

    updateVariables()
    {       
        if (this.isDataValid())
        {
            this.templateData.module.ID = this.selectedCategory;
            debugger;
            this.uomService.saveUomVariables(this.templateData)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.variablesSaved });
                        this.activeModal.close('true');
                    }
                },
                err => {
                    this.messageService.show(Constants.Error, err, Constants.Error);
                    this.activeModal.close('true');
                });
        }
        else {
            this.messageService.show(Constants.Warning, Constants.RequiredMsg, Constants.Warning);
            this.activeModal.close('true');
        }
    }

    isDataValid()
    {
        debugger;
        if (this.templateData == null || this.templateData.Variables == null || this.templateData.Variables.length < 1) {
            return false;
        }

        if (this.templateData.Variables.filter((x: any) => x.Precision.trim === "").length > 0) {
            return false;
        }
        return true;
    }

    ngOnDestroy() { 
        if (this.isDataSaved) {
            this.messageService.show(Constants.Success, this.variablesSaved, Constants.Success);
        }
    }
    navigateToManageUOM() {
        this.router.navigateByUrl('Manage/UOM');
    }
}