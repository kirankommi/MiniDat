﻿import { Component, OnInit, OnChanges, ViewChild, Input, ElementRef, Renderer, EventEmitter, Output } from '@angular/core';
import * as  Constants from '../Shared/globalconstants';
import { FlyoutExistsDataModel } from '../Models/FlyoutExistsDataModel';
import { TooltipModule } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    selector: 'flyout',
    templateUrl: 'Flyout.html'
})

export class FlyOutDirective implements OnInit, OnChanges {
    @Input() flyoutdata: any;
    @Input() flyouttempdata: any = [];
    @Input() fTitle: string;
    @Input() colList: string[];
    @Input() eventSource: string;
    @Input() datalist: FlyoutExistsDataModel;
    @Output() flyoutEvent = new EventEmitter();
    columnNames: any[] = [];
    check: boolean;
    eventTypeChkBox: any = [];
    selectedItem: any[];
    Isout: boolean;
    QuerySearch: string = "";
    fromListValues: any = [];

    @ViewChild('flyoutTable') flyoutTable: any;
   

    constructor(public el: ElementRef, renerer: Renderer) {
        this.datalist = new FlyoutExistsDataModel();
        this.datalist.ExistsList = [];
    }

    ngOnInit() {
        // this.getColumnNames();
     
    }
    
    ngOnChanges(changes: any) {
        this.getColumnNames();
    }
    getColumnNames() {
        this.columnNames = [];

        if (this.flyoutdata && this.flyoutdata.length > 0) {
            if (this.datalist && this.datalist.ExistsList.length > 0) {
                for (var j = 0; j < this.flyoutdata.length; j++) {
                    let p = this.datalist.ExistsList.filter((p: any) => (p[this.datalist.MatchColumn] == this.flyoutdata[j][this.datalist.SourceColumn]) && (p[this.datalist.MatchColumn2] == this.flyoutdata[j][this.datalist.SourceColumn2]));
                    this.flyoutdata[j].isExists = (p.length > 0) ? true : false;
                }
            }
            let columns = Object.keys(this.flyoutdata[0]);
            if (this.colList && this.colList.length > 0) {
                this.columnNames = this.colList;
            }
            else if (columns && columns.length > 0) {
                columns.forEach(x => {
                    this.columnNames.push({ Key: x, Value: x });
                });
            }
            else {
                this.columnNames = [];
            }
        }
    }

    toggleMenu() {
        for (let iz of this.eventTypeChkBox) {
            iz.checked = false;
        }
    }

    getSHeight() {
        return (window.innerHeight * 70 / 100) + "px";
    }

    onModelChange(eventTypeChkBoxObj: any) {
        let searchterm: any;
        let checknext: any = true;
        if (this.QuerySearch == "") {
            if (eventTypeChkBoxObj.checked) {
                this.QuerySearch = eventTypeChkBoxObj.val + ':=';
                this.fromListValues.push(eventTypeChkBoxObj.val)
            }
            else {
                for (let item of this.fromListValues) {
                    let index: number = item.indexOf(eventTypeChkBoxObj.val);
                    if (index !== -1) {
                        this.fromListValues.splice(index, 1);
                    }
                }
                //a.replace(pattern, "THE");
                //  this.QuerySearch.replace('/' + eventTypeChkBoxObj.val + ':=' + '/', " ");
            }
            if (this.fromListValues.length > 0) {
                for (let iz of this.fromListValues) {
                    this.QuerySearch = iz + ':=';
                }
            }
        }
        else {
            if (eventTypeChkBoxObj.checked) {
                this.QuerySearch = this.QuerySearch + ';' + eventTypeChkBoxObj.val + ':=';
            }
            else {
                searchterm = this.QuerySearch.split(';');
                for (var i = 0; i < searchterm.length; i++) {
                    if (searchterm[i].includes(eventTypeChkBoxObj.val)) {
                        searchterm.splice(i, 1);
                        this.QuerySearch = "";
                    }
                }
                for (var i = 0; i < searchterm.length; i++) {
                    this.QuerySearch = this.QuerySearch + searchterm[i];
                }
            }
        }
    }

    SearchOp() {   
        debugger;     
        let result: any;
        let resultFilter: any = [];
        let filters: any;
        let searchvalue: any = [];
        let searchfields: any = [];
        let andsatisfy: boolean = false;
        this.flyoutdata = this.flyouttempdata;

        let inputFilterElements = this.el.nativeElement.querySelectorAll(".component-data-filter-container .component-data-filter-field");
        inputFilterElements.forEach((elem) => {
            if (elem.value && elem.value != "") {
                searchvalue.push(elem.value);
                searchfields.push(elem.id);
            }
        });        
        for (var i = 0; i < this.flyoutdata.length; i++) {
            andsatisfy = false;
            for (var j = 0; j < searchfields.length; j++) {                
                if (this.flyoutdata[i][searchfields[j]].toString().toUpperCase().includes(searchvalue[j].toUpperCase())) {
                    andsatisfy = true;
                }
                else {
                    andsatisfy = false;
                    break;
                }
            }
            if (andsatisfy) {
                resultFilter.push(this.flyoutdata[i]);
            }
        }
        this.flyoutdata = resultFilter;

        //if (this.QuerySearch == "") {
        //    for (let iz of this.eventTypeChkBox) {
        //        iz.checked = false;
        //    }
        //}
        //else {
        //    if (this.QuerySearch != null) {
        //        this.flyoutdata = this.flyouttempdata;
        //        result = this.QuerySearch.split(';');
        //        for (var i = 0; i < result.length; i++) {
        //            filters = result[i].split(':=');
        //            searchvalue.push(filters[1]);
        //            searchfields.push(this.columnNames.filter(x => x.Value == filters[0])[0].Key);
        //        }
        //        for (var i = 0; i < this.flyoutdata.length; i++) {
        //            for (var j = 0; j < searchfields.length; j++) {
        //                if (this.flyoutdata[i][searchfields[j]].toString().toUpperCase().includes(searchvalue[j].toUpperCase())) {
        //                    andsatisfy = true;
        //                }
        //                else {
        //                    andsatisfy = false;
        //                    break;
        //                }
        //            }
        //            if (andsatisfy) {
        //                resultFilter.push(this.flyoutdata[i]);
        //            }
        //        }
        //        this.flyoutdata = resultFilter;
        //    }
        //}
    }

    onRowUnselect($event: any) { }

    onRowSelect(event: any) {
        this.QuerySearch = "";
        for (let x of this.eventTypeChkBox) {
            x.checked = false;
        }

        if (event.data != undefined && event.data != null && !event.data.isExists) {
            this.flyoutdata = this.flyouttempdata;
            this.flyoutdata.selectedRow = {};
            this.flyoutdata.selectedRow = event.data;
            this.selectedItem = event.data;
            this.flyoutTable.selection = {};
            this.flyoutEvent.emit(this.selectedItem);
        }
    }

    close() {
        this.reset();
        this.flyoutEvent.emit("Close");
    }

    Refresh() {
        this.reset();
    }

    reset() {
        debugger;
        this.QuerySearch = ""
        this.flyoutTable.selection = {};
        for (let x of this.eventTypeChkBox) {
            x.checked = false;
        }
        //clear all inputs filter values
        let inputFilterElements = this.el.nativeElement.querySelectorAll(".component-data-filter-container .component-data-filter-field");
        inputFilterElements.forEach((elem) => {
            elem.value = '';
        });

        this.flyoutdata = this.flyouttempdata;
    }

    ngDoCheck() {
        if (!this.check) {
            //if (this.eventSource != undefined && this.eventSource != null) {
            //    switch (this.eventSource) {
            //        case 'plant': {
            //            this.flyoutdata = Constants.PlantList;
            //            this.flyouttempdata = Constants.PlantList;
            //            break;
            //        }
            //        case 'inventory': {
            //            this.flyoutdata = Constants.InventoryList;
            //            this.flyouttempdata = Constants.InventoryList;
            //            break;
            //        }
            //        default:
            //            break;
            //    }

            //}
            if (this.flyoutdata != undefined) {
                if (this.flyoutdata.length > 0) {
                    this.getColumnNames();
                    for (var i = 1; i <= this.columnNames.length; i++) {
                        if (this.columnNames[i - 1])
                            this.eventTypeChkBox.push({ id: "item" + i, val: this.columnNames[i - 1].Value, checked: false })
                    }
                    this.check = true;
                }
            }
        }
    }
    customize(rowData, rowIndex): string {
        let style = '';
        if (rowData.isExists) {
            style = 'exist-row';
        }
        return style;
    }
}

