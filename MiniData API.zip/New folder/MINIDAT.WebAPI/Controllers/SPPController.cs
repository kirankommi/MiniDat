﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model.Manage.Mode;
using MINIDAT.Model;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace MINIDAT.WebAPI.Controllers
{
    public class SPPController : AppController
    {
        ISPPRepository _sppRepository;
        public SPPController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Mode Template: SPP" }));
            _sppRepository = new SPPRepository(new MINIDATDatabase());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet, ActionName("GetSPPData")]
        public HttpResponseMessage GetSPPData(string templateId)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _sppRepository.getSPPTemplateData(templateId));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get SPP data");
            }
        }
    }
}
