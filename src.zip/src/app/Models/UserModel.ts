export class UserModel {
    FirstName: string;
    LastName: string;
    Initial: string;
    EmailId: string;
    OldUserId: string;
    DisplayName: string;
    DepartmentCode: KeyValue;
    RoleCode: KeyValue;
    StatusCode: KeyValue;
    EID: string;
    Phone: string

    //AppName: string; 
    //AppId: number;
    UserRoleDetails: ApplicationModel[];
    RoleName: string;
    StatusName: string;
    DepartmentName: string; 
}

export class ApplicationModel { 
    ApplicationName: string; 
    RoleName?: string;
    ApplicationId?: number;
    RoleCd?: string;
    IsChecked?: boolean;
    IsallowedCheck?: boolean;
}
export class KeyValue {
    Key: string;
    Value: string;
}

