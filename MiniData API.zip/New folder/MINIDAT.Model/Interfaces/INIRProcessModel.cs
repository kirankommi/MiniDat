﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Interfaces
{
    public interface INIRProcessModel
    {
        string ParameterName { get; set; }
        double? ParameterValue { get; set; }
        //string ParameterUOM { get; set; }
        string DefaultUnit { get; set; }

    }
}
