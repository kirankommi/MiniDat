﻿
namespace MINIDAT.Model.UOM
{
    public class ModuleEntity
    {
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
    }
}
