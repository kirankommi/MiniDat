﻿using MINIDAT.Model.Run;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IRunSetupRepository
    {

        RunSetupModel GetRunSetupModel(string Plant_cd, string RunId);
        void SaveRunSetupInformation(RunSetupModel run, string userId);

        RunSetupModel getMetaData(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getMasterData(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getGeneralInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getNIRModelInformation(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getProcessSpecData(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getRunAnalyticalInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getRunCutBoilingPointsInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getRunCatalystInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getRunTCSpec(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getTMFCalibrationInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getRunAdditionalInfo(RunSetupModel rs, IDataReader objSqlDr);
        RunSetupModel getFeedInfo(RunSetupModel rs, IDataReader objSqlDr);


    }
}
