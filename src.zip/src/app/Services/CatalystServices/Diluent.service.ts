﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { DiluentModel, KeyValue } from '../../Models/Catalyst/DiluentModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class DiluentService {
    private getDiluentdata = "/Diluent/SearchDiluentdata/";
    private getActiveDiluentinfo = "/Diluent/GetActiveDiluentdata/";
    private saveDiluentdata = "/Diluent/SaveDiluentInformation/";
    private deleteDiluentdata = "/Diluent/DeleteDiluentInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getDiluentInformatin(diluent: DiluentModel) {

        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(diluent, this.getDiluentdata);
    }

    saveDiluentInformation(diluent: DiluentModel)
    {
        return this.httpaction.post(diluent, this.saveDiluentdata);
    }

    deleteDiluent(diluent: DiluentModel)
    {
        debugger;
        return this.httpaction.post(diluent, this.deleteDiluentdata);
    } 
    getActiveDiluentInformatin(diluent: DiluentModel) {

        debugger;
        let options = new RequestOptions(Constants.options)
        return this.httpaction.post(diluent, this.getActiveDiluentinfo);
    }   
}
