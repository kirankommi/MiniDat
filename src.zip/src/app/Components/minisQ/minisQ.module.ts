/// <reference path="../../pipes/runpipe.ts" />
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MinisQComponent } from './minisQ.component';
import { sharedModule } from '../../Directives/shared.module';
import { routeResolver } from '../../services/route/routeresolver';
import { runPipe } from '../../Pipes/runPipe';
// import { StickyHeaderDirective } from '../../Directives/sticky-header-directive';

const routes:Routes=[
  {
    path: 'queue',
    component: MinisQComponent,
    resolve: {
      UOM: routeResolver
    }
  }];
@NgModule({
  imports: [
    sharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [MinisQComponent, runPipe
    // ,
    // StickyHeaderDirective
  ]
})
export class MinisQModule { }
