﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystAliasSSRepository : ICRUDRepository<CatalystAliasSSModel>
    {
        CatalystAliasSSSearchModel GetCatalystAliasSSData(CatalystAliasSSModel catalystType);
        string DeleteCatalystAliasSSData(CatalystAliasSSModel catalystType);
        void SaveCatalystAliasSSData(CatalystAliasSSModel _catalystType, string userId); 

    }
}
