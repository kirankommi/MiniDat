﻿import { ErrorMessage } from './ErrorMessage';
import * as  Constants from './globalconstants';
export class AppErrorMessages {
    ErrorMessages: ErrorMessage[] =
    [
        { Id: "InvalidLIMSID", Title: "", Details: "Invalid ID Input.", Error: null },
        { Id: "NoLIMSDATAOnSearch", Title: "", Details: "No data exists for the search criteria.", Error: null },
        { Id: "RoleInUse", Title: "", Details: "Role cannot be deleted - Role is already in Use.", Error: null },
        { Id: "UserAlreadyExists", Title: "", Details: "User Details failed to save - User Already Exists.", Error: null },
        { Id: "UserSaveError", Title: "", Details: "User Details failed to save.", Error: null },
        { Id: "UnKnownError", Title: "", Details:"" , Error: null },
        { Id: "FixedRole", Title: "", Details:"Default Role cannot be deleted." , Error: null },
        { Id: "NullSampleData", Title: "", Details:"Invalid ID Input." , Error: null },
        { Id: "ErrorWhenSampleSearch", Title: "", Details:"Invalid ID Input." , Error: null },
        { Id: "NullWorkItemData", Title: "", Details:"No data exists for the selected workitem." , Error: null },
        { Id: "ErrorWhenLIMSGetResultSearch", Title: "", Details: "Unexpected error during retrieving the result.", Error: null },
        { Id: "CrudeNotFound", Title: "Not Found", Details: "Crude not found", Error: null },
        { Id: "CrudesNotFound", Title: "Not Found", Details: "Crudes not found", Error: null },
        { Id: "Error", Title: "", Details: "Error", Error: null },
        { Id: "ErrorCrudeDetailsSave", Title: "Error", Details: "Error in Crude Details Save", Error: null },
        { Id: "InvalidFileNotExcel", Title: "", Details: "Invalid file selected, valid files are of .xlsx, .xls types.", Error: null },
        { Id: "Invalid", Title: "", Details: "Please Select Related Source Names", Error: null },
        { Id: "UNIQUE", Title: "", Details: "Feed Details failed to save - Feed Already Exists", Error: null },
        { Id: "UNIQUE_QUERY", Title: "", Details: "Query Details failed to save - Query Name Already Exists.", Error: null },
        { Id: "InvalidInput", Title: "", Details: "Invalid Input", Error: null },
        { Id: "RequiredAll", Title: "", Details: "Please fill in all the required fields", Error: null },
        { Id: "selectaFile", Title: "", Details: "Select a File", Error: null },
        { Id: "selectavalidFile", Title: "", Details: "Select a Valid File", Error: null },
        { Id: "selectaFeed", Title: "", Details: "Select a Feed", Error: null },
        { Id: "ProjectSaveError", Title: "Save Project", Details: "Project Details failed to save.", Error: null },
        { Id: "ProjectSearchError", Title: "Project", Details: "Project Details failed to load.", Error: null },
        { Id: "ProjectAccoladeLoadError", Title: "Project", Details: "Accolade Project Details failed to load.", Error: null },
        { Id: "AccoladeProjectAlreadyExists", Title: "Save Project", Details: "Accolade Project already exists.", Error: null },
        { Id: "RoleNameAlreadyExists", Title: "Save Role", Details: "Role already exists.", Error: null },
        { Id: "ProjectDeleteError", Title: "Delete Project", Details: "Project Details failed to delete.", Error: null },
        { Id: "ProjectInUseDeleteError", Title: "Delete Project", Details: "Project already in use hence can't delete.", Error: null },
        { Id: "DuplicateLogReadingLabel", Title: "Save PI Tag", Details: "Entered Logreading Label already Exist for one of the Different PI Tags.", Error: null },
        { Id: "DuplicatePITag", Title: "Save PI Tag", Details: "Entered PI Tag Name already Exist for same Plant", Error: null },
        { Id: "DefaultMode", Title: "Delete Mode", Details: "Default Mode cannot be deleted.", Error: null },	
        { Id: "DuplicateMode", Title: "Save Mode", Details: "Entered Mode Number already Exist.", Error: null },
        { Id: "DuplicateCatalystFamily", Title: "Save Catalyst Family", Details: "Entered Catalyst Family already Exist.", Error: null },
        { Id: "Duplicatediluent", Title: "Save Diluent", Details: "Entered Diluent Information already Exist.", Error: null },	
        { Id: "DuplicateTemplateName", Title: "Save Loading Template", Details: "Entered Template Name already Exist.", Error: null },
		{ Id: "CatalystSaveError", Title: "Save Catalyst", Details: "Catalyst Details failed to save.", Error: null },
        { Id: "CatalystSearchError", Title: "Catalyst", Details: "Catalyst Details failed to load.", Error: null },	
        { Id: "CatalystSaveDuplicateKeyError", Title: "Save Catalyst", Details: "Catalyst ID/Designation already exist.", Error: null },
        { Id: "CatalystDeleteError", Title: "Delete Catalyst", Details: "Catalyst Details failed to delete.", Error: null },
        { Id: "CatalystInUseDeleteError", Title: "Delete Catalyst", Details: "Catalyst already in use hence can't delete.", Error: null },        
        { Id: "AnalysisInUse", Title: "Delete Analysis Method", Details: "Selected Analysis method cannot be deleted - It is in Use.", Error: null },
        { Id: "DiluentInUse", Title: "Delete Diluent", Details: "Selected Diluent cannot be deleted - It is in Use.", Error: null },
        { Id: "CatalystFamilyInUse", Title: "Delete Catalyst Family", Details: "Selected Family cannot be deleted - It is in Use.", Error: null },
        { Id: "CatalystSizeInUse", Title: "Delete Catalyst Size", Details: "Selected Size Information cannot be deleted - It is in Use.", Error: null },
        { Id: "CatalysTypeInUse", Title: "Delete Catalyst Type", Details: "Selected Type Information cannot be deleted - It is in Use.", Error: null },
        { Id: "CatalystAliasSSInUse", Title: "Delete Catalyst Alias", Details: "Selected Catalyst Alias SS Information cannot be deleted - It is in Use.", Error: null },
        { Id: "DuplicatecatalystSize", Title: "Save Catalyst Size", Details: "Entered Catalyst Size Information already Exist.", Error: null }, 
        { Id: "DuplicatecatalystType", Title: "Save Catalyst Type", Details: "Entered Catalyst Type Information already Exist.", Error: null },	
        { Id: "DuplicateAliasSSName", Title: "Save Catalyst Alias SS", Details: "Entered Catalyst Alias SS Information already Exist.", Error: null },
        { Id: "DuplicatecatalystScale", Title: "Save Catalyst Scale", Details: "Entered Catalyst Scale Information already Exist.", Error: null }, ,
        { Id: "CatalystScaleInUse", Title: "Delete Catalyst Scale", Details: "Selected Scale Information cannot be deleted - It is in Use.", Error: null }, 
        { Id: "DuplicateCatalystState", Title: "Save Catalyst State", Details: "Entered Catalyst State Information already Exist.", Error: null }, ,
        { Id: "CatalystStateInUse", Title: "Delete Catalyst State", Details: "Selected State Information cannot be deleted - It is in Use.", Error: null },
        { Id: "FeedInUse", Title: "Delete Feed", Details: "Selected Feed Information cannot be deleted - It is in Use.", Error: null },
        { Id: "CatalystShapeInUse", Title: "Delete Catalyst Shape", Details: "Selected Catalyst Shape Information cannot be deleted - It is in Use.", Error: null },
        { Id: "DuplicateCatalystShape", Title: "Save Catalyst Shape", Details: "Entered Catalyst Shape Information already Exist.", Error: null },
        { Id: "RunSaveError", Title: "Save Run Information", Details: "Run Details failed to save.", Error: null },
        { Id: "TestSearchError", Title: "Search Test Information", Details: "No data exists for the search criteria.", Error: null },	
        { Id: "TestDataLoadError", Title: "Get Test Information", Details: "Unable to load the flyout information", Error: null },	
        { Id: "NullPlantCode", Title: "Get Run Information", Details: "Plant Code is Not Selected.", Error: null },	
        { Id: "CatalystLoadingInUse", Title: "", Details: "Selected Loading Template is already associated to a Run. Modifications are not allowed!", Error: null },
        { Id: "LoadingTemplateInUse", Title: "", Details: "Selected Loading Template cannot be deleted - Loading Template is already in Use.!", Error: null },
        
    ];    

    public getErrorMessage(id: string) 
    {
        
        if (this.ErrorMessages&& this.ErrorMessages.length>0)
        {
            var msg = this.ErrorMessages.filter(x => x.Id == id)[0];
            if (msg)
            {
                return msg;
            }
            else
            {
                return new ErrorMessage();
            }

        }

    }

    //public displayErrorMessage1(id: string) {
    //    
    //    let msg: any = {};       
    //    var message = this.getErrorMessage(id)
    //    if (message) {
    //        
    //        msg.severity = Constants.severityError;
    //        msg.detail = message.Details;
    //        msg.summary = message.Title;
    //        Constants.Msgs = [];
    //        Constants.Msgs.push(msg);
    //    }
    //}
}