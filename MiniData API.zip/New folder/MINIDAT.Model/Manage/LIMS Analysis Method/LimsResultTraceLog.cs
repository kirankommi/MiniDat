﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace FDMS.Model.Manage.LIMS_Analysis_Method
{
    public class LimsResultTraceLog
    {
        public int TraceLogIdSQ { get; set; }
        public string SampleId { get; set; }
        public string UserSampleId { get; set; }
        public string LimsOperationName { get; set; }
        public string ComponentName { get; set; }
        public string UOM { get; set; }
        public DateTime SampleDate { get; set; }
        public string Status { get; set; }
        public string CreatedByUserID { get; set; }
        public DateTime CreatedOnDate { get; set; }
    }


    public class MissingOperatorsViewModel
    {
        public string AnalysisMethodId { get; set; }
        public string LIMSOperation { get; set; }
        public string methodName { get; set; }
        public string methodNumber { get; set; }
        public string UOMGroup { get; set; }

        private IList<AnalysisSource> _Source = new List<AnalysisSource>();
        public IList<AnalysisSource> Source
        {
            get { return _Source; }
        }

        public string methodDescription { get; set; }

    }

    [Serializable]
    [JsonObject]
    [XmlRoot(ElementName = "AnalysisSource")]
    public class AnalysisSource
    {
        [XmlAttribute(AttributeName = "SourceName")]
        public string SourceName { get; set; }
        [XmlAttribute(AttributeName = "SourceCode")]
        public string SourceCode { get; set; }
    }

    /*
      <AnalysisMethod Id="2323" AnalysisMethodName="AnalysisMethodName2" AnalysisMethodNumber="AnalysisMethodNumber2" AnalysisMethodDescription="TEST" 
      UomGroupName="asdasd" LimsOperationName="Limsoperation2">
       <AnalysisSources>
              <AnalysisSource SourceName="SOURCE3" SourceCode="TESTCD3" />
       </AnalysisSources>
       </AnalysisMethod>
     */
    [XmlType(TypeName = "AnalysisMethods")]
    public class AnalysisMethods
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        [XmlElement(ElementName = "AnalysisMethod")]
        public List<AnalysisMethod> Methods { get; set; }
    }
    public class AnalysisMethod
    {
        [XmlAttribute]
        public string AnalysisMethodId { get; set; }
        [XmlAttribute]
        public string AnalysisMethodName { get; set; }
        [XmlAttribute]
        public string AnalysisMethodNumber { get; set; }
        [XmlAttribute]
        public string AnalysisMethodDescription { get; set; }
        [XmlAttribute]
        public string UomGroupName { get; set; }
        [XmlAttribute]
        public string LimsOperationName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public List<AnalysisSource> AnalysisSources { get; set; }
    }






    public class filteredMissingComponentGroupViewModel
    {
        public filteredMissingComponentGroupViewModel()
        {
            Components = new Collection<MissingComponentViewModel>();
        }
        public filteredMissingComponentGroupViewModel(Collection<MissingComponentViewModel> components)
        {
            Components = components;
        }
        [XmlAttribute(AttributeName = "LimsOperationName")]
        public string Operation { get; set; }

        [XmlElement(ElementName = "LimsComponent")]
        public Collection<MissingComponentViewModel> Components { get; }
    }


    public class MissingComponentViewModel
    {
        [XmlAttribute(AttributeName = "LimsComponentName")]
        public string ComponentName { get; set; }

        [XmlAttribute(AttributeName = "LimsComponentStdName")]
        public string StandardComponentName { get; set; }

        [XmlAttribute(AttributeName = "DefaultUomName")]
        public string UOMUnit { get; set; }

        [XmlAttribute(AttributeName = "Precision")]
        public string Precision { get; set; }
    }
    [XmlType(TypeName = "LimsOperations")]
    public class filteredMissingComponentGroupViewModels
    {
        public filteredMissingComponentGroupViewModels()
        {
            LimsOperation = new Collection<filteredMissingComponentGroupViewModel>();
        }

        [XmlElement(ElementName = "LimsOperation")]
        public Collection<filteredMissingComponentGroupViewModel> LimsOperation
        {
            get;
        }
    }

}
