﻿import { KeyValue } from '../KeyValue';
export class CatalystModel {
    public CatalystId: number;
    public CatalystDesignation: string;
    public CatalystDescription: string;
    public CatalystFamilyId: number;
    public CatalystFamilyName: string;
    public CatalystTypeId: number;
    public CatalystTypeName: string;
    public CatalystShapeId: number;
    public CatalystShapeName: string;
    public CatalystSizeId: number;
    public CatalystSizeName: string;
    public CatalystAliasId: number;
    public CatalystAliasName: string;
    public ReferenceCatalystInd: Boolean;
    public RegenCatalystInd: Boolean;
    public CatalystStateId: number;
    public CatalystStateName: string;
    public GroundInd: Boolean;
    public AnalyticalApproveInd: Boolean;
    public AnalyticalStatusCd: string;
    public AnalyticalStatusName: string;
    public AnalyticalStatusNameTemp: string;
    public BulkLocationInd: Boolean;
    public CatalystLeaderCd: string;
    public CatalystLeaderName: string;
    public ApparentBedDensity: number;
    public VibratedBedDensity: number;
    public CatalystScaleId: number;
    public CatalystScaleName: string;
    public CatalystPieceDensity: number;
    public LOIAt500Msr ?: number;
    public CatalystVoidFraction: number;
    public CatalystVoidFractionCrushed: number;
    public ActiveInd: string;
    public CreatedBy: string;
    public CreatedOn: Date;
    public UpdatedBy: string;
    public UpdatedOn: Date;
    public LIMSs: CatalystLimsSample[];
    public IsInitialLoad: boolean;
}
export class CatalystFamily {
    public CatalystFamilyId: number;
    public CatalystFamilyName: string;
    public CatalystFamilyInd: string;
    public CatalystTypeId: number;
}
export class CatalystAlias {
    public CatalystAliasId: number;
    public CatalystShapeId: number;
    public CatalystSizeInd: number;
    public CatalystAliasName: string;
}
export class CatalystMasterDataModel {
    public CatalystFamilys: CatalystFamily[];
    public CatalystTypes: KeyValue[];
    public CatalystShapes: CatalystShape[];
    public CatalystSizes: KeyValue[];
    public CatalystAlias: CatalystAlias[];
    public CatalystState: KeyValue[];
    public CatalystLeaders:KeyValue[];
    public CatalystScale: KeyValue[];
}
export class CatalystLimsSample {
    public CatalystId: number;
    public SampleId: string;
}
export class CatalystShape {
    public CatalystShapeId: number;
    public CataystShapeName: number;
    public CatalystVoidFractionId: number;
    public CatalystVoidFraction: number;
    public CatalystVoidFractionCrushed: number;
}