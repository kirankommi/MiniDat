﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { RoleModel } from '../Models/RoleModel';
import { HttpActionService } from './httpaction.service';
//import Constants = require('../Shared/globalconstants');
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class RoleMenuService {
    private getAllRoles = "/RoleMenu/GetRoles/";
    private getPrivileges = "/RoleMenu/GetPrivilegesbyRoles/";
    private savePrivileges = "/RoleMenu/SaveRolePrivileges/";

    constructor(private httpaction: HttpActionService) { }

    getRoles() {
        return this.httpaction.get(this.getAllRoles, Constants.options);
    }

    getRolePrivileges(roleCode: string, appCode: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('RoleCode', roleCode);
        params.set('AppCode', appCode);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getPrivileges, options);
    }

    saveRolePrivileges(menus: any, roleCode: string, appCode: string) {
        let role_appCode = roleCode + ";" + appCode;
        return this.httpaction.post(menus, this.savePrivileges + "?roleCode=" + role_appCode + "");
    }
}

