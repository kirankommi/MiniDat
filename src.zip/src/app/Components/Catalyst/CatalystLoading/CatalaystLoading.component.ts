﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { TemplateService } from '../../../Services/CatalystServices/CatalystLoading.service';
import { CatalystLoading, Bed, ReactorModel } from '../../../models/Catalyst/CatalystLoadingModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';
import { DiluentService } from '../../../Services/CatalystServices/Diluent.service';
import { DiluentModel, KeyValue } from '../../../models/Catalyst/DiluentModel';

@Component({  
    templateUrl: 'CatalaystLoading.component.html',
    providers: [TemplateService, DiluentService,AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalaystLoadingComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    selectedRow: CatalystLoading;
    public catalystLoading: CatalystLoading;
    public templateList: CatalystLoading[]; 
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    internalDiaUomObj: any = {};
    bedLengthUomObj: any = {};  
    bedVolumeUomObj: any = {};
    Statuses: KeyValue[];     
    diluentListCols: KeyValue[];
    addIconPath = Constants.addIcon;
    deleteIconPathEn = Constants.deleteIconEn;
    IsallowedChange: boolean = true;
    LoadingTemplateSaved: string = "Loading Template Details Saved Successfully";
    LoadingTemplateDeleted: string = "Loading Template Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number; 
    flyoutHeader: string = "Diluents";  
    pHolder: string = "Diluent Name";
    bed: Bed;
    count: number = 0;   
    lstDiluents: any;
    diluent: DiluentModel;   
    ReactorInformation: string; 
    TotalVolume: any=0;
    ReactorBedLength: number=0;        
    constructor(private templateService: TemplateService, private diluentService: DiluentService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    resetRowId() {

        if (this.catalystLoading.Beds != null && this.catalystLoading.Beds.length > 0) {
            var maxRowId = 0;
            for (var i = 0; i < this.catalystLoading.Beds.length; i++) {
                maxRowId = i + 1;
                this.catalystLoading.Beds[i].RowId = maxRowId;
                this.catalystLoading.Beds[i].BedNumber = maxRowId;
            }
            this.count = maxRowId;
        }
    }
    AddFile() {
        this.count++;
        this.catalystLoading.Beds.push({ RowId: this.count, TemplateID: this.catalystLoading.TemplateID, BedNumber: this.count, CatalystVolume: null, Split: null, DiluentID: null,DiluentDesignation: "", DiluentVolume: null });
    }

    private reset()
    {        
        this.catalystLoading = new CatalystLoading();
        this.catalystLoading.TemplateID = null;
        this.catalystLoading.TemplateName ="";
        this.catalystLoading.TemplateDescription = null;
        this.catalystLoading.ReactorInternalDia = null;
        this.catalystLoading.BedLength = null;
        this.catalystLoading.BedVolume = null;       

        this.catalystLoading.StatusName = Constants.Select;       
        this.count = 0;
        this.bed = new Bed();
        this.catalystLoading.Beds = [];
        this.AddFile();
        this.searchLoadingTemplates();

        this.internalDiaUomObj = { unitGroupName: 'LENGTH', baseValue: null, baseupdate: true };
        this.bedLengthUomObj = { unitGroupName: 'LENGTH', baseValue: null, baseupdate: true };
        this.bedVolumeUomObj = { unitGroupName: 'VOLUME', baseValue: null, baseupdate: true };
        this.catalystLoading.ReactorInternalDia = 0.0117856;  //Fixed Base value for Reactor Internal dia

    }
    updateBedVolume()
    {
        debugger;
        if (this.catalystLoading.Beds.length == 0)
        {
            this.ReactorBedLength = 0;
            this.TotalVolume = 0;
        }
        for (var i = 0; i < this.catalystLoading.Beds.length; i++)
        {
            if (i == 0)
            {
                this.TotalVolume = 0;
            }
            this.TotalVolume = this.TotalVolume +
                                (this.catalystLoading.Beds[i].CatalystVolume == null ? 0 : this.catalystLoading.Beds[i].CatalystVolume) +
                                (this.catalystLoading.Beds[i].DiluentVolume == null ? 0 : this.catalystLoading.Beds[i].DiluentVolume)                     
        }
        this.ReactorBedLength = (this.TotalVolume) / (3.14 * (this.catalystLoading.ReactorInternalDia/2) * (this.catalystLoading.ReactorInternalDia/2))
        this.catalystLoading.BedLength = this.ReactorBedLength;
        this.catalystLoading.BedVolume = this.TotalVolume;
    }
    ngOnInit()
    {
        this.reset();       
        this.diluent = new DiluentModel();
        this.diluent.Designation = null;
        this.diluent.Source = null;
        this.diluent.Description = null;
        this.diluent.size = null;
        this.diluent.ReferenceName = null;
        this.diluent.StatusName = null;
        this.diluent.PieceDensity = null;
        this.diluent.ApparentBulkDensity = null;

        this.fillFlyoutColumns();   
        this.title = Constants.CatalystLoadingTemplate;      
    }

    fillFlyoutColumns()
    {
        this.diluentListCols = []
        this.diluentListCols.push({ Key: "Designation", Value: "Diluent Designation", Groupcd:null });
        this.diluentListCols.push({ Key: "Source", Value: "Diluent Source", Groupcd: null });
        this.diluentListCols.push({ Key: "Description", Value: "Description", Groupcd: null });

        this.diluentService.getActiveDiluentInformatin(this.diluent)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.lstDiluents = data.Lstdiluents;
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );

    }

    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    updateDiluentSelection(event, condition, rowId: any)
    {
        debugger;        
        this.catalystLoading.Beds.filter((i: Bed) => i.RowId == rowId)[0].DiluentDesignation = event.Designation;
        this.catalystLoading.Beds.filter((i: Bed) => i.RowId == rowId)[0].DiluentID = event.DiluentID;       
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystLoading.TemplateID = event.data.TemplateID;
        this.catalystLoading.TemplateName = event.data.TemplateName;
        this.catalystLoading.TemplateDescription = event.data.TemplateDescription;
        this.catalystLoading.ReactorInternalDia = event.data.ReactorInternalDia;
        this.catalystLoading.BedLength = event.data.BedLength;
        this.catalystLoading.BedVolume = event.data.BedVolume;
        this.catalystLoading.StatusName = event.data.StatusCode.Key;

        this.internalDiaUomObj.baseValue = event.data.ReactorInternalDia;
        this.bedLengthUomObj.baseValue = event.data.BedLength;
        this.bedVolumeUomObj.baseValue = event.data.BedVolume;  

        this.catalystLoading.Beds = [];
        this.count = 0;
        if (this.catalystLoading && this.catalystLoading.TemplateID > 0)
        {
            this.templateService.GetReactorBedDetails(this.catalystLoading.TemplateID)
                .subscribe(
                (data: any) => {
                    debugger;
                    if (data && data.length > 0) {
                        for (var i = 0; i < data.length; i++) {
                            this.catalystLoading.Beds.push({ RowId: data[i].RowId, TemplateID: data[i].TemplateID, BedNumber: data[i].BedNumber, CatalystVolume: data[i].CatalystVolume, Split: data[i].Split, DiluentID: data[i].DiluentID, DiluentDesignation: data[i].DiluentDesignation, DiluentVolume: data[i].DiluentVolume });
                            this.count = data[i].RowId;
                        }
                    }
                    else {
                        this.AddFile();
                    }

                });
        }  

    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    searchLoadingTemplates()
    {
        debugger;
        this.templateService.searchLoadingTemplates(this.catalystLoading)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.templateList = data.LstTemplates;              
                this.Statuses = data.lstStatus;               
                this.totalRecords = data.RecordsFetched;            
                if (this.catalystLoading.StatusName == undefined || this.catalystLoading.StatusName == null)
                { this.catalystLoading.StatusName = Constants.Select; }               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveLoadingInformation()
    {
        debugger;
        let response: any;
        if (this.isDataValid() && this.isBedsEmpty())
        {           
            if (this.catalystLoading.BedLength <= 0.8255) //
            {
                this.templateService.saveLoadingInformation(this.catalystLoading)
                .subscribe(
                (data: any) => {
                    debugger;
                    if (data == Constants.Success) {
                        this.reset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.LoadingTemplateSaved});
                        this.appComponent.GetUserData();
                    }
                },
                err => { }
                );
            }
            else
            {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.ExceedingBedLentgh });
            }
            
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(loadingTemplate: CatalystLoading) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteLoadingInfo(loadingTemplate);}
        });
    }

    deleteLoadingInfo(loadingTemplate: CatalystLoading)
    {
        debugger;
        this.templateService.deleteTemplateInfo(loadingTemplate)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.reset();
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.LoadingTemplateDeleted});
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }

    isDataValid()
    {
        debugger;
        if (this.catalystLoading == null || !this.catalystLoading.TemplateName || this.catalystLoading.StatusName == "Select"
            || (!this.catalystLoading.ReactorInternalDia)
            || (!this.catalystLoading.BedLength)
            || (!this.catalystLoading.BedVolume)
          )
        {
            return false;
        }
        return true;
    }

    isBedsEmpty()
    {
        let result: boolean = false;
        debugger;        
            for (var i = 0; i < this.catalystLoading.Beds.length; i++)
            {
                if (this.catalystLoading.Beds.length >0 && (this.catalystLoading.Beds[i].CatalystVolume == null || this.catalystLoading.Beds[i].CatalystVolume == undefined) ||
                    (this.catalystLoading.Beds[i].DiluentDesignation == "" || this.catalystLoading.Beds[i].DiluentDesignation == undefined) ||
                    (this.catalystLoading.Beds[i].DiluentVolume == null || this.catalystLoading.Beds[i].DiluentVolume == undefined) ||
                    (this.catalystLoading.Beds[i].DiluentID == null || this.catalystLoading.Beds[i].DiluentID == undefined) ||
                    (this.catalystLoading.Beds[i].Split == null || this.catalystLoading.Beds[i].Split == undefined))
                {
                    result = false;
                }
                else
                {
                    result = true;
                }
        }
       return result;
    }

    onDeleteBed(event: any, bedNumber: any, rowId: any)
    {
        debugger;
        let bed = this.catalystLoading.Beds.filter((i: Bed) => i.BedNumber == bedNumber)[0];
        if (bed != undefined && bed != null)
        {
            if (bed.BedNumber > 0)
            {
                this.catalystLoading.Beds = this.catalystLoading.Beds.filter((i: any) => i.RowId != rowId);
                this.resetRowId();
                this.updateBedVolume();
                //this.messageService.show("Delete Bed", Constants.ConfirmMsg, Constants.Confirm).then((result) =>
                //{
                //    result = result == Constants.ConfirmTrue; //casting string to boolean
                //    if (result)
                //    {                       
                       
                //    }

                //});
            }
            else
            {
                this.catalystLoading.Beds = this.catalystLoading.Beds.filter((i: any) => i.RowId != rowId);
                this.resetRowId();
                this.updateBedVolume();
            }
        }
        if (this.catalystLoading.Beds.length <= 0)
        {
            this.count = 0;
            this.AddFile();
        }
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {
        //debugger;
        if (!this.check)
        {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {
                    //FUNC000017 - Application function code for Loading Template screen
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000017" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {                    
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
