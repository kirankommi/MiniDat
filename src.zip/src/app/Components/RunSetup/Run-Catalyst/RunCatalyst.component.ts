import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, RunCatalystSearchModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import { KeyValue } from '../../../Models/KeyValue';
import * as Constants from '../../../Shared/globalconstants';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
  selector: 'runCatalyst',
  templateUrl: './RunCatalyst.component.html',
  providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})
export class RunCatalystComponent implements OnInit
{
    // run1: RunModel; 
    run: RunSetupModel; 
    streamCols: KeyValue[];
    IsallowedSave: boolean = true;  
    check: boolean = false;
    runSaved: string = "Catalyst Informaiton Saved Successfully";
    routerLinkVariable = "../../../../../Catalyst/Pool"; 

    constructor(private runService: RunService, public runDataService: RunDataService, private messageService: messageModalUtility, private alertMessage: AlertMessage, private runComponent: RunComponent) { } 
  ngOnInit()
  {
      debugger;
      this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel)
 
      this.runComponent.exportData.selectedPopupList = [];
      this.runComponent.exportData.selectedPopupList.push({ Key: "3", Value: "Catalyst", Groupcd: 0 });  
  }
  formatCatalyst(catalystId: any){
      debugger;
      catalystId = catalystId.replace(/\s/g, "$");
      return catalystId;
  }
  getRunCatalystInformation(RunNum: string)
  {
      debugger;
      this.runService.GetRunCatalystInfo(RunNum)
      .subscribe(
          (data: any) =>
          {
            debugger;             
            this.run.Cataysts = data.LstCatalysts;
            this.run.Beds = data.LstBeds;          
        },
        err => { }        
      );
  }

  onReset()
  {
      debugger;
      this.getRunCatalystInformation(this.run.MetaData.RunId);
      this.runDataService.changeMessage(this.run);      
  } 
  ngDoCheck() {
      if (!this.check) {
          if (Constants.UserPrivileges.length > 1) {
              for (let i in Constants.UserPrivileges) {
                  if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000067" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                      this.IsallowedSave = true;
                      this.check = true;
                  }
              }
          }
      }

  }
}

