﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.DataViewerModel;
using MINIDAT.Model.TestCreation;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.TestCreation
{
    public class WCResultSummaryRepository : IWCResultSummaryRepository
    {

        private IDatabase _db;
        public WCResultSummaryRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<WCResultSummaryModel> getDataForWCResultSummary(string Plant, string Run, string Test, string Category, string User_Id)
        {
            try
            {
                List<WCResultSummaryModel> result = new List<WCResultSummaryModel>();
                IDataReader reader = null;
               
                using (IDbCommand command = _db.CreateCommand("[md].[Get_WeightCheck_Results_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", Plant);
                    parameters.Add("@proc_in_Run_Num", Int32.Parse(Run));
                    parameters.Add("@proc_in_Test_Num", Int32.Parse(Test)); 
                    parameters.Add("@proc_vr_Category", Category);
                    parameters.Add("@proc_vr_User_Id", User_Id);
                    _db.CreateParameters(command,parameters);
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        WCResultSummaryModel objRecord = new WCResultSummaryModel()
                        {
                            Parameter = Convert.ToString(reader["PARAMETER_NM"]),
                            UOM = Convert.ToString(reader["UOM_GROUP_NM"]),
                            ParamDisplayOrder = Convert.ToString(reader["PARAM_DISPLAY_ORDER_NUM"]),
                            Value = Convert.ToString(reader["VALUE_MSR"]),
                            DefaultUOM = Convert.ToString(reader["DEFAULT_UNIT_NM"])

                        };
                        result.Add(objRecord);
                    }
                    reader.NextResult();
                    reader.Close();
                    return result;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }




        }
        public WCExportPopup exportWCRepository(string Plant, string Run, string Test, string Category, string User_Id)
        {
                try
                {
                    
                    WCExportPopup exportdata = new WCExportPopup();
                    IDataReader reader = null;
                    string[] categories;
                    categories = Category.Split(',');
                    using (IDbCommand command = _db.CreateCommand("[md].[Export_WC_Summary_Sp]"))
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("@proc_vr_Plant_Cd", Plant);
                        parameters.Add("@proc_in_Run_Num", Int32.Parse(Run));
                        parameters.Add("@proc_in_Test_Num", Int32.Parse(Test));
                        parameters.Add("@category_List", Category);
                        parameters.Add("@proc_vr_User_Id", User_Id);

                        _db.CreateParameters(command, parameters);

                        using (reader = _db.ExecuteReader(command))
                        {
                            foreach (var category in categories)
                            {
                                List<WCExport> tableData = new List<WCExport>();
                                while (reader.Read())
                                {
                                    WCExport objRecord = new WCExport()
                                    {
                                        Parameter = Convert.ToString(reader["PARAMETER_NM"]),
                                        Value = Convert.ToString(reader["VALUE_MSR"]),
                                        UOM = Convert.ToString(reader["DEFAULT_UNIT_DISPLAY_NM"]),

                                    };
                                    tableData.Add(objRecord);
                                }
                                reader.NextResult();
                                switch (category)
                                {
                                    case "Plant Calculations":
                                        exportdata.PlantCalculations = tableData;
                                        break;
                                    case "Normalized Gas Yields":
                                        exportdata.NormalizedGasYields = tableData;
                                        break;
                                    case "Gas Volumes":
                                        exportdata.GasVolumes = tableData;
                                        break;
                                    case "Gas Weights":
                                        exportdata.GasWeights = tableData;
                                        break;
                                    case "Weight Recovery":
                                        exportdata.WeightRecovery = tableData;
                                        break;
                                    case "Liquid Weights":
                                        exportdata.LiquidWeights_LP690 = tableData;
                                        break;
                                    case "Liquid Weights Percent":
                                        exportdata.LiquidWeights_percent = tableData;
                                        break;
                                    case "Liquid Weights(Sim Dist)":
                                        exportdata.LiquidWeights_Simdist = tableData;
                                        break;
                                    case "Normalized Liquid Weight":
                                        exportdata.NormalizedLiquidWeights = tableData;
                                        break;
                                    case "Raw Product Weights":
                                        exportdata.RawProductWeights = tableData;
                                        break;
                                    case "Raw Product Weight Percent":
                                        exportdata.RawProductWeights_percent = tableData;
                                        break;
                                    case "Mass Balance Adjusted Prod Wt Percent":
                                        exportdata.MBAdjustedProductWt_percent = tableData;
                                        break;
                                    case "Dopant Adjustment":
                                        exportdata.DopantAdjustments = tableData;
                                        break;
                                    case "Dopant Adjusted Mb":
                                        exportdata.DAMassBalanceProductWt_perscent = tableData;
                                        break;
                                    case "Product Ratios":
                                        exportdata.ProductRatios = tableData;
                                        break;
                                    case "Feed Weight(Sim Dist)":
                                        exportdata.FeedWeights = tableData;
                                        break;
                                    case "Feed Weight Percent(Sim Dist)":
                                        exportdata.FeedWeightsPercent = tableData;
                                        break;
                                    case "Conversion Calculations":
                                        exportdata.ConversionCalculation = tableData;
                                        break;
                                    case "Quality Calculations":
                                        exportdata.QualitCalculation = tableData;
                                        break;
                                    case "LP Product Properties":
                                        exportdata.H2LPProductProperties = tableData;
                                        break;
                                    case "H By NIR Yields":
                                        exportdata.H2ByNIR = tableData;
                                        break;
                                    case "H By NMR Yields":
                                        exportdata.H2ByNMR = tableData;
                                        break;
                                }
                            }

                        }
                        reader.Close();
                    }
                    return exportdata;
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
        }

    }
}
