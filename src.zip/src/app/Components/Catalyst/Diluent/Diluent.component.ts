﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { DiluentService } from '../../../Services/CatalystServices/Diluent.service';
import { DiluentModel, KeyValue } from '../../../models/Catalyst/DiluentModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'Diluent.component.html',
    providers: [DiluentService, AlertMessage, HttpActionService, ConfirmationService]
})

export class DiluentComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    diluent: DiluentModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    diluentList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    diluentSaved: string = "Diluent Details Saved Successfully";
    diluentDeleted: string = "Diluent Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private diluentService: DiluentService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;  

        //this.pieceDensityUomObj = { unitGroupName: 'DENSITY', baseValue: null, baseupdate: true };
        //this.apparentBulkDensityUomObj = { unitGroupName: 'DENSITY', baseValue: null, baseupdate: true };      
    }

    ngOnInit()
    {
        debugger;
        this.diluent = new DiluentModel();
        this.diluent.Designation = null;
        this.diluent.Source = null;
        this.diluent.Description = null;   
        this.getdiluentsList();
        this.title = Constants.ManageDiluent;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.diluent.Designation = event.data.Designation;
        this.diluent.Source = event.data.Source;   
        this.diluent.size = event.data.Sizecd.Key;       
        this.diluent.ReferenceName = event.data.Referencecd.Key;
        this.diluent.StatusName = event.data.StatusCode.Key;
        this.diluent.PieceDensity = event.data.PieceDensity;
        this.diluent.ApparentBulkDensity = event.data.ApparentBulkDensity;     
        this.diluent.DiluentID = event.data.DiluentID;
        this.diluent.Description = event.data.Description;
    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getdiluentsList()
    {
        debugger;
        //this.diluent.PieceDensity = (this.pieceDensityUomObj.displayValue == undefined ? null : this.pieceDensityUomObj.baseValue);
        //this.diluent.ApparentBulkDensity = (this.apparentBulkDensityUomObj.displayValue == undefined ? null : this.apparentBulkDensityUomObj.baseValue);       

        this.diluentService.getDiluentInformatin(this.diluent)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.diluentList = data.Lstdiluents;              
                this.Statuses = data.lstStatus;
                this.sizes = data.lstSizes;
                this.references = data.lstReferences;
                this.totalRecords = data.RecordsFetched;
                if (this.diluent.size == undefined || this.diluent.size == null)
                { this.diluent.size = 0; }
                if (this.diluent.ReferenceName == undefined || this.diluent.ReferenceName == null)
                { this.diluent.ReferenceName = Constants.Select; }
                if (this.diluent.StatusName == undefined || this.diluent.StatusName == null)
                { this.diluent.StatusName = Constants.Select; }               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveDiluent()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {                          
            this.diluent.AppCode = this.selectedApplicationCode;        
            //this.diluent.PieceDensity = this.pieceDensityUomObj.baseValue;
            //this.diluent.ApparentBulkDensity = this.apparentBulkDensityUomObj.baseValue;                

            this.diluentService.saveDiluentInformation(this.diluent)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.diluentSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(mode: DiluentModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteModeInfo(mode);}
        });
    }

    deleteModeInfo(diluent: DiluentModel)
    {
        debugger;
        diluent.AppCode = this.selectedApplicationCode;

        this.diluentService.deleteDiluent(diluent)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.diluentDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }   

    onReset() {
        debugger;
        this.diluent = new DiluentModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.diluent.Description = null;
        //this.pieceDensityUomObj = { unitGroupName: 'DENSITY', baseValue: null, baseupdate: true };
        //this.apparentBulkDensityUomObj = { unitGroupName: 'DENSITY', baseValue: null, baseupdate: true };      
        this.getdiluentsList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.diluent == null || !this.diluent.Description || !this.diluent.Designation || this.diluent.size == 0 || this.diluent.ReferenceName == "Select" || this.diluent.StatusName == "Select"
            || !this.diluent.Source
            || (this.diluent.PieceDensity == null || this.diluent.PieceDensity == undefined)
            || (this.diluent.ApparentBulkDensity == null || this.diluent.ApparentBulkDensity == undefined))
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {
        debugger;
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    //if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "ROLE" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000016" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
