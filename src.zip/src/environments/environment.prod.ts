export const environment = {
  production: true,
  apiendpoints: 'http://ie1avwihps006:89/',
};
