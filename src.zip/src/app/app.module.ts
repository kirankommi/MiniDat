import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { AppComponent } from './app.component';
import { sharedModule } from './Directives/shared.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { routing, appRoutingProviders } from './app.routing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TagCloudModule } from 'angular-tag-cloud-module';


import { UserService } from './Services/user.service';
import { messageModalUtility } from './Shared/message-modal.utility';

import { DateAdapter } from '@angular/material/core';
import { MatInputModule, MatNativeDateModule } from '@angular/material';
import { MultiSelectModule } from 'primeng/primeng'
import { CalendarModule } from 'primeng/calendar';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { messageModalComponent } from './Shared/message-modal.component';
import { HttpClientModule } from '@angular/common/http';

import { RouterAuthService } from './Services/routerAuth.service';

import { UnauthorizedAccessComponent } from './Components/UnauthorizedAccess/Unauthorized.component';
import { MenuType, MenuModel } from './Components/NavBar/navbar.metadata';
import * as Constants from './Shared/globalconstants';
import { appService } from './Services/app.service';
import { FeedComponent } from './Components/Feed/Feed.component';
import { RecipeSppComponent } from './Components/RecipeSPPTemp/recipespp.component';
import { DataViewerComponent } from './Components/data-viewer/data-viewer.component';
//import { TestCreationComponent } from './Components/TestCreation/TestCreation.component';
//import { RunFeedComponent } from './Components/Run/Run-Feed/RunFeed.component';
//import { GeneralInfoComponent } from './Components/Run/GeneralInfo/GeneralInfo.component';

export function get_session(appService: appService) {
  return () => new Promise((resolve, reject) => {
    appService.getSessionData()
      .subscribe((data: any) => {
        debugger;
        if (data != null) {
        if (data.User != null && data.User != undefined) {
          let menu: MenuModel[] = [];
            Constants.SetUserSession(data.User);
            if (data.Privileges != null && data.Privileges != undefined) {
              Constants.SetUserPrivileges(data.Privileges);
            }
            if (data.UnitGroups != null && data.UnitGroups != undefined) {
              Constants.SetUnitGroups(data.UnitGroups);
            }
            if (data.UomVariables != null && data.UomVariables != undefined) {
              Constants.SetUomVariables(data.UomVariables);
            }
            if (data.AvailableApplications != undefined && data.AvailableApplications != null) {
              Constants.SetApplications(data.AvailableApplications);
            }
            if (data.AppRoles != undefined && data.AppRoles != null) {
              Constants.SetAppRoles(data.AppRoles);
            }
            if (data.Function_UOMs != undefined && data.Function_UOMs != null) {
              Constants.SetFunctionUOMs(data.Function_UOMs);
            }
          }
        }
        resolve();
      },
        (err: any) => {
          reject();
        });
  });
}

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AuthenticationComponent,
    messageModalComponent,
    UnauthorizedAccessComponent,
    FeedComponent,
    RecipeSppComponent,
    DataViewerComponent,
  ],
  imports: [
      BrowserModule,
      routing,
      BrowserAnimationsModule,
      MultiSelectModule,
      CalendarModule,
      NgbModule.forRoot(),
      TagCloudModule,
      MatInputModule,
      MatDatepickerModule,
      HttpClientModule,
      sharedModule],
  entryComponents: [
      messageModalComponent
  ],
  providers: [
      NgbActiveModal,
      appRoutingProviders,
      UserService,
      messageModalUtility,
      MatDatepickerModule,
      MatNativeDateModule,
      RouterAuthService,
      { provide: APP_INITIALIZER, useFactory: get_session, deps: [appService], multi: true }
  ],
  bootstrap: [
      AppComponent
  ]
})
export class AppModule {


}
