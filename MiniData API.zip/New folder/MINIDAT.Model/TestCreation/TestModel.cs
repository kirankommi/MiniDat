﻿/*
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	TestModel.cs
 	Project Title			:	MINIS
	Author(s)				:	Shankar
	Created Date			:	3 Jan 2012
	Requirements Tag		:	FR 4.1
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using System;
using System.Collections.Generic;
using Calculations;
using LIMSService.Interface;
using MINIDAT.Model.Manage;
using Newtonsoft.Json;

//C:\Project Source Code\MINIDAT\Development\MINIDAT.Model\Manage\PITag\PITagModel.cs
namespace MINIDAT.Model.Test
{   
    /// <summary>
    /// TestModel
    /// </summary>
  public class TestModel
    {
       
        public string Plant { get; set; }      
        public int? Run { get; set; }       
        public int? Test { get; set; }     
        public DateTime? TestStartTime { get; set; }
        public DateTime? TestEndTime { get; set; }   
        public string TestComment { get; set; }      
        public string LineOut { get; set; }     
        public KeyValue WeightCheckQuality { get; set; }
        public string WCName { get; set; }
        public string PIData { get; set; }
        public string LIMSData { get; set; }
        public DateTime? PiReTransmitTime { get; set; }
        public DateTime? LimsReTransmitTime { get; set; }
        public DateTime? LastCalculatedOn { get; set; }
        public bool IsInitialLoad { get; set; }
        public string AutoGenerateInd { get; set; }
        public int RunTestIdsq { get; set; }
        public string PlantLocation { get; set; }
        //public string MaxMeterScaleMsr { get; set; }
        //public int RecordsFetched { get; set; }


    }
    public class RunFlyoutModel
    {
        public string Plantcode { get; set; }
        public int RunNumber { get; set; }
    }
    public class TestSearchModel
    {
        
        private IList<KeyValue> _wcQuality = new List<KeyValue>();
        public IList<KeyValue> lstwcQuality { get { return _wcQuality; } }

        private List<RunFlyoutModel> run = new List<RunFlyoutModel>();
        public List<RunFlyoutModel> lstRuns { get { return run; } }

        private IList<TestModel> _tests = new List<TestModel>();
        public IList<TestModel> lstTests { get { return _tests; } }

        public IList<PlantModel> _plant = new List<PlantModel>();
        public IList<PlantModel> lstPlants { get { return _plant; } }
        public int RecordsFetched { get; set; }

    }

    public class TestParameter : ITestParameter
    {
        public string Plant { get; set; }
        public string Run { get; set; }
        public string Test { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string ServerName { get; set; }
        public string TimeZone { get; set; }
    }
}
