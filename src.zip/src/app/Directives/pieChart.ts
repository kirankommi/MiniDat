﻿import { Component, OnInit, Input, AfterViewInit} from '@angular/core';
import { Chart } from 'chart.js';

@Component({
    selector: 'cust-pieChart',
    templateUrl: 'pieChart.html'
})

export class PieChartDirective implements OnInit, AfterViewInit {
    @Input() chartdata: any = [];

    chart: any;
    constructor() {
        Chart.pluginService.register({
            beforeDraw: function (chart) {
                if (chart.data.datasets && chart.data.datasets.length > 0) {
                    let total = chart.data.datasets.map(q => (q.data as number[]).reduce((sum, current) => sum + current)).reduce((sum, current) => sum + current);
                    //if (chart.config.options.elements.center) {
                    //Get ctx from string
                    var ctx = chart.ctx;

                    //Get options from the center object in options
                    var centerConfig = {
                        text: '121\n343',
                        color: '#000000', // Default is #000000
                        fontStyle: 'HoneywellSans-medium', // Default is Arial
                        sidePadding: 20 // Defualt is 20 (as a percentage)
                    };
                    var fontStyle = centerConfig.fontStyle || 'Arial';
                    var txt = centerConfig.text;
                    var color = centerConfig.color || '#000';
                    var sidePadding = centerConfig.sidePadding || 20;
                    var sidePaddingCalculated = (sidePadding / 100) * (chart['innerRadius'] * 2)
                    //Start with a base font of 30px
                    ctx.font = "30px " + fontStyle;

                    //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
                    var stringWidth = ctx.measureText(txt).width;
                    var elementWidth = (chart['innerRadius'] * 2) - sidePaddingCalculated;

                    // Find out how much the font can grow in width.
                    var widthRatio = elementWidth / stringWidth;
                    var newFontSize = Math.floor(30 * widthRatio);
                    var elementHeight = (chart['innerRadius'] * 2);

                    // Pick a new font size so it will not be larger than the height of label.
                    var fontSizeToUse = Math.min(newFontSize, elementHeight);

                    //Set font settings to draw it correctly.
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
                    var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
                    ctx.font = (fontSizeToUse - fontSizeToUse * 0.3).toString() + "px " + fontStyle;
                    ctx.fillStyle = color;

                    //Draw text in center
                    ctx.fillText('Total', centerX, centerY - newFontSize / 2);
                    ctx.font = fontSizeToUse + "px " + fontStyle;
                    ctx.fillText(total.toString(), centerX, centerY + newFontSize / 2);
                }
                //}
            }
        });
        this.chart
    }

    ngOnInit() {
        this.chart = new Chart('canvas', {
            type: 'doughnut',
            data: this.chartdata,
            options: {
                legendCallback: function (chart) {

                    var text = [];
                    var data = chart.data;
                    var datasets = data.datasets;
                    var labels = data.labels;

                    if (datasets.length) {
                        for (var i = 0; i < datasets[0].data.length; ++i) {
                            text.push('<div><div style="float:left;margin-top:7px;position:relative;width:10px;height:10px;background-color:' + datasets[0].backgroundColor[i] + '"></div>');
                            if (labels[i]) {
                                text.push('<div style="left: 10px;position: relative;">' + labels[i] + ' : ' + datasets[0].data[i] + '</div></div>');
                                text.push('<div><div style="float:left;margin-top:7px;position:relative;width:10px;height:10px;"></div><div style="left: 10px;position: relative;">' + chart.data.additionaLabels[0] + ' : ' + chart.data.additionalData[i] + '</div></div>');
                            }
                        }
                    }
                    return text.join('');
                },
                legend: {
                    display: false,
                    position: 'right'
                }
            }
        });
    }


    ngAfterViewInit() {
        document.getElementById('chartjs-legend').innerHTML = this.chart.generateLegend();
        var tt = this.chart.generateLegend();
    }
}
