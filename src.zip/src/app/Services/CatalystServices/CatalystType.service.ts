﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystTypeModel, KeyValue } from '../../Models/Catalyst/CatalystTypeModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystTypeService {
    private getCatalystTypedata = "/CatalystType/SearchCatalystTypedata/";
    private getActiveCatalystTypeinfo = "/CatalystType/GetActiveCatalystTypedata/";
    private saveCatalystTypedata = "/CatalystType/SaveCatalystTypeInformation/";
    private deleteCatalystTypedata = "/CatalystType/DeleteCatalystTypeInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystTypeInformation(catalystType: CatalystTypeModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystType, this.getCatalystTypedata);
    }

    saveCatalystTypeInformation(catalystType: CatalystTypeModel)
    {
        return this.httpaction.post(catalystType, this.saveCatalystTypedata);
    }

    deleteCatalystType(catalystType: CatalystTypeModel)
    {
        debugger;
        return this.httpaction.post(catalystType, this.deleteCatalystTypedata);
    }    
}
