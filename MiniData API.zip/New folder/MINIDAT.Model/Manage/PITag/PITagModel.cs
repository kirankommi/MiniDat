﻿using System.Collections.Generic;

namespace MINIDAT.Model.Manage
{
    public class PITagModel
    {

        public string PITagID { get; set; }
        public string Plantcode { get; set; }        
        public string LogsheetReadingLabel { get; set; }
        public string PITagName { get; set; }
        public double? MinRange { get; set; }
        public double? MaxRange { get; set; }
        public int? DisplayOrder { get; set; }
        public KeyValue PIValueType { get; set; }
        //Search Parameters        
        public string ValueTypeName { get; set; }
        public string CanDelete { get; set; }       

    }
    public class PlantModel
    {
        public string Plantcode { get; set; }
        public string Location { get; set; }
        public string BuildingNumber { get; set; }       
    }

        public class PITagSearchModel
    {
        private IList<KeyValue> _readingTypes = new List<KeyValue>();
        public IList<KeyValue> lstReadingTypes { get { return _readingTypes; } }

        private IList<KeyValue> status = new List<KeyValue>();
        public int RecordsFetched { get; set; }
        public IList<KeyValue> Status { get { return status; } }
        //public IList<RoleModel> Roles { get; set; }

        private IList<PITagModel> _piTags = new List<PITagModel>();
        public IList<PITagModel> lstPITags { get { return _piTags; } }

        private IList<ApplicationModel> _applications = new List<ApplicationModel>();
        public IList<ApplicationModel> ApplicationList { get { return _applications; } }

        private IList<PlantModel> _lstPlants = new List<PlantModel>();
        public IList<PlantModel> lstPlants { get { return _lstPlants; } }
    }
}
