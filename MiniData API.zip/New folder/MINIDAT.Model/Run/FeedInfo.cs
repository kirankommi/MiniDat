﻿using System.Collections.Generic;
using MINIDAT.Model.Feed;

namespace MINIDAT.Model.Run
{
    public class Plant
    {
        public string Name { get; set; }
        public string Key { get; set; }
        public string Location { get; set; }
    }
    public class FeedModel
    {
        public int? FeedID { get; set; }
        public double TotalBlendWeight { get; set; }
        public double TotalBlendWeightpct { get; set; }
        public string UOPNumber { get; set; }
        public string Name { get; set; }
        public double? H2InFeed { get; set; }
        public double? Density { get; set; }
        public double? API { get; set; }
        public double? RelativeDensity { get; set; }
        public double? SulfurInSweetFeed { get; set; }
        public double? NitrogenInSweetFeed { get; set; }
        public double? SulfurInFeedBlend { get; set; }
        public double? NitrogenInFeedBlend { get; set; }
        public string StatusName { get; set; }
        public KeyValue StatusCode { get; set; }
        public List<FeedBlend> Blendcomponents { get; set; }
        public List<AnalysisMethod> AnalysisMethods { get; set; }

        public List<StoichiometryModel> DopantStoichiometry { get; set; }

    }
    public class RunPoolModel
    {
        public int RunID { get; set; }
        public string RunNumber { get; set; }
        public string Plant { get; set; }
        public string Specialist { get; set; }
        public string FromCreated { get; set; }
        public string ToCreated { get; set; }
        public string Status { get; set; }
    }
    public class AnalysisMethod
    {
        public int AnalysisMethodId { get; set; }
        public string AnalysisMethodName { get; set; }
        public string AnalysisMethodNum { get; set; }
        public string SourceName { get; set; }
        public List<MethodComponent> AnalyticalComponents { get; set; }
    }
    public class MethodComponent
    {
        public string ComponentName { get; set; }
        public double ComponentAverageValue { get; set; }
        public string UOM { get; set; }
    }
    public class FeedBlend
    {
        public int ComponentId { get; set; }
        public string ComponentName { get; set; }
        public decimal? Amountadded { get; set; }
        public decimal? Weightpct { get; set; }
        public string UOPNumber { get; set; }
    }
    public class StoichiometryModel
    {
        public string COMPONENT_NAME { get; set; }
        public double? COMP_MASS_H2S_COMP_MSR { get; set; }
        public double? COMP_MASS_SN_COMP_MSR { get; set; }       
        public string DOPANT_TYPE { get; set; }
        public double? FEED_ADJUSTMNT_FACTOR_MSR { get; set; }
    }
}
