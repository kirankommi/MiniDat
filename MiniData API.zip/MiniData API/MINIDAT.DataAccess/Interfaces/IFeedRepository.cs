﻿using MINIDAT.Model.Feed;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IFeedRepository : ICRUDRepository<FeedModel>
    {
        FeedSearchModel GetFeedData(FeedModel feed);
        string DeleteFeedData(FeedModel feed);
        void SaveFeedData(FeedModel _feed, string userId);      

    }
}
