﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model.FileBrowser;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MINIDAT.DataAccess.Repository.FileBrowser
{
    
    public  abstract class FileBrowserRepository
    {
        private IDatabase _db;
        public FileBrowserRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public abstract List<FileModel> BrowseFiles(int? id = null);
        public abstract FileModel DownloadFiles(int id );
    }
    public class ProjectFileBrowserRepository : FileBrowserRepository
    {
        private IDatabase _db;
        public ProjectFileBrowserRepository(IDatabase dbInstance):base(dbInstance)
        {
            _db = dbInstance;
        }
        public override List<FileModel> BrowseFiles(int? id=null)
        {
            List<FileModel> docs = new List<FileModel>();
            IDictionary parameters = new Dictionary<string, object>();            
            parameters.Add("Project_Id", id);
            using (IDbCommand cmd = _db.CreateCommand("Get_Project_Browse_All_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    FileModel doc = new FileModel();
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.FileType = "Project";
                    doc.FileTypeId = Convert.ToInt32(reader["PROJECT_ID"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileSize =Math.Round(Convert.ToDecimal(reader["SIZE"])>1024? Convert.ToDecimal(reader["SIZE"])/1024: Convert.ToDecimal(reader["SIZE"]),2);
                    doc.SizeUnit = Convert.ToDecimal(reader["SIZE"]) > 1024 ?"KB": "Bytes";
                    doc.LastUpdatedDateTime = Convert.ToString(reader["LASTUPDTEDATE"]);
                    //doc.FileData = (byte[])reader["DATA"];
                    docs.Add(doc);
                }
                reader.Close();
                return docs;
            }
        }
        public override FileModel DownloadFiles(int id)
        {
            FileModel doc = new FileModel();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("FILE_ID", id);
            using (IDbCommand cmd = _db.CreateCommand("Get_Project_Download_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {

                    doc.RowId = Convert.ToInt32(reader["RowId"]);                 
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileData = (byte[])reader["DATA"];

                }
                reader.Close();
                return doc;
            }
        }
    }

    public class RecipeSppBrowserRepository : FileBrowserRepository
    {
        private IDatabase _db;
        public RecipeSppBrowserRepository(IDatabase dbInstance):base(dbInstance)
        {
            _db = dbInstance;
        }
        public override List<FileModel> BrowseFiles(int? id = null)
        {
            List<FileModel> docs = new List<FileModel>();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("Project_Id", id);
            using (IDbCommand cmd = _db.CreateCommand("Get_RecipeSpp_Browse_All_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    FileModel doc = new FileModel();
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.FileType = "SPP";
                    //doc.FileTypeId = Convert.ToInt32(reader["FileTypeId"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileSize = Math.Round(Convert.ToDecimal(reader["SIZE"]) > 1024 ? Convert.ToDecimal(reader["SIZE"]) / 1024 : Convert.ToDecimal(reader["SIZE"]), 2);
                    doc.SizeUnit = Convert.ToDecimal(reader["SIZE"]) > 1024 ? "KB" : "Bytes";
                    doc.LastUpdatedDateTime = Convert.ToString(reader["LASTUPDTEDATE"]);
                    //doc.FileData = (byte[])reader["DATA"];
                    docs.Add(doc);
                }
                reader.Close();
                return docs;
            }
        }
        public override FileModel DownloadFiles(int id)
        {
            FileModel doc = new FileModel();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("FILE_ID", id);
            using (IDbCommand cmd = _db.CreateCommand("Get_RecipeSpp_Download_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                DateTime dtNow = DateTime.Now;
                string dtStrNow = dtNow.ToString("dd-MMM-yyyy HH-mm-ss").Replace(' ', '_');
                while (reader.Read())
                {

                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileData = (byte[])reader["DATA"];

                    if (!string.IsNullOrEmpty(doc.FileName))
                    {
                        string path = doc.FileName;
                        string fileName = path.Substring(path.LastIndexOf(((char)92)) + 1);
                        int index = fileName.LastIndexOf('.');
                        string onlyName = fileName.Substring(0, index);
                        string fileExtension = fileName.Substring(index + 1);
                        doc.FileName = onlyName +"_"+ dtStrNow +"."+ fileExtension;
                    }
                }
                reader.Close();
                return doc;
            }
        }
    }
}
