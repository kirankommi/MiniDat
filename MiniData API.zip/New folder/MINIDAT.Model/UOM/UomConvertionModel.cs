﻿namespace MINIDAT.Model.UOM
{
    using MINIDAT.Framework.Regex;
    using MINIDAT.Model;
    using System;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Newtonsoft.Json;
    using Session;

    public class UomConvertionModel
    {
        private enum doubleConst {NAN=999997, NA= 999996, PositiveInfinity= 999999, NegativeInfinity=-999999 }
        private Unit displayUnit;
        private string precision;
        private UnitGroup group;
        private double? baseValue;
        private double? displayValue;
        private string displayText;

        [JsonIgnore,XmlIgnore]
        public UnitGroup Group
        {
            get { return group; }
            set { group = value; }
        }


        [JsonIgnore, XmlIgnore]
        

        public Unit DisplayUnit
        {
            get
            {
                if (displayUnit == null)
                {
                    displayUnit = new Unit();
                }
                return displayUnit;
            }
            set
            {
                displayUnit = value;
                if (baseValue == null)
                {
                    displayValue = null;
                }
                else
                {
                    displayValue = DisplayUnit.convertToTargetunit(baseValue);

                }             
            }
        }
        //Constructor for xml serialization
        public UomConvertionModel()
        {

        }

        [JsonIgnore]
        public string Precision
        {
            get
            {
                //return "0.000";
                return precision;
            }
            set
            {
                precision = value;
            }
        }

        public UomConvertionModel(string variableName)
        {
            UomVariable variable = UserSession.Instance.GetVariableByName(variableName);
            this.Group = UserSession.Instance.UnitGroups.FirstOrDefault(q => q.UnitGroupName == variable.UnitGroupName);
            if (Group != null)
            {
                this.DisplayUnit = Group.Units.FirstOrDefault(q => q.UnitName == variable.DefaultUnitName);
                this.Precision = GetPrecision(variable.Precision);
            }
        }

        public string GetPrecision(int? precision)
        {
            StringBuilder strPrecision = new StringBuilder("0.000000");

            if (precision != null && precision > 0)
            {
                strPrecision.Clear();
                strPrecision.Append("0.");
                int max = Convert.ToInt32(precision);
                for (int i = max; i > 0; i--)
                {
                    strPrecision.Append("0");
                }
            }

            return strPrecision.ToString();
        }

        public double? DisplayValue
        {
            get
            {
                return displayValue;
            }
            set
            {
                displayValue = value;
                if (value.HasValue && DisplayUnit != null)
                {
                    this.baseValue = displayUnit.convertToBaseUnit(value);
                }
            }
        }


        public double? BaseValue
        {
            get
            {
                return baseValue;
            }
            set
            {
                baseValue = value;
                if (value.HasValue && DisplayUnit != null)
                {
                    this.displayValue = DisplayUnit.convertToTargetunit(value);
                }
            }
        }

        public string DisplayText
        {
            get
            {
                if (displayValue.HasValue)
                {
                    displayText = displayValue.Value.ToString(Precision);

                }
                return displayText;
            }

            set
            {
                //Regex validation for double
                string strRegEx = @"^\-?\d*\.?\d*$";
                string strRegVal = value;
                if (strRegVal == null)
                {
                    strRegVal = string.Empty;
                }
                if (!System.Text.RegularExpressions.Regex.IsMatch(Convert.ToString(strRegVal), strRegEx))
                {
                    displayText = value;
                    if (displayValue != null)
                    {
                        BaseValue = DisplayUnit.convertToBaseUnit(displayValue);
                    }
                    else
                    {
                        displayText = string.Empty;
                    }

                }
                else
                {
                    double d = 0;
                    //this will not validate ur regex, fix this in regex
                    if (value == ".")
                    {
                        value = "0.0";
                    }
                    if (double.TryParse(value, out d))
                    {
                        DisplayValue = d;
                        if (displayValue.HasValue)
                        {
                            displayText = displayValue.Value.ToString(Precision);

                        }
                    }
                    else
                    {
                        DisplayValue = null;
                        displayText = value;
                    }
                }
            }
        }

        private UomVariable uomVar;

        public UomVariable UomVariable
        {
            get { return uomVar; }
            set { uomVar = value; }
        }

    }
}
