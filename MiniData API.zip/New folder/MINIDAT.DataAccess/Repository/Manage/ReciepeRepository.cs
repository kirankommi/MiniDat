﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Dynamic;
using System.IO;
using Newtonsoft.Json;
using MINIDAT.Model;
using MINIDAT.DataAccess.Interfaces;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using MINIDAT.Model.Manage.Mode;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class ReciepeRepository : IReciepesRepository
    {
        /// <summary>
        /// 
        /// </summary>
        private IDatabase _db;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbInstance"></param>
        public ReciepeRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<dynamic> getReciepesTemplateData(string mode)
        {
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Get_RECIEPE_ModeTemplateValues_sp]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("@mode", mode);

                _db.CreateParameters(command, parameters);

                using (reader = _db.ExecuteReader(command))
                {
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }
                }
            }
        }
        private dynamic GetDynamicData(IDataReader reader)
        {
            var expandoObject = new ExpandoObject() as IDictionary<string, object>;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                expandoObject.Add(reader.GetName(i), reader[i]);
            }
            return expandoObject;
        }

    }
}

