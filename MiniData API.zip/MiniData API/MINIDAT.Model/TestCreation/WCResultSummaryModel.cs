﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
  public class WCResultSummaryModel
    {
        public string Parameter { get; set; }
        public string UOM { get; set; }
        public string DefaultUOM { get; set; }
        public string ParamDisplayOrder { get; set; }
        public string Value { get; set; }

    }
}
