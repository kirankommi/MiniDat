export class CalculateAllModel{
    Plant: string;
    Run: number;
    User_Id:string;
}
export class CalculateAllTableModel{
    WC_Number:number;
    Status:string;
    Remarks:string;
}