import { Injectable } from '@angular/core';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import { RequestOptions, URLSearchParams } from '@angular/http';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { KeyValue } from '../../Models/usermodel';


@Injectable()
export class minisQService {
  private masterDataUrl: string = "/MINISQ/GetMasterData";
  private masterStudiesUrl: string = "/MINISQ/GetStudies";
  // private reOrderPlantRunsUrl: string = "/MINISQ/ReOrderPlantRuns";
  private reOrderRunsUrl: string = "/MINISQ/ReOrderRuns";
  private saveColumnPreferencesUrl: string='/MINISQ/SaveColumnPreferences';
  constructor(private httpAction: HttpActionService) {

  }

  getMasterData() {
    return this.httpAction.get(this.masterDataUrl, Constants.options);
  }
  getStudiesData() {
    return this.httpAction.get(this.masterStudiesUrl, Constants.options);
  }
  reOrderPlantRuns(reOrderedRuns: any) {
    return this.httpAction.post(reOrderedRuns, this.reOrderRunsUrl);
  }
  saveColumnPreferences(columns: any) {
    debugger;
    return this.httpAction.post(columns, this.saveColumnPreferencesUrl);
  }
}

