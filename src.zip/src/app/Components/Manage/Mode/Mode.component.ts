﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { ModeService } from '../../../Services/Mode.service';
import { ModeModel, KeyValue } from '../../../models/ModeModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({
    //moduleId: module.id,
    templateUrl: 'Mode.component.html',
    providers: [ModeService, AlertMessage, HttpActionService, ConfirmationService]
})

export class ModeComponent implements OnInit {
    @Input()
    propertyType: string;
    title: string;
    LIMSOpNameDisabled: boolean = true;
    defaultUnit: string;
    @Input()
    LimsOpComponentList: any[];
    IsallowedSave: boolean;
    totalRecords: number;
    mode: ModeModel;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    plantListCols: any[] = [];
    lstPlants: any;
    isCollapsed = false;
    setStyles: boolean;
    cloneIconPath: string;
    insertUpdate: boolean = false;
    @ViewChild('roleTable') dataTableComponent: any;
    selComponentType: string;
    applicationList: any;
    lhsvUomObj: any = {};
    pressureUomObj: any = {};
    scfbUomObj: any = {};
    modeList: any;
    modeTypes: KeyValue[];
    ControlTypes: KeyValue[];
    SulfidingTypes: KeyValue[];
    sortField: string;
    sortOrder: number;
    selectedApplicationCode: string;
    IsallowedChange: boolean = true;
    NotModifiable: boolean = false;
    flyoutHeader: string = "Modes";
    pHolder: string = "Mode#";
    modeSaved: string = "Mode Details Saved Successfully";
    modeDeleted: string = "Mode Deleted Successfully";
    LocalAccess: boolean = false;
    check: boolean = false;


    constructor(private modeService: ModeService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.cloneIconPath = Constants.cloneIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    ngOnInit() {
        this.mode = new ModeModel();
        this.mode.Description = null;
        this.getModes();
        this.title = Constants.ManageMode;
    }


    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse() {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any) {
        debugger;
        this.mode.ModeNumber = event.data.ModeNumber;
        this.mode.Description = event.data.Description;
        this.mode.ModeType = event.data.ModeType;
        this.mode.ControlName = event.data.ControlName;
        this.mode.SulfidingType = event.data.SulfidingType;
        this.mode.Pressure = event.data.Pressure;
        this.mode.LHSV = event.data.LHSV;
        this.mode.SCFB = event.data.SCFB;
        this.mode.Conditions = event.data.Conditions;
        this.mode.ModeID = event.data.ModeID;

        if (event.data.CanEdit == 'N') {
            this.LocalAccess = true;
            //this.IsallowedChange = false;
            this.IsallowedSave = false;
        }
        else {
            this.LocalAccess = false;
            //this.IsallowedChange = false;
            this.IsallowedSave = true;
        }
    }

    onRowUnselect($event: any) {
        debugger;
        this.LocalAccess = false;
    }
    updateDescUOMChange(event, param) {
        debugger;
        if (!this.mode.Description) {
            this.mode.Description = "";
        }
        if (this.mode.Conditions != undefined && isNaN(parseInt(this.mode.Conditions.toString()))) { this.mode.Conditions = null }
        else if (this.mode.Conditions) { { this.mode.Conditions = parseInt(this.mode.Conditions.toString()) } }

        debugger;
        this.mode.Description = (this.mode.ModeType == Constants.Select ? "" : this.mode.ModeType + " " + "Mode") + (this.mode.ControlName == Constants.Select ? "" : ", " + this.mode.ControlName + " " + "Control")
            + (this.mode.SulfidingType == Constants.Select ? "" : ", " + this.mode.SulfidingType + " " + "Sulfided")
            + (this.pressureUomObj.displayValue == undefined ? "" : ", " + Math.floor(this.pressureUomObj.displayValue) + " " + this.pressureUomObj.defaultUnitText)
            + (this.lhsvUomObj.displayValue == undefined ? "" : ", " + parseFloat(this.lhsvUomObj.displayValue).toFixed(1) + " " + "LHSV")
            + (this.scfbUomObj.displayValue == undefined ? "" : ", " + Math.floor(this.scfbUomObj.displayValue) + " " + this.scfbUomObj.defaultUnitText)
            + (this.mode.Conditions == undefined ? "" : ", " + "2 WCs Each at " + this.mode.Conditions);

        if (this.mode.ControlName != Constants.Select && this.mode.ControlName == "NIR Conv" && (this.mode.Conditions != null || this.mode.Conditions != undefined)) {
            this.mode.Description = this.mode.Description + " Conversions";
        }
        else if (this.mode.ControlName != Constants.Select && this.mode.ControlName == "Temperature" && (this.mode.Conditions != null || this.mode.Conditions != undefined)) { this.mode.Description = this.mode.Description + " Temperatures"; }

    }

    getModes() {
        debugger;
        this.modeService.getModeInformatin(this.mode)
            .subscribe(
                (data: any) => {
                    debugger;
                    this.modeList = data.lstModes;
                    this.applicationList = data.ApplicationList;
                    this.ControlTypes = data.lstControlNames;
                    this.modeTypes = data.lstModeTypes;
                    this.SulfidingTypes = data.lstSulfidingTypes;
                    this.totalRecords = data.RecordsFetched;
                    if (this.mode.ControlName == undefined || this.mode.ControlName == null) { this.mode.ControlName = Constants.Select; }
                    if (this.mode.SulfidingType == undefined || this.mode.SulfidingType == null) { this.mode.SulfidingType = Constants.Select; }
                    if (this.mode.ModeType == undefined || this.mode.ModeType == null) { this.mode.ModeType = Constants.Select; }


                    this.applicationList = data.ApplicationList;

                    if (data.ApplicationList.length > 0) {
                        this.selectedApplicationCode = data.ApplicationList[0].ApplicationId;
                    }
                    else {
                        this.selectedApplicationCode = "5";
                    }

                },
                err => { }
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onAppchange() {
        //
    }

    SaveMode() {
        // debugger;
        let response: any;
        if (this.isDataValid()) {
            let conditionsRegexPattern = /^[0-9]*$/;
            if (!conditionsRegexPattern.test(this.mode.Conditions.toString())) {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'Invalid Conditions', detail: "Only Numeric values are allowed !" })
                return false;
            }
            this.mode.AppCode = this.selectedApplicationCode;
            this.mode.CanEdit = "Y";
            this.modeService.saveModeInformation(this.mode)
                .subscribe(
                    (data: any) => {
                        debugger;
                        if (data == Constants.Success) {
                            this.onReset()
                            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.modeSaved });
                            this.appComponent.GetUserData();
                        }
                    },
                    err => { }
                    // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(mode: ModeModel) {
        this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteModeInfo(mode); }
        });
    }
    onClone(mode: ModeModel) {
        debugger;
        this.messageService.show(Constants.Confirm, Constants.ConfirmCloneMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.cloneModeInfo(mode); }
        });
    }
    cloneModeInfo(mode: ModeModel) {
        let tempMode = Math.max(...this.modeList.map(o => o.ModeNumber), 0);
        tempMode += 1;
        mode.ModeNumber = tempMode.toString();
        this.mode = mode;
        this.SaveMode();
    }
    deleteModeInfo(mode: ModeModel) {
        debugger;
        mode.AppCode = this.selectedApplicationCode;

        this.modeService.deleteMode(mode)
            .subscribe(
                (data: any) => {
                    if (data == "Delete") {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.modeDeleted });
                    }
                    else {
                        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    updateDesc() {
        debugger;
        this.mode.Description = (this.mode.ModeType == Constants.Select ? " " : this.mode.ModeType) + "  " + "Mode" +
            (this.mode.ControlName == Constants.Select ? " " : this.mode.ControlName) + "  " + "Control" +
            (this.mode.SulfidingType == Constants.Select ? " " : this.mode.SulfidingType) + "  " + "Sulfided" +
            "2 WCs Each at" + (this.mode.Conditions == undefined ? " " : this.mode.Conditions) + "  " + "Sulfided"
    }

    onReset() {
        debugger;
        this.mode = new ModeModel();
        this.sortField = "";
        this.sortOrder = 0;
        this.mode.LHSV = null;
        this.mode.Pressure = null;
        this.mode.SCFB = null;
        this.mode.Conditions = null;

        this.lhsvUomObj = { unitGroupName: 'FREQ/SPACE VELOCITY', baseValue: null, baseupdate: true };
        this.pressureUomObj = { unitGroupName: 'PRESSURE', baseValue: null, baseupdate: true };
        this.scfbUomObj = { unitGroupName: 'GAS TO LIQUID RATIO', baseValue: null, baseupdate: true };
        this.getModes();
        //this.dataTableComponent.reset();
        this.selectedApplicationCode = "5";
        this.LocalAccess = false;
        this.check = false;
    }

    isDataValid() {
        debugger;
        if (this.mode == null || !this.mode.ModeNumber || this.mode.ControlName == "Select" || this.mode.SulfidingType == "Select" || this.mode.ModeType == "Select" || !this.mode.Description
            || (this.mode.LHSV == null || this.mode.LHSV == undefined || this.mode.LHSV == 0)
            || (this.mode.Pressure == null || this.mode.Pressure == undefined || this.mode.Pressure == 0)
            || (this.mode.SCFB == null || this.mode.SCFB == undefined)
            || (this.mode.Conditions == null || this.mode.Conditions == undefined)
        ) {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string) {
        if (!this.IsallowedSave || CanEdit === 'N') {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;
    }
    getClonePath(CanClone: string) {
        return this.cloneIconPath;
    }
    ngDoCheck() {
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1 && this.LocalAccess != true) {
                for (let i in Constants.UserPrivileges) {
                    //if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "ROLE" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") 
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000012" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                        
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }

    }

}
