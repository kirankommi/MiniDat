﻿using LIMSService.Interface;
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.Catalyst;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers.CatalystControllers
{
    public class CatalystController : AppController
    {

        [HttpGet,ActionName("GetCatalystLite")]
        public HttpResponseMessage GetCatalystLite()
        {
            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _catalystRepository.GetCatalystLite());

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystSearchError.ToString());
            }
        }

        [HttpGet, ActionName("GetCatalystDetails")]
        public HttpResponseMessage GetCatalystDetails()
        {
            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _catalystRepository.GetCatalystDetails());

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystSearchError.ToString());
            }
        }


        [HttpPost, ActionName("SaveCatalyst")]
        public HttpResponseMessage SaveCatalystDetails(CatalystModel catalyst)
        {
            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                int cnt = _catalystRepository.SaveCatalyst(catalyst);
                //get lims result
                if (catalyst.LIMSs != null && catalyst.LIMSs.Count > 0)
                {
                    UploadLimsDataForSampleIDs(catalyst.LIMSs.Select(x => x.SampleId).ToList());
                }
                return Request.CreateResponse(HttpStatusCode.OK, catalyst.CatalystId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message.Contains("Cannot insert duplicate key"))
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystSaveDuplicateKeyError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystSaveError.ToString());
                }
                       
            }
        }

        [HttpPost, ActionName("SearchCatalystDetails")]
        public HttpResponseMessage SearchCatalystDetails(CatalystModel catalyst)
        {
            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _catalystRepository.SearchCatalystDetails(catalyst));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystSearchError.ToString());
            }
        }





        [HttpGet, ActionName("DeleteCatalyst")]
        public HttpResponseMessage DeleteCatalyst(int catalystId)
        {

            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _catalystRepository.DeleteCatalyst(catalystId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "CatalystInUseDeleteError")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystInUseDeleteError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.CatalystDeleteError.ToString());
                }
            }
        }

        [HttpGet, ActionName("GetCatalystSampleIds")]
        public HttpResponseMessage GetCatalystSampleIds(int catalystId)
        {

            CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _catalystRepository.GetCatalystSampleIds(catalystId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);                
            }
        }


        [HttpGet]
        public async Task<HttpResponseMessage> GetLimsSampleIdsByUserSample(string UOPNumber, int catalystId=0)
        {
            try
            {
                CatalystRepository _catalystRepository = new CatalystRepository(new MINIDATDatabase());
                var samplesToAdd = new List<CatalystLimsSample>();
                //var feed = _catalystRepository.GetById(catalystId);
                if (!string.IsNullOrEmpty(UOPNumber))
                {
                    LIMSService.Service.LIMSServiceDataAccess daccess = new LIMSService.Service.LIMSServiceDataAccess(DATSource.MINDAT);
                    using (LIMSService.Service.LIMSService client = new LIMSService.Service.LIMSService(daccess, DATSource.MINDAT))
                    {
                        var sampleIDs = client.GetSampleIDsByUserSample(UOPNumber);
                        if (sampleIDs != null)
                        {
                            var sampleIDlist = sampleIDs.OfType<string>().ToList();

                            //sampleIDlist.RemoveAll(x => feed.FeedLIMS.Any(y => y.SampleID.Equals(x)));
                            sampleIDlist.ForEach((sampleid) =>
                            {
                                CatalystLimsSample fL = new CatalystLimsSample();
                                fL.CatalystId = catalystId;
                                fL.SampleId = sampleid;
                                //fL.IsDefault = true;
                                //fL.LIMSDataUploadIndicator = "N";
                                //fL.CreatedByUserID = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
                                //fL.Is_Lims_Smpl_Dissociated = false;
                                //fL.SampleType = "LIMS";
                                samplesToAdd.Add(fL);
                            });                            
                        }
                    }
                }
               
                return Request.CreateResponse(HttpStatusCode.OK, samplesToAdd);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        private bool UploadLimsDataForSampleIDs(IList<string> sampleids)
        {
            var isUploaded = false;
            try
            {
                if (sampleids != null && sampleids.Any())
                {
                    ISampleParameter sampleParamObj = new LIMSService.Service.SampleParameter();
                    sampleParamObj.SampleIds = (List<string>)sampleids;
                    LIMSService.Service.LIMSServiceDataAccess daccess = new LIMSService.Service.LIMSServiceDataAccess(DATSource.MINDAT);
                    using (LIMSService.Service.LIMSService client = new LIMSService.Service.LIMSService(daccess, DATSource.MINDAT))
                    {
                        client.ImportCatalystSampleDataAsync(sampleParamObj, loadWithResult: false);
                        isUploaded = true;
                    }
                }
                return isUploaded;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [HttpGet]
        public HttpResponseMessage GetLimsComponents(string catalystId, string analysisId, string methodSource)
        {
            try
            {
                var limsResult = new List<CatalystLimsResult>();
                if (Model.Session.UserSession.Instance == null)
                {
                    using (AppController app = new AppController())
                    {
                        SetSession(false);
                    }
                }
                if (Model.Session.UserSession.Instance != null)
                {
                   
                    CatalystRepository limsResultsRepository = new CatalystRepository(new MINIDATDatabase());
                    switch (methodSource)
                    {
                        case "Property":
                            limsResult = limsResultsRepository.GetCatalystPhyPropertyResults(Convert.ToInt32(catalystId), Convert.ToInt32(analysisId), Model.Session.UserSession.Instance.UnitGroups, Model.Session.UserSession.Instance.UomVariables, Model.Session.UserSession.Instance.LimsValidations).ToList();
                            break;
                        
                    }
                }
                return Request.CreateResponse(HttpStatusCode.OK, limsResult);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost]
        public HttpResponseMessage UpdateLimsResults(UpdateLimsModel analysisMethodData)
        {
            try
            {
                CatalystRepository limsResultsRepository = new CatalystRepository(new MINIDATDatabase());
                var result = limsResultsRepository.UpdateLimsResult(analysisMethodData, User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1));
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        [HttpGet]
        public HttpResponseMessage GetViewLimsMaster(string catalystId)
        {
            try
            {
               
                CatalystRepository limsResultsRepository = new CatalystRepository(new MINIDATDatabase());
                var limsMasterResult = limsResultsRepository.GetCatalystAnalysisMethods(Convert.ToInt32(catalystId));
                if (Model.Session.UserSession.Instance == null)
                {
                    using (AppController app = new AppController())
                    {
                        SetSession(false);
                    }
                }
                Model.Session.UserSession.Instance.LimsValidations.Clear();
                ((List<Validation>)Model.Session.UserSession.Instance.LimsValidations).AddRange(limsMasterResult.Validations);
                return Request.CreateResponse(HttpStatusCode.OK, limsMasterResult);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

    }
}
