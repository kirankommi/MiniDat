import { Component, Input, Output, EventEmitter, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AlertMessage } from '../../services/alertmessage.service';
import * as  Constants from '../../Shared/globalconstants';
import { debug } from 'util';
import { FileModel } from '../../Models/file.model';
import { KeyValue } from '../../Models/KeyValue';
declare var sorttable: any;

@Component({
  templateUrl: "filebrowse.component.html",
  selector: "browse-file"
})
export class fileBrowserComponent implements OnInit, AfterViewInit {
  @Input()
  fileLst: any[] = [];
  @Input() handler: uploadHandler;
  deleteIDs: number[] = [];
  @Input() colList: KeyValue[];

  uploadIconPath: string;
  downloadIconPath: string;
  detailsIconPathEn: string;
  detailsIconPathDis: string;
  deleteIconPathEn: string;
  deleteIconPathDis: string;

  constructor(private alertMessage: AlertMessage, public el: ElementRef) {
     
  }
  ngAfterViewInit() { sorttable.reload(true); }
  ngOnInit(): void {
      
      if (this.colList ==null)
      {
          this.colList = [new KeyValue("FileName", "File Name"), new KeyValue("Description", "Description"), new KeyValue("FileSize", "File Size"),  new KeyValue("LastUpdatedDateTime", "Date Modified")];
      }
      this.handler.alertMessage = this.alertMessage;
      this.resizeMe();     

      
  }

  onClick() {
    //alert(this.handler.uploadFileValidation(new FileModel()));
  }

  DownloadFile(fileData: any, fileName: string, contentType: any) {
    var byteCharacters = atob(fileData);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);
    var blob = new Blob([byteArray], { type: "" });
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    var chrome = ua.indexOf("Chrome");

    if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      window.navigator.msSaveOrOpenBlob(blob, fileName);
    }
    else {
      var objectUrl = URL.createObjectURL(blob);
      //console.log("objectUrl  :   " + objectUrl);
      var link = document.createElement("A");
      link.setAttribute("href", objectUrl);
      //link.setAttribute("download", fileName + "." + contentType);
      link.setAttribute("download", fileName);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
  onResize(event)
  {
      this.resizeMe();
  }
  resizeMe()
  {

      var height = (window.innerHeight - 255) + "px";
      let table = this.el.nativeElement.querySelector('#table-scroll');
      table.style.height = height;

  }
  testDownLoad(file: FileModel)
  {
      debugger;
  }
  onDownload(file: FileModel) {    
    if (file.FileData) {
      var reader = new FileReader();
      reader.readAsBinaryString(file.FileData);
      var blob = file.FileData;
      var ua = window.navigator.userAgent;
      var msie = ua.indexOf("MSIE ");
      var chrome = ua.indexOf("Chrome");

      if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        window.navigator.msSaveOrOpenBlob(blob, file.FileName);
      }
      else {
        var objectUrl = URL.createObjectURL(blob);
        //console.log("objectUrl  :   " + objectUrl);
        var link = document.createElement("A");
        link.setAttribute("href", objectUrl);
        //link.setAttribute("download", fileName + "." + contentType);
        link.setAttribute("download", file.FileName);
        link.setAttribute("target", "_blank");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    } else {
        this.handler.downloadFile(file).subscribe(data => {
        if (data != undefined && data != null) {
          this.DownloadFile(data.FileData, data.FileName, data.ContentType);
        }
      });
    }
  }
  

  
}






export class uploadHandler {

  //uploadFileValidation: (file: FileModel) => boolean = () => {
  //  return false;
  //}

  public alertMessage: AlertMessage;
  fileDeletedMsg: string = "File Deleted Successfully";
  fileSizeMsg: string = "File Size limit Exceeded";
  fileTypeMsg: string = "Selected File type is not Allowed";
  fileNameError: string = "File name cannot exceed 100 characters !";

  constructor() {

  }

  public downloadFile: (fileID: any) => Observable<any>;
  

  ValidateFile: (fileName: string, fileSize: number) => boolean = (fileName: string, fileSize: number) => {
    let isValidType = false;
    let isValidSize = false;
    if (fileName != undefined && fileName != null && fileName.trim() != '') {
      //var type = fileName.split('.')[fileName.split('.').length - 1];
      var type = fileName.split('.')[fileName.split('.').length - 1].toLowerCase();
      if (type == "jpg" || type == "jpeg" || type == "png" || type == "doc" || type == "docx" || type == "xls" || type == "xlsx" || type == "pdf" || type == "ppt" || type == "pptx") {
        isValidType = true;
      }
      else {
        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileTypeMsg })
      }
      if (fileName.length > 100) {
        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileNameError })
        return false;
      }
      if (fileSize / 1048576 <= 6) {
        isValidSize = true;
      }
      else {
        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileSizeMsg })
      }
    }
    return isValidType && isValidSize;
  }

}
