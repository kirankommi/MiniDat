﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace MINIDAT.WebAPI
{

    public class JsonProtector : DelegatingHandler
    {
        protected async override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var response = await base.SendAsync(request, cancellationToken);
            string _responseContentString =await response.Content.ReadAsStringAsync();
            response.Content = new StringContent(")]}',\n" + _responseContentString);
            return response;
        }
    }
}