﻿export class NIRModelTemplateModel {
    NIRModelType: number;
    ModelTypecd: KeyValue;
    ModelID: string;
    ConversionType: number;
    ConversionTypecd: KeyValue;
    Low: number;
    High: number;
    SigmaError: number;
    StatusCode: KeyValue;
    StatusName: string;
    ModelTypeName: string;
    Feeds: FeedInfo;
    ConversionTypeName: string;
    ConversionCutPoint: number;
    //Search Parameters


    plantsTestedCode: KeyValue;
    plantsTestedKey: number;
    selectedplants: any;
    lstFeedNames: string[];
    lstFeedIds: number[];
    plantsSelectedlist: string;
    feedSelectedList: string;
    ActiveInd: string;
    NIRModelSQID: number;
    selectedPlantKeyList: string;
    selectedplantsKeys: string[];
    selectedPlantsCodeList: string;
    selectedPlantsCode: string[];
    DateLastRun_MinisQueue: string;
    public IsInitialLoad: boolean;
}

export class KeyValue {
    Key: string;
    Value: string;
    Groupcd: number;
}

export class FeedInfo {
    ID: number;
    Name: string;
    Desc: string;
    HasDopant: boolean;
    BookNum: string;
    UOPNum: string;
    DensityMsr: number;
}