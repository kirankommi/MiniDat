﻿export class LimsComponentModel {
    LIMSOperationName: string;
    LIMSComponent: string; 
    UOM: string;
    UOMGroupName: string;
    UOMUnitName: string;
    FDMSComponent: string; 
    uomGroupList: KeyValue[];
    uomUnitList: KeyValue[];
    AnalysisTypeName: string;
    ComponentType: string;
    ComponentLabel: string;
    Precision: number;     
    currentUOMUnitList: KeyValue[];
    LIMSOperationID: string; //Added for MINIDAT Flyout
    AnalysisMethodName: string; //Added for MINIDAT Flyout
    AnalysisMethodNumber: string; //Added for MINIDAT Flyout
}

export class LimsOpFlyoutModel {
    LIMSOperationName: string;
    AnalysisTypeName: string;
    UOM: string;   
}

export class LimsComponentFlyoutModel {
    ComponentType: string;
    ComponentName: string;  
}

export class KeyValue {
    Key: string;
    Value: string;
}
export class OperationComponentMappingVM {
    Operation: string;
    Component: string;
    Row: number;
    status: string;
    constructor(operation: string, component: string, row:number) {
        this.Operation = operation;
        this.Component = component;
        this.Row = row;
    }
}