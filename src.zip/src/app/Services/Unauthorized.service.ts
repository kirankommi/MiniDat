import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { UserModel } from '../Models/usermodel';
import { HttpActionService } from './httpaction.service';
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class UnauthorizedAccessService {

    private sendNewUserNotificationToAdmins = "/User/SendNewUserNotificationToAdmins/";

    constructor(private httpaction: HttpActionService, private http: Http) { }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    SendNewUserNotificationToAdmins(userData: UserModel) {
        let options = new RequestOptions(Constants.options);
        let queryParams = "?EID=" + userData.EID + "&FirstName=" + userData.FirstName + "&LastName=" + userData.LastName + "&EmailId=" + userData.EmailId;
        return this.http.get(Constants.apiBaseUrl + this.sendNewUserNotificationToAdmins + queryParams, options)
            .map((res: Response) => res || res.json())
            .catch(this.handleError);
    }
}

