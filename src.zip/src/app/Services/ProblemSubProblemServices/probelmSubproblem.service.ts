import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions, URLSearchParams} from '@angular/http';
import { Observable, of, from } from 'rxjs';
export var headers = new Headers({ 'Content-Type': 'application/json' });
import * as  Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
@Injectable({
  providedIn: 'root'
})

export class ProblemSubProblemAreaService {
    private getProblemSubProblemUrl = "/sentiment/itPersona ";
    constructor(private http: Http, private httpaction: HttpActionService) { }
    private handleError(error: any): Promise<any> {
        return Promise.reject(error.message || error);
    }
    getProblemSubProblem(searchValue: string) {
        let params: URLSearchParams = new URLSearchParams();
        //params.set('serviceOwner', '');
        //params.set('serviceGroup', null);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getProblemSubProblemUrl, options);
    }

    getProblemSubProblemArea()
    {
        return this.httpaction.get(this.getProblemSubProblemUrl, Constants.options);
            //.map((res: Response) => res.json())
            //.catch(this.handleError);
    }
}
