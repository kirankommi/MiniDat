﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystStateService } from '../../../Services/CatalystServices/CatalystState.service';
import { CatalystStateModel, KeyValue } from '../../../models/Catalyst/CatalystStateModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'CatalystState.component.html',
    providers: [CatalystStateService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystStateComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystState: CatalystStateModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    catalystStateList: any;     
    Statuses: KeyValue[];
    srIndicators: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    catalystStateSaved: string = "Catalyst State Details Saved Successfully";
    catalystStateDeleted: string = "Catalyst State Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private catalystStateService: CatalystStateService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {       
        this.catalystState = new CatalystStateModel();
        this.catalystState.CatalystStateID = null;       
        this.catalystState.SRIndicator = null;
        this.catalystState.CatalystState = null;   
        this.getcatalystStatesList();
        this.title = Constants.ManageCatalystState;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystState.CatalystStateID = event.data.CatalystStateID;
        this.catalystState.CatalystState = event.data.CatalystState;      
        this.catalystState.SRIndicator = event.data.SRIndicatorcd.Key;             
        this.catalystState.StatusName = event.data.StatusCode.Key;    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getcatalystStatesList()
    {       
        this.catalystStateService.getCatalystStateInformation(this.catalystState)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystStateList = data.LstcatalystStates;              
                this.Statuses = data.lstStatus;      
                this.srIndicators = data.lstSRIndicators;      
                this.totalRecords = data.RecordsFetched;              
                if (this.catalystState.StatusName == undefined || this.catalystState.StatusName == null)
                { this.catalystState.StatusName = Constants.Select; }     
                if (this.catalystState.SRIndicator == undefined || this.catalystState.SRIndicator == null)
                { this.catalystState.SRIndicator = Constants.Select; }                
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystState()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.catalystStateService.saveCatalystStateInformation(this.catalystState)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystStateSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(catalystState: CatalystStateModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteCatalystStateInfo(catalystState);}
        });
    }

    deleteCatalystStateInfo(catalystState: CatalystStateModel)
    {
        debugger;     
        this.catalystStateService.deleteCatalystState(catalystState)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystStateDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }   

    onReset() {
        debugger;
        this.catalystState = new CatalystStateModel();       
        this.sortField = "";
        this.sortOrder = 0;       
        this.catalystState.SRIndicator = null;   
        this.getcatalystStatesList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.catalystState == null || !this.catalystState.CatalystState ||
            this.catalystState.StatusName == "Select" || this.catalystState.SRIndicator == "Select")
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {       
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {                   
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000026" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
