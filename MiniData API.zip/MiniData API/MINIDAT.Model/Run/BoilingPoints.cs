﻿namespace MINIDAT.Model.Run
{
    public class BoilingPointModel
    {
        public int RowId { get; set; }
        public double InitialBoilingPoint { get; set; }
        public double EndBoilingPoint { get; set; }
        public string YieldCutLabel { get; set; }
        public string BoilingPointType { get; set; }

    }
}
    