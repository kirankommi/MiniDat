﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	UOMTemplateController.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using MINIDAT.Manage.UOMTemplate;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class UOMTemplateController : AppController
    {
        public UOMTemplateController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage UOM Template" }));
        }
        /// <summary>
        ///  gets the Application details
        /// </summary>
        /// <param name="templateID"></param>
        /// <returns></returns>
        [HttpGet, ActionName("GetApplicationDetails")]
        public IList<Application> GetApplicationDetails()
        {
            IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var appDetails=_uomrepo.GetApplications();
            return appDetails;
        }
        /// <summary>
        /// search and gets the uom variable data in the manage variable pop up
        /// </summary>
        /// <param name="templateID"></param>
        /// <returns></returns>
        [HttpGet, ActionName("GetTemplateVariables")]
        public IList<TemplateVariable> GetVariableData([FromUri] string templateID)
        {
            IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var variableArray = _uomrepo.GetVariableData(templateID);
            return variableArray;
        }
        /// <summary>
        /// saves the uom variable template data
        /// </summary>
        /// <param name="template"></param>
        /// <returns></returns>

        [HttpPost, ActionName("SaveTemplateData")]
        public HttpResponseMessage SaveTemplateData([FromBody] UOMTemplateModel template)
        {
            if ( template != null)
            {

                try
                {
                    IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
                    //Call the Save function here.
                    _uomrepo.SaveTemplateData(template, User.Identity.Name);
                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        /// <summary>
        /// makes the default uom template
        /// </summary>
        /// <param name="template"></param>
        /// <returns></returns>

        [HttpPost, ActionName("MakeDefault")]
        public HttpResponseMessage PostDefault([FromBody] UOMTemplateModel template)
        {
            if (template != null)
            {

                try
                {
                    IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
                    //Call the Save function here.
                    _uomrepo.MakeDefault(template, User.Identity.Name);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        /// <summary>
        /// saves the uom template variable
        /// </summary>
        /// <param name="templatedata"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SaveVariables")]
        public HttpResponseMessage SaveTemplateVariables([FromBody] TemplateData templatedata)
        {
            if ( templatedata != null)
            {

                try
                {
                    IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
                    _uomrepo.SaveVariables(templatedata.Template, templatedata.Variables.ToList(), User.Identity.Name);
                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }

        [HttpPost, ActionName("SaveTemplateVariables")]
        public HttpResponseMessage SaveTemplateUOMVariables([FromBody] TemplateData templatedata)
        {
            if (templatedata != null)
            {

                try
                {
                    IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
                    _uomrepo.SaveUOMVariables(templatedata.Template, templatedata.Module, templatedata.Variables.ToList(), User.Identity.Name);
                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        /// <summary>
        /// Delete uom template variable
        /// </summary>
        /// <param name="template"></param>
        /// <returns></returns>

        [HttpPost, ActionName("DeleteTemplate")]
        public HttpResponseMessage Delete([FromBody] UOMTemplateModel template)
        {
            if ( template != null)
            {

                try
                {
                    IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
                    //Call the Delete function here.
                   _uomrepo.DeleteTemplateData(template);
                    SetSession(true);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }

            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        /// <summary>
        /// gets the details of uom template variable
        /// </summary>
        /// <returns></returns>

        [HttpGet, ActionName("GetTemplates")]
        public IList<UOMTemplateModel> Get()
        {
            IUomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var templateArray = _uomrepo.GetTemplateData(new UOMTemplateModel(), User.Identity.Name);
            return templateArray;
        }
        /// <summary>
        /// search the uom template
        /// </summary>
        /// <param name="uomTemplateModel"></param>
        /// <returns></returns>

        [HttpGet, ActionName("SearchTemplates")]
        public IList<UOMTemplateModel> Search([FromUri] UOMTemplateModel uomTemplateModel)
        {
            UomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var templateArray = _uomrepo.GetTemplateData(uomTemplateModel, User.Identity.Name);
            return templateArray;
        }


        [HttpGet, ActionName("GetUOMgroups")]
        public IList<Group> GetUOMGroups() {
            UOMRepository _repo = new UOMRepository(new MINIDATDatabase());
           
            Model.Session.UserSession session = SetSession(false); //new Model.Session.UserSession();

            return  _repo.GetAll(session.User.UOMTemplateId);
        }

        [HttpGet, ActionName("GetVariableCategories")]
        public IList<Module> GetVariableCategories([FromUri] string templateID)
        {
            UomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var moduleArray = _uomrepo.GetModuleData(templateID);
            return moduleArray;
        }

        [HttpGet, ActionName("GetVariables")]
        public IList<Variable> GetVariables([FromUri] string templateID, [FromUri] string ModuleID)
        {
            UomTemplateRepository _uomrepo = new UomTemplateRepository(new MINIDATDatabase());
            var variableArray = _uomrepo.GetVariableData(templateID, ModuleID);
            return variableArray;
        }
    }
}
