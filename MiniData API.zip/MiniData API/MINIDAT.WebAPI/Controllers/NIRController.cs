﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using MINIDAT.Model.Manage.Mode;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class NIRController : AppController
    {
        INIRRepository _nirRepository;
        public NIRController()
        {
            Model.LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Mode Template: NIR" }));
            _nirRepository = new NIRRepository(new MINIDATDatabase());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet, ActionName("GetNIRData")]
        public HttpResponseMessage Get(string templateId)
        {
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _nirRepository.getNIRTemplateData(templateId));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get SPP data");
            }
        }
    }
}
