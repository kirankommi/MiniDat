import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class doeMediatorService {
  saveData: any = {};
  masterData: any = {};
  onRuoteIntialized: Subject<any> = new Subject<any>();
  projectName: any ="";
  studyName: any = "";

  public getBasicInformation: () => Promise<any>;
  public getDOEInformation: () => any;
}
