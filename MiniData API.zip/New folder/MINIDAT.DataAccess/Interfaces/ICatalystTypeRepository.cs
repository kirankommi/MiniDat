﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystTypeRepository : ICRUDRepository<CatalystTypeModel>
    {
        CatalystTypeSearchModel GetCatalystTypeData(CatalystTypeModel catalystType);
        string DeleteCatalystTypeData(CatalystTypeModel catalystType);
        void SaveCatalystTypeData(CatalystTypeModel _catalystType, string userId); 

    }
}
