import { Component, OnInit, AfterViewInit, HostListener } from '@angular/core';
import { SessionService } from '../Shared/session.service';
import { environment } from '../../environments/environment';
import { TableModule } from 'primeng/table';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { NavigationEnd, Router } from '@angular/router';
import { Chart } from 'chart.js';
import { DashboardService } from '../Services/dashboard.service';
import { debug } from 'util';
import { SharedDataService, appService } from '../Services/app.service';
import { AlertMessage } from '../services/alertmessage.service';
import * as Constants from '../Shared/globalconstants';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [AlertMessage, appService]
  //host: {
  //    '(window:resize)': 'onResize($event)'
  //}
})
export class DashboardComponent implements OnInit, AfterViewInit {

  data: any;
  chartData: any;
  chart: any;
  barChart: any;
  lineChart: any;
  srcMaxIcon: string;
  srcSettingsIcon: string;
  srcCloseIcon: string;
  tsGridStyle: string = "tspackage_expanded";
  divInnerHeight: number;
  months: Array<string> = [];
  labels: Array<string> = [];
  csatScores: Array<any> = [10];

  constructor(private _SessionService: SessionService, private service: DashboardService, private router: Router, private appService: appService, private alertMessage: AlertMessage) {

  }

  @HostListener('window:resize')
  onResize(event) {
    //this.adjustDivHeight();
  }

  onChartClick(event) {
    var activePoint = this.barChart.getElementAtEvent(event)[0];
    var data = activePoint._chart.data;
    var datasetIndex = activePoint._datasetIndex;
    let legendLabel = data.labels[activePoint._index];
    this.router.navigateByUrl('/enggPerformance/' + legendLabel);

  }


  adjustDivHeight() {
    this.divInnerHeight = (window.innerHeight - 150);
  }

  ngOnInit() {
    //this.chartData = {
    //  labels: ["Standard Tools", "Non Standard Tools", "Unidentified "],
    //  additionaLabels: [
    //    "TCO"
    //  ],
    //  additionalData: ["$12M", "$64M", "$4M"],
    //  datasets: [{
    //    data: [274, 804, 200],
    //    backgroundColor: [
    //      '#1791e5',
    //      '#f37021',
    //      '#ffc627'
    //    ],
    //    borderColor: [
    //      '#1791e5',
    //      '#f37021',
    //      '#ffc627'
    //    ],
    //    borderWidth: 0
    //  }]
    //};

    //this.barChart = new Chart('perfomance', {
    //  type: 'bar',
    //  data: {
    //    labels: ["People & Productivity", "Compliance", "Delivery", "Operations"],
    //    datasets: [

    //      {
    //        label: 'Performance',
    //        data: [82, 79, 96, 83],
    //        backgroundColor: [
    //          '#9ad8af',
    //          '#f12e15',
    //          '#9ad8af',
    //          '#9ad8af'
    //        ]
    //      }]
    //  },
    //  options: {
    //    legend: {
    //      display: false
    //    },
    //    responsive: true,
    //    maintainAspectRatio: false,

    //    scales: {
    //      xAxes: [{
    //        maxBarThickness: 75,
    //      }],
    //      yAxes: [{
    //        barThickness:10,
    //        ticks: {
    //          suggestedMax: 100,
    //          suggestedMin: 0,
    //          stepSize: 50,
    //          callback: function (value) {
    //            return value + "%"
    //          }
    //        }
    //      }]
    //    },
    //    animation: {
    //      duration: 2000,
    //      onComplete: function () {
    //        var chartInstance = this.barChart;
    //      }
    //    },
    //    events: ['click']
    //  }
    //});
    //this.barChart.click = function (evt) {

    //};
    //this.service.GetCsatScore().subscribe((json: any) => {
    //  let data = json.data;
    //  let mnts = this.months;
    //  this.labels = [];
    //  data.forEach((val) => {
    //    this.labels.push(this.months[val.month]);
    //  });
    //  this.csatScores = data.map((q) => q.score * 10);

    //  this.lineChart = new Chart('enggApps', {
    //    type: 'line',
    //    data: {
    //      labels: this.labels,//['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    //      datasets: [{
    //        data: [90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90],
    //        borderDash: [10, 5],
    //        fill: false
    //      }, {
    //        data: [50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50],
    //        borderDash: [10, 5],
    //        fill: false
    //      },
    //      {
    //        data: this.csatScores,
    //        backgroundColor: '#CAEDFE',
    //        borderColor: '#1792E5',
    //        label: 'CSAT'
    //      }

    //      ],
    //    },
    //    options: {
    //      legend: {
    //        display: false
    //      },

    //      responsive: true,
    //      maintainAspectRatio: false,
    //      scales: {
    //        yAxes: [{
    //          ticks: {
    //            callback: function (label, index, labels) {
    //              return label + '%';
    //            },
    //            suggestedMax: 100,
    //            suggestedMin: 0,
    //            stepSize: 50
    //          },
    //          scaleLabel: { display: true, labelString: 'CSAT Score' }
    //        }]
    //      }
    //    }
    //  });
    //});
  }

  getCsatScore() {

  }

  ngAfterViewInit() {
    this.adjustDivHeight();
  }
}






