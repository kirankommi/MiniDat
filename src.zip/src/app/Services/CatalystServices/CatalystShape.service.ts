﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystShapeModel, KeyValue } from '../../Models/Catalyst/CatalystShapeModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystShapeService {
    private getCatalystShapedata = "/CatalystShape/SearchCatalystShapedata/";
    private getActiveCatalystShapeinfo = "/CatalystShape/GetActiveCatalystShapedata/";
    private saveCatalystShapedata = "/CatalystShape/SaveCatalystShapeInformation/";
    private deleteCatalystShapedata = "/CatalystShape/DeleteCatalystShapeInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystShapeInformation(catalystShape: CatalystShapeModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystShape, this.getCatalystShapedata);
    }

    saveCatalystShapeInformation(catalystShape: CatalystShapeModel)
    {
        return this.httpaction.post(catalystShape, this.saveCatalystShapedata);
    }

    deleteCatalystShape(catalystShape: CatalystShapeModel)
    {
        debugger;
        return this.httpaction.post(catalystShape, this.deleteCatalystShapedata);
    }    
}
