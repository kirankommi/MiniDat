﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class RunCatalystModelExport
    {
        public string CatalystId { get; set; }
        public string CatalystFamilyName { get; set; }
        public double? pieceDensityValue { get; set; }
        public string pieceDensityUOM { get; set; }
        public string CatalystSize { get; set; }
        public string Crushed { get; set; }
        public string CatalystShape { get; set; }
        public double? Voidfraction { get; set; }
        public string LoadingDensityTypeName { get; set; }
        public double? CustomBedDensity { get; set; }
        public string Custom_bed_density_uom { get; set; }
        public double? vibrated_bed_density_value { get; set; }
        public string vibrated_bed_density_UOM { get; set; }
        public double? CalculatedBedDensity { get; set; }
        public string Calculated_Bed_Density_UOM { get; set; }
        public double? LoadDensityValue { get; set; }
        public string LoadDensityUOM { get; set; }
        public string CatalystDescription { get; set; }
        
    }
    public class BedDetailsExport
    {
        public int BedNumber { get; set; }
        public string CatalystId { get; set; }
        public double? CatalystVolume { get; set; }
        public int Split { get; set; }
        public string DiluentDesignation { get; set; }
        public double? DiluentVolume { get; set; }

    }
}
