﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
    public class LogSheetPeriodReadingModel
    {
        public string LogReadingLabel { get; set; }
        public string InputVariableType { get; set; }
        public string UOM { get; set; }
        public double? AverageReadingValueMsr { get; set; }
        public double? InitialReadingValueMsr { get; set; }
        public double? FinalReadingValueMsr { get; set; }
        public string ParamterDefaultUnitName { get; set; }


    }
    public class PeriodReadingModel
    {
        public string PlantCd { get; set; }
        public int RunId { get; set; }
        public int TestId { get; set; }
        public List<LogSheetPeriodReadingModel> PeriodReadingList { get; set; }
        public dynamic LogSheetTimeReading { get; set; } //For exporting to excel
    }

    public class LogSheetKeyModel
    {
        public string PlantCd { get; set; }
        public int LogSheetKey { get; set; }
        public DateTime ReadingTime { get; set; }
    }
}
