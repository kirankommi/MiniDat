﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           LIMSAnalysisMethodController.cs
Project Title:      FeedStockDAT
Created on:         2-June-2017
Requirements Tag:   Repository for Managing LIMS Analysis method
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */




using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using MINIDAT.Model.Manage.LIMSAnalysisMethod;
using MINIDAT.Models.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class AnalysisMethodRepository : IAnalysisMethodRepository
    {
        private IDatabase _db;
        public AnalysisMethodRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }


        /// <summary>
        /// Get the list of LIMS analysis method previously saved along with the list of source names and UOM group List
        /// </summary>
        /// <param name="Method"></param>
        public LIMSAnalysisMethodSearchModel GetMethodData(LIMSAnalysisMethodModel Method)
        {
            try
            {
                LIMSAnalysisMethodSearchModel Methodlist = new LIMSAnalysisMethodSearchModel();
                if (Method == null)
                {
                    return Methodlist;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("Get_LIMS_AnalysisMethod_Details_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Analysis_Method_Nm", Method.MethodName);
                    parameters.Add("proc_vr_Analysis_Method_Desc", Method.MethodDescription);
                    parameters.Add("proc_vr_Analysis_Source_Nm", Serializer.ConvertToXML(Method.CheckedSources));
                    parameters.Add("proc_vr_Analysis_Method_Num", Method.MethodNumber);
                    parameters.Add("proc_nm_Uom_Grp_Nm", Method.UOMSearch == "Select" ? null : Method.UOMSearch);
                    parameters.Add("proc_vr_Lims_oper_Nm", Method.LIMSOperation);
                    _db.CreateParameters(command, parameters);
                    Methodlist.Sources.Clear();
                    reader = _db.ExecuteReader(command);
                    //List of Source Name List
                    List<SourceName> sourceNameList = new List<SourceName>();
                    while (reader.Read())
                    {
                        SourceName src = new SourceName()
                        {
                            Id = Convert.ToString(reader["RETRANSMIT_CAT_CD"]),
                            Name = Convert.ToString(reader["RETRANSMIT_CAT_NM"]),
                            IsUsed = false
                        };
                        Methodlist.Sources.Add(src);
                    }
                    //List of UOM Group
                    Methodlist.UOM.Clear();
                    List<KeyValue> UOMGroupList = new List<KeyValue>();
                    Methodlist.UOM.Add(new KeyValue { Key = "Select", Value = "Select" });
                    reader.NextResult();
                    while (reader.Read())
                    {
                        KeyValue uom = new KeyValue()
                        {
                            Key = Convert.ToString(reader["UOM_GROUP_CD"]),
                            Value = Convert.ToString(reader["UOM_GROUP_NM"])
                        };
                        Methodlist.UOM.Add(uom);
                    }

                    Methodlist.AnalysisMethod.Clear();

                    //List of Analysis Merhod
                    if (reader.NextResult())
                    {
                        while (reader.Read())
                        {
                            List<SourceName> Sourcelist = new List<SourceName>();
                            if (reader["ANALYSIS_CD"].ToString().Length > 0)
                            {
                                string[] sourceNameCodes = reader["ANALYSIS_CD"].ToString().Split(',');
                                string[] sourceName = reader["ANALYSIS_SOURCE_NM"].ToString().Split(',');
                                var sourcelength = sourceNameCodes.Length - 1;
                                if (sourceNameCodes.Length > 0)
                                {
                                    while (sourcelength > -1)
                                    {
                                        SourceName sourcelist = new SourceName()
                                        {
                                            Id = sourceNameCodes[sourcelength],
                                            Name = sourceName[sourcelength],
                                            IsUsed = true

                                        };
                                        sourcelength--;
                                        Sourcelist.Add(sourcelist);
                                    }

                                }


                            }

                            else
                            {

                            }
                            LIMSAnalysisMethodModel newMethod = new LIMSAnalysisMethodModel()
                            {
                                Id = Convert.ToInt32(reader["ANALYSIS_METHOD_ID_SQ"]),
                                MethodName = Convert.ToString(reader["ANALYSIS_METHOD_NM"]),
                                MethodDescription = Convert.ToString(reader["ANALYSIS_METHOD_DESC"]) == "NULL" ? null : Convert.ToString(reader["ANALYSIS_METHOD_DESC"]),
                                MethodNumber = Convert.ToString(reader["ANALYSIS_METHOD_NUM"]) == "NULL" ? null : Convert.ToString(reader["ANALYSIS_METHOD_NUM"]),
                                // UOMGroup = new KeyValue() { Key = Convert.ToString(reader["UOM_ID_SQ"]), Value = Convert.ToString(reader["UOM_GROUP_NM"]) },
                                UOMGroup = new KeyValue() { Key = Convert.ToString(reader["UOM_GROUP_CD"]), Value = Convert.ToString(reader["UOM_GROUP_NM"]) },
                                LIMSOperation = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                                CheckedSourcesNames = Convert.ToString(reader["ANALYSIS_SOURCE_NM"])
                            };
                            newMethod.Sources.Clear();
                            ((List<SourceName>)newMethod.Sources).AddRange(Sourcelist);
                            Methodlist.AnalysisMethod.Add(newMethod);
                        }
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        Methodlist.RecordsFetched = (int)reader["RECORD_COUNT"];
                    }
                    reader.Close();

                    return Methodlist;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        public bool Delete(LIMSAnalysisMethodModel Method)
        {
            if (Method == null) throw new ArgumentNullException("Method");
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                using (IDbCommand cmd = _db.CreateCommand("Delete_Analysis_Method_sp"))
                {
                    parameters.Add("proc_in_Analysis_Method_Id", Method.Id);
                    parameters.Add("proc_vr_Lims_Operation_Nm", Method.LIMSOperation);
                    _db.CreateParameters(cmd, parameters);
                    _db.ExecuteNonQuery(cmd);
                }
                return true;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {

            }
        }

        public void Add(LIMSAnalysisMethodModel Method)
        {
            //InsertOrUpdate(_model);
        }


        public void Update(LIMSAnalysisMethodModel Method)
        {
            //InsertOrUpdate(_model);
        }


        public bool SaveMethodData(LIMSAnalysisMethodModel method, string currentUser)
        {
            try
            {
                if (method == null) throw new ArgumentNullException("method");
                if (!string.IsNullOrEmpty(currentUser))
                {
                    string source = ListToCommaSeparated(method.CheckedSources);
                    string EID = currentUser.Substring(currentUser.IndexOf("\\") + 1);
                    using (IDbCommand command = _db.CreateCommand("Insert_Update_Analysis_Method_Sp"))
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("proc_vr_Analysis_Method_Nm", method.MethodName);
                        parameters.Add("proc_vr_Analysis_Method_Desc", method.MethodDescription);
                        parameters.Add("proc_vr_Analysis_Cd", source);
                        parameters.Add("proc_vr_Lims_oper_Nm", method.LIMSOperation);
                        parameters.Add("proc_vr_Analysis_Method_Num", method.MethodNumber);
                        parameters.Add("proc_nm_Uom_Grp_Nm", method.UOMGroup.Key);
                        parameters.Add("proc_in_Analysis_Method_Id", method.Id);
                        parameters.Add("proc_vr_Created_By_User_Id", EID);
                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                        return true;
                    }
                }
                return false;
            }
            catch (Exception Ex)
            {
                LogManager.Error(Ex);
                throw;
            }
        }

        public IList<LIMSAnalysisMethodModel> List(ICriteria _criteria)
        {
            if (_criteria == null) throw new ArgumentNullException("_criteria");
            IDataReader _reader = null;
            //  AppUserCriteria _userCriteria = (AppUserCriteria)_criteria;
            try
            {
                IList<LIMSAnalysisMethodModel> _list = new List<LIMSAnalysisMethodModel>();
                return _list;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {
                //if (_reader != null)
                //{
                //    _reader.Close();

                //}
            }
        }


        public string ListToCommaSeparated(IList<SourceName> list)
        {
            if (list == null) throw new ArgumentNullException("list");
            string commaSeparatedValue = null;
            string commaSeparatedID = null;
            foreach (SourceName source in list)
            {
                if (source.IsUsed == true)
                {
                    commaSeparatedID = commaSeparatedID + source.Id + ",";
                    commaSeparatedValue = commaSeparatedValue + source.Name + ",";
                }
            }
            if (commaSeparatedValue != null)
            {
                commaSeparatedValue = commaSeparatedValue.Substring(0, commaSeparatedValue.Length - 1);
                commaSeparatedID = commaSeparatedID.Substring(0, commaSeparatedID.Length - 1);
            }

            return commaSeparatedID;
        }

        //public IList<AnalysisMethodGetAllBySourceResult> GetAllBySource(string feedIds, string source)
        //{
        //    IList<AnalysisMethodGetAllBySourceResult> list = new List<AnalysisMethodGetAllBySourceResult>();
        //    try
        //    {
        //        using (IDbCommand cmd = _db.CreateCommand("Get_AnalysisMethods_By_Source_Sp"))
        //        {
        //            IDbDataParameter cmdParam = cmd.CreateParameter();
        //            cmdParam.ParameterName = "Source";
        //            cmdParam.Value = source;
        //            cmd.Parameters.Add(cmdParam);

        //            IDbDataParameter cmdParamfeedIds = cmd.CreateParameter();
        //            cmdParamfeedIds.ParameterName = "feedIds";
        //            cmdParamfeedIds.Value = feedIds;
        //            cmd.Parameters.Add(cmdParamfeedIds);

        //            IDataReader reader = _db.ExecuteReader(cmd);
        //            while (reader.Read())
        //            {
        //                var analysisMethod = new AnalysisMethodGetAllBySourceResult();
        //                analysisMethod.Id = Convert.ToInt32(reader["ANALYSIS_METHOD_ID_SQ"]);
        //                analysisMethod.MethodDescription = Convert.ToString(reader["ANALYSIS_METHOD_DESC"]);
        //                analysisMethod.MethodName = Convert.ToString(reader["ANALYSIS_METHOD_NM"]);
        //                analysisMethod.MethodNumber = Convert.ToString(reader["ANALYSIS_METHOD_NUM"]);
        //                list.Add(analysisMethod);
        //            }
        //            reader.Close();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.Error(ex);
        //        throw;
        //    }
        //    return list;
        //}

        public IList<SourceName> GetLimsSources()
        {
            IList<SourceName> list = new List<SourceName>();
            try
            {
                using (IDbCommand cmd = _db.CreateCommand("getLimsSources"))
                {
                    IDataReader reader = _db.ExecuteReader(cmd);
                    while (reader.Read())
                    {
                        var source = new SourceName();
                        source.Id = Convert.ToString(reader["RETRANSMIT_CAT_CD"]);
                        source.Name = Convert.ToString(reader["RETRANSMIT_CAT_NM"]);
                        list.Add(source);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            return list;
        }

        public bool CheckIsOperationExists(string name)
        {
            IDictionary parameters = new Dictionary<string, object>();
            try
            {
                using (IDbCommand cmd = _db.CreateCommand("CheckIsOperationExists_sp"))
                {
                    parameters.Add("name", name);
                    _db.CreateParameters(cmd, parameters);
                    var result = _db.ExecuteScalar(cmd);
                    return Convert.ToBoolean(result);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
         
    }
}
