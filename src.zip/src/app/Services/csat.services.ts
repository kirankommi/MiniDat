﻿import { Injectable, ReflectiveInjector } from '@angular/core';
import { HttpActionService } from './httpaction.service';
import * as Constants from '../Shared/globalconstants';

@Injectable({
    providedIn: 'root'
})
export class csatService {
    wordCloudUrl: string = "/wordCloud";


    constructor(private httpaction: HttpActionService) {

    }

    GetwordCloudData() {

        return this.httpaction.get(this.wordCloudUrl, Constants.options);
    }
}