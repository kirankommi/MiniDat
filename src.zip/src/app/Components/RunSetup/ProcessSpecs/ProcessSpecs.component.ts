import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import * as Constants from '../../../Shared/globalconstants';
import { KeyValue } from '../../../Models/KeyValue';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
    selector: 'processSpec',
    templateUrl: './ProcessSpecs.component.html',
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})
export class ProcessSpecsComponent implements OnInit {
    // run1: RunModel;
    run: RunSetupModel;
    runSaved: string = "Run Process Specification Information Saved Successfully";
    lstdoecatalyst: any[];
    lstflyoutfeeds: any[];
    feedFlyoutcolumns: KeyValue[];
    IsDisabled: boolean = false;
    oldValue: number = 0;
    //feedFlyoutcolumns: any[] = [
    //    { Key: "UOPNum", Value: "UOP #" },
    //    { Key: "BookNum", Value: "Book #" },
    //    { Key: "Name", Value: "Name" }        

    //];

    constructor(private processSpecService: RunService, public runDataService: RunDataService, private alertMessage: AlertMessage, private runComponent: RunComponent) { }
    ngOnInit() {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel)

        this.fillFlyoutColumns();
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "8", Value: "Process Specification", Groupcd: 0 });
    }

    fillFlyoutColumns() {
        this.feedFlyoutcolumns = [];
        this.feedFlyoutcolumns.push({ Key: "UOPNum", Value: "UOP #" });
        this.feedFlyoutcolumns.push({ Key: "Name", Value: "Name" });
    }

    getProcessSpecInformation(PlantCd: string, RunId: string) {

        this.processSpecService.GetProcessSpecInformation(PlantCd, RunId)
            .subscribe(
                (data: any) => {

                    this.run.lstProcessSpec = data;
                    this.setDefaultValues();
                    this.PopulatedcalculatedParameters();

                },
                err => { }
            );
    }
    PopulatedcalculatedParameters() {

        let TMFIntercept;
        let TMFSlope;
        this.lstdoecatalyst = this.run.MasterData.lstDoeCataystinfo;
        //check if calibrations list has data filled already. If not populate the data from service call.
        if (this.run.lstTMF_Calibrations == null || this.run.lstTMF_Calibrations == undefined || this.run.lstTMF_Calibrations.length == 0) {
            this.run.lstTMF_Calibrations = null;
            this.processSpecService.GetTMFCalibrationInformation(this.run.MetaData.Plant, this.run.MetaData.RunId)
                .subscribe(
                    (data: any) => {

                        this.run.lstTMF_Calibrations = data;
                        TMFIntercept = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0].Value;
                        TMFSlope = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0].Value;
                    },
                    err => { }
                );
        }
        else {
            TMFIntercept = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Intercept")[0].Value;
            TMFSlope = this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0] == undefined ? null : this.run.lstTMF_Calibrations.filter((x: any) => x.Parameter == "TMF Slope")[0].Value;
        }

        this.run.lstProcessSpec.map((x, i) => {
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Catalyst') {
                //x.ValueText = "2345-36";
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Feed UOP#') {
                x.ValueText = this.run.FeedInfo.UOPNumber;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Catalyst Volume') {

                //x.Value = this.run.CatalystVolume;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'LHSV') {

                x.Value = this.run.MetaData.ModeLHSV;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2/HC') {

                x.Value = this.run.MetaData.ModeSCFB;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2 TMF % Output PV') {
                debugger;
                let scfh = (this.run.MetaData.ModeSCFB * this.run.MetaData.CatalystVolume * this.run.MetaData.ModeLHSV * 42 * 28316.85) / 3785;
                scfh = (scfh * 127132.8002); //Conversion factor for converting M3/Sec value to  SCFH
                x.Value = ((scfh - (TMFIntercept * 100)) / (TMFSlope * 100)) / 100;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'H2 TMF % Output PV (HITC)') {
                debugger;
                let scfh = (this.run.MetaData.ModeSCFB * this.run.MetaData.CatalystVolume * this.run.MetaData.ModeLHSV * 42 * 28316.85) / 3785;
                scfh = (scfh * 127132.8002); //Conversion factor for converting  M3/Sec value to  SCFH
                x.Value = ((scfh - (TMFIntercept * 100)) / (TMFSlope * 100) / 100);
                //x.Value = 0.5;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Plant Pressure, HPS') {

                x.Value = this.run.MetaData.ModePressure;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'Feed Rate') {
                let feedrate;

                if (this.run.FeedInfo.RelativeDensity != undefined && this.run.FeedInfo.RelativeDensity != null) {
                    feedrate = this.run.MetaData.ModeLHSV * this.run.MetaData.CatalystVolume * this.run.FeedInfo.RelativeDensity;
                }
                else {
                    feedrate = null;
                }
                x.Value = feedrate;
            }
            if (x.RecordSet == 'PLANTMASTER' && x.ParameterName == 'ISCO Feed Rate (HITC)') {

                let Iscofeedrate;
                if (this.run.FeedInfo.RelativeDensity != undefined && this.run.FeedInfo.RelativeDensity != null) {
                    Iscofeedrate = (this.run.MetaData.ModeLHSV * this.run.MetaData.CatalystVolume * this.run.FeedInfo.RelativeDensity / this.run.MetaData.FeedISCOTemp);
                }
                else {
                    Iscofeedrate = null;
                }
                x.Value = Iscofeedrate;
            }
        });

    }
    setDefaultValues() {
        this.run.lstProcessSpec.map((x, i) => {
            if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Top Block Offset Low') {
                x.Value = 269.15;
            }
            if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Top Block Offset High') {
                x.Value = 271.65;
            }
            if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'Feed Rate Filter (stdev)') {
                x.Value = 2;
            }
            if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'HPS Pressure RCP OP-High') {
                x.Value = .80;
            }
            if (x.RecordSet == 'DEFAULT' && x.ParameterName == 'HPS Pressure RCP OP-Low') {

                x.Value = .20;
            }
            if (x.RecordSet == 'SAVED' && x.ParameterName == 'Feed (Sulfiding)') {
                x.ValueText = this.run.MasterData.lstFlyoutFeeds.filter((y: any) => y.ID == x.Value)[0] == undefined ? null : this.run.MasterData.lstFlyoutFeeds.filter((y: any) => y.ID == x.Value)[0].Name;
            }
        });
    }
    updateFeedSelection(event, index: any) {
        this.run.lstProcessSpec[index].Value = event.ID;
        this.run.lstProcessSpec[index].ValueText = event.Name;
    }




    onReset() {

        this.run.lstProcessSpec = null;
        this.getProcessSpecInformation(this.run.MetaData.Plant, this.run.MetaData.RunId);
        this.runDataService.changeMessage(this.run);
    }
    captureOldValue(event) {
        this.oldValue = Number(event.target.value);
    }



    updateValue(event: any, value: any, rowId: any, unit: any, index: any) {
        let currentvalue = Number(event.target.value);
        if (this.oldValue != currentvalue) {
            if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
                this.run.lstProcessSpec[index].Value = unit.Slope / (currentvalue + unit.Intercept);
            }
            else {
                this.run.lstProcessSpec[index].Value = currentvalue * unit.Slope + unit.Intercept;
            }
        }
    }
}

