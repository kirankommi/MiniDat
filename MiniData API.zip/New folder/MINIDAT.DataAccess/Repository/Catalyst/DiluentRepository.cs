﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageDiluent.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class DiluentRepository : IDiluentRepository
    {
        private IDatabase _db;
        public DiluentRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        IList<KeyValue> rerefernces = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Yes"},
                     new KeyValue() {Key="N", Value="No"}
                };


        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public DiluentSearchModel GetDiluentData(DiluentModel diluent)
        {
            try
            {
                DiluentSearchModel diluentarr = new DiluentSearchModel();
                if (diluent == null)
                {
                    return diluentarr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_Diluent_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_diluent_designation", string.IsNullOrEmpty(Convert.ToString(diluent.Designation)) ? (object)null : diluent.Designation);
                    parameters.Add("proc_vr_source", string.IsNullOrEmpty(Convert.ToString(diluent.Source)) ? (object)null : diluent.Source);
                    parameters.Add("proc_vr_description", string.IsNullOrEmpty(Convert.ToString(diluent.Description)) ? (object)null : diluent.Description);
                    parameters.Add("proc_in_size", (diluent.size == 0?null: diluent.size));
                    parameters.Add("proc_in_reference", string.IsNullOrEmpty(diluent.ReferenceName == "Select" ? null : diluent.ReferenceName) ? (object)null : diluent.ReferenceName);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(diluent.StatusName == "Select" ? null : diluent.StatusName) ? (object)null : diluent.StatusName);                   
                    parameters.Add("proc_nm_Piece_denisty_Msr", diluent.PieceDensity);
                    parameters.Add("proc_nm_apparent_bulk_density_Msr", diluent.ApparentBulkDensity);                  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    diluentarr.Lstdiluents.Clear();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)diluentarr.lstSizes).Add(new KeyValue()
                        {
                            Key = reader["DILUENT_SIZE_ID_SQ"].ToString(),
                            Value = reader["DILU_SIZE_NM"].ToString()
                        });
                    }                             

                    reader.NextResult();
                    while (reader.Read())
                    {
                        DiluentModel _diluent = new DiluentModel()
                        {
                            DiluentID = Convert.ToInt32(reader["DILUENT_ID_SQ"]),
                            Designation = reader["DILUENT_NM"].ToString(),
                            Description = reader["DILUENT_DESC"].ToString(), 
                            Source = reader["DILUENT_SOURCE_NM"].ToString(),
                            size = Convert.ToInt32(reader["DILUENT_SIZE_ID"]),                          
                            Sizecd = new KeyValue() { Key = reader["DILUENT_SIZE_ID"].ToString(), Value = reader["DILUENT_SIZE_NM"].ToString() },                          
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            PieceDensity = (reader["DILUENT_PD_VF"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["DILUENT_PD_VF"]),
                            ApparentBulkDensity = (reader["DILUENT_ABD_VF"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["DILUENT_ABD_VF"]),                           
                            ReferenceName = reader["REFERENCE_DILUENT_IND"].ToString(),
                            Referencecd = new KeyValue() { Key = reader["REFERENCE_DILUENT_IND"].ToString(), Value = reader["REF_IND_NM"].ToString() }
                        };
                        diluentarr.Lstdiluents.Add(_diluent);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        diluentarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    diluentarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)diluentarr.lstStatus).AddRange(statuses);
                    diluentarr.lstReferences.Clear();
                    ((List<KeyValue>)diluentarr.lstReferences).AddRange(rerefernces);
                    return diluentarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteDiluentData(DiluentModel diluent)
        {
            try
            {
                if (diluent == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_Diluent_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_diluent_ID", string.IsNullOrEmpty(Convert.ToString(diluent.DiluentID)) ? (object)null : diluent.DiluentID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SaveDiluentData(DiluentModel _diluent, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _diluent == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_Diluent_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_diluent_Id", _diluent.DiluentID);
                    parameters.Add("proc_vr_designation", _diluent.Designation);
                    parameters.Add("proc_vr_source", _diluent.Source);
                    parameters.Add("proc_vr_description", _diluent.Description);
                    parameters.Add("proc_vr_size", _diluent.size);
                    parameters.Add("proc_vr_reference", _diluent.ReferenceName);
                    parameters.Add("proc_vr_Status_Nm", _diluent.StatusName);
                    parameters.Add("proc_nm_Piece_denisty_Msr", _diluent.PieceDensity);
                    parameters.Add("proc_nm_Bulk_denisty_Msr", _diluent.ApparentBulkDensity);                   
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(DiluentModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(DiluentModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<DiluentModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(DiluentModel _model)
        {
            throw new NotImplementedException();
        }

        public DiluentSearchModel GetActivediluents(DiluentModel diluent)
        {
            try
            {
                DiluentSearchModel diluentarr = new DiluentSearchModel();
                if (diluent == null)
                {
                    return diluentarr;
                }


                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Get_Active_Diluents_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_diluent_designation", string.IsNullOrEmpty(Convert.ToString(diluent.Designation)) ? (object)null : diluent.Designation);
                    parameters.Add("proc_vr_source", string.IsNullOrEmpty(Convert.ToString(diluent.Source)) ? (object)null : diluent.Source);
                    parameters.Add("proc_vr_description", string.IsNullOrEmpty(Convert.ToString(diluent.Description)) ? (object)null : diluent.Description);
                    parameters.Add("proc_in_size", (diluent.size == 0 ? null : diluent.size));
                    parameters.Add("proc_in_reference", string.IsNullOrEmpty(diluent.ReferenceName == "Select" ? null : diluent.ReferenceName) ? (object)null : diluent.ReferenceName);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(diluent.StatusName == "Select" ? null : diluent.StatusName) ? (object)null : diluent.StatusName);
                    parameters.Add("proc_nm_Piece_denisty_Msr", diluent.PieceDensity);
                    parameters.Add("proc_nm_apparent_bulk_density_Msr", diluent.ApparentBulkDensity);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    diluentarr.Lstdiluents.Clear();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)diluentarr.lstSizes).Add(new KeyValue()
                        {
                            Key = reader["DILUENT_SIZE_ID_SQ"].ToString(),
                            Value = reader["DILU_SIZE_NM"].ToString()
                        });
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        DiluentModel _diluent = new DiluentModel()
                        {
                            DiluentID = Convert.ToInt32(reader["DILUENT_ID_SQ"]),
                            Designation = reader["DILUENT_NM"].ToString(),
                            Description = reader["DILUENT_DESC"].ToString(),
                            Source = reader["DILUENT_SOURCE_NM"].ToString(),
                            size = Convert.ToInt32(reader["DILUENT_SIZE_ID"]),
                            Sizecd = new KeyValue() { Key = reader["DILUENT_SIZE_ID"].ToString(), Value = reader["DILUENT_SIZE_NM"].ToString() },
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            PieceDensity = (reader["DILUENT_PD_VF"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["DILUENT_PD_VF"]),
                            ApparentBulkDensity = (reader["DILUENT_ABD_VF"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["DILUENT_ABD_VF"]),
                            ReferenceName = reader["REFERENCE_DILUENT_IND"].ToString(),
                            Referencecd = new KeyValue() { Key = reader["REFERENCE_DILUENT_IND"].ToString(), Value = reader["REF_IND_NM"].ToString() }
                        };
                        diluentarr.Lstdiluents.Add(_diluent);
                    }                   
                    diluentarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)diluentarr.lstStatus).AddRange(statuses);
                    diluentarr.lstReferences.Clear();
                    ((List<KeyValue>)diluentarr.lstReferences).AddRange(rerefernces);
                    return diluentarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
