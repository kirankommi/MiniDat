﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.DOE;
using MINIDAT.DataAccess.Repository.MinisQ;
using MINIDAT.Model;
using MINIDAT.Model.DOE;
using MINIDAT.Model.MINISQ;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class MINISQController:ApiController
    {
        [HttpGet, ActionName("GetMasterData")]
        public HttpResponseMessage GetMasterData()
        {

            Repository _repository = new Repository(new MINIDATDatabase());
            try
            {
                string userId = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
                return Request.CreateResponse(HttpStatusCode.OK, _repository.GetMasterData(userId));

            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get MasterData");
            }
        }
        [HttpGet, ActionName("GetStudies")]
        public HttpResponseMessage GetStudies()
        {

            Repository _repository = new Repository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _repository.GetStudiesData());

            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get studies data");
            }
        }
       
        [HttpPost, ActionName("ReOrderRuns")]
        public HttpResponseMessage ReOrderRuns([FromBody] ReOrderedRuns reOrderedRuns)
        {
            Repository _repository = new Repository(new MINIDATDatabase());

            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _repository.ReOrderRuns(reOrderedRuns));

            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to update dates");
            }
        }

        [ActionName("SaveColumnPreferences"), HttpPost]
        public HttpResponseMessage SaveColumnPreferences([FromBody]ColumnsPreferences columns)
        {
            Repository _repository = new Repository(new MINIDATDatabase());
            try
            {
                columns.UserId = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
                return Request.CreateResponse(HttpStatusCode.OK, _repository.SaveColPreferences(columns));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateResponse(HttpStatusCode.OK, ex.Message);
            }
        }
    }
}