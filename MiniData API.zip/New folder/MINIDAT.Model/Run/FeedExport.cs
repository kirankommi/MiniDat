﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class FeedExport
    {
        public string UOPNumber { get; set; }
        public string Name { get; set; }
        public double? API { get; set; }
        public string API_UOM { get; set; }
        public double? H2InFeed { get; set; }
        public string H2InFeed_UOM { get; set; }
        public double? SulfurInSweetFeed { get; set; }
        public string SulfurInSweetFeed_UOM { get; set; }
        public double? NitrogenInSweetFeed { get; set; }
        public string NitrogenInSweetFeed_UOM { get; set; }
        public double? SulfurInFeedBlend { get; set; }
        public string SulfurInFeedBlend_UOM { get; set; }
        public double? NitrogenInFeedBlend { get; set; }
        public string NitrogenInFeedBlend_UOM { get; set; }
        public List<FeedBlendExport> Blendcomponents { get; set; }
        public FeedExport()
        {
            Blendcomponents = new List<FeedBlendExport>();
        }
    }
    public class FeedBlendExport
    {
        public string ComponentName { get; set; }
        public string UOPNumber { get; set; }
        public decimal? Amountadded { get; set; }
        public decimal? Weightpct { get; set; }
    }
}
