import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import * as Constants from '../../../Shared/globalconstants';
import { NIRModelTemplateModel, KeyValue, FeedInfo } from '../../../models/NIRModelTemplateModel';
import { NIRModelTemplateService } from '../../../Services/NIRModelTemplate.service';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { UomControl } from '../../../Directives/uomcontrol.component';
import { SelectItem } from 'primeng/api';


@Component({
    selector: 'NIRModelTemplateManage',
    templateUrl: 'NIRModelTemplate.component.html',
    providers: [NIRModelTemplateService, AlertMessage, HttpActionService, ConfirmationService],
    styles: [`
        :host ::ng-deep .ui-multiselected-item-token,
        :host ::ng-deep .ui-multiselected-empty-token {
            padding: 2px 4px;
            margin: 0 0.286em 0 0;
            display: inline-block;
            vertical-align:middle;
            height: 1.857em;
        }

        :host ::ng-deep .ui-multiselected-item-token {
            background: #007ad9;
            color: #ffffff;
        }

        :host ::ng-deep .ui-multiselected-empty-token {
            background: #007ad9;
            color: #ffffff;
        }
    `]
})
export class NIRModelTemplateComponent implements OnInit {
    IsallowedSave: boolean = false;
    title: string;
    statuses: KeyValue[];
    ModelType: KeyValue[];
    selectedModelType: string;
    ConversionType: KeyValue[];
    selectedConversionType: string;
    lowUomObj: any = {};
    highUomObj: any = {};
    sigmaError: any = {};
    NIRData: NIRModelTemplateModel;
    check: boolean = false;
    nirTemplateSaved: string = "NIR Model Template Details Saved Successfully";
    nirTemplateDeleted: string = "NIR Model Template Deleted Successfully";
    LocalAccess: boolean = false;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    nirtemplatelst: any;
    conversionType: any;
    selectedFeed: string[];
    plantsSelectedlist: string[];
    selectedPlantKeyList: any;
    cloneIconPath: string;
    ModelTypeKey: any;
    conersionTypeKey: any;
    //feed: FeedInfo;
    feed: any;
    cancelPath: string;
    totalRecords: number;
    //Plants selected dropdown
    plantsMasterList: SelectItem[];
    plantsTestedlist: any
    //selectedplants: any;
    dummyfeed: any;
    duplicateFeedCheck = "Duplicate Feed Selected";
    isAlreadySelected: string[] = [];
    feedFlyoutcolumns: any[] = [
        { Key: "UOPNum", Value: "UOP #" },
        // { Key: "BookNum", Value: "Book #" },
        { Key: "Name", Value: "Name" },
        { Key: "DensityMsr", Value: "Feed Density at ISCO OP temperature (g/cc)" },

    ];
    constructor(private nirModelTemplateService: NIRModelTemplateService, private alertMessage: AlertMessage, private messageService: messageModalUtility
        , public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent, private confirmationService: ConfirmationService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.cloneIconPath = Constants.cloneIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
        this.cancelPath = Constants.cancelIcon;
    }
    ngDoCheck() {

        if (!this.check) {
            if (Constants.UserSessionData != Constants.Undefined) {
                if (Constants.UserPrivileges.length > 1) {
                    for (let i in Constants.UserPrivileges) {
                        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000028" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                            this.IsallowedSave = true;
                            this.check = true;
                        }
                    }

                }
            }
        }
    }

    ngOnInit() {
        this.NIRData = new NIRModelTemplateModel();
        this.getNIRModelTemplates();
        //this.NIRData.StatusName = Constants.Select;
        //this.NIRData.ConversionType = 0;
        //this.NIRData.NIRModelType = 0;
        this.title = Constants.ManageNIRModelTemplate;
        this.onReset();

    }
    //Load the data
    getNIRModelTemplates() {
        debugger;
        this.nirModelTemplateService.GetNIRModelTemplatInformation()
            .subscribe(
            (data: any) => {
                debugger;
                //this.NIRData = data;
                
                // this.nirtemplatelst = data.LstNIRModelTemplateModel;
                this.ModelType = data.lstModelTypes;
                this.feed = data.Feeds;
                this.ConversionType = data.lstConversionTypes;
                this.statuses = data.Status;
                this.plantsMasterList = data.lstPlantsTested.map((q) => ({ label: q.Key, value: q.Value }));

                //this.plantsMasterList = data.lstPlantsTested.map((q) => ({ Key: q.Key, Value: q.Value })); 
                console.log(this.NIRData);
                if (this.NIRData.NIRModelType == undefined || this.NIRData.NIRModelType == null) {
                    this.NIRData.NIRModelType = 0;
                }
                if (this.NIRData.ConversionType == undefined || this.NIRData.ConversionType == null) {
                    this.NIRData.ConversionType = 0;
                }
                if (this.NIRData.StatusName == undefined || this.NIRData.StatusName == null) {
                    this.NIRData.StatusName = Constants.Select;
                }


            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    onFeedSelected(event: any)
    {
        debugger;
        this.NIRData.lstFeedNames = this.NIRData.lstFeedNames || [];
        this.NIRData.lstFeedNames.push(event.Name);
        this.NIRData.lstFeedIds = this.NIRData.lstFeedIds || [];
        this.NIRData.lstFeedIds.push(event.ID);
        this.isAlreadySelected = [];
        if (this.NIRData.lstFeedNames.length > 1)
        {
            this.isAlreadySelected = this.NIRData.lstFeedNames.filter((elem, i, arr) => {
                if (arr.indexOf(elem) !== i) {
                    return elem
                }
            });
            
        }
        
        //let isAlreadySelected = this.NIRData.lstFeedNames.filter(q => q == event.Name);
        if (this.isAlreadySelected.length > 0) {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.duplicateFeedCheck });
            //this.NIRData.lstFeedNames = [];
            //this.NIRData.lstFeedIds = [];
            this.NIRData.lstFeedNames = this.NIRData.lstFeedNames.filter((elem, i, arr) => {
                if (arr.indexOf(elem) === i) {
                    return elem
                }
            });
            this.NIRData.lstFeedIds = this.NIRData.lstFeedIds.filter((elem, i, arr) => {
                if (arr.indexOf(elem) === i) {
                    return elem
                }
            });
            //return false;
        }
        
    }
    //delete
    getDelPath() {
        // debugger;
        if (!this.IsallowedSave) {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;
    }
    onDelete(nirModel: NIRModelTemplateModel) {
        this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) {
                this.deleteNIRTemplateInfo(nirModel);
                this.searchNIRTemplate(true);
            }
        });
    }

    deleteNIRTemplateInfo(nirModel: NIRModelTemplateModel) {
        debugger;

        this.nirModelTemplateService.deleteNIRModelTemplatInformation(nirModel)
            .subscribe(
            (data: any) => {
                if (data == "Delete") {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.nirTemplateDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    //reset
    onReset() {
        debugger;
        this.NIRData = new NIRModelTemplateModel();
        //this.sortField = "";
        //this.sortOrder = 0;
        this.NIRData.ConversionType = 0;
        this.NIRData.ModelID = "";
        this.NIRData.lstFeedIds = [];
        this.NIRData.lstFeedNames = [];
        this.NIRData.selectedplants = [];
        this.NIRData.NIRModelType = 0;
        this.NIRData.StatusName = Constants.Select;
        this.searchNIRTemplate(true);
    }

    //Search
    find() {
        this.searchNIRTemplate(false);
    }
    searchNIRTemplate(isInit: boolean) {
        debugger;
        this.NIRData.IsInitialLoad = isInit;
        if (this.NIRData.selectedplants.length != 0) {
            debugger;
            this.selectedPlantKeyList = this.plantsMasterList.filter(q => this.NIRData.selectedplants.includes(q.value)).map(q => q.label);
            this.plantsSelectedlist = this.NIRData.selectedplants;
            this.NIRData.selectedplants = [];
            for (let i = 0; i < this.plantsSelectedlist.length; i++) {
                this.NIRData.selectedplants.push(
                    {
                        Key: this.selectedPlantKeyList[i].trim(),
                        Value: this.plantsSelectedlist[i].trim()
                    }

                )
            }
        }
        this.nirModelTemplateService.SearchNIRModelTemplatInformation(this.NIRData).subscribe((data: any) => {
            debugger;
            this.nirtemplatelst = data;
        });
        let tempPlants = this.NIRData.selectedplants;
        this.NIRData.selectedplants = [];
        tempPlants.forEach(element => { this.NIRData.selectedplants.push(element.Value)})
    }
    isDataValidate()
    {
        if (this.NIRData.StatusName == "Select"
            || this.NIRData.NIRModelType == 0
            || this.NIRData.ModelID.length == 0
            || (this.NIRData.NIRModelType == 1 && (this.NIRData.ConversionCutPoint == null || this.NIRData.ConversionCutPoint == undefined))
            || this.NIRData.lstFeedNames.length == 0
            || this.NIRData.ConversionType == 0
            || this.NIRData.Low == null || this.NIRData.Low == undefined
            || this.NIRData.High == null || this.NIRData.High == undefined
            || this.NIRData.selectedplants.length == 0
        )
        {
            return false;
        }
        return true;
    }
    //save
    save() {
        debugger;
       
        if (this.isDataValidate())
        {
            this.selectedPlantKeyList = this.plantsMasterList.filter(q => this.NIRData.selectedplants.includes(q.value)).map(q => q.label);
            this.plantsSelectedlist = this.NIRData.selectedplants;
            this.NIRData.selectedplants = [];
            for (let i = 0; i < this.plantsSelectedlist.length; i++) {
                this.NIRData.selectedplants.push(
                    {
                        Key: this.selectedPlantKeyList[i].trim(),
                        Value: this.plantsSelectedlist[i].trim()
                    }

                )
            }

            if (this.NIRData.lstFeedIds.length != this.NIRData.lstFeedNames.length) {
                this.dummyfeed = this.feed.filter(q => this.NIRData.lstFeedNames.includes(q.Name)).map(q => q.ID);
                this.NIRData.lstFeedIds = this.dummyfeed;
            }

            this.nirModelTemplateService.SaveNIRModelTemplatInformation(this.NIRData).subscribe((data: any) => {
                debugger;
                //this.onReset();
                this.searchNIRTemplate(true);
                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Saved NIR Model Template', detail: this.nirTemplateSaved });
            });
            let tempPlants = this.NIRData.selectedplants;
            this.NIRData.selectedplants = [];
            tempPlants.forEach(element => { this.NIRData.selectedplants.push(element.Value) })
        //}
        //else if (this.repeatedFeed(this.NIRData.lstFeedNames)) {
        //    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.duplicateFeedCheck });
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onRowSelect(event: any) {
        debugger;

        this.NIRData.NIRModelType = event.data.ModelTypecd.Key;
        this.NIRData.ModelID = event.data.ModelID;
        this.NIRData.ConversionCutPoint = event.data.ConversionCutPoint;
        this.selectedFeed = (event.data.feedSelectedList).split("/");
        this.NIRData.lstFeedNames = (this.selectedFeed.length != 0) ? this.selectedFeed : [];
        this.conversionType = event.data.ConversionTypecd.Key;
        this.NIRData.ConversionType = this.conversionType;
        this.NIRData.Low = event.data.Low;
        this.NIRData.High = event.data.High;
        this.NIRData.SigmaError = event.data.SigmaError;
        this.plantsSelectedlist = (event.data.plantsSelectedlist).split(",");
        this.selectedPlantKeyList = (event.data.selectedPlantKeyList).split(",");
        this.NIRData.selectedplants = [];
        for (let i = 0; i < this.plantsSelectedlist.length; i++) {
            this.NIRData.selectedplants.push(

                this.plantsSelectedlist[i].trim()

            )
        }
        this.NIRData.StatusName = (event.data.StatusCode.Key != "Active") ? "N" : "Y";
        
        //for (let i = 0; i < this.plantsSelectedlist.length; i++) {
        //    this.NIRData.selectedplants.push(
        //        {
        //            Key: this.selectedPlantKeyList[i].trim(),
        //            Value: this.plantsSelectedlist[i].trim()
        //        }

        //    )
        //}

    }
   
    onPlantDeselect(event: any) {
        debugger;
        var index = (this.NIRData.selectedplants).indexOf(event);
        (this.NIRData.selectedplants).splice(index, 1);
        console.log(this.NIRData.selectedplants);
    }
    getCancel() {
        return this.cancelPath;
    }
    //clone
    getClonePath() {
        //    debugger;
        return this.cloneIconPath;
    }
    onClone(nir: NIRModelTemplateModel) {
        debugger;
        this.messageService.show(Constants.Confirm, Constants.ConfirmCloneMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) {
                this.cloneNIRModelInfo(nir);
            }
        });
    }
    cloneNIRModelInfo(nir: NIRModelTemplateModel) {
        debugger;
        let tempNIRID = Math.max(...this.nirtemplatelst.map(o => o.NIRModelSQID), 0);
        tempNIRID += 1;
        nir.ModelID = tempNIRID.toString();
        this.NIRData = nir;
        this.ModelTypeKey = nir.ModelTypecd.Key;
        this.NIRData.NIRModelType = this.ModelTypeKey;
        this.selectedFeed = (nir.feedSelectedList).split("/");
        this.NIRData.lstFeedNames = (this.selectedFeed.length != 0) ? this.selectedFeed : [];
        this.conersionTypeKey = nir.ConversionTypecd.Key;
        this.NIRData.ConversionType = this.conersionTypeKey;
        this.NIRData.StatusName = (nir.StatusCode.Key != "Active") ? "N" : "Y";
        this.NIRData.lstFeedNames = nir.feedSelectedList.split("/");
        this.plantsSelectedlist = (nir.plantsSelectedlist).split(",");
        //this.NIRData.selectedplants = this.plantsSelectedlist;
        //for (let i = 0; i < this.plantsSelectedlist.length; i++)
        //{
        //    this.NIRData.selectedplants[i] = this.plantsSelectedlist[i];
        //}
        //this.plantsSelectedlist = (nir.plantsSelectedlist).split(",");
        this.selectedPlantKeyList = (nir.selectedPlantKeyList).split(",");
        this.NIRData.selectedplants = [];
        for (let i = 0; i < this.plantsSelectedlist.length; i++) {
            this.NIRData.selectedplants.push(
                {
                    Key: this.selectedPlantKeyList[i].trim(),
                    Value: this.plantsSelectedlist[i].trim()
                }

            )
        }

        this.saveClone();

    }
    saveClone() {
        if (this.isDataValidate()) {
            this.dummyfeed = this.feed.filter(q => this.NIRData.lstFeedNames.includes(q.Name)).map(q => q.ID);
            this.NIRData.lstFeedIds = this.dummyfeed;
            this.nirModelTemplateService.SaveNIRModelTemplatInformation(this.NIRData).subscribe((data: any) => {
                debugger;
                //this.onReset();
                this.searchNIRTemplate(true);
                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Saved NIR Model Template', detail: this.nirTemplateSaved });
            });
            let tempPlants = this.NIRData.selectedplants;
            this.NIRData.selectedplants = [];
            tempPlants.forEach(element => { this.NIRData.selectedplants.push(element.Value) })
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }
}