﻿using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model
{
    public static class LogCategory
    {
        public const string FUNCTIONALITY = "Functionality";
        public const string EXCEPTION = "Exception";
        public const string LOGGED_IN_USER = "LoggedInUser";
        public const string UNAUTHORIZED_ATTEMPT = "UnAuthorizedAttempt";
        public const string PERFORMANCE_METRICS = "PerformanceMetrics";
        public const string LOGGED_IN_REGION = "LoggedInRegion";
    }
    public static class LogModuleCategory
    {
        public const string CreateFeed = "Create Feed";
        public const string CreateCrude = "Create Crude";        
        public const string LIMSSearch = "LIMS Search";
        public const string ViewSearch = "View/Search";
        public const string ManageRole = "Manage Role";
        public const string ManageUser = "Manage User";
        public const string ManageUOMTemplate = "Manage UOM Template";
        public const string ManageCustomer = "Manage Customer/Supplier";
        public const string ManageRoelMenu = "Manage RoleMenu";
        public const string ManageLIMSAnalysisMethod = "Manage LIMS Analysis Method";
        public const string ManageComponent = "Manage Component";
        public const string BlendFeed = "Blend Feed";
        public const string CrudeFeed = "Crude Feed";
        public const string SourceMapping = "Source Mapping";
        public const string ExternalSearch = "External Search";
        


    }
    public static class LogManager
    {
      
        const string FDMS_LOGGER_NAME = "MINIDAT";        
        public static void Info(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(FDMS_LOGGER_NAME);
            _logger.Info(message);
        }
        public static void Info<T>(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(typeof(T));
            _logger.Info(message);
        }

        public static void Error(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(FDMS_LOGGER_NAME);
            _logger.Error(message);
        }
        public static void Error<T>(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(typeof(T));
            _logger.Error(message);
        }
        public static void Error(Exception ex)
        {
            if (ex == null) throw new ArgumentNullException("ex");
            ILog _logger = log4net.LogManager.GetLogger(FDMS_LOGGER_NAME);
            _logger.Info(JsonConvert.SerializeObject(new { Category = LogCategory.EXCEPTION, Value = ex.GetType().ToString(), Source=ex.Source }));
            _logger.Error(JsonConvert.SerializeObject(ex));
        }

        public static void Fatal(Exception ex)
        {
            if (ex == null) throw new ArgumentNullException("ex");
            ILog _logger = log4net.LogManager.GetLogger(FDMS_LOGGER_NAME);
            _logger.Info(JsonConvert.SerializeObject(new { Category = LogCategory.EXCEPTION, Value = ex.GetType().ToString(), Source = ex.Source }));
            _logger.Fatal(JsonConvert.SerializeObject(ex));            
        }
        public static void Fatal(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(FDMS_LOGGER_NAME);
            _logger.Error(message);
        }
        public static void Fatal<T>(string message)
        {
            ILog _logger = log4net.LogManager.GetLogger(typeof(T));
            _logger.Fatal(message);
        }
    }
}
