﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Project;
using MINIDAT.Model;
using MINIDAT.Model.Run;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using NPOI.XSSF.UserModel;
using System.IO;
using NPOI.SS.UserModel;
using System.ComponentModel;
using System.Collections;
using System.Drawing;
using NPOI.SS.Util;
using System.Xml;

namespace MINIDAT.WebAPI.Controllers.RunController
{
    public class RunController : ApiController
    {
        [HttpGet, ActionName("GetRunSetupInfo")]
        public HttpResponseMessage GetRunSetupInfo(string Plant_cd, string RunId)
        {

            RunSetupRepository _RunRepository = new RunSetupRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetRunSetupModel(Plant_cd, RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost, ActionName("SaveRunSetUpDetails")]
        public HttpResponseMessage SaveRunSetUpDetails([FromBody] RunSetupModel run)
        {
            IRunSetupRepository _RunRepository = new RunSetupRepository(new MINIDATDatabase());
            try
            {
                _RunRepository.SaveRunSetupInformation(run, User.Identity.Name);
                //return Request.CreateResponse(HttpStatusCode.OK, runId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.RunSaveError.ToString());
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }

        [HttpGet, ActionName("GetGeneralInfo")]
        public HttpResponseMessage GetGeneralInfo(string Plant_cd,string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetGeneralInfo(Plant_cd,RunId));
                
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetRunSetUpMetadata")]
        public HttpResponseMessage GetRunSetUpMetadata(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetRunMetaData(Plant_cd, RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet, ActionName("GetFeedInfo")]
        public HttpResponseMessage GetFeedInfo(string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetFeedInfo(RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetNIRModelInformation")]
        public HttpResponseMessage GetNIRModelInformation(string Plant_cd, int ModeId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetNIRModelInformation(Plant_cd, ModeId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetProcessSpecInformation")]
        public HttpResponseMessage GetProcessSpecInformation(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetProcessSpecInformation(Plant_cd,RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetAnalyticalSampleInformation")]
        public HttpResponseMessage GetAnalyticalSamplingInfo(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetAnalyticalSamplingInfo(Plant_cd,RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetRunCutBoilingPointsInfo")]
        public HttpResponseMessage GetRunCutBoilingPointsInfo(string Plant_cd, string RunId, string ModeType)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetRunCutBoilingPointsInfo(Plant_cd, RunId, ModeType));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        
        [HttpPost, ActionName("SaveRunDetails")]
        public HttpResponseMessage SaveRunDetails([FromBody] RunModel run)
        {
            IRunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                _RunRepository.SaveRunInformation(run, User.Identity.Name);
               //return Request.CreateResponse(HttpStatusCode.OK, runId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.RunSaveError.ToString());                
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }

        [HttpGet, ActionName("GetRunMasterDetails")]
        public HttpResponseMessage GetRunMasterDetails(string Plant_cd, string Mode_Type)
        {
            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetRunMasterDetails(Plant_cd, Mode_Type));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetRunCatalystDetails")]
        public HttpResponseMessage GetRunCatalystDetails(string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetRunCatalystDetails(RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetTCCalibrationInformation")]
        public HttpResponseMessage GetTCCalibrationInformation(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetTCCalibrationInformation(Plant_cd,RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetTMFCalibrationInformation")]
        public HttpResponseMessage GetTMFCalibrationInformation(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetTMFCalibrationInformation(Plant_cd,RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet, ActionName("GetAdditionalInformation")]
        public HttpResponseMessage GetAdditionalInfo(string Plant_cd, string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetAdditionalInfo(Plant_cd, RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost, ActionName("SaveRunFeedDetails")]
        public HttpResponseMessage SaveRunFeedDetails([FromBody] GeneralInfoModel feed)
        {
            IRunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                _RunRepository.SaveRunFeedInformation(feed);
                //return Request.CreateResponse(HttpStatusCode.OK, runId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "AccoladeProjectAlreadyExists")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }

        [HttpGet, ActionName("GetSavedRunFeedDetails")]
        public HttpResponseMessage GetSavedRunFeedDetails(string RunId)
        {

            RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _RunRepository.GetSavedRunFeedDetails(RunId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet, ActionName("GetRunRecipeDetails")]
        public HttpResponseMessage GetRunRecipeDetails(string runId)
        {
            RunRepository _repository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _repository.getReciepesTemplateData(runId));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get receipes data");
            }
        }

        [HttpGet, ActionName("GetModeMasterData")]
        public HttpResponseMessage GetModeMasterData(string modeId)
        {
            RunRepository _repository = new RunRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _repository.getModeMasterData(modeId));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to get receipes data");
            }
        }
        [HttpGet, ActionName("GetCostVolume")]
        public async Task<HttpResponseMessage> GetCostVolume(string workitems)
        {
            try
            {
                string errMsg = String.Empty;

                dynamic json = JsonConvert.DeserializeObject(workitems);
                List<string> items = new List<string>();
                foreach (var item in json)
                {
                    items.Add(item.Value.ToString());
                }
                string[] workItems = items.ToArray();
                List<LIMSCostVolume> limsCostVolume = new List<LIMSCostVolume>();
                if (workItems.Length > 0)
                {

                    LIMSService.Service.LIMSSearch client = new LIMSService.Service.LIMSSearch();
                    var sampleIDs = client.GetWorkItemsCostVolume(workItems, ref errMsg);
                    if (sampleIDs != null)
                    {

                        limsCostVolume = (from DataRow row in sampleIDs.Rows
                                          select new LIMSCostVolume
                                          {
                                              LimsOperationName = row["Name"].ToString(),
                                              Cost = row["Cost"].ToString(),
                                              Volume = row["Volume"].ToString()

                                          }).ToList();
                    }
                }
                return Request.CreateResponse(HttpStatusCode.OK, limsCostVolume);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost, ActionName("SaveWeightChecks")]
        public HttpResponseMessage SaveWeightChecks([FromBody] RunMode runMode)
        {
            IRunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            string userId= User.Identity.Name;
            try
            {
                _RunRepository.SaveWeightChecks(runMode, userId);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }

        [HttpPost, ActionName("SaveRecipeData")]
        public HttpResponseMessage SaveRecipeData([FromBody] dynamic recipe, [FromUri] int runId)
        {
            IRunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
            string userId = User.Identity.Name;
            try
            {
                _RunRepository.SaveRecipeData(recipe, userId, runId);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex);
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        [HttpPost, ActionName("ExportData")]
        public Byte[] GenerateExcel_withDefaultUOM([FromBody] RunExport exportData)
        {
            try
            {
                RunRepository _RunRepository = new RunRepository(new MINIDATDatabase());
                //string userId = User.Identity.Name;
                string userId = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
                XSSFWorkbook workbook = new XSSFWorkbook();
                var normalStyle = setTableStyle(workbook);
                ISheet sheet1 = workbook.CreateSheet("Run Setup");
                sheet1.SetColumnWidth(0, 4000);
                sheet1.SetColumnWidth(1, 4000);
                sheet1.SetColumnWidth(2, 4000);
                sheet1.SetColumnWidth(4, 4000);
                sheet1.SetColumnWidth(5, 5000);
                sheet1.SetColumnWidth(6, 4000);
                sheet1.SetColumnWidth(7, 4000);
                sheet1.SetColumnWidth(8, 6000);
                sheet1.SetColumnWidth(9, 4000);
                sheet1.SetColumnWidth(10, 4000);
                sheet1.SetColumnWidth(11, 4000);
                var _rowIndex = 0;

                var row = sheet1.CreateRow(_rowIndex++);
                SetTitle(sheet1, workbook, "Run Setup");

                /////////////////Header Styling for table/////////////////////////////////////////
                var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.FillPattern = FillPattern.SolidForeground;
                headerStyle.WrapText = true;
                headerStyle.BorderTop = BorderStyle.Thin;
                headerStyle.BorderBottom = BorderStyle.Thin;
                headerStyle.BorderLeft = BorderStyle.Thin;
                headerStyle.BorderRight = BorderStyle.Thin;
                headerStyle.Alignment = HorizontalAlignment.Center;
                XSSFFont hFont = (XSSFFont)workbook.CreateFont();
                hFont.FontHeightInPoints = 11;
                hFont.FontName = "Calibri";
                hFont.Boldweight = (short)FontBoldWeight.Bold;
                headerStyle.SetFont(hFont);
                //////////////////////////////////////////////////////////

                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);
                row.SetCellValue(1, "Plant", headerStyle);
                row.SetCellValue(2, exportData.Plant, normalStyle);
                row.SetCellValue(4, "Run", headerStyle);
                row.SetCellValue(5, exportData.RunNum.ToString(),normalStyle);
                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);

                
                RunExport exportedRunData = new RunExport();
                exportedRunData = _RunRepository.GetExportData(userId,Convert.ToInt16(exportData.RunId));
                

                ////////////////
                //General Info//
                ////////////////
                if (exportData.PopupSummary.isGeneralInfo)
                {
                    GeneralInfoModel GI = new GeneralInfoModel();
                    GI = exportData.GeneralInfo;


                    row = sheet1.CreateRow(_rowIndex++);
                    SetSubTitle2(sheet1, workbook, "General Info", _rowIndex);

                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, "Run Start Time", headerStyle);
                    row.SetCellValue(1, "Zero HOS Time", headerStyle);
                    row.SetCellValue(2, "Mode", headerStyle);
                    row.SetCellValue(3, "Feed Condition", headerStyle);
                    row.SetCellValue(4, "Network #", headerStyle);
                    row.SetCellValue(5, "Project Manager/Specialist", headerStyle);
                    row.SetCellValue(6, "Technician 1", headerStyle);
                    row.SetCellValue(7, "Technician 2", headerStyle);
                    row.SetCellValue(8, "Run Description", headerStyle);
                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, exportData.StartDate == null ? "" : Convert.ToDateTime(exportData.StartDate).ToString(), normalStyle);
                    row.SetCellValue(1, exportData.ZeroHOSTime == null ? "" : Convert.ToDateTime(exportData.ZeroHOSTime).ToString(), normalStyle);
                    row.SetCellValue(2, GI.ModeType, normalStyle);
                    row.SetCellValue(3, exportedRunData.GeneralInfo.FeedCondition, normalStyle);
                    row.SetCellValue(4, GI.NetworkNumber, normalStyle);
                    row.SetCellValue(5, GI.projectMgr, normalStyle);
                    row.SetCellValue(6, GI.Technician1, normalStyle);
                    row.SetCellValue(7, GI.Technician2, normalStyle);
                    row.SetCellValue(8, GI.RunDescription, normalStyle);
                }
                ////////////////////
                //Boiling Point   //
                ////////////////////
                if (exportData.PopupSummary.isBoilingPoint && exportedRunData.lstRunCutBoilingPoints.Count>0)
                {
                    DataTable dt = ConvertToDataTable<BoilingPointExport>(exportedRunData.lstRunCutBoilingPoints);

                    object InitialBoilingPointUOM = dt.Rows[0][3];
                    object EndBoilingPointUOM = dt.Rows[0][4];
                    dt.Columns["InitialBoilingPoint"].ColumnName = "Initial Boiling Point (" + Convert.ToString(InitialBoilingPointUOM) + ")";
                    dt.Columns["EndBoilingPoint"].ColumnName = "End Boiling Point (" + Convert.ToString(EndBoilingPointUOM) + ")";
                    dt.Columns["YieldCutLabel"].ColumnName = "Yield Cut Label";
                    dt.Columns.Remove("InitialBoilingPointUOM");
                    dt.Columns.Remove("EndBoilingPointUOM");

                    _rowIndex = AddDataToExcel(dt, _rowIndex, "Boiling Point", workbook, sheet1);
                }
                ////////////////////
                //Catalyst And Bed//
                ////////////////////

                if (exportData.PopupSummary.isCatalyst && exportedRunData.Cataysts.Count > 0)
                {
                    DataTable dt = ConvertToDataTable<RunCatalystModelExport>(exportedRunData.Cataysts);
                    dt.Columns["CatalystId"].ColumnName = "Catalyst ID #";
                    dt.Columns["CatalystFamilyName"].ColumnName = "Family";
                    string PiecDensityUOM =Convert.ToString( dt.Rows[0]["pieceDensityUOM"]);
                    dt.Columns["pieceDensityValue"].ColumnName = "Piece Density ("+ PiecDensityUOM + ")";
                    dt.Columns.Remove("pieceDensityUOM");
                    dt.Columns["CatalystSize"].ColumnName = "Size";
                    dt.Columns["CatalystShape"].ColumnName = "Shape";
                    dt.Columns["Voidfraction"].ColumnName = "Void Fraction";
                    dt.Columns["LoadingDensityTypeName"].ColumnName = "Loading Density Type";
                    dt.Columns["LoadDensityValue"].ColumnName = "Loading Density Value";
                    dt.Columns["LoadDensityUOM"].ColumnName = "Loading Density UOM";

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string loadingDensity = Convert.ToString(dt.Rows[i]["Loading Density Type"]);
                        if (loadingDensity == "Calculated")
                        {
                            dt.Rows[i]["Loading Density Value"] = dt.Rows[i]["CalculatedBedDensity"];
                            dt.Rows[i]["Loading Density UOM"] = dt.Rows[i]["Calculated_Bed_Density_UOM"];
                        }
                        else if (loadingDensity == "Custom")
                        {
                            dt.Rows[i]["Loading Density Value"] = dt.Rows[i]["CustomBedDensity"];
                            dt.Rows[i]["Loading Density UOM"] = dt.Rows[i]["Custom_bed_density_uom"];
                        }
                        else if (loadingDensity == "Vibrated")
                        {
                            dt.Rows[i]["Loading Density Value"] = dt.Rows[i]["vibrated_bed_density_value"];
                            dt.Rows[i]["Loading Density UOM"] = dt.Rows[i]["vibrated_bed_density_UOM"];
                        }
                    }
                    dt.Columns.Remove("CalculatedBedDensity");
                    dt.Columns.Remove("Calculated_Bed_Density_UOM");
                    dt.Columns.Remove("vibrated_bed_density_value");
                    dt.Columns.Remove("vibrated_bed_density_UOM");
                    dt.Columns.Remove("CustomBedDensity");
                    dt.Columns.Remove("Custom_bed_density_uom");
                    dt.Columns["CatalystDescription"].ColumnName = "Description";
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "Catalyst", workbook, sheet1);

                    DataTable dt2 = ConvertToDataTable<BedDetailsExport>(exportedRunData.Beds);
                    dt2.Columns["CatalystId"].ColumnName = "Catalyst ID #";
                    dt2.Columns["BedNumber"].ColumnName = "Bed #";
                    dt2.Columns["CatalystVolume"].ColumnName = "Catalyst Volume (cc)";
                    dt2.Columns["DiluentDesignation"].ColumnName = "Diluent Designation";
                    dt2.Columns["DiluentVolume"].ColumnName = "Diluent Volume (cc)";
                    _rowIndex = AddDataToExcel(dt2, _rowIndex, "Loading Teamplate", workbook, sheet1);
                }
                ////////
                //Feed//
                ////////
                if (exportData.PopupSummary.isFeed && exportedRunData.FeedInfo != null)
                {
                    decimal? totalAmout = 0;
                    double totalAmoutdouble=0;
                    double totalWeightDouble=0;
                    decimal? totalWeight = 0;
                    _rowIndex = _rowIndex + 3;
                    row = sheet1.CreateRow(_rowIndex++);
                    SetSubTitle2(sheet1, workbook, "Feed Info", _rowIndex);

                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, "UOP#", headerStyle);
                    row.SetCellValue(1, "Name", headerStyle);
                    row.SetCellValue(2, "API (" + Convert.ToString(exportedRunData.FeedInfo.API_UOM) + ")", headerStyle);
                    row.SetCellValue(3, "H2 in Feed (" + Convert.ToString(exportedRunData.FeedInfo.H2InFeed_UOM) + ")", headerStyle);
                    row.SetCellValue(4, "S in Sweet Feed (" + Convert.ToString(exportedRunData.FeedInfo.SulfurInSweetFeed_UOM) + ")", headerStyle);
                    row.SetCellValue(5, "N in Sweet Feed (" + Convert.ToString(exportedRunData.FeedInfo.NitrogenInSweetFeed_UOM) + ")", headerStyle);
                    row.SetCellValue(6, "S in Feed Blend (" + Convert.ToString(exportedRunData.FeedInfo.SulfurInFeedBlend_UOM) + ")", headerStyle);
                    row.SetCellValue(7, "N in Feed Blend (" + Convert.ToString(exportedRunData.FeedInfo.NitrogenInFeedBlend_UOM) + ")", headerStyle);
                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, exportedRunData.FeedInfo.UOPNumber, normalStyle);
                    row.SetCellValue(1, exportedRunData.FeedInfo.Name, normalStyle);
                    row.SetCellValue(2, Convert.ToString(exportedRunData.FeedInfo.API), normalStyle);
                    row.SetCellValue(3, Convert.ToString(exportedRunData.FeedInfo.H2InFeed), normalStyle);
                    row.SetCellValue(4, Convert.ToString(exportedRunData.FeedInfo.SulfurInSweetFeed), normalStyle);
                    row.SetCellValue(5, Convert.ToString(exportedRunData.FeedInfo.NitrogenInSweetFeed), normalStyle);
                    row.SetCellValue(6, Convert.ToString(exportedRunData.FeedInfo.SulfurInFeedBlend), normalStyle);
                    row.SetCellValue(7, Convert.ToString(exportedRunData.FeedInfo.NitrogenInFeedBlend), normalStyle);

                    _rowIndex = _rowIndex + 1;
                    row = sheet1.CreateRow(_rowIndex++);
                    SetSubTitle2(sheet1, workbook, "Feed Blend Component", _rowIndex);
                    
                    //row.CreateCell(0).SetCellValue("Feed Blend Component");
                    DataTable dt = ConvertToDataTable<FeedBlendExport>(exportedRunData.FeedInfo.Blendcomponents);
                    dt.Columns["ComponentName"].ColumnName = "Component Name";
                    dt.Columns["UOPNumber"].ColumnName = "UOP#";
                    dt.Columns["Amountadded"].ColumnName = "Added Amount (Grams)";
                    dt.Columns["Weightpct"].ColumnName = "Weight %";
                    row = sheet1.CreateRow(_rowIndex++);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        String columnName = Convert.ToString(dt.Columns[j]);
                        row.SetCellValue(j, columnName, headerStyle);
                    }
                    //loops through data
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        row = sheet1.CreateRow(_rowIndex++);
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            String columnName = Convert.ToString(dt.Columns[j]);
                            row.SetCellValue(j, Convert.ToString(dt.Rows[i][columnName]), normalStyle);
                        }
                    }
                    //Total Value of amount and Weight
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        totalAmout = totalAmout +Convert.ToDecimal(dt.Rows[i]["Added Amount (Grams)"]);
                        totalAmoutdouble=Math.Round(Convert.ToDouble(totalAmout), 2, MidpointRounding.AwayFromZero);
                        totalWeight = totalWeight + Convert.ToDecimal(dt.Rows[i]["Weight %"]);
                        totalWeightDouble=Math.Round(Convert.ToDouble(totalWeight), 2, MidpointRounding.AwayFromZero);
                    }
                    
                    row = sheet1.CreateRow(_rowIndex++);
                    row = sheet1.CreateRow(_rowIndex++);
                    //////////////////////////////////////////////////////
                    var SubStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                    SubStyle.BorderTop = BorderStyle.Thin;
                    SubStyle.BorderBottom = BorderStyle.Thin;
                    SubStyle.BorderLeft = BorderStyle.Thin;
                    SubStyle.BorderRight = BorderStyle.Thin;
                    SubStyle.Alignment = HorizontalAlignment.Center;
                    SubStyle.WrapText = true;
                    SubStyle.VerticalAlignment = VerticalAlignment.Center;
                    XSSFFont hFont1 = (XSSFFont)workbook.CreateFont();
                    hFont1.FontHeightInPoints = 11;
                    hFont1.FontName = "Calibri";
                    hFont1.Boldweight = (short)FontBoldWeight.Bold;
                    SubStyle.SetFont(hFont1);
                    //////////////////////////////////////////////////////
                    row.SetCellValue(1, "Total", SubStyle);
                    row.SetCellValue(2, Convert.ToString(totalAmoutdouble) +" Grams", SubStyle);
                    row.SetCellValue(3, Convert.ToString(totalWeightDouble)+"%", SubStyle);
                }
                //////////////////////
                //Analytical Samples//
                /////////////////////
                if (exportData.PopupSummary.isAnalyticalSample && exportedRunData.lstAnalyticalSamples.Count > 0)
                {
                    DataTable dt = ConvertToDataTable<AnalyticalInfoModelExport>(exportedRunData.lstAnalyticalSamples);
                    dt.Columns["StreamName"].ColumnName = "Stream Name";
                    dt.Columns["LIMSOPerationName"].ColumnName = "LIMS Operation Name";
                    dt.Columns["MethodNumber"].ColumnName = "Method Number";
                    dt.Columns["SampleVolumeinCC"].ColumnName = "Sample Volume";
                    dt.Columns["SampleCost"].ColumnName = "Sample Cost ($)";
                    dt.Columns["FrequencyName"].ColumnName = "Frequency";
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "Analytical Samples", workbook, sheet1);
                }
                //////////////////
                //// NIR Specs ///
                //////////////////
                if (exportData.PopupSummary.isNIRSpecs && exportedRunData.lstNIRSpec.Count>0)
                {
                    DataTable dt = ConvertToDataTable<NIRModelExport>(exportedRunData.lstNIRSpec);
                    dt.Columns["ParameterUOM"].ColumnName = "UOM";
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "NIR Specs", workbook, sheet1);
                }
                /////////////////////////////////////
                //TMF & Mass Flow Meter Calibration//
                ////////////////////////////////////
                if (exportData.PopupSummary.isTMS && exportedRunData.lstTMF_Calibrations.Count>0)
                {
                    DataTable dt = ConvertToDataTable<TMF_Calibration>(exportedRunData.lstTMF_Calibrations);
                    dt.Columns["ParameterUOM"].ColumnName = "UOM";
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "TMF & Mass Flow Meter Calibration", workbook, sheet1);
                }
                /////////////////////////
                //Process Specification//
                /////////////////////////
                if (exportData.PopupSummary.isProcessSpec)
                {
                    DataTable dt = ConvertToDataTable<ProcessSpecsInfoExport>(exportedRunData.lstProcessSpec);
                    dt.Columns["ParameterName"].ColumnName = "Parameter";
                    dt.Columns["ParameterUOM"].ColumnName = "UOM";
                    dt.Columns["Range"].ColumnName = "+/- Range";
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "Process Specs", workbook, sheet1);
                }
                /////////////////
                //Additional Info//
                /////////////////
                if (exportData.PopupSummary.isAdditionalInfo && exportedRunData.AdditionalInfo != null)
                {
                    _rowIndex = _rowIndex + 3;
                    row = sheet1.CreateRow(_rowIndex++);
                    SetSubTitle2(sheet1, workbook, "Additional Info", _rowIndex);

                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, "Treatment of Simdist & GLC Mismatch", headerStyle);
                    row.SetCellValue(1, "Expected C6-C10 Offgas Heavies Weight(" + exportedRunData.AdditionalInfo.OffgasHeaviesWeight_UOM + ")", headerStyle);
                    row.SetCellValue(2, "H2 TMF PV Spec (" + exportedRunData.AdditionalInfo.H2TMFSpec_UOM + ")", headerStyle);
                    row.SetCellValue(3, "Feed Source", headerStyle);
                    row.SetCellValue(4, "Plant or TC Offset (" + exportedRunData.AdditionalInfo.PlantTCOffset_UOM + ")", headerStyle);
                    row.SetCellValue(5, "HPS Pressure Controller Offset (" + exportedRunData.AdditionalInfo.HPSControllerOffset_UOM + ")", headerStyle);
                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, exportedRunData.AdditionalInfo.SelectedNormalizationFactor, normalStyle);
                    row.SetCellValue(1, Convert.ToString(exportedRunData.AdditionalInfo.OffgasHeaviesWeight), normalStyle);
                    row.SetCellValue(2, Convert.ToString(exportedRunData.AdditionalInfo.H2TMFSpec), normalStyle);
                    row.SetCellValue(3, Convert.ToString(exportedRunData.AdditionalInfo.SelectedFeedSource), normalStyle);
                    row.SetCellValue(4, Convert.ToString(exportedRunData.AdditionalInfo.PlantTCOffset), normalStyle);
                    row.SetCellValue(5, Convert.ToString(exportedRunData.AdditionalInfo.HPSControllerOffset), normalStyle);
                }
                //////////////////
                //TC Calibration//
                //////////////////
                if (exportData.PopupSummary.isTCCaliration && exportedRunData.lstTC_Calibrations.Count>0)
                {
                    DataTable dt = ConvertToDataTable<TC_Calibration_Export>(exportedRunData.lstTC_Calibrations);
                    dt.Columns["ParameterName"].ColumnName = "Parameter";
                    dt.Columns["ParameterUOM"].ColumnName = "UOM";
                    var BottomName = dt.Rows[dt.Rows.Count - 1]["Parameter"];
                    var topName = dt.Rows[dt.Rows.Count - 2]["Parameter"];
                    var TC_Bottom_Change_Date = dt.Rows[dt.Rows.Count - 1]["CalibrationDate"];
                    var TC_Top_Change_Date = dt.Rows[dt.Rows.Count - 2]["CalibrationDate"];
                    dt.Columns.Remove("CalibrationDate");
                    _rowIndex = AddDataToExcel(dt, _rowIndex, "TC Calibration", workbook, sheet1);
                    _rowIndex = _rowIndex - 2;
                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, Convert.ToString(topName), normalStyle);
                    row.SetCellValue(1, Convert.ToString(TC_Top_Change_Date), normalStyle);
                    row.SetCellValue(2, "", normalStyle);
                    row = sheet1.CreateRow(_rowIndex++);
                    row.SetCellValue(0, Convert.ToString(BottomName), normalStyle);
                    row.SetCellValue(1, Convert.ToString(TC_Bottom_Change_Date), normalStyle);
                    row.SetCellValue(2, "", normalStyle);
                }
                ////////////
                // Recipe //
                ////////////
                if (exportData.PopupSummary.isRecipe)
                {
                    IEnumerable<dynamic> RecipeData;
                    RecipeData = _RunRepository.getReciepes(userId, Convert.ToInt16(exportData.RunId));
                    List<dynamic> RecipeDatalist = RecipeData.ToList();
                    if (RecipeDatalist.Count > 0)
                    {
                        var json = JsonConvert.SerializeObject(RecipeData);
                        DataTable dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
                        dt.Columns["RECEIPE_TAG"].ColumnName = "Tag";
                        dt.Columns["RECEIPE_TAG_DESC"].ColumnName = "Description";
                        dt.Columns["ENERGIZE_TXT"].ColumnName = "Energized";
                        _rowIndex = AddDataToExcel2(dt, _rowIndex, "Recipe", workbook, sheet1,"");
                    }

                }
                using (MemoryStream output = new MemoryStream())
                {
                    workbook.Write(output);
                    return output.ToArray();
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public int AddDataToExcel(DataTable dt,int _rowIndex, String ModuleName,XSSFWorkbook workbook,ISheet sheet1)
        {
            var normalStyle = setTableStyle(workbook);
            /////////////////Header Styling for table/////////////////////////////////////////
            var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
            headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.FillPattern = FillPattern.SolidForeground;
            headerStyle.WrapText = true;
            headerStyle.BorderTop = BorderStyle.Thin;
            headerStyle.BorderBottom = BorderStyle.Thin;
            headerStyle.BorderLeft = BorderStyle.Thin;
            headerStyle.BorderRight = BorderStyle.Thin;
            headerStyle.Alignment = HorizontalAlignment.Center;
            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 11;
            hFont.FontName = "Calibri";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            headerStyle.SetFont(hFont);
            //////////////////////////////////////////////////////////
            _rowIndex = _rowIndex + 3;
            var row = sheet1.CreateRow(_rowIndex++);
            SetSubTitle2(sheet1, workbook, ModuleName, _rowIndex);
            row = sheet1.CreateRow(_rowIndex++);

            for (int j = 0; j < dt.Columns.Count; j++)
            {

                String columnName = Convert.ToString(dt.Columns[j]);
                row.SetCellValue(j, columnName, headerStyle);
            }
            //loops through data
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                row = sheet1.CreateRow(_rowIndex++);
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    String columnName = dt.Columns[j].ToString();
                    row.SetCellValue(j, Convert.ToString(dt.Rows[i][columnName]), normalStyle);
                }
            }
            return _rowIndex;
        }
        public int AddDataToExcel2(DataTable dt, int _rowIndex, String ModuleName, XSSFWorkbook workbook, ISheet sheet1, string exportSheetName)
        {
            var normalStyle = setTableStyle(workbook);
            /////////////////Header Styling for table/////////////////////////////////////////
            var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
            headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.FillPattern = FillPattern.SolidForeground;
            headerStyle.WrapText = true;
            headerStyle.BorderTop = BorderStyle.Thin;
            headerStyle.BorderBottom = BorderStyle.Thin;
            headerStyle.BorderLeft = BorderStyle.Thin;
            headerStyle.BorderRight = BorderStyle.Thin;
            headerStyle.Alignment = HorizontalAlignment.Center;
            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 11;
            hFont.FontName = "Calibri";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            headerStyle.SetFont(hFont);
            //////////////////////////////////////////////////////////
            _rowIndex = _rowIndex + 3;
            var row = sheet1.CreateRow(_rowIndex++);
            SetSubTitle2(sheet1, workbook, ModuleName, _rowIndex);
            row = sheet1.CreateRow(_rowIndex++);

            for (int j = 0; j < dt.Columns.Count; j++)
            {

                String columnName = Convert.ToString(dt.Columns[j]);
                row.SetCellValue(j, columnName, headerStyle);
            }

            if(exportSheetName!= "DataViewer")
            {
                row = sheet1.CreateRow(_rowIndex++);
                int ind = 1;
                for (int k = 4; k < dt.Columns.Count; k++)
                {
                    row.SetCellValue(k, "RCP #" + Convert.ToString(ind), headerStyle);
                    ind++;
                }
            }
            //loops through data
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                row = sheet1.CreateRow(_rowIndex++);
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    String columnName = dt.Columns[j].ToString();
                    row.SetCellValue(j, Convert.ToString(dt.Rows[i][columnName]), normalStyle);
                }
            }
            return _rowIndex;
        }
        public void SetTitle(ISheet sheet, XSSFWorkbook workbook,string title)
        {
            var Style = (XSSFCellStyle)workbook.CreateCellStyle();
            Style.Alignment = HorizontalAlignment.Center;
            Style.WrapText = true;
            Style.VerticalAlignment = VerticalAlignment.Center;

            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 14;
            hFont.FontName = "Arial";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            Style.SetFont(hFont);
            var cra = new NPOI.SS.Util.CellRangeAddress(0, 1, 3, 7);
            sheet.AddMergedRegion(cra);
            sheet.GetRow(0).SetCellValue(3, title, Style);
        }
        public void SetSubTitle2(ISheet sheet, XSSFWorkbook workbook, string subTitleName, int _rowIndex)
        {
            var Style = (XSSFCellStyle)workbook.CreateCellStyle();
            Style.Alignment = HorizontalAlignment.Left;
            Style.WrapText = true;
            Style.VerticalAlignment = VerticalAlignment.Center;

            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 14;
            hFont.FontName = "Courier";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            hFont.Underline = FontUnderlineType.Single;
            Style.SetFont(hFont);
            _rowIndex = _rowIndex - 1;
            CellRangeAddress crasub = new CellRangeAddress(_rowIndex, _rowIndex, 0, 6);
            sheet.AddMergedRegion(crasub);
            sheet.GetRow(_rowIndex).SetCellValue(0, subTitleName, Style);
        }
        XSSFCellStyle tableCenteredStyle;
        public XSSFCellStyle setTableStyle(XSSFWorkbook workbook)
        {
            if (tableCenteredStyle == null)
            {
                tableCenteredStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                tableCenteredStyle.BorderTop = BorderStyle.Thin;
                tableCenteredStyle.BorderBottom = BorderStyle.Thin;
                tableCenteredStyle.BorderLeft = BorderStyle.Thin;
                tableCenteredStyle.BorderRight = BorderStyle.Thin;
                tableCenteredStyle.Alignment = HorizontalAlignment.Center;
                tableCenteredStyle.VerticalAlignment = VerticalAlignment.Center;
                tableCenteredStyle.WrapText = true;
                XSSFFont hFont = (XSSFFont)workbook.CreateFont();
                hFont.FontHeightInPoints = 11;
                hFont.FontName = "Calibri";
                tableCenteredStyle.SetFont(hFont);
            }
            return tableCenteredStyle;
        }
        public DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }
        

    }
    public static class ExportUtility
    {
        static decimal decimalNumber = 0;
        static double doubleNumber = 0.0;
        public static IRow SetCellValue(this IRow Row, int CellNo, string Value, ICellStyle style)
        {
            if (Row != null)
            {
                var Namecell = Row.CreateCell(CellNo);
                if (Decimal.TryParse(Value, out decimalNumber) || Double.TryParse(Value, out doubleNumber))
                {
                    Namecell.SetCellValue(Convert.ToDouble(Value));
                }
                else
                {
                    Namecell.SetCellValue(Value);
                }
                Namecell.CellStyle = style;
            }
            return Row;
        }
    }
}
