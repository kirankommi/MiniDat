import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { RunModel, FeedModel, RunCatalyst, GeneralInfoModel, RunModeData } from '../../Models/Run/RunModel';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { KeyValue } from '../../Models/usermodel';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Injectable({
    providedIn: 'root'
})
export class RunService {
    private GetGeneralInfoUrl = "/Run/GetGeneralInfo/";
    private GetFeedInfoUrl = "/Run/GetFeedInfo/";
    private GetNIRModelInformationUrl = "/Run/GetNIRModelInformation/";
    private GetProcessSpecInformationUrl = "/Run/GetProcessSpecInformation/";
    private GetAnalyticalSamplingInfoUrl = "/Run/GetAnalyticalSamplingInfo/";
    private GetBoilingPointsInfoUrl = "/Run/GetBoilingPointsInfo/";
    private SaveRunDetailsUrl = "/Run/SaveRunDetails/";
    private SaveRunSetupDetailsUrl = "/Run/SaveRunSetUpDetails/";
    private SaveRunFeedDetailsUrl = "/Run/SaveRunFeedDetails/";
    private GetRunMasterDetailsUrl = "/Run/GetRunMasterDetails/";
    private GetRunCatalystDetailsUrl = "/Run/GetRunCatalystDetails/";
    private GetTCCalibrationInformationUrl = "/Run/GetTCCalibrationInformation/";
    private GetTMFCalibrationInformationUrl = "/Run/GetTMFCalibrationInformation/";
    private GetAdditionalInformationUrl = "/Run/GetAdditionalInformation/";
    private GetRunCutBoilingPointInformationUrl = "/Run/GetRunCutBoilingPointsInfo/";
    private GetAnalyticalSampleInformationUrl = "/Run/GetAnalyticalSampleInformation/";
    private GetSavedRunFeedDetailsUrl = "/Run/GetSavedRunFeedDetails/";
    private GetLIMSCostVolumeUrl = "/Run/GetCostVolume/";
    private GetRunMetaDataUrl = "/Run/GetRunSetUpMetadata/";


    private GetRecipeDataUrl = "/Run/GetRunRecipeDetails/";
    private GetModeMasterUrl = "/Run/GetModeMasterData/";
    private SaveWeightCheckUrl = "/Run/SaveWeightChecks/";
    private SaveRecipeUrl = "/Run/SaveRecipeData/";
    private GetExportPopUpUrl = "/Run/ExportData/"; 
    private GetRunSetupInfoUrl = "/Run/GetRunSetupInfo/";
    constructor(private httpaction: HttpActionService) { }

    GetGeneralInfo(Plant_cd: string, RunId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetGeneralInfoUrl, options);
    }
    GetRunMetaData(Plant_cd: string, RunId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunMetaDataUrl, options);
    }
    GetFeedInfo(RunId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetFeedInfoUrl, options);
    }

    GetNIRModelInformation(Plant_cd: string, ModeId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        //params.set('runId', RunId);
        params.set('Plant_cd', Plant_cd);
        params.set('ModeId', ModeId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetNIRModelInformationUrl, options);
    }
    GetProcessSpecInformation(Plant_cd: string, RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetProcessSpecInformationUrl, options);
    }
    GetAnalyticalSampleInformation(Plant_cd: string, RunId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAnalyticalSampleInformationUrl, options);
    }

    GetRunBoilingPointsInfo(Plant_cd: string, RunId: string, ModeType: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('RunId', RunId);
        params.set('ModeType', ModeType);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunCutBoilingPointInformationUrl, options);
    }
    SaveRunDetails(run: RunModel) {
        debugger;
        return this.httpaction.post(run, this.SaveRunDetailsUrl);
    }
    SaveRunSetupDetails(run: RunSetupModel) {
        debugger;
        return this.httpaction.post(run, this.SaveRunSetupDetailsUrl);
    }
    SaveRunFeedDetails(feed: GeneralInfoModel) {
        debugger;
        return this.httpaction.post(feed, this.SaveRunFeedDetailsUrl);
    }
    GetRunMasterDataInfo(Plant_cd: string, Mode_Type: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('Mode_Type', Mode_Type);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunMasterDetailsUrl, options);
    }
    GetRunCatalystInfo(RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunCatalystDetailsUrl, options);
    }
    GetSavedRunFeedInfomration(RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetSavedRunFeedDetailsUrl, options);
    }
    GetTMFCalibrationInformation(Plant_cd: string, RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetTMFCalibrationInformationUrl, options);
    }
    GetTCCalibrationInformation(Plant_cd: string, RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetTCCalibrationInformationUrl, options);
    }
    GetAdditionalInformation(Plant_cd: string, RunId: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', Plant_cd);
        params.set('runId', RunId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAdditionalInformationUrl, options);
    }
    GetLIMSInfo(workItems: string[]) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('workitems', JSON.stringify(workItems));
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetLIMSCostVolumeUrl, options);
    }
    GetRecipeInformation(runId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('runId', runId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRecipeDataUrl, options);
    }
    GetModeMasterData(modeId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('modeId', modeId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetModeMasterUrl, options);
    }
    SaveWeightChecks(runMode: RunModeData) {
        let params: URLSearchParams = new URLSearchParams();
        return this.httpaction.post(runMode, this.SaveWeightCheckUrl);

    }
    GetExportData(_exportData:RunModel){
        debugger;
        return this.httpaction.post(_exportData, this.GetExportPopUpUrl);
    }
    SaveRecipeInfo(recipe: any, runId: string) {
        let params: URLSearchParams = new URLSearchParams();
        return this.httpaction.post(recipe, this.SaveRecipeUrl + "?runId=" + Number(runId) );
    }
    getRunSetupInfo(plant: any, runId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('Plant_cd', plant);
        params.set('runId', runId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunSetupInfoUrl, options);
    
    }
}

