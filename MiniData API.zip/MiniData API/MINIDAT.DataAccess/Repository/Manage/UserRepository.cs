/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	UserRepository.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	01 june 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Framework.Emailing;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using MINIDAT.Model.Search;
using MINIDAT.Model.Session;
using MINIDAT.Model.UOM;
using MINIDAT.Models.Interfaces;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess
{
    public class UserRepository : IUserRepository
    {

        private IDatabase _db;

        public UserRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public UserSearchModel GetUserData(UserModel user, ICriteria _criteria)
        {
            UserSearchModel usersearchModel = new UserSearchModel();
            if (_criteria == null) throw new ArgumentNullException("_criteria");
            IDataReader reader = null;
            try
            {
                IDbCommand command = _db.CreateCommand("Search_User_Sp");
                if (user == null) throw new ArgumentNullException("user");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Employee_Id", user.EID);
                    parameters.Add("proc_vr_User_Init_Cd", user.Initial);
                    parameters.Add("proc_vr_First_Nm", user.FirstName);
                    parameters.Add("proc_vr_Last_Nm", user.LastName);
                    parameters.Add("proc_vr_Phone_Num", user.Phone);
                    parameters.Add("proc_vr_Email_Txt", user.EmailId);

                    parameters.Add("proc_vr_Dept_Cd", user == null ? null : user.DepartmentName != null ? (user.DepartmentName == "Select" ? null : user.DepartmentName) : null);
                    parameters.Add("proc_vr_Status_Cd", user == null ? null : user.StatusName != null ? (user.StatusName == "Select" ? null : user.StatusName) : null);
                    parameters.Add("proc_vr_Default_Role_Cd", user == null ? null : user.RoleName != null ? (user.RoleName == "Select" ? null : user.RoleName) : null);
                    parameters.Add("proc_bl_Master_Data_Ind", 1);
                    parameters.Add("@proc_var_src_system_id", ApplicationSettings.AppId);

                    // parameters.Add("proc_in_Page_Size_Num", 999);
                    //  parameters.Add("proc_in_Current_Page_Num", 1);
                    // parameters.Add("proc_vr_Sort_Column_Nm", user.SortColumn);
                    //parameters.Add("proc_vr_Sort_Order_Nm", user.SortOrder);

                    _db.CreateParameters(command, parameters);
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        usersearchModel.RecordsFetched = reader["TOTAL_RECORDS"].ToString();
                    }

                    reader.NextResult();
                    usersearchModel.Departments.Clear();
                    usersearchModel.Departments.Add(new KeyValue { Key = "Select", Value = "Select" });
                    while (reader.Read())
                    {
                        usersearchModel.Departments.Add(new KeyValue()
                        {
                            Key = Convert.ToString(reader["DEPARTMENT_CD"]),
                            Value = Convert.ToString(reader["DEPARTMENT_NM"])
                        });
                    }
                    reader.NextResult();
                    usersearchModel.Roles.Clear();
                    usersearchModel.Roles.Add(new KeyValue { Key = "Select", Value = "Select" });
                    while (reader.Read())
                    {
                        usersearchModel.Roles.Add(new KeyValue()
                        {
                            Key = Convert.ToString(reader["ROLE_CD"]),
                            Value = Convert.ToString(reader["ROLE_NM"])
                        });
                    }

                    reader.NextResult();
                    usersearchModel.Status.Clear();
                    usersearchModel.Status.Add(new KeyValue { Key = "Select", Value = "Select" });
                    while (reader.Read())
                    {
                        usersearchModel.Status.Add(new KeyValue()
                        {
                            Key = Convert.ToString(reader["STATUS_CD"]),
                            Value = Convert.ToString(reader["STATUS_NM"])
                        });
                    }

                    //ADDED 
                    reader.NextResult();
                    usersearchModel.Applications.Clear();
                    while (reader.Read())
                    {
                        usersearchModel.Applications.Add(new KeyValue()
                        {
                            Key = Convert.ToString(reader["SRC_SYSTEM_ID"]),
                            Value = Convert.ToString(reader["SRC_SYSTEM_NM"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                    }


                    reader.NextResult();
                    usersearchModel.Users.Clear();
                    while (reader.Read())
                    {
                        usersearchModel.Users.Add(new UserModel()
                        {
                            EID = Convert.ToString(reader["EMPLOYEE_ID"]),
                            FirstName = Convert.ToString(reader["FIRST_NM"]),
                            LastName = Convert.ToString(reader["LAST_NM"]),
                            EmailId = Convert.ToString(reader["EMAIL_ID"]),
                            Phone = Convert.ToString(reader["TELEPHONE_NUM"]),
                            DepartmentCode = new KeyValue() { Key = Convert.ToString(reader["DEPARTMENT_CD"]), Value = Convert.ToString(reader["DEPARTMENT_NM"]) },
                            RoleCode = new KeyValue() { Key = Convert.ToString(reader["ROLE_CD"]), Value = Convert.ToString(reader["ROLE_CD"]) },
                            StatusCode = new KeyValue() { Key = Convert.ToString(reader["STATUS_CD"]), Value = Convert.ToString(reader["STATUS_DESC"]) },

                    });
                    }
                    return usersearchModel;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
        public void SaveUserData(UserModel user, string xml, string currentUser, string serverBasePath = null, bool sendEmailNotification = true)
        {
            try
            {
                if (!string.IsNullOrEmpty(currentUser))
                {
                    //string EID = currentUser.Substring(currentUser.IndexOf("\\") + 1);
                    string strUser = Serializer.ConvertToXML(user);
                    IDbCommand command = _db.CreateCommand("Insert_User_Sp");
                    if (user == null) throw new ArgumentNullException("user");
                    if (xml == null) throw new ArgumentNullException("xml");
                    using (command)
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("proc_vr_Employee_Id", user.EID.ToString());
                        parameters.Add("proc_vr_Old_User_Id", user.OldUserId.ToString());
                        parameters.Add("proc_vr_First_Nm", user.FirstName);
                        parameters.Add("proc_vr_User_Init_Cd", user.Initial);
                        parameters.Add("proc_vr_Last_Nm", user.LastName);
                        parameters.Add("proc_vr_Phone_Num", user.Phone);
                        parameters.Add("proc_vr_Email_Txt", user.EmailId);
                        parameters.Add("proc_vr_Status_Cd", user.StatusCode.Key);
                        //parameters.Add("proc_vr_Default_Role_Cd",user.RoleCode.Key);
                        parameters.Add("proc_vr_User_Role_Xml", xml);
                        parameters.Add("proc_vr_Dept_Cd", user.DepartmentCode.Key);
                        parameters.Add("proc_vr_Created_User_Id", currentUser);
                        parameters.Add("proc_app_id", ApplicationSettings.AppId);
                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                    }

                    //Send Email to user and admin cc's only after creating the new account.
                    if (string.IsNullOrEmpty(user.OldUserId) && sendEmailNotification)
                    {
                        NotifyUserOnAccountCreation(user, serverBasePath);
                    }
                }
            }
            catch (Exception Ex)
            {
                LogManager.Error(Ex);
                throw;
            }
        }

        public string DeleteUser(UserModel userFilter, string user)
        {
            try
            {
                if (user == null) throw new ArgumentNullException("user");
                if (userFilter == null) throw new ArgumentNullException("userFilter");
                // Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                //  DbCommand command = db.GetStoredProcCommand("Delete_User_Sp");
                IDbCommand command = _db.CreateCommand("Delete_User_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Employee_Id", userFilter.EID);
                    parameters.Add("proc_nm_Current_User_Id", user.Substring(user.IndexOf("\\") + 1));
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public UserApplicationModel GetUsersessionData(UserModel user)
        {
            try
            {
                UserApplicationModel userApplicationModel = new UserApplicationModel(); 

                IDataReader reader = null;
                IDbCommand command = _db.CreateCommand("Search_User_Sp");
                if (user == null) throw new ArgumentNullException("user");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Employee_Id", user.EID);
                    parameters.Add("proc_vr_User_Init_Cd", user.Initial);
                    parameters.Add("proc_vr_First_Nm", user.FirstName);
                    parameters.Add("proc_vr_Last_Nm", user.LastName);
                    parameters.Add("proc_vr_Phone_Num", user.Phone);
                    parameters.Add("proc_vr_Email_Txt", user.EmailId);
                    parameters.Add("proc_vr_Dept_Cd", user.DepartmentCode);
                    parameters.Add("proc_vr_Status_Cd", user.StatusCode);
                    parameters.Add("proc_vr_Default_Role_Cd", user.RoleCode);
                    parameters.Add("proc_bl_Master_Data_Ind", 0);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        userApplicationModel.UnitAliases.Add(new KeyValue
                        {
                            Key = Convert.ToString(reader["UOM_ID"]),
                            Value = Convert.ToString(reader["UOM_ALIAS_NM"])
                        });
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        var app = new MINIDAT.Manage.UOMTemplate.Application()
                        {
                            Id = Convert.ToInt32(reader["SRC_SYSTEM_ID"]),
                            Name = Convert.ToString(reader["SRC_SYSTEM_NM"]),
                            Description = Convert.ToString(reader["SRC_SYSTEM_DESC"])

                        };
                        if (reader["DISPLAY_ORDER_NUM"] != DBNull.Value)
                        {
                            app.OrderNum = Convert.ToInt32(reader["DISPLAY_ORDER_NUM"]);
                        }
                        userApplicationModel.AvailableApplications.Add(app);
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        userApplicationModel.UserApplicationRoles.Add(new KeyValue()
                        {
                            Key = Convert.ToString(reader["SRC_SYSTEM_NM"]),
                            Value = Convert.ToString(reader["ROLE_NM"])
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        userApplicationModel.Users.Add(new UserModel()
                        {
                            EID = Convert.ToString(reader["EMPLOYEE_ID"]),
                            FirstName = Convert.ToString(reader["FIRST_NM"]),
                            LastName = Convert.ToString(reader["LAST_NM"]),
                            EmailId = Convert.ToString(reader["EMAIL_ID"]),
                            StatusCode = new KeyValue() { Key = Convert.ToString(reader["STATUS_CD"]), Value = Convert.ToString(reader["STATUS_NM"]) },
                            RoleCode = new KeyValue() { Key = Convert.ToString(reader["ROLE_CD"]), Value = Convert.ToString(reader["ROLE_CD"]) },
                            UOMTemplateId = Convert.ToString(reader["UOM_TEMPLATE_ID"]),
                            ApplicationId = ApplicationSettings.AppId
                        });
                    }

                    if (userApplicationModel.AvailableApplications != null && userApplicationModel.AvailableApplications.Count() > 0)
                    {
                        ((List<MINIDAT.Manage.UOMTemplate.Application>)userApplicationModel.AvailableApplications).Where(x => x.OrderNum != null && x.OrderNum > 0).ToList().ForEach(x =>
                              {
                                  userApplicationModel.ApplicationModels.Add(new KeyValue()
                                  {
                                      Key = Convert.ToString(x.Id),
                                      Value = x.Name
                                  });
                              });
                    }

                    reader.Close();

                    return userApplicationModel;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2208:InstantiateArgumentExceptionsCorrectly")]
        public void SendNewUserNotificationToAdmins(UserModel user, string serverBasePath = null)
        {
            if (user == null)
                throw new ArgumentNullException("UserModel for email cannot be null !");

            CreateEmailModelAndSendToAdmin(user, serverBasePath);
            //NotifyUserOnAccountCreation(user, serverBasePath);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void CreateEmailModelAndSendToAdmin(UserModel user, string serverBasePath)
        {
            try
            {
                if (string.IsNullOrEmpty(serverBasePath))
                    serverBasePath = string.Empty;
                var feedstockDATAppLink = serverBasePath + ApplicationSettings.FeedstockClientAppAlias + "User";
                var feedstockAppSignature = ConfigurationManager.AppSettings["FeedstockTeamName"].ToString();

                var fromEmailId = ApplicationSettings.ApplicationMailId;
                var adminEmailIds = GetAdminEMailIDs();
                var subjectLine = "MINIDAT application access requested by " + user.EID + " (" + user.FirstName + " " + user.LastName + ")";

                var emailBody = "<body style='font-family: Calibri;'><table style='height: auto; width: 100%; border-spacing: 0px !important;'><tbody>";
                //header row styling
                emailBody += "<tr><td style='width: 100%; color: #ffffff; height: 50px; font-size: 20px; background-color: #303030;padding-left:10px;'><strong>MINIDAT</strong></td></tr>";
                //body row styling
                emailBody += "<tr><td style='width: 100%; background-color: #efefef; font-size: 16px;>";
                emailBody += "<p style='text-align: justify; margin-left: 10px;'>&nbsp;</p>";
                emailBody += "<p style='text-align: justify; margin-left: 10px;'>Hi,</p>";
                emailBody += "<p style='margin-left: 10px;'>MINIDAT application access is requested by&nbsp; " + user.EID + " (" + user.FirstName + " " + user.LastName + "), please take the necessary action.</p>";

                emailBody += "<h4 style='margin-left: 10px;'>Employee ID : &nbsp; " + user.EID + "</h4>";
                emailBody += "<h4 style='margin-left: 10px;'>Email ID : &nbsp; " + user.EmailId + "</h4>";
                emailBody += "<h4 style='margin-left: 10px;'>First Name : &nbsp; " + user.FirstName + "</h4>";
                emailBody += "<h4 style='margin-left: 10px;'>Last Name : &nbsp; " + user.LastName + "</h4>";

                emailBody += "<br/><h3 style='text-align: left;margin-left:10px;'><a style='color: #3fa7ed; text-decoration: none; cursor: pointer;' title='MINIDAT' href='" + feedstockDATAppLink + "' target='_blank'>Take me to MINIDAT</a>&nbsp;</h3>";
                emailBody += "<h5 style='margin-left: 10px;'>Note : Please use MINIDAT application in google chrome browser for better experience.</h5>";
                emailBody += "<br/><p style='margin-left: 10px;color: #3fa7ed;'>Regards,</p><p style='margin-left: 10px;color: #3fa7ed;'> " + feedstockAppSignature + "</p>";
                //emailBody += "<p style='margin-left: 10px;font-size: 12px;'>For any feedback, feel free to write to our stake holders Wang,Haiyan(Haiyan.Wang@Honeywell.com), Tripathi Raghav(raghav.tripathi@honeywell.com).</p></td></tr><br/>";
                //Footer row styling
                emailBody += "<tr><td style='width: 100%; background-color: #263238; color: #ffffff; height: 50px;margin-left: 10px;text-align: center;'> &nbsp; &copy; Honeywell - UOP 2019.All Rights Reserved. | MINIDAT </td></tr>";
                emailBody += "</tbody></table></body>";
                emailBody += "";
                if (adminEmailIds.Any() && !string.IsNullOrEmpty(fromEmailId))
                {
                    Email.SendMail(fromEmailId, adminEmailIds.ToArray(), new string[] { }, subjectLine, emailBody);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
            }
        }

        /// <summary>
        /// Sends confirmation email to user after the account is created keeping admins in CC.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void NotifyUserOnAccountCreation(UserModel user, string serverBasePath)
        {
            try
            {
                if (string.IsNullOrEmpty(serverBasePath))
                    serverBasePath = string.Empty;
                var feedstockDATAppLink = serverBasePath + ApplicationSettings.FeedstockClientAppAlias;
                //var videoTutorialLink = ConfigurationManager.AppSettings["VideoTutorialLink"].ToString(); 

                var fromEmailId = ApplicationSettings.ApplicationMailId;
                var adminEmailIds = GetAdminEMailIDs();

                var subjectLine = "Hey " + user.FirstName + ", Welcome to MINI DAT !";
                var feedstockAppSignature = ConfigurationManager.AppSettings["FeedstockTeamName"].ToString();

                var emailBody = "<body style='font-family: Calibri;'><table style='height: auto; width: 100%; border-spacing: 0px !important;'><tbody>";
                //header row styling
                emailBody += "<tr><td style='width: 100%; color: #ffffff; height: 50px; font-size: 20px; background-color: #303030;padding-left:10px;'><strong>MINI DAT</strong></td></tr>";
                //body row styling
                emailBody += "<tr><td style='width: 100%; background-color: #efefef; font-size: 16px;>";
                emailBody += "<p style='text-align: justify; margin-left: 10px;'>&nbsp;</p>";
                emailBody += "<p style='text-align: justify; margin-left: 10px;'>Hey " + user.FirstName + ",</p>";

                emailBody += "<p><h3 style='text-align: justify;margin-left: 10px; color: #3fa7ed;'>You're ready to go !</h3></p><p style='text-align: justify; margin-left: 10px;' > We've finished setting up your MINI DAT account.</p>";

                //emailBody += "<br/><h3 style='text-align: justify; margin-left: 10px; color: #3fa7ed;'> What is the Feedstock DAT ?</h3> <p style='margin-left: 10px;'> Feedstock DAT is the central repository for reference information on feedstock characteristics. It allows users to quickly search, find and compare chemical and physical properties of one or more feedstocks including crudes that are relevant to UOP processes. It provides the ability to search and collect data from LIMS. This Application also provides the linkage to other UOP Data Analysis systems (Naphtha DAT, HYDAT, Mini DAT and FCCDAT) and MES Tank Farm system, which are associated with a given feedstock.</p> ";
                emailBody += "<br/><h3 style='text-align: justify; margin-left: 10px; color: #3fa7ed;'> What is the MINI DAT ?</h3> <p style='margin-left:10px;'> MiniDAT is a critical piece of the Honeywell UOP Digitization strategy.  It is a secure database of experimentation which reduces data reduction time, preserves data for re-use with improved knowledge management in keeping data with user intent and conclusions, and increases that amount of data that can be processed in making a decision.   These together allow Honeywell UOP to reduce overall Project End to End Cycle time (ETECT).</p>";
                emailBody += "<p style='margin-left: 10px;'>&nbsp;</p>";
                emailBody += "<h3 style='text-align: left;margin-left:10px;'><a style='color: #3fa7ed; text-decoration: none; cursor: pointer;' title='MINI DAT' href='" + feedstockDATAppLink + "' target='_blank'>Take me to MINI DAT</a>&nbsp;</h3>";
                //emailBody += "<h4 style='text-align: left;margin-left:10px;'><a style='color: #3fa7ed; text-decoration: none; cursor: pointer;' title='Feedstock DAT Tutorial' href='" + videoTutorialLink + "' target='_blank'>Feedstock Video Tutorials</a>&nbsp;</h4>";
                emailBody += "<h5 style='margin-left: 10px;'>Note : Please use MINI DAT application in google chrome browser and clear browser cache for better experience.</h5>";

                emailBody += "<br/><p style='margin-left: 10px;color: #3fa7ed;'>Regards,</p><p style='margin-left: 10px;color: #3fa7ed;'> " + feedstockAppSignature + "</p>";
                //Footer row styling
                emailBody += "<tr><td style='width: 100%; background-color: #263238; color: #ffffff; height: 50px;margin-left: 10px;text-align: center;'> &nbsp; &copy; Honeywell - UOP 2019.All Rights Reserved. | MINI DAT </td></tr>";
                emailBody += "</tbody></table></body>";
                emailBody += "";
                if (!string.IsNullOrEmpty(fromEmailId) && !string.IsNullOrEmpty(user.EmailId))
                {
                    Email.SendMail(fromEmailId, new string[] { user.EmailId }, adminEmailIds.ToArray(), subjectLine, emailBody);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
            }
        }

        private bool IsValidEmailAddress(string emailId)
        {
            return Regex.IsMatch(emailId, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }

        private List<string> GetAdminEMailIDs()
        {
            List<string> adminEmailIDs = new List<string>();
            try
            {
                AppUserCriteria _usrCriteria = new AppUserCriteria();
                var usersData = GetUserData(new UserModel(), _usrCriteria);
                foreach (UserModel usr in usersData.Users)
                {
                    if (usr.StatusCode != null && usr.StatusCode.Key == "UACT" && usr.RoleCode != null && usr.RoleCode.Value.ToLower().Trim().Contains("mini dat") && usr.RoleCode.Value.ToLower().Contains("administrator") && !string.IsNullOrEmpty(usr.EmailId) && IsValidEmailAddress(usr.EmailId))
                    {
                        adminEmailIDs.Add(usr.EmailId);
                    }
                }
                return adminEmailIDs;
            }
            catch (Exception e)
            {
                LogManager.Error(e);
                return new List<string>();
            }
        }
    }
}
