﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystSize.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystSizeRepository : ICatalystSizeRepository
    {
        private IDatabase _db;
        public CatalystSizeRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystSizeSearchModel GetCatalystSizeData(CatalystSizeModel catalystSize)
        {
            try
            {
                CatalystSizeSearchModel catalystSizearr = new CatalystSizeSearchModel();
                if (catalystSize == null)
                {
                    return catalystSizearr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystSize_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystSize", string.IsNullOrEmpty(Convert.ToString(catalystSize.CatalystSizeName)) ? (object)null : catalystSize.CatalystSizeName);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystSize.StatusName == "Select" ? null : catalystSize.StatusName) ? (object)null : catalystSize.StatusName);  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystSizearr.LstcatalystSizes.Clear();
                    while (reader.Read())
                    {
                        CatalystSizeModel _catalystSize = new CatalystSizeModel()
                        {
                            CatalystSizeID = Convert.ToInt32(reader["CATALYST_SIZE_ID_SQ"]),
                            CatalystSizeName = reader["CATALYST_SIZE_CD"].ToString(),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() }
                        };
                        catalystSizearr.LstcatalystSizes.Add(_catalystSize);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystSizearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystSizearr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystSizearr.lstStatus).AddRange(statuses);                  
                    return catalystSizearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystSizeData(CatalystSizeModel catalystSize)
        {
            try
            {
                if (catalystSize == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystSize_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystSize_ID", string.IsNullOrEmpty(Convert.ToString(catalystSize.CatalystSizeID)) ? (object)null : catalystSize.CatalystSizeID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystSizeData(CatalystSizeModel _catalystSize, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystSize == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystSize_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystSize_Id", _catalystSize.CatalystSizeID);
                    parameters.Add("proc_vr_catalystSize", _catalystSize.CatalystSizeName);                     
                    parameters.Add("proc_vr_Status_Nm", _catalystSize.StatusName);                                    
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystSizeModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystSizeModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystSizeModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystSizeModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
