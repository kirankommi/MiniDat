﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class ProcessSpecModel
    {
        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public double? Value { get; set; }
        public double? Range { get; set; }
        public string ParameterUOM { get; set; }
        public string RecordSet { get; set; }
        public bool IsEditable { get; set; }
        public bool IsModeVariable { get; set; }
        public int DisplayOrder { get; set; }

        public string ValueText { get; set; }
        //public string selectedMethod { get; set; }
        //public string methodName { get; set; }


    }
}
