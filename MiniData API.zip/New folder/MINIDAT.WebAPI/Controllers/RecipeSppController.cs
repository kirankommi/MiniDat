﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.FileBrowser;
using MINIDAT.Model;
using MINIDAT.Model.FileBrowser;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers
{
    public class RecipeSppController : ApiController
    {
        // GET: RecipeSpp
       

        [HttpGet, ActionName("GetAllDocuments")]
        public HttpResponseMessage GetAllDocuments()
        {
            try
            {

                FileBrowserRepository _projectRepository = new RecipeSppBrowserRepository(new MINIDATDatabase());
                List<FileModel> files = _projectRepository.BrowseFiles();
                return Request.CreateResponse(HttpStatusCode.OK, files);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpGet, ActionName("DownloadFile")]
        public HttpResponseMessage DownloadFile(string fileId)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileId))
                {
                    FileBrowserRepository _projectRepository = new RecipeSppBrowserRepository(new MINIDATDatabase());
                    FileModel file = _projectRepository.DownloadFiles(Convert.ToInt32(fileId));
                    return Request.CreateResponse(HttpStatusCode.OK, file);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

    }
}