﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystSizeModel, KeyValue } from '../../Models/Catalyst/CatalystSizeModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystSizeService {
    private getCatalystSizedata = "/CatalystSize/SearchCatalystSizedata/";
    private getActiveCatalystSizeinfo = "/CatalystSize/GetActiveCatalystSizedata/";
    private saveCatalystSizedata = "/CatalystSize/SaveCatalystSizeInformation/";
    private deleteCatalystSizedata = "/CatalystSize/DeleteCatalystSizeInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystSizeInformation(catalystSize: CatalystSizeModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystSize, this.getCatalystSizedata);
    }

    saveCatalystSizeInformation(catalystSize: CatalystSizeModel)
    {
        return this.httpaction.post(catalystSize, this.saveCatalystSizedata);
    }

    deleteCatalystSize(catalystSize: CatalystSizeModel)
    {
        debugger;
        return this.httpaction.post(catalystSize, this.deleteCatalystSizedata);
    }    
}
