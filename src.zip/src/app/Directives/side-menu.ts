import { Component, OnInit, Input } from '@angular/core';
import { trigger, state, animate, transition, style } from '@angular/animations';
import { Router, NavigationEnd } from '@angular/router';

import { Message, TreeModule, TreeNode } from 'primeng/primeng';
//import { DashboardService } from '../Services/dashboard.service';
import { appService } from '../Services/app.service';
import { MenuType, MenuModel } from '../Components/NavBar/navbar.metadata';
import * as Constants from '../Shared/globalconstants';
//declare var $: any;

@Component({
    selector: 'side-menu',
    templateUrl: 'side-menu.html',
    animations: [
        trigger('toggleState', [
            state('false', style({ maxHeight: '44px' })),
            state('true', style({ maxHeight: '400px' })),
            transition('* => *', animate('300ms')),
        ]),
        trigger('toggleCaret', [
            state('true', style({ maxHeight: '44px' })),
            state('false', style({ maxHeight: '400px' })),
            transition('* => *', animate('300ms')),
        ])
    ],
    host: {
        '(window:resize)': 'onResize($event)'
    }
})

export class SideMenuDirective implements OnInit {

    @Input() menuData: any;
    files: TreeNode[];
    selectedMenu: string;
    signedUser: string;
    signedUserName: string;
    signedUserInitial: string;
    toggledMenu: string[] = [];
    routes: MenuModel[] = [];
    public brandMenu: MenuModel;

    //Added later by chirag
    IsUnauthorizedAccess: boolean = false;

    constructor(private router: Router, private appService: appService) { }

    ngOnInit() {
        //this.files = this.dashboardService.getFiles();
        this.GetUserData();
    }


    ngAfterViewInit() {
        debugger;
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.selectedMenu = event.url.replace("/", "");
                //this.selectedMenu = (this.selectedMenu && this.selectedMenu.includes('SelectFeedStep')) ? this.selectedMenu = 'SelectFeedStep' : this.selectedMenu;                
                // if (this.selectedMenu == "User" || this.selectedMenu == "Role" || this.selectedMenu == "RoleMenu" || this.selectedMenu == "UOM" || this.selectedMenu == "LimsAnalysisMethod" || this.selectedMenu == "LimsComponent" || this.selectedMenu == "CustomizeLandingPage") {
                if (this.isInManageMenuList(this.selectedMenu)) {
                    this.expandMenu('MANAGE');
                }
                if (this.selectedMenu == "SelectFeedStep" || this.selectedMenu == "Crude/Create" || this.selectedMenu == "SelectFeedStep/createfeed") {
                    this.expandMenu('FEED CREATION');
                }
                if (this.selectedMenu == "automap/map/component") {
                    this.selectedMenu = "automap/map/operation";
                }
            }
        });
        this.adjustMenuScroll();
    }
    onResize(event: any) {
        this.adjustMenuScroll();
    }

    isMenuToggled(_menu: string) {
        if (_menu == null) return false;
        return this.toggledMenu.indexOf(_menu) > -1;
    }


    adjustMenuScroll() {
        //$($("fdms-side-menu  .nav.level-1.score-component")[0]).slimScroll({
        //    position: 'left',
        //    height: (window.innerHeight - 113) + 'px',
        //    railVisible: false,
        //    alwaysVisible: false
        //});
    }


    selectMenu(_menu: string) {
        this.selectedMenu = _menu;
    }

    expandMenu(_menu: string) {
        if (this.toggledMenu.indexOf(_menu) < 0)
            this.toggledMenu.push(_menu);
    }

    expandCollapseMenu(_menu: string) {
        if (this.toggledMenu.indexOf(_menu) > -1)
            this.toggledMenu.splice(this.toggledMenu.indexOf(_menu), 1);
        else
            this.toggledMenu.push(_menu);
    }


    titleCase(input: string): string {
        if (!input) {
            return '';
        } else {
            return input.replace(/\w\S*/g, (txt => txt[0].toUpperCase() + txt.substr(1).toLowerCase()));
        }
    }


    GetUserData() {

        this.brandMenu = this.routes.filter((menuItem: any) => menuItem.menuType === MenuType.BRAND)[0];

        this.appService.getSessionData()
            .subscribe((data: any) => {
                let menu: MenuModel[] = [];
                if (data != null) {
                    if (data.Menu != null && data.Menu != undefined && data.Menu.length > 0) {
                        menu = data.Menu;
                    }
                    if (data.User != null && data.User != undefined) {
                        this.IsUnauthorizedAccess = false;
                        this.signedUser = data.User.EID;
                        let firstName: string = "", lastName: string = "";
                        if (data.User.FirstName != null) firstName = data.User.FirstName;
                        if (data.User.LastName != null) lastName = data.User.LastName;
                        this.signedUserName = firstName + " " + lastName;
                        this.signedUserInitial = firstName.substring(0, 1) + lastName.substring(0, 1);
                        this.generateMenu(menu);
                    }
                }
                // this.isLoading = false;
            },
                (err: any) => {
                    // this.isLoading = false;
                });
    }


    generateMenu(menu: MenuModel[]) {

        for (let item of menu) {
            this.routes.push(item);
        }
    }
    getMenuImage(_title: string) {
        switch (_title.toUpperCase()) {
            case "PROJECT":
                return "assets/Images/Project.svg";
            case "CATALYST":
                return "assets/Images/Catalyst.svg";
            case "MANAGE":
                return "assets/Images/Manage.svg";
            case "FEED":
                return "assets/Images/Feed_Creation_icon_unselected.svg";
            case "EXPERIMENT":
                return "assets/Images/Experiment.svg";
            case "MINIS QUEUE":
                return "assets/Images/Minis_Active.svg";
            default:
                return "assets/Images//Advanced_Search_icon_unselect.svg";
        }
    }
    getManageMenu() {
        let manageMenu: any = this.routes.filter((menuItem: any) => menuItem.action == "Manage");
        if (manageMenu.length > 0 && manageMenu[0].subMenu.length > 0) {
            return manageMenu[0].subMenu;
        } else {
            return [];
        }
    }

    isInManageMenuList(menu: string) {
        const list = ["User", "Role", "RoleMenu", "UOM",
            "LimsAnalysisMethod", "LimsComponent", "CustomizeLandingPage",
            "automap/map/operation", "automap/map/component"];
        return list.indexOf(menu) >= 0;
    }
}
