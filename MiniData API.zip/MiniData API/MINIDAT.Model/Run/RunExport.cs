﻿using System.Collections.Generic;
using MINIDAT.Model.Manage;

namespace MINIDAT.Model.Run
{
    public class RunExport
    {
        public int? ID { get; set; }
        public string Plant { get; set; }
        public int? RunNum { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ZeroHOSTime { get; set; }
        public string RunDescription { get; set; }
        public string Status { get; set; }
        public int DOERun { get; set; }
        public List<NIRModelExport> lstNIRSpec { get; set; }
        public List<AnalyticalInfoModelExport> lstAnalyticalSamples { get; set; }
        public GeneralInfoModel GeneralInfo { get; set; }
        public FeedExport FeedInfo { get; set; }
        public AdditionalInfoExport AdditionalInfo { get; set; }
        public List<BoilingPointExport> lstRunCutBoilingPoints { get; set; }
        public List<RunCatalystModelExport> Cataysts { get; set; }
        public List<BedDetailsExport> Beds { get; set; }
        public List<TC_Calibration_Export> lstTC_Calibrations { get; set; }
        public List<TMF_Calibration> lstTMF_Calibrations { get; set; }
        public List<ProcessSpecsInfoExport> lstProcessSpec { get; set; }
        public List<KeyValue> Technicians { get; set; }
        public List<KeyValue> lstStreams { get; set; }
        public List<KeyValue> LstAnalysisMethods { get; set; }
        public List<KeyValue> LstLoadingDensiyTypes { get; set; }
        public List<KeyValue> LstNormalizationFactors { get; set; }
        public List<KeyValue> LstFeedSource { get; set; }
        public dynamic Recipe { get; set; }
        public int? RunId { get; set; }
        public ExportPopupSummary PopupSummary { get; set; }


        public RunExport()
        {
            lstNIRSpec = new List<NIRModelExport>();
            lstAnalyticalSamples = new List<AnalyticalInfoModelExport>();
            GeneralInfo = new GeneralInfoModel();
            FeedInfo = new FeedExport();
            lstRunCutBoilingPoints = new List<BoilingPointExport>();
            lstTC_Calibrations = new List<TC_Calibration_Export>();
            lstTMF_Calibrations = new List<TMF_Calibration>();
            Cataysts = new List<RunCatalystModelExport>();
            Beds = new List<BedDetailsExport>();
            lstProcessSpec = new List<ProcessSpecsInfoExport>();
            PopupSummary = new ExportPopupSummary();
        }
    }
    public class ExportPopupSummary
    {
        public bool isGeneralInfo { get; set; }
        public bool isBoilingPoint { get; set; }
        public bool isCatalyst { get; set; }
        public bool isFeed { get; set; }
        public bool isAnalyticalSample { get; set; }
        public bool isNIRSpecs { get; set; }
        public bool isTMS { get; set; }
        public bool isProcessSpec { get; set; }
        public bool isAdditionalInfo { get; set; }
        public bool isTCCaliration { get; set; }
        public bool isRecipe { get; set; }
    }
}
