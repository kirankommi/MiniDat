﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.Manage.Mode;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class NIRRepository : INIRRepository
    {
        /// <summary>
        /// 
        /// </summary>
        private IDatabase _db;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbInstance"></param>
        public NIRRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public NIRProcessModel getNIRTemplateData(string mode)
        {
            try
            {
                NIRProcessModel nirModel = new NIRProcessModel();

                if (String.IsNullOrEmpty(mode))
                {
                    return nirModel;
                }

                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_NIR_ProcessSpec_ModeTemplateValues_sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@mode", mode);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    List<NIRSpecModel> lstModelInfo = new List<NIRSpecModel>();
                    while (reader.Read())
                    {

                        NIRSpecModel nirSpecModel = new NIRSpecModel()
                        {
                            ParameterName = reader["PARAMETER_NM"].ToString(),
                            ParameterValue = reader["Value"].FormatDouble(),
                            //ParameterUOM = reader["DefaultUnit"].ToString(),
                            DefaultUnit = reader["DefaultUnit"].ToString()
                        };
                        lstModelInfo.Add(nirSpecModel);
                    }
                    nirModel.lstNIRSpecModel = lstModelInfo;
                    List<ProcessSpecModel> lstProcessSpecInfo = new List<ProcessSpecModel>();
                    reader.NextResult();
                    while (reader.Read())
                    {

                        ProcessSpecModel processSpecInfo = new ProcessSpecModel()
                        {
                            ParameterName = reader["PARAMETER_NM"].ToString(),
                            ParameterValue = reader["Value"].FormatDouble(),
                            //ParameterUOM = reader["DefaultUnit"].ToString(),
                            DefaultUnit = reader["DefaultUnit"].ToString(),
                            ParameterRange = reader["Range"].ToString()
                        };
                        lstProcessSpecInfo.Add(processSpecInfo);

                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        nirModel.ConversionCutPoint = reader["ConversionPoint"].ToString();
                    }
                    nirModel.lstProcessSpecModel = lstProcessSpecInfo;

                }
                return nirModel;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}

