﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystShapeService } from '../../../Services/CatalystServices/CatalystShape.service';
import { CatalystShapeModel, KeyValue } from '../../../models/Catalyst/CatalystShapeModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'CatalystShape.component.html',
    providers: [CatalystShapeService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystShapeComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystShape: CatalystShapeModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    catalystShapeList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    catalystShapeSaved: string = "Catalyst Shape Details Saved Successfully";
    catalystShapeDeleted: string = "Catalyst Shape Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private catalystShapeService: CatalystShapeService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {       
        this.catalystShape = new CatalystShapeModel();
        this.catalystShape.CatalystShapeID = null;
        this.catalystShape.AssumedVoidFraction = null;
        this.catalystShape.CrushedVoidFraction = null;
        this.catalystShape.CatalystShape = null;   
        this.getcatalystShapesList();
        this.title = Constants.ManageCatalystShape;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystShape.CatalystShapeID = event.data.CatalystShapeID;
        this.catalystShape.CatalystShape = event.data.CatalystShape;
        this.catalystShape.AssumedVoidFraction = event.data.AssumedVoidFraction;   
        this.catalystShape.CrushedVoidFraction = event.data.CrushedVoidFraction;            
        this.catalystShape.StatusName = event.data.StatusCode.Key;    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getcatalystShapesList()
    {       
        this.catalystShapeService.getCatalystShapeInformation(this.catalystShape)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystShapeList = data.LstcatalystShapes;              
                this.Statuses = data.lstStatus;            
                this.totalRecords = data.RecordsFetched;              
                if (this.catalystShape.StatusName == undefined || this.catalystShape.StatusName == null)
                { this.catalystShape.StatusName = Constants.Select; }               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystShape()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.catalystShapeService.saveCatalystShapeInformation(this.catalystShape)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystShapeSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(catalystShape: CatalystShapeModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteCatalystShapeInfo(catalystShape);}
        });
    }

    deleteCatalystShapeInfo(catalystShape: CatalystShapeModel)
    {
        debugger;     
        this.catalystShapeService.deleteCatalystShape(catalystShape)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystShapeDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }   

    onReset() {
        debugger;
        this.catalystShape = new CatalystShapeModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.catalystShape.AssumedVoidFraction = null;       
        this.catalystShape.CrushedVoidFraction = null;   
        this.getcatalystShapesList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.catalystShape == null || !this.catalystShape.CatalystShape
            || this.catalystShape.StatusName == "Select"
            || !this.catalystShape.AssumedVoidFraction
            || !this.catalystShape.CrushedVoidFraction)
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {       
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {                   
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000027" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
