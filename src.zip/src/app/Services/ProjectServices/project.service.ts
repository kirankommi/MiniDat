﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { AccoladeProjectModel,NPDProjectModel ,CapabilityProjectModel,CustomerProjectModel} from '../../Models/Project/ProjectModel';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { KeyValue } from '../../Models/usermodel';

@Injectable({
    providedIn: 'root'
})
export class ProjectService {
    private GetAccoladeProjectsUrl = "/Project/GetAccoladeProjects/";
    private DeleteProjectUrl = "/Project/DeleteProject/";
    private GetProjectDetailsUrl = "/Project/GetProjectDetails/";
    private saveNpdProjectDetailsUrl ="/Project/SaveNpdProjectDetails/"
    private searchProjectDetailsUrl = "/Project/SearchNpdProjectDetails/"
    private saveCapProjectDetailsUrl = "/Project/SaveCapabilityProjectDetails/"
    private searchCapProjectDetailsUrl = "/Project/SearchCapabilityProjectDetails/"
    private SaveCustomerProjectDetailsUrl = "/Project/SaveCustomerProjectDetails/"
    private SearchCustomerProjectDetailsUrl = "/Project/SearchCustomerProjectDetails/"
    private GetAllDocumentsUrl = "/Project/GetAllDocuments/";
    private DownloadFileUrl = "/Project/DownloadFile/";
    private uploadFileProjectUrl = "/Project/UploadFiles/";
    constructor(private httpaction: HttpActionService) { }
   
    GetAccoladeProjects(projectType: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('projectType', projectType);       
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAccoladeProjectsUrl, options);
    }
    DeleteProject(projectId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('projectId', projectId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.DeleteProjectUrl, options);
    }
    

    GetProjectDetails(projectType: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('projectType', projectType);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetProjectDetailsUrl, options);
    }

    saveNpdProjectDetails(npdModel: NPDProjectModel) {        
        return this.httpaction.post(npdModel, this.saveNpdProjectDetailsUrl);
    }

    searchProjectDetails(npdModel: NPDProjectModel) {
        return this.httpaction.post(npdModel, this.searchProjectDetailsUrl);
    }

    saveCapProjectDetails(npdModel: CapabilityProjectModel) {
        return this.httpaction.post(npdModel, this.saveCapProjectDetailsUrl);
    }

    searchCapProjectDetails(npdModel: CapabilityProjectModel) {
        return this.httpaction.post(npdModel, this.searchCapProjectDetailsUrl);
    }
    saveCustomerProjectDetails(npdModel: CustomerProjectModel) {
        return this.httpaction.post(npdModel, this.SaveCustomerProjectDetailsUrl);
    }

    searchCustomerProjectDetails(npdModel: CustomerProjectModel) {
        return this.httpaction.post(npdModel, this.SearchCustomerProjectDetailsUrl);
    }
    
    GetAllDocuments() {
      
        let params: URLSearchParams = new URLSearchParams();
       // params.set('projectId', projectId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAllDocumentsUrl, options);
    }

    DownLoadProjectDocuments(fileid:string) {

        let params: URLSearchParams = new URLSearchParams();
        params.set('fileId', fileid);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.DownloadFileUrl, options);
    }


    uploadFiles(files: any, data: KeyValue[]) {
        return this.httpaction.postFiles(files, this.uploadFileProjectUrl, data);
    }
}

