﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model.Test;
using MINIDAT.Model;
using MINIDAT.Model.Session;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using MINIDAT.Model.TestCreation;
using MINIDAT.WebAPI.Controllers.RunController;
using System.Data;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using System.IO;
using System.Collections.Generic;

namespace MINIDAT.WebAPI.Controllers.TestCreationControllers
{
    public class LogSheetController : ApiController
    {
        //ILogSheetRepository _logSheetRepository;
        public LogSheetController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Log Sheet Repository" }));
            //_logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
        }

        [HttpPost, ActionName("GetLogSheetDetails")]
        public HttpResponseMessage GetLogSheetDetails([FromBody] PeriodReadingModel periodReadingModel)
        {
            LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _logSheetRepository.GetLogSheetDetails(periodReadingModel, User.Identity.Name));
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }

        [HttpPost, ActionName("GetLogSheetPeriodReadingDetails")]
        public HttpResponseMessage GetLogSheetPeriodReadingDetails([FromBody] PeriodReadingModel periodReadingModel)
        {
            LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _logSheetRepository.GetLogSheetPeriodReadingDetails(periodReadingModel, User.Identity.Name));
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }

        [HttpPost, ActionName("SavePeriodReading")]
        public HttpResponseMessage SavePeriodReading([FromBody] PeriodReadingModel periodReadingModel)
        {
            if (periodReadingModel != null)
            {
                try
                {
                    LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
                    _logSheetRepository.SavePeriodReading(periodReadingModel, User.Identity.Name);
                    return Request.CreateResponse(HttpStatusCode.OK, "Success");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }

        [HttpPost, ActionName("SaveLogSheet")]
        public HttpResponseMessage SaveLogSheet(dynamic LogSheet, [FromUri] string plantCd)
        {
            try
            {
                LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
                _logSheetRepository.SaveLogSheet(LogSheet,plantCd, User.Identity.Name);
                return Request.CreateResponse(HttpStatusCode.OK, "Success");
            }
            catch (SqlException ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost, ActionName("ExportDataLogSheetTimeReading")]
        public Byte[] GenerateExcel_LogSheetTimeReading_withDefaultUOM([FromBody] PeriodReadingModel exportData)
        {
            LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
            try
            {
                RunController.RunController _runController = new RunController.RunController();
                XSSFWorkbook workbook = new XSSFWorkbook();
                var normalStyle = _runController.setTableStyle(workbook);
                /////////////////Header Styling for table/////////////////////////////////////////
                var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.FillPattern = FillPattern.SolidForeground;
                headerStyle.WrapText = true;
                headerStyle.BorderTop = BorderStyle.Thin;
                headerStyle.BorderBottom = BorderStyle.Thin;
                headerStyle.BorderLeft = BorderStyle.Thin;
                headerStyle.BorderRight = BorderStyle.Thin;
                headerStyle.Alignment = HorizontalAlignment.Center;
                XSSFFont hFont = (XSSFFont)workbook.CreateFont();
                hFont.FontHeightInPoints = 11;
                hFont.FontName = "Calibri";
                hFont.Boldweight = (short)FontBoldWeight.Bold;
                headerStyle.SetFont(hFont);
                //////////////////////////////////////////////////////////
                DataTable dt;

                /////////////////////////////////////
                // Export Log Sheet Time Reading/////
                ////////////////////////////////////
                ISheet sheet1 = workbook.CreateSheet("Log Sheet Time Reading");
                for (int i = 0; i < 20; i++)
                {
                    sheet1.SetColumnWidth(i, 4000);
                }
                sheet1.SetColumnWidth(0, 8000);
                sheet1.SetColumnWidth(1, 8000);
                var _rowIndex = 0;
                var row = sheet1.CreateRow(_rowIndex++);
                _runController.SetTitle(sheet1, workbook, "Log Sheet Time Reading");
                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);
                row.SetCellValue(2, "Plant", headerStyle);
                row.SetCellValue(3, exportData.PlantCd, normalStyle);
                row.SetCellValue(5, "Run", headerStyle);
                row.SetCellValue(6, exportData.RunId.ToString(), normalStyle);
                row.SetCellValue(8, "Test", headerStyle);
                row.SetCellValue(9, exportData.TestId.ToString(), normalStyle);
                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);

                exportData.LogSheetTimeReading = _logSheetRepository.ExportLogsheetTimeReading(exportData, User.Identity.Name);
                var logTime = exportData.LogSheetTimeReading;
                var json = JsonConvert.SerializeObject(logTime);
                dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
                dt.Columns["LOG_READING_LABEL_TXT"].ColumnName = "Log Reading Label";
                dt.Columns["PI_TAG_NM"].ColumnName = "PI Tag Name";
                dt.Columns["DEFAULT_UNIT_DISPLAY_NM"].ColumnName = "UOM";
                dt.Columns.Remove("LOG_LABEL_ORDER_NUM");
                _rowIndex = _runController.AddDataToExcel2(dt, _rowIndex, "Log Sheet Time Reading Details", workbook, sheet1, "DataViewer");
                

                using (MemoryStream output = new MemoryStream())
                {
                    workbook.Write(output);
                    return output.ToArray();
                }
            }
            catch(Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost, ActionName("GetLogSheetKey")]
        public HttpResponseMessage GetLogSheetKey([FromBody] LogSheetKeyModel LogSheetKeyModel)
        {
            LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _logSheetRepository.GetLogSheetKey(LogSheetKeyModel, User.Identity.Name));
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestDataLoadError.ToString());
            }
        }
        [HttpPost, ActionName("ExportDataLogSheetPeriodReading")]
        public Byte[] GenerateExcel_LogSheetPeriodReading_withDefaultUOM([FromBody] PeriodReadingModel exportData)
        {
            LogSheetRepository _logSheetRepository = new LogSheetRepository(new MINIDATDatabase());
            try
            {
                RunController.RunController _runController = new RunController.RunController();
                XSSFWorkbook workbook = new XSSFWorkbook();
                var normalStyle = _runController.setTableStyle(workbook);
                /////////////////Header Styling for table/////////////////////////////////////////
                var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
                headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
                headerStyle.FillPattern = FillPattern.SolidForeground;
                headerStyle.WrapText = true;
                headerStyle.BorderTop = BorderStyle.Thin;
                headerStyle.BorderBottom = BorderStyle.Thin;
                headerStyle.BorderLeft = BorderStyle.Thin;
                headerStyle.BorderRight = BorderStyle.Thin;
                headerStyle.Alignment = HorizontalAlignment.Center;
                XSSFFont hFont = (XSSFFont)workbook.CreateFont();
                hFont.FontHeightInPoints = 11;
                hFont.FontName = "Calibri";
                hFont.Boldweight = (short)FontBoldWeight.Bold;
                headerStyle.SetFont(hFont);
                //////////////////////////////////////////////////////////
                DataTable dt;

                /////////////////////////////////////
                // Export Log Sheet Period Reading/////
                ////////////////////////////////////
                ISheet sheet1 = workbook.CreateSheet("Log Sheet Period Reading");
                for (int i = 0; i < 20; i++)
                {
                    sheet1.SetColumnWidth(i, 4000);
                }
                var _rowIndex = 0;
                var row = sheet1.CreateRow(_rowIndex++);
                _runController.SetTitle(sheet1, workbook, "Log Sheet Period Reading");
                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);
                row.SetCellValue(1, "Plant", headerStyle);
                row.SetCellValue(2, exportData.PlantCd, normalStyle);
                row.SetCellValue(4, "Run", headerStyle);
                row.SetCellValue(5, exportData.RunId.ToString(), normalStyle);
                row.SetCellValue(7, "Test", headerStyle);
                row.SetCellValue(8, exportData.TestId.ToString(), normalStyle);
                _rowIndex = _rowIndex + 3;
                row = sheet1.CreateRow(_rowIndex);

                exportData.PeriodReadingList = _logSheetRepository.ExportLogSheetPeriodReadingDetails(exportData, User.Identity.Name);
                dt = _runController.ConvertToDataTable<LogSheetPeriodReadingModel>(exportData.PeriodReadingList);
                dt.Columns["LogReadingLabel"].ColumnName = "Log Reading Label";
                dt.Columns["InputVariableType"].ColumnName = "Input Variable Type";
                dt.Columns["AverageReadingValueMsr"].ColumnName = "Average Reading";
                dt.Columns["InitialReadingValueMsr"].ColumnName = "Initial Reading";
                dt.Columns["FinalReadingValueMsr"].ColumnName = "Final Reading";
                dt.Columns.Remove("ParamterDefaultUnitName");
                _rowIndex = _runController.AddDataToExcel(dt, _rowIndex, "Log Sheet Period Reading Details", workbook, sheet1);
                using (MemoryStream output = new MemoryStream())
                {
                    workbook.Write(output);
                    return output.ToArray();
                }

            }
            catch(Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
