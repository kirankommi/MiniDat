import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductPhysicalPropertiesComponent } from './product-physical-properties.component';

describe('ProductPhysicalPropertiesComponent', () => {
  let component: ProductPhysicalPropertiesComponent;
  let fixture: ComponentFixture<ProductPhysicalPropertiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductPhysicalPropertiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductPhysicalPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
