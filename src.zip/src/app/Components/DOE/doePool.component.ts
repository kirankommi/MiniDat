import { Component, OnInit } from '@angular/core';
import * as Constants from '../../Shared/globalconstants';
import { doeService } from '../../Services/DoeServices/doe.service';
import { Router } from '@angular/router';
import { AlertMessage } from '../../Services/alertmessage.service';
import { messageModalUtility } from '../../Shared/message-modal.utility';
import { DownloadFromStream } from '../../Directives/bulkupload/downloadFromStream';
import { uploadHandler } from '../../Directives/filebrowse/filebrowse.component';
import { Observable } from "rxjs";
import { KeyValue } from '../../Models/KeyValue';
@Component({
  templateUrl: 'doePool.component.html',
  providers: [doeService]
})
export class doePoolComponent implements OnInit {
  ngOnInit(): void {
    this.service.getPoolMasterData().subscribe((data) => {
      this.statuses = data.Statuses;
      this.specialists = data.Specialists;
      this.reset()
    });
    this.phandler = new uploadHandler();
    this.phandler.downloadFile = this.onDownload.bind(this);
  };

  files: any[] = [];
  specialists: any[] = [];
  phandler: uploadHandler;
  statuses: any[] = [];
  IsallowedSave: boolean = false;
  searchComponent: any = {};
  DOEList: any[] = [];
  deleteIconPath: string = Constants.deleteIconPath;
  editIconPath: string = Constants.editIconPath;
  downloadIconPath: string = Constants.downloadIcon;
  searchBy: string = "pool";
  colList: any[] = [new KeyValue("FileName", "File Name"), new KeyValue("StudyNM", "Study Name"), new KeyValue("Description", "Description"), new KeyValue("FileSize", "File Size"), new KeyValue("LastUpdatedDateTime", "Date Modified")];

  constructor(private service: doeService, private router: Router, private alertMessage: AlertMessage,
    private messageService: messageModalUtility) {
    this.deleteIconPath = Constants.deleteIconPath;
  }

  searchDOE() {
    this.service.search(this.searchComponent).subscribe((data) => {
      this.DOEList = data;
    });
  }

  reset() {
    this.searchComponent = { status: "", Specialist: "" };
    this.searchDOE();
  }
  onEdit(studyID) {
    // debugger;
    this.router.navigateByUrl('/Experiment/DOE/' + studyID);
  }

  onDownloadAttachment(studyID, Study) {
    this.service.onDownloadStudyDoc(studyID, Study).subscribe(data => {
      if (data != undefined && data != null) {
        DownloadFromStream.DownloadFile(data.FileData, data.FileName, data.ContentType);
      }
    });
  }

  onDownload(file: any): Observable<any> {
    return this.service.DownloadFile(file.FileId, file.StudyID);
  }

  onDelete(studyID) {
    this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
      result = result == Constants.ConfirmTrue; //casting string to boolean
      if (result) {
        this.service.deleteDOE(studyID).subscribe((rslt) => {
          if (rslt == "Deleted") {
            this.alertMessage.displaySuccessMessage("DOEDelete");
            this.searchDOE()
          } else {
            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Experiment', detail: rslt });
          }
        });
      }
    });

  }
  ngDoCheck() {
    if (Constants.UserPrivileges.length > 1) {
      for (let i in Constants.UserPrivileges) {
        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000021" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
          this.IsallowedSave = true;
        }
      }
    }

  }

  onSearchBy(by: string) {
    this.searchBy = by;
    if (this.files.length == 0) {
      this.service.GetAllDocuments()
        .subscribe(
          (data: any) => {

            this.files = data;
          });
    }
  }
}
