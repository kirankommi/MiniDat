﻿using MINIDAT.Framework.Common;
using MINIDAT.Framework.Extension;
using MINIDAT.Model.UOM;
using MINIDAT.Model;
using MINIDAT.Model.Session;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace MINIDAT.DataAccess.Home
{
    public class HomePageDataAccess
    {
        //public ILog logger = LogManager.GetLogger(typeof(HomePageDataAccess));
        public IEnumerable<MenuModel> GetMenubyRole(string roleId)
        {
            try
            {
                var menuList = new List<MenuModel>();

                #region Create & execute the command

                Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                DbCommand command = db.GetStoredProcCommand("[Get_Priv_For_Role_Sp]");

                db.AddInParameter(command, "@proc_vr_Role_Cd", DbType.String, roleId);
                db.AddInParameter(command, "@src_system_id", DbType.String, ApplicationSettings.AppId);
                
                using (IDataReader reader = db.ExecuteReader(command))
                {
                    while (reader.Read())
                    {
                        MenuModel model = new MenuModel()
                        {

                            FunctionCode = Convert.ToString(reader["FUNCTION_CD"]),
                            Title = Convert.ToString(reader["FUNCTION_DESC"]),
                            Action = Convert.ToString(reader["PAGE_DESC"]),
                            ParentFunctionCode = Convert.ToString(reader["PARENT_FUNCTION_CD"]),
                            FunctionOrder = Convert.ToString(reader["FUNCTION_ORDER_NUM"]),
                            PrivilegeName = Convert.ToString(reader["PRIVILEGE_NM"]),

                        };
                        model.IsReadOnly =
                            Convert.ToString(reader["PRIVILEGE_NM"]).ToUpper().Equals("READ");

                        if (reader["MENU_ITEM_IND"].ToString().Equals("Y", StringComparison.CurrentCultureIgnoreCase))
                        {
                            menuList.Add(model);
                        }
                    }
                }

                #endregion Create & execute the command
                return menuList;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }


        public IEnumerable<string> GetUserRules(string userID)
        {
            try
            {
                // Key would be Menu Id
                List<string> rules = new List<string>();
                if (!string.IsNullOrEmpty(userID))
                {
                    string userEid = userID.Substring(userID.IndexOf("\\") + 1);

                    #region Create & execute the command
                    Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                    DbCommand command = db.GetStoredProcCommand("[Get_UserRules_Sp]");

                    db.AddInParameter(command, "proc_vr_employee_id", DbType.String, userEid);
                    using (IDataReader reader = db.ExecuteReader(command))
                    {
                        while (reader.Read())
                        {
                            rules.Add(Convert.ToString(reader["FUNCTION_NM"]));

                        }
                    }

                }
                #endregion Create & execute the command
                return rules;
            }
            catch(Exception ex)
            {
                LogManager.Error(ex);
                throw ;
            }
        }

    }
}
