﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	Catalyst repository.cs
 	Project Title			:	MINIDAT
	Author(s)				:	GOLDY
	Change History			:   NR--01-Sandip for HCYE Catalyst master Data
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Catalyst;
using MINIDAT.Model.Session;
using System.Collections;
using System.Data;
using MINIDAT.Model;
using MINIDAT.Model.Project;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model.UOM;
using MINIDAT.Framework.Extension;
namespace MINIDAT.DataAccess.Repository.Catalyst
{

    public class CatalystRepository : ICatalystRepository
    {
        private IDatabase _db;
        public CatalystRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public bool DeleteCatalyst(int catalystId)
        {
            try
            {
                if (catalystId == null) throw new ArgumentNullException("CatalystId");
                if (UserSession.Instance.User.EID == null) throw new ArgumentNullException("user");
                IDbCommand command = _db.CreateCommand("catalyst.Delete_Catalyst_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_Catalyst_id", catalystId);
                    parameters.Add("proc_User_Id", UserSession.Instance.User.EID);
                    _db.CreateParameters(command, parameters);
                    int cnt = _db.ExecuteNonQuery(command);
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public CatalystMasterDataModel GetCatalystDetails()
        {
            try
            {
                #region setting up DBCommand with parameters
                CatalystMasterDataModel mstr = new CatalystMasterDataModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("catalyst.GetCatalystDetails"))
                {                                                      
                    objSqlDr = _db.ExecuteReader(command);
                    mstr.CatalystFamilys = new List<CatalystFamily>();
                    mstr.CatalystTypes = new List<KeyValue>();
                    mstr.CatalystTypes.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.CatalystShapes = new List<CatalystShape>();
                    mstr.CatalystShapes.Add(new CatalystShape { CatalystShapeId = 0, CataystShapeName = "Select", CatalystVoidFractionId=0,CatalystVoidFraction=0,CatalystVoidFractionCrushed=0 });
                    mstr.CatalystSizes = new List<KeyValue>();
                    mstr.CatalystSizes.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.CatalystAlias = new List<CatalystAlias>();
                    mstr.CatalystAlias.Add(new CatalystAlias {CatalystAliasId=0,CatalystShapeId=0,CatalystSizeInd=0,CatalystAliasName="Select" });
                    mstr.CatalystState = new List<KeyValue>();
                    mstr.CatalystState.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.CatalystLeaders = new List<KeyValue>();                   
                    mstr.CatalystScale = new List<KeyValue>();
                    mstr.CatalystScale.Add(new KeyValue { Key = "0", Value = "Select" });
                    //NR--01
                    mstr.CatalystApplication = new List<KeyValue>();
                    mstr.CatalystApplication.Add(new KeyValue { Key = "0", Value = "Select" });
                    while (objSqlDr.Read())
                    {
                        
                        CatalystFamily family = new CatalystFamily();
                        family.CatalystFamilyId = Convert.ToInt32(objSqlDr["CATALYST_FAMILY_ID"]);
                        family.CatalystFamilyInd = Convert.ToString(objSqlDr["CATALYST_FAMILY_IND"]);
                        family.CatalystFamilyName = Convert.ToString(objSqlDr["FAMILY_NAME"]);
                        family.CatalystTypeId = Convert.ToInt32(objSqlDr["CATALYST_TYPE_ID"]);
                        mstr.CatalystFamilys.Add(family);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue type = new KeyValue();
                        type.Key = Convert.ToString(objSqlDr["CATALYST_TYPE_ID"]);
                        type.Value = Convert.ToString(objSqlDr["CATALYST_TYPE_NM"]);
                        mstr.CatalystTypes.Add(type);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        CatalystShape shape = new CatalystShape();
                        shape.CatalystShapeId = Convert.ToInt32(objSqlDr["CATALYST_SHAPE_ID"]);
                        shape.CataystShapeName = Convert.ToString(objSqlDr["CATALYST_SHAPE_NM"]);
                        shape.CatalystVoidFractionId = Convert.ToInt32(objSqlDr["CATALYST_VOIDFRACTION_ID_SQ"]);
                        shape.CatalystVoidFraction = (objSqlDr["ASSUMED_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["ASSUMED_FRACTION_MSR"]);
                        shape.CatalystVoidFractionCrushed = (objSqlDr["CRUSHED_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["CRUSHED_FRACTION_MSR"]);
                        mstr.CatalystShapes.Add(shape);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue size = new KeyValue();
                        size.Key = Convert.ToString(objSqlDr["CATALYST_SIZE_ID"]);
                        size.Value = Convert.ToString(objSqlDr["CATALYST_SIZE_NM"]);
                        mstr.CatalystSizes.Add(size);
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        CatalystAlias alias = new CatalystAlias();
                        alias.CatalystAliasId = Convert.ToInt32(objSqlDr["CATALYST_ALIAS_SS_ID"]);
                        alias.CatalystShapeId = Convert.ToInt32(objSqlDr["CATALYST_SHAPE_ID"]);
                        alias.CatalystSizeInd = Convert.ToInt32(objSqlDr["CATALYST_SIZE_ID"]);
                        alias.CatalystAliasName = Convert.ToString(objSqlDr["CATALYST_ALIAS_SS_NM"]);
                        mstr.CatalystAlias.Add(alias);
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue state = new KeyValue();
                        state.Key = Convert.ToString(objSqlDr["CATALYST_STATE_ID"]);
                        state.Value = Convert.ToString(objSqlDr["CATALYST_STATE_NM"]);
                        mstr.CatalystState.Add(state);
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue leader = new KeyValue();
                        leader.Key = Convert.ToString(objSqlDr["EMPLOYEE_ID"]);
                        leader.Value = Convert.ToString(objSqlDr["CATALYST_LEADER"]);
                        mstr.CatalystLeaders.Add(leader);
                    }
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue scale = new KeyValue();
                        scale.Key = Convert.ToString(objSqlDr["CATALYST_SCALE_ID"]);
                        scale.Value = Convert.ToString(objSqlDr["CATALYST_SCALE_NM"]);
                        mstr.CatalystScale.Add(scale);
                    }
                    //NR--01
                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue application = new KeyValue();
                        application.Key = Convert.ToString(objSqlDr["CATALYST_APPLICATION_ID_SQ"]);
                        application.Value = Convert.ToString(objSqlDr["CATALYST_APPLICATION_NM"]);
                        mstr.CatalystApplication.Add(application);
                    }
                }
                return mstr;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<CatalystLite> GetCatalystLite()
        {
            try
            {

                List<CatalystLite> catalysts = new List<CatalystLite>();

                #region setting up DBCommand with parameters

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("catalyst.Catalyst_lst_Flyout"))
                {
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        CatalystLite cat = new CatalystLite
                        {
                            CatalystId = Convert.ToInt32(objSqlDr["CATALYST_ID_SQ"]),
                            CatalystDesignation = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]),
                            CatalystDescription = Convert.ToString(objSqlDr["CATALYST_DESC"]),
                            CatalystFamilyName = Convert.ToString(objSqlDr["FAMILY_NAME"]),
                            CatalystTypeName = Convert.ToString(objSqlDr["CATALYST_TYPE_NM"]),
                            ActiveInd = Convert.ToString(objSqlDr["ACTIVE_IND"]),
                            AnalyticalStatusName=Convert.ToString(objSqlDr["ANALYTICAL_STATUS"]),
                            CatalystLeaderName=Convert.ToString(objSqlDr["CATALYST_LEADER_NM"]),
                            BulkLocationInd = Convert.ToString(objSqlDr["BULK_LOCATION_IND"])
                        };
                        catalysts.Add(cat);
                    }
                }
                return catalysts;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<CatalystLimsSample> GetCatalystSampleIds(int catalystId)
        {
            try
            {
                if (catalystId == null) throw new ArgumentNullException("CatalystId");
                IDbCommand command = _db.CreateCommand("catalyst.GetCatalystSampleIds");
                IDataReader objSqlDr = null;
                List<CatalystLimsSample> samples = new List<CatalystLimsSample>();
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("catalyst_id", catalystId);
                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {
                        CatalystLimsSample sample = new CatalystLimsSample
                        {
                            SampleId= Convert.ToString(objSqlDr["LIMS_SAMPLE_ID"]),
                            CatalystId= Convert.ToInt32(objSqlDr["CATALYST_ID"]),
                            UploadDate= String.IsNullOrEmpty( Convert.ToString(objSqlDr["LAST_UPLOAD_DT"])) ? (DateTime?)null:Convert.ToDateTime(objSqlDr["LAST_UPLOAD_DT"]),
                            uploadInd = Convert.ToString(objSqlDr["LIMS_DATA_UPLOAD_IND"])
                        };
                        samples.Add(sample);
                    }
                }
                return samples;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public int SaveCatalyst(CatalystModel catalyst)
        {
            
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                string xmlData = Serializer.ConvertToXML<CatalystModel>(catalyst);
                int catalystID = 0;
                parameters.Add("@INPUT_FILE_XML", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                parameters.Add("@proc_vr_Created_By_User_Id", UserSession.Instance.User.EID);
               
                

                using (IDbCommand cmd = _db.CreateCommand("catalyst.Insert_Update_Catalyst"))
                {
                    if (cmd == null) throw new ArgumentNullException("cmd");
                    if (parameters == null) throw new ArgumentNullException("parameterValues");
                    for (IEnumerator iter = parameters.GetEnumerator(); iter.MoveNext();)
                    {
                        DictionaryEntry parameter = (DictionaryEntry)iter.Current;
                        if (parameter.Value == null) continue;
                        IDbDataParameter cmdParam = cmd.CreateParameter();
                        cmdParam.ParameterName = parameter.Key.ToString();
                        cmdParam.Value = parameter.Value;
                        cmd.Parameters.Add(cmdParam);
                    }
                    IDbDataParameter cmdOutParam = cmd.CreateParameter();
                    cmdOutParam.ParameterName = "@catalyst_id_out";
                    cmdOutParam.Value = catalystID;
                    cmdOutParam.Direction = ParameterDirection.Output; 
                    cmd.Parameters.Add(cmdOutParam);                  
                    //_db.CreateParameters(cmd, parameters);
                    int cnt= _db.ExecuteNonQuery(cmd);
                    cmdOutParam = (IDbDataParameter)cmd.Parameters["@catalyst_id_out"];
                    catalystID = Convert.ToInt32(cmdOutParam.Value);
                    catalyst.CatalystId = catalystID;
                    return cnt;

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);                
                throw;
            }
        }

        public List<CatalystModel> SearchCatalystDetails(Model.Catalyst.CatalystModel catalyst)
        {
            try
            {
               
                List<CatalystModel> catalysts = new List<CatalystModel>();

                #region setting up DBCommand with parameters

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("catalyst.Search_Catalyst"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    string xmlData = Serializer.ConvertToXML<CatalystModel>(catalyst);
                    parameters.Add("@INPUT_FILE_XML", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        CatalystModel cat = new CatalystModel
                        {
                            CatalystId = Convert.ToInt32(objSqlDr["CATALYST_ID_SQ"]),
                            CatalystDesignation = Convert.ToString(objSqlDr["CATALYST_DESIGNATION_NM"]),
                            CatalystDescription = Convert.ToString(objSqlDr["CATALYST_DESC"]),
                            CatalystFamilyId = Convert.ToInt32(objSqlDr["CATALYST_FAMILY_ID"]),
                            CatalystFamilyName = Convert.ToString(objSqlDr["FAMILY_NAME"]),
                            CatalystTypeId = Convert.ToInt32(objSqlDr["CATALYST_TYPE_ID"]),
                            CatalystTypeName = Convert.ToString(objSqlDr["CATALYST_TYPE_NM"]),
                            CatalystShapeId = Convert.ToInt32(objSqlDr["CATALYST_SHAPE_ID"]),
                            CatalystShapeName = Convert.ToString(objSqlDr["CATALYST_SHAPE_NM"]),
                            CatalystSizeId = Convert.ToInt32(objSqlDr["CATALYST_SIZE_ID"]),
                            CatalystSizeName = Convert.ToString(objSqlDr["CATALYST_SIZE_CD"]),
                            CatalystAliasId = (objSqlDr["CATALYST_ALIAS_SS_ID"] == DBNull.Value) ? (int?)null : Convert.ToInt32(objSqlDr["CATALYST_ALIAS_SS_ID"]),
                            //CatalystAliasName = Convert.ToDouble(objSqlDr["PTE_PERCNT"]),
                            ReferenceCatalystInd = Convert.ToString(objSqlDr["REFERENCE_CATALYST_IND"])=="Y"?true:false,
                            RegenCatalystInd =Convert.ToString(objSqlDr["REGENERATED_CATALYST_IND"])=="Y"?true:false,
                            CatalystStateId = Convert.ToInt32(objSqlDr["CATALYST_STATE_ID"]),
                            CatalystStateName = Convert.ToString(objSqlDr["CATALYST_STATE_NM"]),
                            GroundInd = Convert.ToString(objSqlDr["GROUND_IND"])=="Y"?true:false,
                            AnalyticalApproveInd = Convert.ToString(objSqlDr["ANALYTICAL_APPROVE_IND"])=="Y"?true:false,
                            AnalyticalStatusName = Convert.ToString(objSqlDr["ANALYTICAL_STATUS"]),
                            AnalyticalStatusNameTemp = Convert.ToString(objSqlDr["ANALYTICAL_STATUS"]),
                            //AnalyticalStatusName = Convert.ToString(objSqlDr["BULK_LOCATION_IND"]),
                            BulkLocationInd = Convert.ToString(objSqlDr["BULK_LOCATION_IND"])=="Y"?true:false,
                            CatalystLeaderCd = Convert.ToString(objSqlDr["CATALYST_LEADER"]),
                            CatalystLeaderName = Convert.ToString(objSqlDr["CATALYST_LEADER_NM"]),
                            ApparentBedDensity = (objSqlDr["APPARENT_BED_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["APPARENT_BED_DENSITY_MSR"]),
                            VibratedBedDensity = (objSqlDr["VIBRATED_BED_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["VIBRATED_BED_DENSITY_MSR"]),
                            CatalystScaleId = Convert.ToInt32(objSqlDr["CATALYST_SCALE_ID"]),
                            //CatalystScaleName = Convert.ToString(objSqlDr["PP_PRIORITY_NM"]),
                            CatalystPieceDensity = (objSqlDr["PIECE_DENSITY_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["PIECE_DENSITY_MSR"]),
                            LOIAt500Msr = (objSqlDr["LOI_500_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["LOI_500_MSR"]),
                            CatalystVoidFraction = (objSqlDr["ASSUMED_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["ASSUMED_FRACTION_MSR"]),
                            CatalystVoidFractionCrushed = (objSqlDr["CRUSHED_FRACTION_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objSqlDr["CRUSHED_FRACTION_MSR"]),                            
                            ActiveInd = Convert.ToString(objSqlDr["ACTIVE_IND"]),
                        };
                        catalysts.Add(cat);
                    }
                }
                return catalysts;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Gets the feed phy property results.
        /// </summary>
        /// <param name="FeedId">The feed identifier.</param>
        /// <param name="AnalysisMethodId">The analysis method identifier.</param>
        /// <returns></returns>
        public IList<CatalystLimsResult> GetCatalystPhyPropertyResults(int? CatalystId, int AnalysisMethodId, IList<UnitGroup> unitGroups, IList<UomVariable> uomVariables, IList<Validation> validationList)
        {
            var properties = new List<CatalystLimsResult>();
            var totalValueSums = new Dictionary<string, double?>();
            List<Sample> samples = new List<Sample>();
            IDictionary parameters = new Dictionary<string, object>();
            IDataReader reader = null;

            parameters.Add("proc_vr_catalyst_id", CatalystId);
            parameters.Add("proc_vr_analysis_method_id", AnalysisMethodId);
            parameters.Add("proc_vr_user_id", UserSession.Instance.User.EID);
            parameters.Add("proc_vr_src_system_id", Framework.Common.ApplicationSettings.AppId);
            using (IDbCommand cmd = _db.CreateCommand("[catalyst].[Get_Catalyst_Lims_Results_Sp]"))
            {
                _db.CreateParameters(cmd, parameters);
                reader = _db.ExecuteReader(cmd);

                #region FEED PHY PROPERTY
                while (reader.Read())
                {
                    var feedPHUnitGroup = (unitGroups != null) ? unitGroups.FirstOrDefault(p => p.UnitGroupCD == Convert.ToString(reader["UOM_GROUP_CD"])) : null;
                   // var UOMVarible = feedPHUnitGroup != null ? Model.Session.UserSession.Instance.UomVariables.First(w => w.UnitGroupName == feedPHUnitGroup.UnitGroupName) : null;
                    var feedPHDefaultUnit = feedPHUnitGroup != null ? feedPHUnitGroup.Units.First(w => w.UnitName == Convert.ToString(reader["UOM_UNIT_NM"])) : null;
                   
                    CatalystLimsResult property = properties.FirstOrDefault(p => p.Component == Convert.ToString(reader["PROPERTY_LABEL_TXT"]));
                    if (property == null)
                    {
                        property = new CatalystLimsResult()
                        {
                            Component = Convert.ToString(reader["PROPERTY_LABEL_TXT"]),
                            CatalystId = (reader["CATALYST_ID"] != DBNull.Value) ? Convert.ToInt32(reader["CATALYST_ID"]) : 0
                        };
                        property.LimsSampleValues.Clear();
                        properties.Add(property);

                    }

                    Sample limsSampleResult = null;
                    limsSampleResult = property.LimsSampleValues.FirstOrDefault(p => p.LimsSampleId == Convert.ToString(reader["SAMPLE_ID"]));
                    if (limsSampleResult == null)
                    {
                        limsSampleResult = new Sample()
                        {
                            LimsSampleId = Convert.ToString(reader["SAMPLE_ID"]),
                            AnalysisMethodId = Convert.ToInt32(reader["ANALYSIS_METHOD_ID"]),
                            LimsID = Convert.ToInt32(reader["CATALYST_PROPERTY_ID"]),
                            PPValueIdSQ = reader["CATALYST_PROPERTY_ID"] != DBNull.Value ? Convert.ToInt32(reader["CATALYST_PROPERTY_ID"]) : 0
                        };
                    }
                    if (!totalValueSums.Keys.Contains(limsSampleResult.LimsSampleId))
                    {
                        totalValueSums.Add(limsSampleResult.LimsSampleId, 0);
                    }
                    limsSampleResult.BaseValue = reader["PROPERTY_VALUE_QTY"].FormatDouble();
                    if (reader["VARIABLE_DECIMAL_PNT"] != DBNull.Value)
                    {
                        limsSampleResult.Precision = getFormatedPrecision(reader["VARIABLE_DECIMAL_PNT"]);
                    }

                    totalValueSums[limsSampleResult.LimsSampleId] += limsSampleResult.BaseValue;
                    limsSampleResult.PPValueText = Convert.ToString(reader["PROPERTY_VALUE_TXT"]);
                    if (property.PropertyUnitGroup == null)
                    {
                        property.PropertyUnitGroup = feedPHUnitGroup;
                        property.PropertyDisplayUnit = feedPHDefaultUnit;
                    }
                    if (reader["PROPERTY_VALUE_QTY"].FormatDouble() != null && reader["PROPERTY_VALUE_QTY"].FormatDouble() != 0.0)
                        limsSampleResult.TargetValue = feedPHDefaultUnit != null ? Convert.ToString(feedPHDefaultUnit.convertToTargetunit(limsSampleResult.BaseValue)) : null;
                    else
                        limsSampleResult.TargetValue = Convert.ToString(reader["PROPERTY_VALUE_TXT"]);
                    limsSampleResult.TargetUnit = feedPHDefaultUnit;
                    limsSampleResult.SelectedValidation = validationList.FirstOrDefault(p => p.ValidationCode == Convert.ToString(reader["VALIDATION_IND"]));
                    property.LimsSampleValues.Add(limsSampleResult);
                }
                #endregion
                reader.Close();
                return properties;
            }
        }
        

        public int UpdateLimsResult(UpdateLimsModel methodDetails, string userId)
        {
            if (methodDetails == null) throw new ArgumentNullException("methodDetails");
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("MethodSource", methodDetails.MethodSource);
            parameters.Add("Lims_Result_Xml", Serializer.ConvertToXML(methodDetails.SampleList));
            parameters.Add("Catalyst_Id", methodDetails.CatalystId);
            parameters.Add("Updated_By_User_Id", userId);
            using (IDbCommand cmd = _db.CreateCommand("[catalyst].[Update_Catalyst_Analysis_Rslt_Sp]"))
            {
                _db.CreateParameters(cmd, parameters);
                var result = _db.ExecuteNonQuery(cmd);
                return result;
            }
        }

        public LimsMasterResults GetCatalystAnalysisMethods(int? catalystId)
        {
            var limsMasterResult = new LimsMasterResults();
            limsMasterResult.AnalysisMethods.Clear();
            limsMasterResult.Validations.Clear();
            var analysisMethods = new List<AnalysisMethod>();
            IDictionary parameters = new Dictionary<string, object>();
            IDataReader reader = null;

            parameters.Add("@proc_vr_catalyst_id", catalystId);  //feedId
            using (IDbCommand cmd = _db.CreateCommand("[catalyst].[Get_Catalyst_Lims_Master_Sp]"))
            {
                _db.CreateParameters(cmd, parameters);
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    analysisMethods.Add(new AnalysisMethod()
                    {
                        Id = Convert.ToInt32(reader["ANALYSIS_METHOD_ID_SQ"]),
                        Name = Convert.ToString(reader["ANALYSIS_METHOD_NM"]),
                        Number = Convert.ToString(reader["ANALYSIS_METHOD_NUM"]),
                        AnalysisMethodSource = Convert.ToString(reader["ANALYSIS_SOURCE_NM"])
                    });
                }

                reader.NextResult();
                var validationList = new List<Validation>();
                while (reader.Read())
                {
                    validationList.Add(new Validation()
                    {
                        ValidationCode = Convert.ToString(reader["VALIDATION_IND"]),
                        ValidationName = Convert.ToString(reader["VALIDATION_IND_NM"])
                    });
                }

            ((List<AnalysisMethod>)limsMasterResult.AnalysisMethods).AddRange(analysisMethods);
                ((List<Validation>)limsMasterResult.Validations).AddRange(validationList);
                reader.Close();
                return limsMasterResult;
            }
        }

        private string getFormatedPrecision(object field)
        {
            var Precision = "0." + new string('0', Convert.ToInt32(field));
            return Precision;
        }
    }
}
