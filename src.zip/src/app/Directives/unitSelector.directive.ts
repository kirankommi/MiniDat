import { Component, Input, Output, EventEmitter } from '@angular/core';
import * as Constants from '../Shared/globalconstants';

@Component({
  selector: 'unitSelector',
  templateUrl:"unitSelector.directive.html"
})
export class unitSelectorDirective {
  private _baseValue: any;
  private _variableCategory: string;
  private _variableName: string;
  isSelectionOpen: boolean = false;
  uomObj: any;
  units: any = [];

  _defaultUnit: any;
   @Input() isDisabled: boolean;
   _isOverlay: boolean = true;
   _width: number = 100;
  @Input()
  get isOverlay() {
    return this._isOverlay;
  }
  set isOverlay(val) {
    this._isOverlay = val;
  }

  @Input()
  get width() {

      return this._width;
  }
  set width(val) {

      this._width = val;
  }

  @Input()
  get defaultunit() {
    return this._defaultUnit;
  }

  @Output() defaultunitChange = new EventEmitter();

  set defaultunit(val) {
    this._defaultUnit = val;
    if (this.uomObj && this.uomObj.Precision) {
      this._defaultUnit.Precision = this.uomObj.Precision;
    }
    this.defaultunitChange.emit(this._defaultUnit);
  }

  @Input()
  set variableCategory(vCat: string) {
    this._variableCategory = vCat;
    this.setUnits();
  }

  @Input()
  set variableName(vName: string) {
    this._variableName = vName;
    this.setUnits()
  }
  constructor() {

  }

  setUnits() {
    if (this._variableCategory && this._variableName) {
      this.uomObj = Constants.UOMCATVariables[this._variableCategory][this._variableName];
      this.units = Constants.UnitGroups.filter((x: any) => x.UnitGroupCD == this.uomObj.UnitGroupCD)[0].Units;
      this.defaultunit = this.units.filter((x: any) => x.DisplayText == this.uomObj.DefaultUnitName)[0];
      this.defaultunit.Precision = this.uomObj.Precision;
    }
  }
  unitChange(event) {
    this.isSelectionOpen = false;
  }

}
