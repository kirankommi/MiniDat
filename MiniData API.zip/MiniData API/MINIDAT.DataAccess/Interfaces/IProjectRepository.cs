﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	IProjectRepository.cs
                                                Project Title			:	MINIDAT
                                                Author(s)				:	E489772
                                                Created Date			:	18 Feb 2019
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.Model;
using MINIDAT.Model.Project;
using MINIDAT.Models.Interfaces;
using System.Collections.Generic;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IProjectRepository
    {
        List<AccoladeProjectModel> GetAccoladeProjects(string projectType);
        ProjectMasterDataModel GetProjectDetails(string projectType);

        int SaveProject(ProjectModel project);
        List<ProjectModel> SearchProjectDetails(ProjectModel project);
        bool DeleteProject(int projectId);

        void InsertProjectDocument(FileImport _doc);
        FileImport GetProjectDocument(string fileId, string projectId);
        List<FileImport> GetProjectAllDocuments(string projectId);
        int DeleteDocument(FileImport _doc);

        string UploadFiles(List<FileImport> Files, string DeleteIDs, int projectID, string UserID);
    }
}
