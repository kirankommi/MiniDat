﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystLite
    {
        public int CatalystId { get; set; }
        public string CatalystDesignation { get; set; }

        public string CatalystDescription { get; set; }

        public string CatalystFamilyName { get; set; }

        public string CatalystTypeName { get; set; }
        public string ActiveInd { get; set; }
        public string AnalyticalStatusName { get; set; }
        public string BulkLocationInd { get; set; }
        public string CatalystLeaderName { get; set; }
    }
    public class CatalystModel
    {
        public int CatalystId { get; set; }
        public string CatalystDesignation { get; set; }

        public string CatalystDescription { get; set; }

        public int CatalystFamilyId { get; set; }
        public string CatalystFamilyName { get; set; }

        public int CatalystTypeId { get; set; }
        
        public string CatalystTypeName { get; set; }
        public int CatalystShapeId { get; set; }
        public string CatalystShapeName { get; set; }
        public int CatalystSizeId { get; set; }
        public string CatalystSizeName { get; set; }
        public int? CatalystAliasId { get; set; }
        public string CatalystAliasName { get; set; }
        
        public int CatalystStateId { get; set; }
        public string CatalystStateName { get; set; }
        public bool ReferenceCatalystInd { get; set; }
        public bool RegenCatalystInd { get; set; }
        public bool GroundInd { get; set; }
        public bool AnalyticalApproveInd { get; set; }
        public bool BulkLocationInd { get; set; }

        public string AnalyticalStatusCd { get; set; }
        public string AnalyticalStatusName { get; set; }
        public string AnalyticalStatusNameTemp { get; set; }
        
        public string CatalystLeaderCd { get; set; }
        public string CatalystLeaderName { get; set; }
        public double? ApparentBedDensity { get; set; }
        public double? VibratedBedDensity { get; set; }
        public int CatalystScaleId { get; set; }
        public string CatalystScaleName { get; set; }
        public double? CatalystPieceDensity { get; set; }
        public double? LOIAt500Msr { get; set; }
        public double? CatalystVoidFraction { get; set; }
        public double? CatalystVoidFractionCrushed { get; set; }
        public string ActiveInd { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime UpdatedOn { get; set; }
        public List<CatalystLimsSample> LIMSs { get; set; }

        public bool IsInitialLoad { get; set; }


    }
    public class CatalystFamily
    {
        public int CatalystFamilyId { get; set; }
        public string CatalystFamilyName { get; set; }
        public string CatalystFamilyInd { get; set; }
        public int CatalystTypeId { get; set; }
    }

    public class CatalystAlias
    {
        public int CatalystAliasId { get; set; }
        public int CatalystShapeId { get; set; }
        public int CatalystSizeInd { get; set; }
        public string CatalystAliasName { get; set; }
    }

    public class CatalystShape
    {        
        public int CatalystShapeId { get; set; }
        public string CataystShapeName { get; set; }
        public int CatalystVoidFractionId { get; set; }
        public double? CatalystVoidFraction { get; set; }
        public double? CatalystVoidFractionCrushed { get; set; }
    }
    public class CatalystMasterDataModel
    {

        public List<CatalystFamily> CatalystFamilys { get; set; }
        public List<KeyValue> CatalystTypes { get; set; }
        public List<CatalystShape> CatalystShapes { get; set; }
        public List<KeyValue> CatalystSizes { get; set; }
        public List<CatalystAlias> CatalystAlias { get; set; }
        public List<KeyValue> CatalystState { get; set; }
        public List<KeyValue> CatalystLeaders { get; set; }
        public List<KeyValue> CatalystScale { get; set; }
        public List<KeyValue> CatalystApplication { get; set; }
    }
    public class CatalystLimsSample
    {
        public int CatalystId { get; set; }
        public string SampleId { get; set; }

        public DateTime? UploadDate { get; set; }
        public string uploadInd { get; set; }
    }

}
