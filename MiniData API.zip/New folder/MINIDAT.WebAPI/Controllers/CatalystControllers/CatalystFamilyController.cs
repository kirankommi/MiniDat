﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	RoleController.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Manage Role - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.Catalyst;
using MINIDAT.Model.Catalyst;
using MINIDAT.Model;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;

namespace MINIDAT.WebAPI.Controllers
{
    public class CatalystFamilyController : AppController
    {
        ICatalystFamilyRepository _catalystFamilyRepository;       
        public CatalystFamilyController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage Catalyst Family" }));
            _catalystFamilyRepository = new CatalystFamilyRepository(new MINIDATDatabase());
        }
        /// <summary>
        /// search the roles
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SearchCatalystFamilydata")]
        public CatalystFamilySearchModel GetData([FromBody] CatalystFamilyModel catalystFamily)
        {
            //RoleRepository _roleRepository = new RoleRepository(new FDMSDatabase());
            var tbpsrModel = _catalystFamilyRepository.GetCatalystFamilyData(catalystFamily);
            return tbpsrModel;
        }
        /// <summary>
        /// save the role after modifications
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>

        [HttpPost, ActionName("SaveCatalystFamilyInformation")]
        public HttpResponseMessage SaveModeInformation([FromBody] CatalystFamilyModel catalystFamily)
        {
            if (catalystFamily != null)
            {
                try
                {
                    ICatalystFamilyRepository _catalystFamilyRepository = new CatalystFamilyRepository(new MINIDATDatabase());
                    _catalystFamilyRepository.SaveCatalystFamilyData(catalystFamily, User.Identity.Name);
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                    
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }
        /// <summary>
        /// remove the role
        /// </summary>
        /// <param name="roleFilter"></param>
        /// <returns></returns>

        [HttpPost, ActionName("DeleteCatalystFamilyInformation")]
        public HttpResponseMessage DeleteModeInformation([FromBody] CatalystFamilyModel catalystFamily)
        {
            if (catalystFamily != null)
            {
                try
                {
                    ICatalystFamilyRepository _catalystFamilyRepository = new CatalystFamilyRepository(new MINIDATDatabase());
                    _catalystFamilyRepository.DeleteCatalystFamilyData(catalystFamily);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);                  
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
    }
   
}
