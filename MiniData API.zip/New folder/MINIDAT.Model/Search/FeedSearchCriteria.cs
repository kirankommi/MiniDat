﻿using MINIDAT.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Search
{
    public class FeedSearchCriteria : ICriteria
    {
        public Guid FeedID { get; set; }
        public string FeedUOPNumber { get; set; }
        public string FeedBookNumber { get; set; }
        public string FeedName { get; set; }
        public string FeedDescription { get; set; }
        public string FeedCategoryName { get; set; }
        public string FeedTBPName { get; set; }
        public string FeedTypeName { get; set; }
        public string FeedSource { get; set; }
        public string StatusCode { get; set; }
        public string Comments { get; set; }
        public float InventoryMSR { get; set; }
        public string UOM_ID { get; set; }
        public string SupplierName { get; set; }
    }
    public static class FeedSearchFrom
    {
        public const string ViewSearch = "ViewSearch";
        public const string Dashboard = "Dashboard";
    }
}
