﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.UOM
{
    public class UOMTemplate :ICloneable
    {
        #region Private_Memebers

        private int templateId;
        private string templateName;

        #endregion Private_Members

        /// <summary>
        /// Get or set Template Id
        /// </summary>
        public int TemplateId
        {
            get
            {
                return templateId;
            }
            set
            {
                templateId = value;
               
            }
        }

        /// <summary>
        /// Get or set the Template Name
        /// </summary>
        public string TemplateName
        {
            get
            {
                return templateName;
            }
            set
            {
                templateName = value;
            }
        }


        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
