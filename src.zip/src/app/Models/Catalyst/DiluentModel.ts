﻿export class DiluentModel {
    DiluentID: number;
    Designation: string;
    Source: string;
    size: number;
    ReferenceName: string;
    StatusName: string;
    Description: string;    
    CanEdit: string;      
    AppCode: string;   
    PieceDensity: number;
    ApparentBulkDensity: number;
    StatusCode: KeyValue;
    Sizecd: KeyValue;
    Referencecd: KeyValue;   
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
