﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystScaleModel, KeyValue } from '../../Models/Catalyst/CatalystScaleModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystScaleService {
    private getCatalystScaledata = "/CatalystScale/SearchCatalystScaledata/";
    private getActiveCatalystScaleinfo = "/CatalystScale/GetActiveCatalystScaledata/";
    private saveCatalystScaledata = "/CatalystScale/SaveCatalystScaleInformation/";
    private deleteCatalystScaledata = "/CatalystScale/DeleteCatalystScaleInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystScaleInformation(catalystScale: CatalystScaleModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystScale, this.getCatalystScaledata);
    }

    saveCatalystScaleInformation(catalystScale: CatalystScaleModel)
    {
        return this.httpaction.post(catalystScale, this.saveCatalystScaledata);
    }

    deleteCatalystScale(catalystScale: CatalystScaleModel)
    {
        debugger;
        return this.httpaction.post(catalystScale, this.deleteCatalystScaledata);
    }    
}
