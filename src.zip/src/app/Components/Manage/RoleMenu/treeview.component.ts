﻿import { Component, Input } from '@angular/core';

@Component({    
    //moduleId: module.id,
    selector: 'treeview',
    templateUrl: 'treeview.component.html',
})
export class TreeView {
    @Input() treeData: any[];
    @Input() treeParent: any[];
    @Input() treeCompleteData: any[];
    selectedparentNode: any;

    constructor() {
    }

    toggleChildren(node: any) {
        node.visible = !node.visible;
    }

    onTabCheck(event: any, node: any, treeNode: any) {
        // 
        this.toggleAllChildNodes(node, event.target.checked)

        if (event.target.checked) {
            this.onSelect(node);
        }
        else {
            this.onUnSelect(node);
        }        
    }

    onUnSelect(node: any) {
        // 
        if (node.ParentID != null) {
            this.unSelectAllParentNode(this.treeParent);
        }
    }

    unSelectAllParentNode(node: any) {
        // 
        if (node != null && node.Items.length > 0) {
            if (node.Items.filter((x:any) => x.IsChecked).length <= 0) {
                node.IsChecked = false;
            }
        }
        if (node.ParentID != null) {
            this.getParentNode(this.treeCompleteData[0], node.ParentID);
            this.unSelectAllParentNode(this.selectedparentNode);
        }
    }

    onSelect(node: any) {
        if (node.ParentID != null && node.ParentID != "FUNC000001") {
            this.selectAllParentNode(this.treeParent);
        }
        else if (node.ParentID == "FUNC000001") {
            let parentNode = this.treeCompleteData[0];
            parentNode.IsChecked = true;
        }
    }

    selectAllParentNode(node: any) {
        // 
        if (node != null) {
            node.IsChecked = true;
            if (node.ParentID != null) {
                this.getParentNode(this.treeCompleteData[0], node.ParentID);
                this.selectAllParentNode(this.selectedparentNode);
            }
        }
    }

    getParentNode(node: any, parentId: any) {
        // 
        if (node.ID == parentId) {
            this.selectedparentNode = node;
            return;
        }
        for (let y of node.Items) {
            this.getParentNode(y, parentId);
        }
    }

    toggleAllChildNodes(node: any, action: any) {
        // 
        node.IsChecked = action;
        node.ReadOnly = action;
        node.CanWrite = action;
        if (node.Items.length > 0) {
            node.Items.filter((x:any) => {
                x.IsChecked = action;
                x.ReadOnly = action;
                x.CanWrite = action;
            });
        }
        for (let item of node.Items) {
            this.toggleAllChildNodes(item, action);
        }
    }

    onReadCheck(event: any, node: any) {
        node.ReadOnly = event.target.checked
        node.IsChecked = node.ReadOnly || node.CanWrite;
        if (event.target.checked) {
            this.onSelect(node);
        }
        else {
            this.onUnSelect(node);
        }
        // 
    }

    onWriteCheck(event: any, node: any) {
        node.CanWrite = event.target.checked
        node.IsChecked = node.ReadOnly || node.CanWrite;
        if (event.target.checked) {
            this.onSelect(node);
        } else {
            this.onUnSelect(node);
        }
        // 
    }
}