﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	RoleMenuRepository.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	01 june 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Manage;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Collections;
using MINIDAT.Model;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Manage
{

    public class RoleMenuRepository : IRoleMenuRepository
    {

        private IDatabase _db;

        public RoleMenuRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public RoleSearchModel GetRoles(string EID)
        {
            IList<RoleModel> roleList = new List<RoleModel>();
            try
            {
                #region DbCommand 

                RoleSearchModel rolesearchModel = new RoleSearchModel();
                using (IDbCommand command = _db.CreateCommand("Get_Roles_Sp"))
                {
                    IDataReader reader = null;
                    #endregion

                    #region Creating Parameters Collection
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_emp_id", EID);

                    parameters.Add("src_system_id", ApplicationSettings.AppId);
                    #endregion

                    #region Create & execute the command 
                    _db.CreateParameters(command, parameters);
                    reader = _db.ExecuteReader(command);
                    #endregion Create & execute the command

                    #region Populate Role List
                    if (reader != null)
                    {

                        RoleModel roleRecord = new RoleModel { RoleCode = "Select", RoleName = "Select" };
                        // roleList.Add(roleRecord); 
                        rolesearchModel.Roles.Add(roleRecord);
                        while (reader.Read())
                        {
                            roleRecord = new RoleModel
                            {
                                RoleCode = Convert.ToString(reader["role_cd"]),
                                RoleName = Convert.ToString(reader["role_nm"]),
                                RoleDescription = Convert.ToString(reader["role_desc"]),
                            };
                            // roleList.Add(roleRecord);
                            rolesearchModel.Roles.Add(roleRecord);
                        }
                        reader.NextResult();
                        ApplicationModel appModel = new ApplicationModel();
                        // rolesearchModel.ApplicationList.Add(new ApplicationModel { ApplicationId = "3", ApplicationName = "FeedStock DAT" });
                        while (reader.Read())
                        {
                            appModel = new ApplicationModel
                            {
                                ApplicationId = Convert.ToString(reader["SRC_SYSTEM_ID"]),
                                ApplicationName = Convert.ToString(reader["SRC_SYSTEM_NM"])

                            };
                            //   roleList.Add(appModel);
                            rolesearchModel.ApplicationList.Add(appModel);
                        }
                    }
                    #endregion

                    #region Return Role List

                    reader.Close();
                    return rolesearchModel;

                    #endregion Return Role List
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public Dictionary<MenuAssignment, string> GetMenuByRole(string roleCode, string appCode)
        {
            Dictionary<MenuAssignment, string> menuAssignmentList = new Dictionary<MenuAssignment, string>();
            MenuAssignment item = new MenuAssignment();
            string privilage = string.Empty;
            try
            {
                #region DbCommand 
                if (roleCode == null) throw new ArgumentNullException("roleCode");
                using (IDbCommand command = _db.CreateCommand("Get_Menus_For_Role_Sp"))
                {
                    IDataReader reader = null;
                    #endregion

                    #region Creating Parameters Collection

                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Role_Cd", roleCode);
                    parameters.Add("proc_vr_App_Cd", appCode);
                    #endregion Creating Parameters Collection

                    #region Create & execute the command

                    _db.CreateParameters(command, parameters);
                    reader = _db.ExecuteReader(command);
                    #endregion Create & execute the command

                    #region Populate Role List
                    if (reader != null)
                    {
                        while (reader.Read())
                        {
                            item = new MenuAssignment
                            {
                                Header = Convert.ToString(reader["FUNCTION_DESC"]),
                                ID = Convert.ToString(reader["FUNCTION_CD"]),
                                Index = Convert.ToString(reader["FUNCTION_ORDER_NUM"]),
                            };
                            //privilagation for each menu item
                            privilage = Convert.ToString(reader["PRIVILEGE_NM"]);
                           // privilage = (reader["PRIVILEGE_NM"] != DBNull.Value) ? Convert.ToString(reader["PRIVILEGE_NM"]) : "Read";

                            //   privilage = (reader["CUST_ID_SQ"] != DBNull.Value) ? Convert.ToInt32(reader["CUST_ID_SQ"]) : 0,

                            //get menu if it already added in menu dictionary
                            var menuItem = from m in menuAssignmentList.Keys
                                           where m.ID == item.ID
                                           select m;

                            if (menuItem.Count() > 0)
                            {
                                //update read/write status
                                UpdateReadWrite(menuItem.FirstOrDefault(), privilage);
                            }
                            else
                            {
                                //add new menu item
                                menuAssignmentList.Add(item, Convert.ToString(reader["PARENT_FUNCTION_CD"]));
                                UpdateReadWrite(item, privilage);
                            }
                        }

                    }

                    reader.Close();
                    #endregion

                    return menuAssignmentList;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        #region UpdateReadWrite
        /// <summary>
        /// update the role status
        /// </summary>
        /// <param name="role"></param>
        /// <param name="value"></param>
        private void UpdateReadWrite(MenuAssignment role, string value)
        {
            //update the role stauts if not null
            if (role != null && !string.IsNullOrEmpty(value))
            {
                switch (value.ToLower().Trim())
                {
                    case "read":
                        role.IsChecked = true;
                        role.ReadOnly = true;
                        break;
                    case "write":
                        role.IsChecked = true;
                        role.CanWrite = true;
                        break;
                }
            }
        }
        #endregion UpdateReadWrite
        public int SaveRoleMenu(string roleCode, string appCode, string xml, string EID)
        {
            try
            {
                #region DbCommand
                if (roleCode == null) throw new ArgumentNullException("roleCode");
                if (appCode == null) throw new ArgumentNullException("appCode");
                if (xml == null) throw new ArgumentNullException("xml");
                if (EID == null) throw new ArgumentNullException("EID");
                IDbCommand command = _db.CreateCommand("Assign_Funcpriv_To_Role_Sp");
                #endregion
                using (command)
                {
                    #region Creating Parameters Collection

                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Role_Cd", roleCode);
                    parameters.Add("proc_vr_App_Cd", appCode);
                    parameters.Add("proc_vr_Function_Xml", xml);
                    parameters.Add("proc_vr_User_Id", EID);
                    _db.CreateParameters(command, parameters);
                    return _db.ExecuteNonQuery(command);

                    #endregion
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }

}
