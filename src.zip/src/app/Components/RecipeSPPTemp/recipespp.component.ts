import { Component, OnInit } from '@angular/core';
import { uploadHandler } from '../../Directives/filebrowse/filebrowse.component';
import { Observable } from "rxjs";
import { FileModel } from '../../Models/file.model';
import { RecipeSppService } from '../../Services/recipespp.service';
@Component({
  selector: 'app-createproject',
  templateUrl: './recipespp.component.html'
 
})
export class RecipeSppComponent implements OnInit {  
    phandler: uploadHandler;    
    files: FileModel[] = [];
    constructor(private recipeSppService: RecipeSppService) {
      
        this.recipeSppService.GetAllDocuments()
            .subscribe(
            (data: any) => {                
                this.files = data;
            });
    }

  ngOnInit() {
      this.phandler = new uploadHandler();
      this.phandler.downloadFile = this.onDownload.bind(this);     
  }

  onDownload(file: any): Observable<any> {
      return this.recipeSppService.DownLoadProjectDocuments(file.FileId.toString());     
  }
  
  onSearchBy(by: string)
  {
      
  }
}
