import { Component, OnInit, Input } from '@angular/core';
import { ProductPhysicalPropertiesService } from 'src/app/Services/TestCreation/ProductPhysicalProperties.service';
import { ProductPhysicalPropertiesModel, ProductPhysicalPropertiesDropdownModel, ProductPhysicalPropertiesInputModel, ValidationIndicator, Streams, ArrayOfProductPhysicalPropertyItemViewModel, ProductPhysicalPropertyItemViewModel } from 'src/app/Models/TestCreation/ProductPhysicalPropertiesModel';
import * as Constants from '../../../../app/Shared/globalconstants';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { Stream } from 'stream';

@Component({
  selector: 'app-product-physical-properties',
  templateUrl: './product-physical-properties.component.html',
  styleUrls: ['./product-physical-properties.component.css'],
  providers: [ProductPhysicalPropertiesService]
})
export class ProductPhysicalPropertiesComponent implements OnInit {
  @Input() PlantCd: string;
  @Input() RunId: string;
  @Input() TestId: string;
  inputObj: ProductPhysicalPropertiesInputModel = new ProductPhysicalPropertiesInputModel()
  streamVal: string = "--Select--";
  // streamList: string[] = [];
  // validationIndicatorList: string[] = [];
  streamList: Streams[] = [];
  validationIndicatorList: ValidationIndicator[] = [];
  tableData: ProductPhysicalPropertiesModel[] = [];
  DataToBeReset: ProductPhysicalPropertiesModel[] = [];
  cols: any[] = [];
  allVarChecked: boolean = false;
  physicalProertyObj: ProductPhysicalPropertiesModel = new ProductPhysicalPropertiesModel();
  selectedRow: ProductPhysicalPropertiesModel = new ProductPhysicalPropertiesModel();
  constants: any = {};
  totalRecordsFetched: number = 0;

  constructor(private _service: ProductPhysicalPropertiesService, private alertMessage: AlertMessage) {
    this.constants = Constants;
  }

  ngOnInit() {
    this.inputObj.PlantCd = this.PlantCd;
    this.inputObj.RunId = Number(this.RunId);
    this.inputObj.TestId = Number(this.TestId);
    this._service.GetProductPhysicalPropertiesDropdownValues(this.inputObj).subscribe((data: ProductPhysicalPropertiesDropdownModel) => {
      this.streamList = data.StreamList;
      this.validationIndicatorList = data.ValidationIndicatorList;
    })
  }

  // isReset:boolean=false;
  DropDownValidate() {
    this.tableData = [];
    this.cols = [];
    if (this.streamVal != "--Select--") {
      debugger;
      this.inputObj.StreamId = this.streamVal;
      this.inputObj.AllVariableChecked = this.allVarChecked;
      // this.inputObj.AllVariableChecked = true;
      this._service.GetProductPhysicalPropertiesData(this.inputObj).subscribe((data: ProductPhysicalPropertiesModel[]) => {
        this.tableData = data;
        this.totalRecordsFetched = data.length;
        // this._service.CacheFetchedRecords(data);
        this.DataToBeReset = data.map(x => ({ ...x }));
        if (this.tableData.length != 0) {
          Object.keys(this.tableData[0]).forEach(item => {
            if (item != "PropertyId" && item != "AnalysisMethodId") {
              switch (item) {
                case 'AnalysisMethodName':
                  this.cols.push({ field: item, header: "Analysis Method" });
                  break;
                case 'SampleId':
                  this.cols.push({ field: item, header: "Sample Id" });
                  break;
                case 'PropertyId':
                  this.cols.push({ field: item, header: "Property Id" });
                  break;

                case 'AnalysisMethodNumber':
                  this.cols.push({ field: item, header: "Analysis Method Number" });
                  break;

                case 'ValidationIndicator':
                  this.cols.push({ field: item, header: "Validation Indicator" });
                  break;
                case 'PropertyLabel':
                  this.cols.push({ field: item, header: "Property Label" });
                  break;
                case 'LIMSOperation':
                  this.cols.push({ field: item, header: "LIMS Operation" });
                  break;
                case 'TargetValue':
                  this.cols.push({ field: item, header: "Value" });
                  break;
                default:
                  this.cols.push({ field: item, header: item });
                  console.log("default", item);
                  break;

              }
            }

          })
        }
      })
    } else {
      this.allVarChecked = false;
    }

  }

  onRowSelection() {

    if (this.selectedRow) {
      this.physicalProertyObj = this.selectedRow;
      console.log("the selected row is", this.selectedRow)
    }
  }

  saveModelData: ArrayOfProductPhysicalPropertyItemViewModel = new ArrayOfProductPhysicalPropertyItemViewModel();
  arrayData: ProductPhysicalPropertyItemViewModel[] = [];
  SaveData() {

    this.saveModelData = new ArrayOfProductPhysicalPropertyItemViewModel();
    this.arrayData = [];
    this.tableData.forEach(el => {
      if (el.TargetValue != null || el.ValidationIndicator != "U") {
        let model = new ProductPhysicalPropertyItemViewModel();
        if (el.TargetValue == null) {
          model.BaseValue = "";
        } else {
          model.BaseValue = this.convertToBaseunit(el.UOM, el.TargetValue.toString());
        }

        model.LimsOperationId = el.LIMSOperationId;
        model.PropertyId = el.PropertyId.toString();
        model.PropertyLabel = el.PropertyLabel;
        model.SampleId = el.SampleId.toString();
        model.ValidationFlag = el.ValidationIndicator;
        model.Text = el.Text;
        this.arrayData.push(model);
      }

    })
    this.saveModelData.ArrayOfProductPhysicalPropertyItemViewModel = this.arrayData;
    this.saveModelData.PlantCd = this.PlantCd;
    this.saveModelData.RunId = Number(this.RunId);
    this.saveModelData.TestId = Number(this.TestId);
    this.saveModelData.StreamId = this.tableData[0].StreamId;

    console.log(this.tableData);
    this._service.SaveProductPhysicalPropertiesData(this.saveModelData).subscribe(
      (data: any) => {
        if (data == Constants.Success) {
          this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.constants.PhysicalPropertySaveSuccess });
        }
      },
      err => { }
    );
  }
  ResetData() {
    // this.tableData =[];
    // this.tableData = this.DataToBeReset.map(x=>({...x}));
    this.DropDownValidate();
  }

  ComputeUOMchange(event, unitsData) {
    debugger
    if (event && unitsData) {
      //if (unit) {
      let unit = unitsData.UOMlist.Units.filter((x: any) => x.DisplayText.toLowerCase() == event.toLowerCase())[0];
      //let precision = this.GetPrecison(component.compUnitGrpNm);
      // unitsData.Samples.forEach((x: any) => {
      if (unitsData.BaseValue != null && unitsData.BaseValue != undefined) {
        let precision = unitsData.Precision;
        unitsData.TargetValue = this.convertToTargetunit(unit, unitsData.BaseValue);
        if (unitsData.TargetValue == undefined) unitsData.TargetValue = 0;
        unitsData.TargetValue = parseFloat(unitsData.TargetValue).toFixed(precision);
        unitsData.TargetValue = isNaN(unitsData.TargetValue) ? '' : unitsData.TargetValue;
      }
      //});
      // }
    }
  }
  convertToTargetunit(unit: any, unitValue: any) {
    if (unit && unitValue) {
      if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
        return (unit.Slope / unitValue) - unit.Intercept;
      }
      else {
        return (unitValue - unit.Intercept) / unit.Slope;
      }
    }
  }
  convertToBaseunit(unit: any, unitValue: any) {
    if (unit && unitValue) {
      if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
        return unit.Slope / (unitValue + unit.Intercept);
      }
      else {
        return (unitValue * unit.Slope) + unit.Intercept;
      }
    }
  }
}
