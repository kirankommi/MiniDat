export class WCResultSummaryModel
{
    Parameter:string
    UOM:string
    DefaultUOM:string
    ParamDisplayOrder:string
    Value:string

}