﻿
import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { LimsComponentModel } from '../../Models/LimsComponentModel';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class LIMSResultService {
   
    public getViewLimsMasterUrl: string = "/Catalyst/GetViewLimsMaster/";
    private getMissingCountUrl = '/TraceLog/getMissingCount';   
    public updateLimsUrl: string = "/Catalyst/UpdateLimsResults/";
    public getLimsCompoentsUrl: string = "/Catalyst/GetLimsComponents/";
    constructor(private http: Http, private httpaction: HttpActionService) { }

    private handleError(error: any): Promise<any> {
        // console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    GetViewLimsMaster(catalystId: any) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('catalystId', catalystId.toString());   //feedId.toString()
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getViewLimsMasterUrl, options);
    }

    //Not implimented
    getMissingCount(catalystId: string) {
        //let params: URLSearchParams = new URLSearchParams(); 
        //if (catalystId && catalystId.length > 0) {
        //    params.set('catalystId', catalystId);
        //}
        //let options = new RequestOptions(Constants.getParamOptions(params));
        //return this.http.get(Constants.apiBaseUrl + this.getMissingCountUrl, options)
        //    .map((res: Response) => res.json())
        //    .catch(this.handleError);

    }


    UpdateLimsResults(analysisMethodData: any) {
        return this.httpaction.post(analysisMethodData, this.updateLimsUrl);
    }
    GetMethodComponents(catalystId: any, analysisId: any, methodSource: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('catalystId', catalystId.toString());     // catalystId.toString()
        params.set('analysisId', analysisId.toString());
        params.set('methodSource', methodSource);
        let options = new RequestOptions(Constants.getParamOptions(params));
        
        return this.httpaction.get(this.getLimsCompoentsUrl, options);
    }
}