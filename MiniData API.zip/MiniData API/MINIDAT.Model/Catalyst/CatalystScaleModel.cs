﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystScaleModel
    {
        public int? CatalystScaleID { get; set; }
        public string CatalystScale { get; set; }
        public string Description { get; set; }
        public string StatusName { get; set; } 
        public KeyValue StatusCode { get; set; }    

    }
    public class CatalystScaleSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalystScaleModel> _lstcatalystScales = new List<CatalystScaleModel>();
        public IList<CatalystScaleModel> LstcatalystScales { get { return _lstcatalystScales; } }

        public int RecordsFetched { get; set; }

    }
}
