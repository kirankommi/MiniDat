﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystSizeModel
    {
        public int? CatalystSizeID { get; set; }
        public string CatalystSizeName { get; set; }     
        public string StatusName { get; set; } 
        public KeyValue StatusCode { get; set; }    

    }
    public class CatalystSizeSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalystSizeModel> _lstcatalystSizes = new List<CatalystSizeModel>();
        public IList<CatalystSizeModel> LstcatalystSizes { get { return _lstcatalystSizes; } }

        public int RecordsFetched { get; set; }

    }
}
