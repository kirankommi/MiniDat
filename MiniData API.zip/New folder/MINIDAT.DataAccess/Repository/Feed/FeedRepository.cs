﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageDiluent.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Feed;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Feed
{
    public class FeedRepository : IFeedRepository
    {
        private IDatabase _db;
        public FeedRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };       

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public FeedSearchModel GetFeedData(FeedModel feed)
      {
            try
            {
                FeedSearchModel feedarr = new FeedSearchModel();
                if (feed == null)
                {
                    return feedarr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[md].[Search_Feed_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(feed.StatusName == "Select" ? null : feed.StatusName) ? (object)null : feed.StatusName);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    feedarr.Lstfeeds.Clear();                  
                    while (reader.Read())
                    {
                        FeedModel _feed = new FeedModel()
                        {
                            FeedID = Convert.ToInt32(reader["FEED_ID"]),    
                            Density = (reader["DENSITY_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["DENSITY_MSR"]),
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() }
                        };
                        feedarr.Lstfeeds.Add(_feed);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        feedarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    feedarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)feedarr.lstStatus).AddRange(statuses);                    
                    return feedarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteFeedData(FeedModel feed)
        {
            try
            {
                if (feed == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[md].[Delete_MINIS_Feed_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_feed_ID", string.IsNullOrEmpty(Convert.ToString(feed.FeedID)) ? (object)null : feed.FeedID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SaveFeedData(FeedModel _feed, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _feed == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[md].[Insert_Update_Feed_Information_Sp]");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_feed_Id", _feed.FeedID);            
                    parameters.Add("proc_vr_feed_nm", _feed.Name);
                    parameters.Add("proc_vr_Status_Nm", _feed.StatusName);
                    parameters.Add("proc_vr_density", _feed.Density);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(FeedModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(FeedModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<FeedModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(FeedModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
