﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IPITagRepository : ICRUDRepository<PITagModel>
    {
        PITagSearchModel GetPITagData(PITagModel PITag);
        string DeletePITagData(PITagModel PITag);
        void SavePITagData(PITagModel PITag, string userId);
        PITagSearchModel GetPlantsData(PlantModel Plant);

    }
}
