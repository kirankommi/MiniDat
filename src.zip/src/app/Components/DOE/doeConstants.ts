import { customColumn } from '../../Directives/columnManipulator';

export var columns: customColumn[] = [
  {
    name: "General Information",
    displayName: "General Information",
    isVisible: true,
    isFrozen: true,
    isStatic: true,
    childrens: [
      {
        name: "Plant #",
        displayName: "Plant #",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Run #",
        displayName: "Plant #",
        isVisible: true,
        isFrozen: true
      },

      {
        name: "Estimated / Actual Start Date ",
        displayName: "Estimated / Actual Start Date",
        isVisible: true,
        isFrozen: true
      },

      {
        name: "Estimated / Actual Complition Date",
        displayName: "Estimated / Actual Complition Date",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Status",
        displayName: "Status",
        isVisible: true,
        isFrozen: true
      }
    ]
  }
  , {
    name: "DOE Run #",
    displayName: "DOE Run #",
    isVisible: true,
    isStatic: true,
    isFrozen: true
  }
  , {
    name: "Requester_Specialist",
    displayName: "Specialist",
    isVisible: true,
    isStatic: true,
    isFrozen: true
  }
  , {
    name: "Network",
    displayName: "Network",
    isVisible: true,
    isStatic: true,
    isFrozen: true
  }, {
    name: "NIR Flag",
    displayName: "NIR Flag",
    isStatic: true,
    isVisible: true,
    isFrozen: true
  }
  , {
    name: "Catalyst Info",
    displayName: "Catalyst Info",
    isVisible: true,
    isFrozen: true,
    childrens: [
      {
        name: "Catalyst ID",
        displayName: "Catalyst ID",
        isVisible: true,
        isFrozen: true,
        isStatic: true
      },
      {
        name: "Catalyst Template Loading",
        displayName: "Catalyst Loading Template",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Catalyst Family",
        displayName: "Catalyst Family",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Leader_MPT_RES",
        displayName: "Catalyst Leader (MPT/RES)",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Analystical Status_Quality",
        displayName: "Analytical Status/ Quality",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Bulk Location",
        displayName: "Bulk Location",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Loading Submitted",
        displayName: "Loading Submitted",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Rx Loaded",
        displayName: "Rx Loaded",
        isVisible: true,
        isFrozen: true
      }
    ]
  }
  , {
    name: "Model Info",
    displayName: "Mode Info",
    isVisible: true,
    isFrozen: true,
    childrens: [{
      name: "Mode #",
      displayName: "Mode #",
      isVisible: true,
      isFrozen: true,
      isStatic: true
    }, {
      name: "Mode",
      displayName: "Mode",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Control",
      displayName: "Control",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Sulfiding",
      displayName: "Sulfiding",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Pressure",
      displayName: "Pressure",
      isVisible: true,
      isFrozen: true
    }, {
      name: "LHSV",
      displayName: "LHSV",
      isVisible: true,
      isFrozen: true
    }, {
      name: "SCFB",
      displayName: "H2/HC",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Condition",
      displayName: "Condition",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Temp_NET Conversion",
      displayName: "Temp/NET Conversion",
      isVisible: true,
      isFrozen: true
    }, {
      name: "SORT",
      displayName: "SORT",
      isVisible: true,
      isFrozen: true
    }
    ]
  }
  , {
    name: "Feed Info",
    displayName: "Feed Info",
    isVisible: true,
    isFrozen: true,
    childrens: [{
      name: "Feedstock Name",
      displayName: "Feedstock Name",
      isVisible: true,
      isFrozen: true,
      isStatic: true
    }
      , {
      name: "Flush Required",
      displayName: "Flush Required",
      isVisible: true,
      isFrozen: true
    }
    ]
  }
  , {
    name: "Action",
    displayName: "Action",
    isVisible: true,
    isFrozen: true,
    isStatic: true
  }
];

export var minisQcolumns: customColumn[] = [
  {
    name: "General Information",
    displayName: "General Information",
    isVisible: true,
    isFrozen: true,
    childrens: [
      {
        name: "ReOrder",
        displayName: "Order/Re-Order",
        isVisible: true,
        isFrozen: true,
        isStatic: true,
        colWidth: 30,
        style: "sticky",
        left: 0
      },
      {
        name: "Project",
        displayName: "Project Name",
        isVisible: true,
        isFrozen: true,
        isStatic: true,
        colWidth: 200,
        style: "sticky",
        left: 30
      },
      {
        name: "Study",
        displayName: "DOE (Study)",
        isVisible: true,
        isFrozen: true,
        colWidth: 150,
        style: "sticky",
        // left: 230

      },
      {
        name: "Plant #",
        displayName: "Plant #",
        isVisible: true,
        isFrozen: true,
        colWidth: 80,
        style: "sticky",
        // left: 380
      },
      {
        name: "Run #",
        displayName: "Run #",
        isVisible: true,
        isFrozen: true,
        colWidth: 120,
        style: "sticky",
        // left: 460
      },

      {
        name: "Estimated / Actual Start Date",
        displayName: "Estimated / Actual Start Date",
        isVisible: true,
        isFrozen: true,
        colWidth: 170,
        style: "sticky",
        // left: 580
      },

      {
        name: "Estimated / Actual Complition Date",
        displayName: "Estimated / Actual Complition Date",
        isVisible: true,
        isFrozen: true,
        colWidth: 170,
        style: "sticky",
        // left: 750
      },
      {
        name: "Status",
        displayName: "State",
        isVisible: true,
        isFrozen: true,
        colWidth: 150,
        style: "sticky",
        // left: 920
      }, {
        name: "Requestor",
        displayName: "Requestor",
        isVisible: true,
        isFrozen: true,
        style: "sticky",
        colWidth: 190
      }
      , {
        name: "Network",
        displayName: "Network #",
        isVisible: true,
        isFrozen: true,
        style: "sticky",
        colWidth: 100
      }, {
        name: "NIR Flag",
        displayName: "NIR Flag",
        isVisible: true,
        isFrozen: true,
        style: "sticky",
        colWidth: 80
      }
    ]
  }

  , {
    name: "Catalyst Info",
    displayName: "Catalyst Info",
    isVisible: true,
    isFrozen: true,
    childrens: [
      {
        name: "Catalyst ID",
        displayName: "Catalyst ID",
        isVisible: true,
        isFrozen: true,
        isStatic: true
      },
      {
        name: "Catalyst Template Loading",
        displayName: "Catalyst Loading Template",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Catalyst Family",
        displayName: "Catalyst Family",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Leader_MPT_RES",
        displayName: "Catalyst Leader (MPT/RES)",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Analystical Status_Quality",
        displayName: "Analytical Status/ Quality",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Bulk Location",
        displayName: "Bulk Location",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Loading Submitted",
        displayName: "Loading Submitted",
        isVisible: true,
        isFrozen: true
      },
      {
        name: "Rx Loaded",
        displayName: "Rx Loaded",
        isVisible: true,
        isFrozen: true
      }
    ]
  }
  , {
    name: "Model Info",
    displayName: "Mode Info",
    isVisible: true,
    isFrozen: true,
    childrens: [{
      name: "Mode #",
      displayName: "Mode #",
      isVisible: true,
      isFrozen: true,
      isStatic: true
    }, {
      name: "Mode",
      displayName: "Mode",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Control",
      displayName: "Control",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Sulfiding",
      displayName: "Sulfiding",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Pressure",
      displayName: "Pressure",
      isVisible: true,
      isFrozen: true
    }, {
      name: "LHSV",
      displayName: "LHSV",
      isVisible: true,
      isFrozen: true
    }, {
      name: "SCFB",
      displayName: "H2/HC",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Condition",
      displayName: "Condition",
      isVisible: true,
      isFrozen: true
    }, {
      name: "Temp_NET Conversion",
      displayName: "Temp/NET Conversion",
      isVisible: true,
      isFrozen: true
    }, {
      name: "SORT",
      displayName: "SORT",
      isVisible: true,
      isFrozen: true
    }
    ]
  }
  , {
    name: "Feed Info",
    displayName: "Feed Info",
    isVisible: true,
    isFrozen: true,
    childrens: [{
      name: "Feedstock Name",
      displayName: "Feedstock Name",
      isVisible: true,
      isFrozen: true,
      isStatic: true
    }
      , {
      name: "Flush Required",
      displayName: "Flush Required",
      isVisible: true,
      isFrozen: true
    }
    ]
  }
  , {
    name: "Action",
    displayName: "Action",
    isVisible: true,
    isFrozen: true,
    isStatic: true
  }
];
