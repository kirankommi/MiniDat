﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { NIRModelTemplateModel } from '../Models/NIRModelTemplateModel';
import * as Constants from '../Shared/globalconstants';
import { HttpActionService } from './httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class NIRModelTemplateService {
    private getNIRModelTemplatedata = "/NIRModelTemplate/GetNIRModelTemplatedata/";
    private saveNIRModelTemplatedata = "/NIRModelTemplate/SaveNIRModelTemplateData/";
    private searchNIRTemplatedata = "/NIRModelTemplate/SearchNIRModelTemplatedata/";
    private deleteNIRTemplatedata = "/NIRModelTemplate/DeleteNIRModelTemplatedata/"
    //private saveRoledata = "/Role/SaveRoledata/";
    //private deleteRoledata = "/Role/DeleteRoledata/";

    constructor(private httpaction: HttpActionService) { }

    //getNIRModelTemplatInformation(NIRModelTemplatesData: NIRModelTemplateModel) {
    //    debugger;
    //    let options = new RequestOptions(Constants.options)
    //    return this.httpaction.post(NIRModelTemplatesData, this.getNIRModelTemplatedata);
    //}
    deleteNIRModelTemplatInformation(nirTemplateModel: NIRModelTemplateModel) {
        debugger;
        return this.httpaction.post(nirTemplateModel, this.deleteNIRTemplatedata);
    }
    GetNIRModelTemplatInformation() {
        let params: URLSearchParams = new URLSearchParams();
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getNIRModelTemplatedata, options);
    }
    SaveNIRModelTemplatInformation(nirTemplateModel: NIRModelTemplateModel) {
        return this.httpaction.post(nirTemplateModel, this.saveNIRModelTemplatedata);
    }
    SearchNIRModelTemplatInformation(nirTemplateModel: NIRModelTemplateModel) {
        return this.httpaction.post(nirTemplateModel, this.searchNIRTemplatedata);
    }
    /*
    saveRoleData(roleData: RoleModel) {
        return this.httpaction.post(roleData, this.saveRoledata);
    }

    deleteRoleData(roleData: RoleModel) {
        return this.httpaction.post(roleData, this.deleteRoledata);
    }
    */
}
