﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Session
{
    public class FunctionUOMCategoryModel
    {
        public string ApplicationFunctionCode { get; set; }
        public string PageDescription { get; set; }
        public string UOMCategory { get; set; }
    }
}
