﻿using MINIDAT.Model;
using MINIDAT.Model.UOM;
using MINIDAT.Manage.UOMTemplate;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MINIDAT.Model.Catalyst;

namespace MINIDAT.Model.Session
{
    public sealed class UserSession
    {

        public UserSession()
        {

        }
        public static UserSession Instance
        {
            get
            {
                return HttpContext.Current.Session["Instance"] as UserSession;
            }
        }

        public UserModel User { get; set; }
        // public IList<UnitGroup> UnitGroups { get; set; }
        private IList<UnitGroup> _unitGroups = new List<UnitGroup>();
        public IList<UnitGroup> UnitGroups { get { return _unitGroups; } }


        private IList<string> _rules = new List<string>();
        public IList<string> Rules { get { return _rules; } }

        private IList<MenuModel> _menu = new List<MenuModel>();
        public IList<MenuModel> Menu { get { return _menu; } }


        private IList<FunctionUOMCategoryModel> _function_UOM = new List<FunctionUOMCategoryModel>();
        public IList<FunctionUOMCategoryModel> Function_UOMs { get { return _function_UOM; } }


        private IList<MenuModel> _privileges = new List<MenuModel>();
        public IList<MenuModel> Privileges { get { return _privileges; } }


        private IList<UomVariable> _uomVariables = new List<UomVariable>();
        public IList<UomVariable> UomVariables { get { return _uomVariables; } }

        public UomVariable GetVariableByName(string VariableName)
        {
            UomVariable variable = new UomVariable();
            if (this.UomVariables.Count(q => q.VariableName == VariableName) > 0)
            {
                variable = this.UomVariables.First(q => q.VariableName == VariableName);
            }
            return variable;
        }
        private IList<KeyValue> _applications = new List<KeyValue>();
        public IList<KeyValue> Applications { get { return _applications; } }

        private IList<Application> _availableApplications = new List<Application>();
        public IList<Application> AvailableApplications { get { return _availableApplications; } }

        private IList<KeyValue> _appRoles = new List<KeyValue>();
        public IList<KeyValue> AppRoles { get { return _appRoles; } }

        private IList<Validation> _limsValidations = new List<Validation>();
        public IList<Validation> LimsValidations { get { return _limsValidations; } }

        private IList<KeyValue> _uomAliases = new List<KeyValue>();
        public IList<KeyValue> UomAliases { get { return _uomAliases; } }

        public void SetUnitGroups(List<UnitGroup> unitgroups)
        {
            this._unitGroups = unitgroups;
        }

        /// <summary>
        /// Gets the name of the group by.
        /// </summary>
        /// <param name="groupName">Name of the group.</param>
        /// <returns></returns>
        public  UnitGroup GetGroupByName(string groupName)
        {
            UnitGroup group = null;

            if (UnitGroups!=null && UnitGroups.Count>0)
            {
                //get the Unit group by querying the cache group data
                group = (from c in UnitGroups where c.UnitGroupName == groupName select c).FirstOrDefault();
            }
            return group;
        }


        /// <summary>
        /// Gets the group by code.
        /// </summary>
        /// <param name="groupCode">The group code.</param>
        /// <returns></returns>
        public UnitGroup GetGroupByCode(string groupCode)
        {
            UnitGroup group = null;

            if (UnitGroups != null && UnitGroups.Count > 0)
            {
                //get the Unit group by querying the cache group data
                group = (from c in UnitGroups where c.UnitGroupCD == groupCode select c).FirstOrDefault();
            }
            return group;
        }


    }
}
