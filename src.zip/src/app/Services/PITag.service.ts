﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { PITagInfoModel, KeyValue,PlantFlyoutModel } from '../Models/PITagInfoModel';
import * as Constants from '../Shared/globalconstants';
import { HttpActionService } from './httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PITagService {
    private getPITagdata = "/PITag/SearchPITagdata/";
    private savePITagdata = "/PITag/SavePITagdata/";
    private deletePITagdata = "/PITag/DeletePITagdata/";
    private getPlantsList = "/PITag/GetPlantsList/"

    constructor(private httpaction: HttpActionService) { }

    getPITags(piTagData: PITagInfoModel) {

        debugger;      
        let options = new RequestOptions(Constants.options)
        //return this.httpaction.get(this.getPITagdata, options);
        return this.httpaction.post(piTagData,this.getPITagdata);
    }

    savePITagData(piTagData: PITagInfoModel)
    {
        return this.httpaction.post(piTagData, this.savePITagdata);
    }

    deletePITagData(piTagData: PITagInfoModel)
    {
        debugger;
        return this.httpaction.post(piTagData, this.deletePITagdata);
    }
    getPlantList(plant: PlantFlyoutModel)
    {
        debugger;
        return this.httpaction.post(plant, this.getPlantsList);
    }
}
