import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as Constants from '../../../../Shared/globalconstants';
@Component({
  selector: 'app-mode-template',
  templateUrl: './mode-template.component.html'
})
export class ModeTemplateComponent implements OnInit {
searchBy: string = 'Reciepes';
title : string ="";
sub: any;
id:any;
goBackIconPath : string;
  constructor(private route: ActivatedRoute) {
    this.goBackIconPath= Constants.goBackIconPath;
  }
  


    ngOnInit() {
      this.sub = this.route.params.subscribe(params => {
        this.id = params['field'];
        });
        this.title = "Mode " + this.id +" Details";
    }
    changeTabSelection(selectedtab) {
      this.searchBy = selectedtab;
      // this.appService.setUserTabSelectionInViewSearchFeedPage(selectedtab);
  }
  getIconPath()
  {
    return this.goBackIconPath;    
  }

}
