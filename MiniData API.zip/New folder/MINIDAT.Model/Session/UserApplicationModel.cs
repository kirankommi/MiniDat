﻿using MINIDAT.Manage.UOMTemplate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Session
{
  public  class UserApplicationModel
    {
        public string EID { get; set; }
        private IList<UserModel> _users = new List<UserModel>();
        public IList<UserModel> Users { get { return _users; } }


        private IList<KeyValue> _userApplicationRoles = new List<KeyValue>();
        public IList<KeyValue> UserApplicationRoles { get { return _userApplicationRoles; } }

        private IList<Application> _availableApplications = new List<Application>();
        public IList<Application> AvailableApplications { get { return _availableApplications; } }

        private IList<KeyValue> _applicationModels = new List<KeyValue>();
        public IList<KeyValue> ApplicationModels { get { return _applicationModels; } }

        private IList<KeyValue> _unitAliases = new List<KeyValue>();
        public IList<KeyValue> UnitAliases { get { return _unitAliases; } }

    }
}
