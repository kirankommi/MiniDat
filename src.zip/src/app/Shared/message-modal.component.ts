import { Component } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    //moduleId: module.id,
    selector: 'message-modal',
    templateUrl: 'message-modal.template.html'
})

export class messageModalComponent {
    constructor(public activeModal: NgbActiveModal) { }

    public title: string;
    public description: string;
    public type: string;
}
