import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { SideMenuDirective } from './side-menu';
import { HeaderDirective } from './header';
import { BodyDirective } from './body';
import { FooterDirective } from './footer';
import { PieChartDirective } from './pieChart';
import { ContainerDirective } from './container';
import { AccordionDirective } from './accordion';
import { CalendarDirective } from './calendar';
import { FlyOutDirective } from './flyout';
import { InputFlyoutComponent } from './inputflyout.component';
import { PerformanceTileDirective } from './performanceTile.directive';
import { LDAPFlyOutDirective } from './ldapflyout';
import { InputLDAPFlyoutComponent } from './inputldapflyout.component';
import { UomControl } from './uomcontrol.component';
import { uomCtrlComponent } from './uomCtrl.component';
import { uomInputComponent } from './uomInputBox.component';
import { unitSelectorDirective } from './unitSelector.directive';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { MenubarModule, DataTableModule, SharedModule, TreeTableModule, ChartModule, TooltipModule, CalendarModule, SplitButtonModule } from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ListboxModule } from 'primeng/listbox';
import { MultiSelectModule } from 'primeng/multiselect';
import { FieldsetModule } from 'primeng/fieldset';
import { ToastModule } from 'primeng/toast';
import { ChipsModule, Chips } from 'primeng/chips';
import { CardModule } from 'primeng/card';
import { DialogModule } from 'primeng/dialog';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DropdownModule } from 'primeng/dropdown';
import { DragDropModule } from 'primeng/dragdrop';
import { convertToDisplayPipe } from '../Pipes/convertToDisplay.pipe';
import { concatStringsPipe } from '../Pipes/concatStrings.pipe';
import { UniqueFilterPipe } from '../Pipes/filterUnique.pipe';
import { fileBrowserComponent } from './filebrowse/filebrowse.component';
import { bulkUploadComponent } from '../Directives/bulkupload/bulkupload.component';
import { RunAccordionDirective } from './accordion - Run';
import { InputFlyoutListComponent } from './inputflyoutlist.component';
import {InputFlyoutDisableComponent} from './inputflyoutDisable.component';
import {RadioButtonModule} from 'primeng/radiobutton';


@NgModule({
  imports: [
    BsDatepickerModule.forRoot(),
    CommonModule,
    RouterModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    DataTableModule,
    RadioButtonModule,
    OverlayPanelModule,
    ListboxModule,
    MultiSelectModule,
    FieldsetModule, ChipsModule, CardModule, DragDropModule, MenubarModule, TooltipModule, ToastModule, SharedModule, TreeTableModule, ChartModule, CalendarModule, SplitButtonModule, TableModule, InputSwitchModule, DropdownModule, DialogModule],
  declarations: [
    SideMenuDirective,
    HeaderDirective,
    BodyDirective,
    FooterDirective,
    PieChartDirective,
    PerformanceTileDirective,
    ContainerDirective,
    AccordionDirective,
    RunAccordionDirective,
    CalendarDirective,
    FlyOutDirective,
    LDAPFlyOutDirective,
    InputFlyoutComponent, InputFlyoutListComponent,InputFlyoutDisableComponent,
    InputLDAPFlyoutComponent,
    UomControl,
    uomCtrlComponent,
    uomInputComponent,
    unitSelectorDirective,
    convertToDisplayPipe,
    UniqueFilterPipe,
    concatStringsPipe,
    fileBrowserComponent,
    bulkUploadComponent,
  ],
  exports: [
    BsDatepickerModule,
    CommonModule,
    RouterModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    DataTableModule,
    RadioButtonModule,
    OverlayPanelModule,
    ListboxModule,
    MultiSelectModule,
    FieldsetModule, ChipsModule, CardModule, DragDropModule, MenubarModule, TooltipModule, ToastModule, SharedModule, TreeTableModule, ChartModule, CalendarModule, SplitButtonModule, TableModule, InputSwitchModule, DropdownModule, DialogModule,
    SideMenuDirective,
    HeaderDirective,
    BodyDirective,
    FooterDirective,
    PieChartDirective,
    PerformanceTileDirective,
    ContainerDirective,
    AccordionDirective,
    RunAccordionDirective,
    CalendarDirective,
    FlyOutDirective,
    LDAPFlyOutDirective,
    InputFlyoutComponent, InputFlyoutListComponent,InputFlyoutDisableComponent,
    bulkUploadComponent,
    InputLDAPFlyoutComponent,
    UomControl,
    uomCtrlComponent,
    uomInputComponent,
    unitSelectorDirective,
    convertToDisplayPipe,
    UniqueFilterPipe,
    concatStringsPipe,
    fileBrowserComponent,
    bulkUploadComponent]
})
export class sharedModule {
  constructor() {

    Chips.prototype.onClick = function (event) {

    }
    //console.log(Chips.prototype.onClick);

  }
}
