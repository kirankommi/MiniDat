﻿export class CatalystScaleModel {
    CatalystScaleID: number;
    CatalystScale: string;  
    StatusName: string;
    Description: string; 
    StatusCode: KeyValue;  
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
