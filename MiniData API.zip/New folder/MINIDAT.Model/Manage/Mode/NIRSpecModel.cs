﻿using MINIDAT.Model.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Manage.Mode
{
    public class NIRSpecModel : INIRProcessModel
    {
        public string ParameterName
        {
            get; set;
        }

        public double? ParameterValue
        {
            get; set;
        }
        //public string ParameterUOM
        //{
        //    get; set;
        //}

        public string DefaultUnit
        {
            get; set;
        }
    }
}
