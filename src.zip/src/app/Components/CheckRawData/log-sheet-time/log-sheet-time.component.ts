import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LogSheetPeriodReadingModel, PeriodReadingModel, LogSheetKeyModel } from '../../../Models/TestCreation/LogSheet.model';
import { LogSheetService } from '../../../Services/TestCreation/LogSheet.service';
import { AlertMessage } from '../../../services/alertmessage.service';
import * as Constants from '../../../Shared/globalconstants';

@Component({
  selector: 'app-log-sheet-time',
  templateUrl: './log-sheet-time.component.html',
  styleUrls: ['./log-sheet-time.component.css'],
  providers: [NgbModal, LogSheetService, AlertMessage],
})
export class LogSheetTimeComponent implements OnInit {
  LogSheet = [];
  ValidationArr = [];
  cols: any[] = [];
  allVariablesArr = [];
  addedTime: Date;
  @Input() PlantCd: string;
  @Input() RunId: string;
  @Input() TestId: string;
  @Input() TestEndTime: string;
  @Input() TestStartTime: string;
  oldValue: number = 0;
  allVarChecked:boolean = false;
  LogSheetPeriodReading: LogSheetPeriodReadingModel[] = [];
  periodReading: PeriodReadingModel = new PeriodReadingModel();
  readingSaved: string = "Log Sheet Period Reading Saved Successfully";
  logSheetSaved: string = "Log Sheet Time Saved Successfully";
  constants: any = {};
  ExportSuccess:string = "Exported Data successfully";
  AddTimeSuccess:string = "Added Time successfully";
  loading: boolean;
  frozenCols: any[] = [];
  scrollableCols: any[] = [];
  totalRecordsFetched: number = 0;
  LogSheetKeyModel: LogSheetKeyModel = new LogSheetKeyModel();

  constructor(private logSheetService: LogSheetService, private alertMessage: AlertMessage, private modalService: NgbModal) {
    this.constants = Constants;
  }

  ngOnInit() {
    this.periodReading.PlantCd = this.PlantCd;
    this.periodReading.RunId = Number(this.RunId);
    this.periodReading.TestId = Number(this.TestId);
    this.periodReading.TestStartTime = this.TestStartTime;
    this.periodReading.TestEndTime = this.TestEndTime;
    this.getLogSheet();
  }

  ngAfterViewInit() {
      const frozenBodyStyle = document.querySelector(".ui-table-frozen-view > .ui-table-scrollable-body")["style"];
      if (frozenBodyStyle["marginBottom"] !== "unset") {
          frozenBodyStyle["paddingBottom"] = frozenBodyStyle["marginBottom"];
          frozenBodyStyle["marginBottom"] = "unset";
      }
  }

  getLogSheet(){
    this.logSheetService.GetLogSheetDetails(this.periodReading).subscribe(
      (data: any) => {
        this.LogSheet = data.LogSheet;
        this.ValidationArr = data.Validation;
        this.allVariablesArr = data.AllVariables;
        this.totalRecordsFetched = data.LogSheet.length;

        for (var j = 0; j < this.allVariablesArr.length; j++) {
          for (var i = 0; i < this.LogSheet.length; i++) {
              if (this.LogSheet[i]["Log Reading Label"] == this.allVariablesArr[j]["Log Reading Label"])
                this.LogSheet.splice(i, 1);
          }
        }

        this.LogSheet.sort((a, b) => (parseInt(a.LabelOrder != null ? a.LabelOrder : 0) > parseInt(b.LabelOrder != null ? b.LabelOrder : 0)) ? 1 : -1);

        this.frozenCols = [];
        this.scrollableCols = [];
        Object.keys(this.LogSheet[0]).forEach(item => {
          if(item == 'Log Reading Label' || item == 'PI Tag Name' || item == 'UOM'){
            this.frozenCols.push({ field: item, header: item , display: 'table-cell'});
          }
          else if (item == 'LabelOrder' || item == 'UnitOrder'){
            this.frozenCols.push({ field: item, header: item , display: 'none'});
          }
          else{
            this.scrollableCols.push({ field: item, header: item , display: 'table-cell'});
          }
        })
      },
      err => { }
    );
  }

  AddTime() {
    let TestStartTime = new Date(localStorage.getItem('TestStartTime'));
    let TestEndTime = new Date(localStorage.getItem('TestEndTime'));
    let addTime = new Date(this.addedTime);

    if(TestStartTime > addTime) {
      this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Reading Time is not valid" })
    }
    else if(addTime > TestEndTime) {
      this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Reading Time is not valid" })
    }
    else {
      this.LogSheetKeyModel.PlantCd = this.PlantCd;
      this.LogSheetKeyModel.ReadingTime = this.addedTime;

      this.logSheetService.GetLogSheetKey(this.LogSheetKeyModel).subscribe(
        (data: any) => {
            if (data == Constants.Success) {
              this.ResetLogSheet();
              this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.AddTimeSuccess });
            }
            if(data == "DuplicateLogsheetKey") {
              this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Reading Time already exists" })
            }
        },
        err => {
          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
        }
      );
    }
  }


  SaveLogSheet() {
    this.cols;
    this.LogSheet;
    let logSheetCols: any = Object.keys(this.LogSheet[0]);
    let logSheet: any = [];
    logSheetCols.forEach(colName => {
      if (!isNaN(Date.parse(colName))) {
        // let currentCol = this.LogSheet.filter(x => x[colName]);
        let Reading: any = [];
        this.LogSheet.forEach(element => {
          let Common: any;
          if (element["Log Reading Label"] != "Log Sheet Key" && element["Log Reading Label"] != "Validation") {
            Reading.push({ "LogReadingLabel": element["Log Reading Label"], "LabelOrder": element["LabelOrder"], "PiTagName": element["PI Tag Name"], "Value": element[colName] });
          }
        });
        logSheet.push({ "LogsheetKey": this.LogSheet[0][colName], "Validation": this.LogSheet[1][colName], "ReadingTime": colName, Reading });
      }
    });
    
    this.logSheetService.SaveLogSheet(logSheet, this.periodReading.PlantCd)
      .subscribe(
        (data: any) => {
          if (data == Constants.Success) {
            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.logSheetSaved });
          }
        },
        err => { }
      );
  }

  ResetLogSheet(){
    this.getLogSheet();
  }

  onlogSheetPeriodReading(content) {
    this.logSheetService.GetLogSheetPeriodReadingDetails(this.periodReading).subscribe(
      (data: any) => {
        this.LogSheetPeriodReading = data;
        this.modalService.open(content, {
          centered: true, backdrop: true, windowClass: "custom-Modal"
        });
      },
      err => {
        this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      }
    );
  }

  SavePeriodReading() {
    this.periodReading.PeriodReadingList = this.LogSheetPeriodReading;
    this.logSheetService.SavePeriodReading(this.periodReading)
      .subscribe(
        (data: any) => {
          if (data == Constants.Success) {
            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.readingSaved });
          }
        },
        err => { }
      );
  }

  ResetPeriodReading() {
    this.loading = true;
    this.logSheetService.GetLogSheetPeriodReadingDetails(this.periodReading).subscribe(
      (data: any) => {
        this.LogSheetPeriodReading = data;
        this.loading = false;
      },
      err => {
        this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
        this.loading = false;
      }
    );
  }
  captureOldValue(event) {
    this.oldValue = Number(event.target.value);
  }



  updateValue(event: any, value: any, rowId: any, unit: any, index: any, readingType: any, Souce: any)
  {
    let currentvalue = Number(event.target.value);
    let updatedValue: any;
    if (this.oldValue != currentvalue) {
        if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5")
        {
            switch (Souce)
            {
                case 'Average':
                    this.LogSheetPeriodReading[index].AverageReadingValueMsr = unit.Slope / (currentvalue + unit.Intercept);
                    break;
                case 'Initial':
                    this.LogSheetPeriodReading[index].InitialReadingValueMsr = unit.Slope / (currentvalue + unit.Intercept);
                    break;
                case 'Final':
                    this.LogSheetPeriodReading[index].FinalReadingValueMsr = unit.Slope / (currentvalue + unit.Intercept);
                    break;
                default:
                    break;
            }        
       }
        else
       {
            switch (Souce)
            {
                case 'Average':
                    this.LogSheetPeriodReading[index].AverageReadingValueMsr = currentvalue * unit.Slope + unit.Intercept;
                    break;
                case 'Initial':
                    this.LogSheetPeriodReading[index].InitialReadingValueMsr = currentvalue * unit.Slope + unit.Intercept;
                    break;
                case 'Final':
                    this.LogSheetPeriodReading[index].FinalReadingValueMsr = currentvalue * unit.Slope + unit.Intercept;
                    break;
                default:
                    break;
            }
       }
    }
    //return updatedValue;
  }
  updateTimeReadingValue(event: any, value: any, unit: any, index: any, col: any)
  {
      debugger;
      let currentvalue = Number(event.target.value);
      let updatedValue: any;
      if (this.oldValue != currentvalue)
      {
          if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5")
          { 
              this.LogSheet[index][col] = unit.Slope / (currentvalue + unit.Intercept);         
          }
          else
          { 
              this.LogSheet[index][col] = currentvalue * unit.Slope + unit.Intercept;
          }
      }     
  }

  addAllVariables(e){
    this.allVarChecked;
    if (e.checked) {
      this.allVariablesArr.forEach((element: any) => {
        this.LogSheet.push(element);
      });

      this.cols = [];
      this.frozenCols = [];
      this.scrollableCols = [];
      Object.keys(this.LogSheet[0]).forEach(item => {
        if(item == 'Log Reading Label' || item == 'PI Tag Name' || item == 'UOM'){
          this.frozenCols.push({ field: item, header: item , display: 'table-cell'});
        }
        else if (item == 'LabelOrder' || item == 'UnitOrder'){
          this.frozenCols.push({ field: item, header: item , display: 'none'});
        }
        else{
          this.scrollableCols.push({ field: item, header: item , display: 'table-cell'});
        }
      })
    }
    else {
      for (var j = 0; j < this.allVariablesArr.length; j++) {
        for (var i = 0; i < this.LogSheet.length; i++) {
            if (this.LogSheet[i]["Log Reading Label"] == this.allVariablesArr[j]["Log Reading Label"])
            this.LogSheet.splice(i, 1);
        }
      }

      this.cols = [];
      this.frozenCols = [];
      this.scrollableCols = [];
      Object.keys(this.LogSheet[0]).forEach(item => {
        if(item == 'Log Reading Label' || item == 'PI Tag Name' || item == 'UOM'){
          this.frozenCols.push({ field: item, header: item , display: 'table-cell'});
        }
        else if (item == 'LabelOrder' || item == 'UnitOrder'){
          this.frozenCols.push({ field: item, header: item , display: 'none'});
        }
        else{
          this.scrollableCols.push({ field: item, header: item , display: 'table-cell'});
        }
      })
    }
  }
  ExportlogsheetPeriodReading(){
    this.logSheetService.GetExportDataLogSheetPeriodReading(this.periodReading)
    .subscribe(
    (data: any) => {
        if (data != null) 
        {
          let DocumentName =  "P"+this.periodReading.PlantCd + "_R" + this.periodReading.RunId + "_T" + this.periodReading.TestId + ".xlsx";
          var byteCharacters = atob(data);
          var byteNumbers = new Array(byteCharacters.length);
          for (var i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          var byteArray = new Uint8Array(byteNumbers);
          var blob = new Blob([byteArray], { type: "" });
          var ua = window.navigator.userAgent;
          var msie = ua.indexOf("MSIE ");
          var chrome = ua.indexOf("Chrome");

          if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
              window.navigator.msSaveOrOpenBlob(blob, DocumentName);
          }
          else {
            var objectUrl = URL.createObjectURL(blob);
            var link = document.createElement("A");
            link.setAttribute("href", objectUrl);
            link.setAttribute("download", DocumentName);
            link.setAttribute("target", "_blank");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.ExportSuccess });
        }
        else {
          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Results are missing for the selected analysis." });
        }
    },
    // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
    );
  }
  ExportDataLogSheetTimeReading(){
    this.logSheetService.GetExportDataLogSheetTimeReading(this.periodReading)
          .subscribe(
          (data: any) => {
              if (data != null) 
              {
                let DocumentName =  "P"+this.periodReading.PlantCd + "_R" + this.periodReading.RunId + "_T" + this.periodReading.TestId + ".xlsx";
                var byteCharacters = atob(data);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                var blob = new Blob([byteArray], { type: "" });
                var ua = window.navigator.userAgent;
                var msie = ua.indexOf("MSIE ");
                var chrome = ua.indexOf("Chrome");

                if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                    window.navigator.msSaveOrOpenBlob(blob, DocumentName);
                }
                else {
                  var objectUrl = URL.createObjectURL(blob);
                  var link = document.createElement("A");
                  link.setAttribute("href", objectUrl);
                  link.setAttribute("download", DocumentName);
                  link.setAttribute("target", "_blank");
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
              }
              this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.ExportSuccess });
              }
              else {
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Results are missing for the selected analysis." });
              }
          },
          // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
          );
  }

}
