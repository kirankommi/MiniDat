﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Manage.LIMSAnalysisMethod;
//using MINIDAT.Model.ASearch;

namespace MINIDAT.DataAccess.Interfaces
{
   public interface IAnalysisMethodRepository:ICRUDRepository<LIMSAnalysisMethodModel>
    {
        LIMSAnalysisMethodSearchModel GetMethodData(LIMSAnalysisMethodModel method);
        // string DeleteRoleData(RoleModel Role);
        bool SaveMethodData(LIMSAnalysisMethodModel method, string userId);

       // IList<AnalysisMethodGetAllBySourceResult> GetAllBySource(string feedIds, string source);
        IList<SourceName> GetLimsSources();
        bool CheckIsOperationExists(string name);
    }
}
