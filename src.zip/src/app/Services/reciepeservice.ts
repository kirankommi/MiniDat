import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { HttpActionService } from "./httpaction.service";
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ReciepeService {
    debugger;
    private getReciepedata = "/Reciepe/GetReciepesData/";
    constructor(private httpaction: HttpActionService) { }
    getReciepeInformation(templateId: any) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateId', templateId);     
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getReciepedata, options);
    }

}