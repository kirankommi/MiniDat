﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { FeedService } from '../../../Services/FeedServices/Feed.service';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, FeedModel } from '../../../models/Run/RunModel';
//import { FeedModel } from '../../../models/Run/FeedModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';
import { RunDataService } from "../run.data.service";
import { ActivatedRoute } from '@angular/router';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component(
    {  
        templateUrl: 'RunFeed.component.html',
        selector: "runfeed",
        providers: [FeedService,RunService, AlertMessage, HttpActionService, ConfirmationService]
})

export class RunFeedComponent implements OnInit 
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean;
    totalRecords: number;
    // run1: RunModel;  
    run: RunSetupModel;  
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;     
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number; 
    lstFeedIDs: any = [];
    lstFeeds: any;
    lstParentFeeds: any;
    lstBledDopants: any;
    lstAnalysisMethods: any;
    blendList: any;
    blendTotalWeight: number;
    blendweightpct: number;
    weightedNitrogenAmt: number;
    weightedSufurAmt: number;
    parentFeedsWeight: number;   
    feedstockLink: string;   
    IsInVisible: boolean = false;
    runSaved: string = "Run Feed Details Saved Successfully";

    constructor(private feedService: FeedService, private route: ActivatedRoute, private runService: RunService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService, public runDataService: RunDataService, private runComponent: RunComponent)
    {
               
    }

    ngOnInit()
    {
        debugger;       
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);
        if (this.run.FeedInfo.FeedID == null)
        {
            this.IsInVisible = true;
        }
        
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "4", Value: "Feed", Groupcd: 0 });      
    }

    
    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }     

   


    
    
}
