﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
    public class WCExport
    {
        public string Parameter { get; set; }
        public string UOM { get; set; }
        public string Value { get; set; }
    }
    public class WCExportPopup
    {
        public List<WCExport> PlantCalculations { get; set; }
        public List<WCExport> NormalizedGasYields { get; set; }
        public List<WCExport> GasVolumes { get; set; }

        public List<WCExport> GasWeights { get; set; }
        public List<WCExport> WeightRecovery { get; set; }
        public List<WCExport> LiquidWeights_LP690 { get; set; }
        public List<WCExport> LiquidWeights_percent { get; set; }
        public List<WCExport> LiquidWeights_Simdist { get; set; }
        public List<WCExport> NormalizedLiquidWeights { get; set; }
        public List<WCExport> RawProductWeights { get; set; }
        public List<WCExport> RawProductWeights_percent { get; set; }

        public List<WCExport> MBAdjustedProductWt_percent { get; set; }
        public List<WCExport> DopantAdjustments { get; set; }
        public List<WCExport> DAMassBalanceProductWt_perscent { get; set; }
        public List<WCExport> ProductRatios { get; set; }
        public List<WCExport> FeedWeights { get; set; }
        public List<WCExport> FeedWeightsPercent { get; set; }
        public List<WCExport> ConversionCalculation { get; set; }
        public List<WCExport> QualitCalculation { get; set; }
        public List<WCExport> H2LPProductProperties { get; set; }
        public List<WCExport> H2ByNMR { get; set; }
        public List<WCExport> H2ByNIR { get; set; }

    }
}
