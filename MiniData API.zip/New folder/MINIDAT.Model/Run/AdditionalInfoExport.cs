﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class AdditionalInfoExport
    {
        public string SelectedNormalizationFactor { get; set; }
        public double? OffgasHeaviesWeight { get; set; }
        public string OffgasHeaviesWeight_UOM { get; set; }
        public double? H2TMFSpec { get; set; }
        public string H2TMFSpec_UOM { get; set; }
        public string SelectedFeedSource { get; set; }
        public double? PlantTCOffset { get; set; }
        public string PlantTCOffset_UOM { get; set; }
        public double? HPSControllerOffset { get; set; }
        public string HPSControllerOffset_UOM { get; set; }
    }
}
