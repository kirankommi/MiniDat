import { Headers } from '@angular/http';
import { debug } from 'util';

//user Constants
export var IsLoading = false;
export var IsTopLoad = false;
export var Msgs: any[] = [];

//Variables
export var Undefined: any = undefined;
export var UserSessionData: any = [];
export var UserPrivileges: any = [];
export var UnitGroups: any = [];
export var UomVariables: any = [];
export var Applications: any = [];
export var AppRoles: any = [];
export var FunctionUoms: any = [];
export var Select = "Select";
export var IsUnauthorizedAccess = false;
//Conflict Path
export var imgBasePath = "assets/"
//export var apiBaseUrl = "http://ie3bvwitss320/MiniDATAPI/api";
export var apiBaseUrl = "http://localhost:60776/api";
export var environment = "ST"
//export var feedstockBaseUrl = "http://ie3bvwitss320/FDMS_ST_API/api"
//export var feedstockBaseUrl = "http://localhost:60800/api"
export var feedstockBaseUrl = "http://ie3bvwitss320/FDMS_ST_API/api"



//export var iisImgBasePath = "./";
//export var iiSapiBaseUrl = "http://ie3bvwsvpc523:8085/api";
//export var iisenvironment = "ST"

//Merge path
//imgBasePath = iisImgBasePath;
//apiBaseUrl = iiSapiBaseUrl;
//environment = iisenvironment;

export var ManageUser = "Manage - User";
export var ManageRole = "Manage - Role";
export var ManagePITag = "Manage - PI Tag";
export var ManageUOMTemplate = "Manage - UOM Template";
export var ManageUOMVariables = "Manage UOM Variables";
export var ManageAnalysisMethod = "Manage LIMS Analysis Method";
export var ManageLimsComponent = "Manage - LIMS Component";
export var ManageNIRModelTemplate = "Create or Find NIR Template"
export var deleteIconPath = imgBasePath + "Images/Delete-Icon.png";
export var cloneIconPath = imgBasePath + "Images/copy.svg";
export var goBackIconPath = imgBasePath + "Images/back.svg";
export var copyIconPath = imgBasePath + "Images/copy.png";
export var pasteIconPath = imgBasePath + "Images/paste.png";
export var editIconPath = imgBasePath + "Images/edit.svg";
export var disabledDeleteIconPath = imgBasePath + "Images/Delete-Icon-Grey.png";
export var addIcon = imgBasePath + "Images/Add_icon.svg";
export var detailsIconEn = imgBasePath + "Images/Details_icon_hover.svg";
export var detailsIconDis = imgBasePath + "Images/Details_icon.svg";
export var deleteIconEn = imgBasePath + "Images/Delete_icon_hover.svg";
export var deleteIconDis = imgBasePath + "Images/Delete_icon.svg";
export var uploadIcon = imgBasePath + "Images/Attach_Icon_hover.svg";
export var uploadIcon_black = imgBasePath + "Images/upload_black.png";
export var downloadIcon = imgBasePath + "Images/download-icon.svg";
export var settingsIcon = imgBasePath + "Images/Settings_icon_selected.svg";
export var collapseIcon = imgBasePath + "Images/DOE_columnCollapse.svg";
export var threeDotIcon=imgBasePath+'Images/three Dots.svg';
export var reOrderIcon=imgBasePath+'Images/drag.svg';
export var filterIcon=imgBasePath+'Images/filter.svg';
export var refreshIcon=imgBasePath+'Images/refresh.svg';
export var copyIcon=imgBasePath+'Images/copy_b.svg';
export var plusIcon = imgBasePath + 'Images/add.svg';
export var printIcon=imgBasePath+'Images/print.svg';
export var exportIcon=imgBasePath+'Images/export.svg';
//export var timePicker = imgBasePath + 'Images/timePicker.png';
export var dropdownIcon=imgBasePath+'Images/Drop_down_icon_hover.svg';
export var expandIcon = imgBasePath + "Images/DOE_columnExpand.svg";
export var dropDownexpandIcon = imgBasePath + "Images/DOE_dropdown.svg";
export var minusIcon = imgBasePath + "Images/minusIcon.png";
export var cancelIcon = imgBasePath + "Images/cross.svg";
export var ManageMode = "Manage - Mode";
export var ManageCatalystFamily = "CREATE OR FIND CATALYST FAMILY";
export var ManageDiluent = "CREATE OR FIND DILUENT";
export var ManageFeed = "CREATE OR FIND FEED";
export var CatalystLoadingTemplate = "CREATE OR FIND CATALYST LOADING TEMPLATE";
export var ManageCatalystType = "CREATE OR FIND CATALYST TYPE";
export var ManageCatalystSize = "CREATE OR FIND CATALYST SIZE";
export var ManageCatalystAliasSS = "CREATE OR FIND CATALYST ALIAS SS";
export var ManageCatalystScale = "CREATE OR FIND CATALYST SCALE";
export var ManageCatalystState = "CREATE OR FIND CATALYST STATE";
export var ManageCatalystShape = "CREATE OR FIND CATALYST SHAPE";
export var TestCreation = "CREATE OR FIND TEST";


//Message Modal Constants
export var Success = "Success";
export var Warning = "Warning";
export var Error = "Error";
export var severitySuccess = "success";
export var severityInfo = "info";
export var severityWarn = "warn";
export var severityError = "error";
export var Confirm = "Confirm";
export var ConfirmISCOHITC = "Selected Feed doesn't have Density at ISCO Op Temperature. Do you want to select this feed for ITC plant?";
export var ConfirmISCOUS = "Selected Feed has Density at ISCO Op Temperature. Do you want to select this feed for RIV plant?";

export var ConfirmCloneMsg = "Are you sure to clone?";
export var ConfirmMsg = "Are you sure to delete?";
export var RequiredMsg = "Please fill in all the required fields";
export var ExceedingBedLentgh = "The calculated bed length of the catalyst and diluent exceeds 32.5 inch, please confer with the Minis Technician to ensure loading is practical";
export var SearchMsg = "Please enter atleast 1 field";
export var ConfirmTrue = "true";
export var RadioBoxCheckRequired = "Atleast one radio button should be checked";
export var CommercialNameRequired = "Please fill In Commercial Name Information";
export var ProgramNameRequired = "Please fill In Program Name Information";

//Http Constants
export var options = { withCredentials: true, headers: new Headers({ 'Content-Type': 'application/json' }) };
//export var options = {headers: new Headers({ 'Content-Type': 'application/json' }) };
export var servermove = "";//"QA"; //"PROD";//"";
export var yeraRange: string = "1900:" + new Date().getFullYear().toString();

export var AppSession: any = {};
export var AppVersion: string;

export var UOMCATVariables: any = {};

export function SetLoading(data: boolean) {
  IsLoading = data;
}

export function SetUOMS(category: string, variables: any) {
  UOMCATVariables[category] = variables;
}

export function ClearMsgs() {
  Msgs = [];
}

export function SetSession(jsondata: any) {
  AppSession = jsondata;
}

export function SetAppVersion(jsondata: any) {
  AppVersion = jsondata;
}

export function getParamOptions(params: any) {
  return { withCredentials: true, headers: this.headers, search: params };
}

export function SetUserSession(jsondata: any) {
  UserSessionData = jsondata;
}

export function SetUserPrivileges(jsondata: any) {
  UserPrivileges = jsondata;
}

export function SetUnitGroups(jsondata: any) {
  UnitGroups = jsondata;
}

export function SetUomVariables(jsondata: any) {
  UomVariables = jsondata;
}

export function SetApplications(jsondata: any) {
  Applications = jsondata;
}

export function SetAppRoles(jsondata: any) {
  AppRoles = jsondata;
}

export function SetFunctionUOMs(jsondata: any) {
  FunctionUoms = jsondata;
}

export class Const {
  public Msgs: any[] = [];
}


// Success message for Components
export var PhysicalPropertySaveSuccess = "Physical Properties Saved Successfully";
export var ExportSuccess = "Exported Data successfully"