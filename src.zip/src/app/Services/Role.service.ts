﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { RoleModel } from '../Models/RoleModel';
import * as Constants from '../Shared/globalconstants';
import { HttpActionService } from './httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class RoleService {
    private getRoledata = "/Role/SearchRoledata/";
    private saveRoledata = "/Role/SaveRoledata/";
    private deleteRoledata = "/Role/DeleteRoledata/";

    constructor(private httpaction: HttpActionService) { }

    getRoles(roleData: RoleModel) {

        let params: URLSearchParams = new URLSearchParams();
        params.set('RoleName', roleData.RoleName);
        params.set('RoleDescription', roleData.RoleDescription);
        params.set('StatusName', roleData.StatusName);
        let options = new RequestOptions(Constants.getParamOptions(params));

        return this.httpaction.get(this.getRoledata, options);
    }

    saveRoleData(roleData: RoleModel) {
        return this.httpaction.post(roleData, this.saveRoledata);
    }

    deleteRoleData(roleData: RoleModel) {
        return this.httpaction.post(roleData, this.deleteRoledata);
    }
}
