﻿
using MINIDAT.Model.TestCreation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ILogSheetRepository
    {
        DataSet GetLogSheetDetails(PeriodReadingModel periodReadingModel, string userId);

        List<LogSheetPeriodReadingModel> GetLogSheetPeriodReadingDetails(PeriodReadingModel periodReadingModel, string userId);

        void SavePeriodReading(PeriodReadingModel periodReadingModel, string userId);

        void SaveLogSheet(dynamic LogSheet,string plantCd, string userId);

        string GetLogSheetKey(LogSheetKeyModel LogSheetKeyModel, string userId);
    }
}
