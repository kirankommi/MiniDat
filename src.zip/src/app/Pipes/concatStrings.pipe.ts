import { Pipe, PipeTransform, ViewChild } from '@angular/core';

@Pipe({
  name: 'concatStrings'
})
export class concatStringsPipe implements PipeTransform {

  transform(value: any, property: string, delimiter: string) {
    try {
      debugger;
      return value.map(q => q[property]).join(delimiter);
    }
    catch (error) {
      return "";
    }
  }

}
