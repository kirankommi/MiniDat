﻿using MINIDAT.Model;
using System.Data;

namespace MINIDAT.Models.Interfaces
{
    public interface IModel
    {
        void CreateModelFromReader(IDataRecord _record);
        ValidationResult Validate();
    }
}
