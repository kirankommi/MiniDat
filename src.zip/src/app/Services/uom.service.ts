﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { UomTemplate } from '../Models/UomTemplate';
import * as Constants from '../Shared/globalconstants';
import { HttpActionService } from './httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable'; 

@Injectable()
export class UomService {
    private getApplication = "/UOMTemplate/GetApplicationDetails/";
    private getTemplates = "/UOMTemplate/GetTemplates/";
    private searchTemplates = "/UOMTemplate/SearchTemplates";
    private getVariables = "/UOMTemplate/GetTemplateVariables/";
    private deleteUom = "/UOMTemplate/DeleteTemplate/";
    private saveUom = "/UOMTemplate/SaveTemplateData/";
    private defaultUom = "/UOMTemplate/MakeDefault/";
    private saveVariables = "/UOMTemplate/SaveVariables/";
    private SaveTemplateVariables = "/UOMTemplate/SaveTemplateVariables/";
    private getUOMgroup = '/UOMTemplate/GetUOMgroups';
    private getVariableCategories = '/UOMTemplate/GetVariableCategories';
    private getVariabledata = '/UOMTemplate/GetVariables';
    constructor(private httpaction: HttpActionService) { }  

    getApplications() {
        return this.httpaction.get(this.getApplication, Constants.options);
    }

    getUomTemplates() {
        return this.httpaction.get(this.getTemplates, Constants.options);
    }

    searchUomTemplates(uomTemplate: UomTemplate) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('TemplateID', uomTemplate.TemplateID);
        params.set('ApplicationId', uomTemplate.ApplicationId.toString());
        params.set('TemplateName', uomTemplate.TemplateName);
        params.set('IsDefault', uomTemplate.IsDefault);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.searchTemplates, options);
    }

    getTemplateVariables(templateId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateID', templateId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getVariables, options);
    }
    GetVariableCategories(templateId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateID', templateId);       
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getVariableCategories, options);
    }

    GetVariablesPerModules(templateId: string,ModuleId: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('templateID', templateId);
        params.set('moduleID', ModuleId);
        debugger;
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getVariabledata, options);
    }

    saveUomTemplate(uomTemplate: UomTemplate) {
        return this.httpaction.post(uomTemplate, this.saveUom);
    }

    makeDefaultUom(uomTemplate: UomTemplate) {
        return this.httpaction.post(uomTemplate, this.defaultUom);
    }

    saveUomVariables(templateData: any) {
        return this.httpaction.post(templateData, this.SaveTemplateVariables);
    }

    deleteUomTemplate(uomTemplate: UomTemplate) {
        return this.httpaction.post(uomTemplate, this.deleteUom);
    }    
    getUOMgroups(): Observable<any> {
        return this.httpaction.get(this.getUOMgroup, Constants.options);
    }
}

