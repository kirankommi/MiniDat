﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystShapeModel
    {
        public int? CatalystShapeID { get; set; }
        public string CatalystShape { get; set; }
        public decimal? AssumedVoidFraction { get; set; }
        public decimal? CrushedVoidFraction { get; set; }
        public string StatusName { get; set; } 
        public KeyValue StatusCode { get; set; }    

    }
    public class CatalystShapeSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalystShapeModel> _lstcatalystShapes = new List<CatalystShapeModel>();
        public IList<CatalystShapeModel> LstcatalystShapes { get { return _lstcatalystShapes; } }

        public int RecordsFetched { get; set; }

    }
}
