import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router';
import { sharedModule } from '../../Directives/shared.module';
import { CreateProjectComponent } from './CreateProject/createproject.component';
import { Capability } from './CreateProject/capability.component';
import { NPD } from './CreateProject/npd.component';
import { Customer } from './CreateProject/customer.component';


const routes: Routes = [{
  path: 'Pool',
    component: CreateProjectComponent
  }];

@NgModule({
  imports: [sharedModule,
    RouterModule.forChild(routes)],
  declarations: [
    CreateProjectComponent,
    Capability,
    NPD,
    Customer]
})
export class projectModule {

}
