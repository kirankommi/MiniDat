﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           CustomerLocationModel.cs
Project Title:      FeedStockDAT
Created on:         5-June-2017
Requirements Tag:   MOdel for Managing Customer Location
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */



using MINIDAT.Models.Interfaces;
using System.Collections.Generic;

namespace MINIDAT.Model.Manage.CustomerLocation
{
  public class CustomerLocationModel : ModelBase, IModel
    {
        public CustomerLocationModel(IValidationLogic<ModelBase> objValid):base(objValid)
        {
        }
        public CustomerLocationModel()
        {

        }
        public int CustomerId { get; set; }
        public int? CustomerUopNum { get; set; }
        public string CustomerAliasName { get; set; }
        public string CustomerOldAliasName { get; set; }
        public string CustomerName { get; set; }
        public string RoleDescription { get; set; }
        public int? LocationId { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string CreatedBy { get; set; }

        public override ValidationResult Validate(IValidationLogic<ModelBase> obj)
        {
            base.Validate(obj);
            return this.ValidationResult;
        }
    }

    //Search Parameters
    public class CustomerLocationSearchModel
    {
        private IList<CustomerLocationModel> _cust = new List<CustomerLocationModel>();
        public IList<CustomerLocationModel> Customers { get { return _cust; } }
        public int RecordsFetched { get; set; }

    }

    public class CustomerMaster
    {
        public string  Name { get; set; }
        public int  Id { get; set; }
        public int? LocationId { get; set; }
        public string City { get; set; } 
        public string Country { get; set; }



    }
    public class LocationMaster
    {        
        public int? LocationId { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

    }
    public class CustomerLocationMasterModel
    {
        private IList<CustomerMaster> _cust = new List<CustomerMaster>();
        public IList<CustomerMaster> Customer { get { return _cust; } }
        private IList<LocationMaster> _loc = new List<LocationMaster>();
        public IList<LocationMaster> Location { get { return _loc; } }

    }
}
