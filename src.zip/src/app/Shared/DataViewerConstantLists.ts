export var GasSubCategories: any[]=[];
GasSubCategories=[
    {
       "export":false,
        "id": 0,
      "description": "Normalized Gas Yields",
      "displayName":"Normalized Gas Yields"
    },
    {
      "export":false,
      "id": 1,
      "description": "Gas Volumes",
      "displayName":"Gas Volumes"
    },
    {
      "export":false,
      "id": 2,
      "description": "Gas Weights",
      "displayName":"Gas Weights"
    }
  ];
  export var LiquidSubCategories: any[]=[];
  LiquidSubCategories=[
    {
       "export":false,
        "id": 0,
      "description": "Liquid Weights",
      "displayName":"Liquid Weights (LP 690)"
    },
    {
      "export":false,
      "id": 1,
      "description": "Liquid Weights Percent",
      "displayName":"Liquid Weights %'s (Sim Dist)"
    },
    {
      "export":false,
      "id": 2,
      "description": "Liquid Weights(Sim Dist)",
      "displayName":"Liquid Weights (Sim Dist)"
    },
    {
      "export":false,
      "id": 3,
      "description": "Normalized Liquid Weight",
      "displayName":"Normalized Liquid Weights"
    }
  ];


  export var YieldSubCategories: any[]=[];
  YieldSubCategories=[
    {
       "export":false,
        "id": 0,
      "description": "Raw Product Weights",
      "displayName":"Raw Product Weights"
    },
    {
      "export":false,
      "id": 1,
      "description": "Raw Product Weight Percent",
      "displayName":"Raw Product Wt %'s"
    },
    {
      "export":false,
      "id": 2,
      "description": "Mass Balance Adjusted Prod Wt Percent",
      "displayName":"MB Adjusted Product Wt %'s"
    },
    {
      "export":false,
      "id": 3,
      "description": "Dopant Adjustment",
      "displayName":"Dopant Adjustments"
    },
    {
      "export":false,
      "id": 4,
      "description": "Dopant Adjusted Mb",
      "displayName":"DA Mass Balance Product Wt %'s "
    },
    {
      "export":false,
      "id": 5,
      "description": "Product Ratios",
      "displayName":"Product Ratios"
    }
  ];

  export var FeedSubCategories: any[]=[];
  FeedSubCategories=[
    {
       "export":false,
        "id": 0,
        "description": "Feed Weight(Sim Dist)",
      "displayName":"Feed Weights (Sim Dist)"
    },
    {
      "export":false,
      "id": 1,
      "description": "Feed Weight Percent(Sim Dist)",
      "displayName":"Feed Weight %'s  (Sim Dist)"
    }
  ];

  export var NmrSubCategories: any[]=[];
  NmrSubCategories=[
    {
       "export":false,
        "id": 0,
      "description": "LP Product Properties",
      "displayName":"LP Product Properties"
    },
    {
      "export":false,
      "id": 1,
      "description": "H By NIR Yields",
      "displayName":"H By NIR Yields"
    },
    {
      "export":false,
        "id": 2,
        "description": "H By NMR Yields",
        "displayName":"H By NMR Yields"
      }
  ];
  export class customExport {
    displayName: string;
    name: string;
    isVisible?: boolean;
    isStatic?: true;
    childrens?: any[] = [];
  }

  export var dataViewerExport: customExport[] = [
    {
    name: "Plant Calculations",
    displayName: "Plant Calculations",
    isVisible: true,
    childrens: [
      {
        "export":false,
        "id": 0,
        "description": "Plant Calculations",
        "displayName":"Plant Calculations"
      }
    ]
  },
  {
    name: "Gas",
    displayName: "Gas",
    isVisible: true,
    childrens: GasSubCategories
  },
  {
    name: "Weight Recovery",
    displayName: "Weight Recovery",
    isVisible: true,
    childrens: [
      {
         "export":false,
        "id": 0,
        "description": "Weight Recovery",
        "displayName":"Weight Recovery"
      }
    ]
  },
  {
    name: "Liquid",
    displayName: "Liquid",
    isVisible: true,
    childrens: LiquidSubCategories
  },
  {
    name: "Yield",
    displayName: "Yield",
    isVisible: true,
    childrens: YieldSubCategories
  },
  {
    name: "Feed",
    displayName: "Feed",
    isVisible: true,
    childrens: FeedSubCategories
  },
  {
    name: "Conversion Calculations",
    displayName: "Conversion",
    isVisible: true,
    childrens: [
      {
         "export":false,
        "id": 0,
        "description": "Conversion Calculations",
        "displayName":"Conversion"
      }
    ]
  },
  {
    name: "Quality Calculations",
    displayName: "Quality Calculations",
    isVisible: true,
    childrens: [
      {
         "export":false,
        "id": 0,
        "description": "Quality Calculations",
        "displayName":"Quality Calculations"
      }
    ]
  },
  
  {
    name: "H2 NMR Calculations",
    displayName: "H2 NMR Calculations",
    isVisible: true,
    childrens: NmrSubCategories
  },

  

    
  ]

  export class dataToExport{
    isPlantCalculations:boolean;  
    isNormalizedGasYields:boolean;
    isGasVolumes:boolean;
    isGasWeights:boolean;
    isWeightRecovery:boolean;
    isLiquidWeights:boolean;
    isLiquidWeightsSimDist:boolean;
    isLiquidWeightsSimDistPercent:boolean;
    isNormalizedLiquidWeights:boolean;
    isYieldRawProductWeights
    isYieldRawProductWeightsPercent:boolean;
    isYieldMBAdjustedProductWtPercent:boolean;
    isYieldDopantAdjustments:boolean;
    isYieldDAMassBalanceProductWtPercent:boolean;
    isYieldProductRatios:boolean;
    isFeedWeights:boolean;
    isFeedWeightsPercent:boolean;
    isConversionCalculation:boolean;
    isQualitCalculation:boolean;
    isH2LPProductProperties:boolean;
    isH2ByNMR:boolean;
    isH2ByNIR:boolean;

  }
 
