﻿import { Injectable } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { messageModalComponent } from './message-modal.component';

@Injectable()
export class messageModalUtility {
    constructor(private modalService: NgbModal) { }

    show(title: string, description: string, type: string): Promise<any> {
        const modalRef = this.modalService.open(messageModalComponent, { backdrop: "static" });
        modalRef.componentInstance.title = title;
        modalRef.componentInstance.description = description;
        modalRef.componentInstance.type = type;
        return modalRef.result;
    }
}
