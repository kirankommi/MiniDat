﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.UOM
{
    public class Unit 
    {
        private string unitName;
        private string displayText;
        private double slope;
        private double intercept;

        public int? UnitId { get; set; }
        /// <summary>
        /// Get o set the name of unit
        /// this is the name ny which unit is refered
        /// </summary>

        public string UnitName
        {
            get { return unitName; }
            set
            {
                unitName = value;
            }
        }

        /// <summary>
        /// Get or set the display text for the unit 
        /// this is text that is displayed on UI for the Unit
        /// </summary>
        //[ComboboxSelectKeyValidations(ErrorMessage = "Unit Name is required.")]
        public string DisplayText
        {
            get { return displayText; }
            set { displayText = value; }

        }

        /// <summary>
        /// Get or set the Slope for unit
        /// this slope is used for unit conversion
        /// </summary>
        public double Slope
        {
            get { return slope; }
            set { slope = value; }

        }

        /// <summary>
        /// Get or set the Intercept for the unit
        /// Intersept used for unit converion
        /// </summary>
        public double Intercept
        {
            get { return intercept; }
            set { intercept = value; }

        }

        public string DefaultUnitInd { get; set; }
        
        public bool IsDefaultUnit { get; set; }
        /// <summary>
        /// Converts the value to the target unit value
        /// </summary>
        /// <param name="unitValue">Value to be converted</param>
        /// <returns>Converted value</returns>
        /// <exception cref="DivideByZeroException" >
        public double? convertToTargetunit(double? unitValue)
        {
            if (UnitName == "API" || UnitName == "BAUME" || UnitName == "BAUME<5")
            {
                return (Slope / unitValue) - Intercept;
            }
            else
            {
                return (unitValue - Intercept) / Slope;
            }
        }

        /// <summary>
        /// Converts the value to the base unit value
        /// </summary>
        /// <param name="unitValue">Value to be converted</param>
        /// <returns>Converted value</returns>
        public double? convertToBaseUnit(double? unitValue)
        {
            if (UnitName == "API" || UnitName == "BAUME" || UnitName == "BAUME<5")
            {
                return Slope / (unitValue + Intercept);
            }
            else
            {
                return unitValue * Slope + Intercept;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="unitValue"></param>
        /// <returns></returns>
        public decimal? convertToTargetunitDecimal(decimal? unitValue)
        {
            if (UnitName == "API" || UnitName == "BAUME" || UnitName == "BAUME<5")
            {
                return (Convert.ToDecimal(Slope) / unitValue) - Convert.ToDecimal(Intercept);
            }
            else
            {
                return (unitValue - Convert.ToDecimal(Intercept)) / Convert.ToDecimal(Slope);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="unitValue"></param>
        /// <returns></returns>
        public decimal? convertToBaseUnitDecimal(decimal? unitValue)
        {
            if (UnitName == "API" || UnitName == "BAUME" || UnitName == "BAUME<5")
            {
                return Convert.ToDecimal(Slope) / (unitValue + Convert.ToDecimal(Intercept));
            }
            else
            {
                return unitValue * Convert.ToDecimal(Slope) + Convert.ToDecimal(Intercept);
            }
        }
    }
}
