﻿using MINIDAT.DataAccess.Interfaces;
//using MINIDAT.Framework.Common;
using MINIDAT.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using Calculations;
using MINIDAT.Calculation;
using System.Reflection;
using MINIDAT.Model.Test;
using MINIDAT.Framework.Extension;
using MINIDAT.Model.Manage;
using MINIDAT.Models.Interfaces;
//using MINIDAT.Framework.Common;
using System.Xml.Serialization;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model.Session;
using System.Globalization;
using MINIDAT.Calculation.Modules;
using MINIDAT.DataAccess.Calculation;
using System.Threading;

namespace MINIDAT.DataAccess.Repository.TestCreation
{
    public class TestCreationRepository : ITestCreationRepository
    {

        private IDatabase _db;
        
        public TestCreationRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public string DeleteTest(TestModel testmodel)
        {
            try
            {
                if (testmodel == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[md].Delete_Test_creation_sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_Run_id", testmodel.RunTestIdsq);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<RunFlyoutModel> GetRunFlyout(string plantcd)
        {
            try
            {
                if (plantcd == null)
                {
                    throw new ArgumentNullException("Plant Number");
                }
                else
                {
                    List<RunFlyoutModel> runList = new List<RunFlyoutModel>();
                    IDataReader reader = null;
                    using (IDbCommand command = _db.CreateCommand("[md].[Get_Test_RunDetails_basedOnPlant]"))
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("proc_plant_cd", plantcd);
                        _db.CreateParameters(command, parameters);

                        reader = _db.ExecuteReader(command);
                        while (reader.Read())
                        {
                            RunFlyoutModel sample = new RunFlyoutModel
                            {
                                Plantcode = reader["PLANT_CD"].ToString(),
                                RunNumber = Convert.ToInt32(reader["RUN_NUM"]),
                            };
                            runList.Add(sample);

                        }
                    }
                    return runList;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }
        public TestSearchModel GetPlantsFlyout()

        {
            try
            {
                TestSearchModel TestArr = new TestSearchModel();

                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_Test_Creation_Details]"))
                {
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        PlantModel newPlant = new PlantModel()
                        {

                            Plantcode = reader["PLANT_CD"].ToString(),
                            BuildingNumber = reader["BUILDING_NM"].ToString(),
                            Location = reader["LOCATION_CD"].ToString()
                        };
                        TestArr.lstPlants.Add(newPlant);
                    }
                    return TestArr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public TestSearchModel GetTest()
        {
            try
            {
                TestSearchModel testarr = new TestSearchModel();
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_Test_Creation_Details]"))
                {
                    reader = _db.ExecuteReader(command);
                    testarr.lstTests.Clear();
                    reader.NextResult();
                    while (reader.Read())
                    {
                        ((List<KeyValue>)testarr.lstwcQuality).Add(new KeyValue()
                        {
                            Key = reader["QUALITY_CD"].ToString(),
                            Value = reader["QUALITY_NM"].ToString()
                        });
                    }
                    reader.NextResult();
                    reader.Close();
                    return testarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public TestSearchModel SearchTest(TestModel TestModel)
        {
            

            try
            {
                TestSearchModel testArr = new TestSearchModel();
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Search_Test_Creation_Details]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_plant_cd", string.IsNullOrEmpty(TestModel.Plant) ? (object)null : TestModel.Plant);
                    parameters.Add("proc_run_id", TestModel.Run == 0 ? (object)null : TestModel.Run);
                    parameters.Add("proc_test_num", TestModel.Test == 0 ? (object)null : TestModel.Test);
                    parameters.Add("proc_run_start_time", TestModel.TestStartTime);
                    parameters.Add("proc_run_end_time", TestModel.TestEndTime);
                    parameters.Add("proc_wc_quality", TestModel.WCName);
                    parameters.Add("proc_test_Comment", string.IsNullOrEmpty(TestModel.TestComment) ? (object)null : TestModel.TestComment);
                    parameters.Add("IsInitialLoad", (TestModel.IsInitialLoad == true ? 'Y' : 'N'));
                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        TestModel _testModel = new TestModel
                        {
                            Plant = Convert.ToString(reader["PLANT_CD"]),
                            Run = Convert.ToInt32(reader["RUN_NUM"]),
                            Test = Convert.ToInt32(reader["TEST_NUM"]),
                            TestStartTime = ((reader["TEST_START_TM"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["TEST_START_TM"])),// Convert.ToDateTime(reader["TEST_START_TM"]),
                            //startTimeStr = DBNull.Value != reader["StartDate"] ?  Convert.ToString(reader["StartDate"]): "",
                            TestEndTime = ((reader["TEST_END_TM"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["TEST_END_TM"])), //Convert.ToDateTime(reader["TEST_END_TM"]),
                            //endTimeStr = DBNull.Value != reader["EndDate"] ? Convert.ToString(reader["EndDate"]) : "",
                            WCName = Convert.ToString(reader["WC_QUALITY_IND"]),
                            //WeightCheckQuality = new KeyValue() { Key = reader["MODEL_TYPE_ID_SQ"].ToString(), Value = reader["MODEL_TYPE_NM"].ToString() },
                            PIData = Convert.ToString(reader["PI_DATA_IND"]),
                            LIMSData = Convert.ToString(reader["LIMS_DATA_IND"]),
                            LineOut = Convert.ToString(reader["LINEOUT_TEST_IND"]),
                            TestComment = Convert.ToString(reader["TEST_COMMENT_TXT"]),
                            PiReTransmitTime = ((reader["PI_RETRANSMIT_TM"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["PI_RETRANSMIT_TM"])),
                            LimsReTransmitTime = ((reader["LIMS_RETRANSMIT_TM"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["LIMS_RETRANSMIT_TM"])),
                            RunTestIdsq = Convert.ToInt32(reader["RUN_TEST_ID_SQ"]),
                            LastCalculatedOn = ((reader["LAST_CALCULATED_DT"] == DBNull.Value) ? (DateTime?)null : Convert.ToDateTime(reader["LAST_CALCULATED_DT"])),
                            PlantLocation = Convert.ToString(reader["PLANT_CD"]),
                            //RecordsFetched = Convert.ToInt32(reader["ROW_COUNT"]),
                        };
                        testArr.lstTests.Add(_testModel);
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        testArr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    reader.Close();
                }
                return testArr;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        
        //new
        public void SaveTestData(TestModel _test, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _test == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                 //_test.TestStartTime = DateTime.ParseExact(_test.startTime, "yyyy/MM/dd HH:mm:ss", CultureInfo.InvariantCulture);
                IDbCommand command = _db.CreateCommand("[md].[InsertUpdateRunTest_Sp]");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Plant_Cd", _test.Plant);
                    parameters.Add("proc_nm_Run_Num", _test.Run);
                    parameters.Add("proc_nm_Test_Num", _test.Test);
                    parameters.Add("proc_vr_Comment_Txt",string.IsNullOrEmpty(_test.TestComment)? (object)DBNull.Value:_test.TestComment.FormatString());
                    parameters.Add("proc_dt_Test_End_Tm", _test.TestEndTime.FormatDateTime());
                    parameters.Add("proc_dt_Test_Start_Tm", _test.TestStartTime.FormatDateTime());
                    
                    if (_test.LineOut == null)
                    {

                        if (_test.TestStartTime.FormatDateTime() == null &&
                            _test.TestEndTime.FormatDateTime() == null)
                        {
                            parameters.Add("proc_ch_Is_LineOut_Ind", "Y");
                        }
                        else
                        {
                            parameters.Add("proc_ch_Is_LineOut_Ind", "N");

                        }
                    }
                    else
                    {
                        parameters.Add("proc_ch_Is_LineOut_Ind", _test.LineOut = ((_test.LineOut == "true") ? "Y" : "N"));
                    }
                    //parameters.Add("proc_vr_Comment_Txt", _test.TestComment);
                    parameters.Add("proc_ch_WC_Quality_Ind", _test.WCName.FormatString());
                    parameters.Add("proc_vr_current_User_Id", userId);
                    if (_test.TestComment.Contains("Auto Generated"))
                    {
                        parameters.Add("proc_ch_auto_generated_Ind", 'Y');
                    }
                    else
                    {
                        parameters.Add("proc_ch_auto_generated_Ind", 'N');
                    }
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// Saves the calculation results.
        /// </summary>
        /// <param name="strPlantCd">The STR plant cd.</param>
        /// <param name="intRunId">The int run id.</param>
        /// <param name="intTestId">The int test id.</param>
        /// <param name="strCalcResults">The STR calc results.</param>
        /// <returns></returns>
        public void SaveCalculationResults(string strPlantCd, int? intRunId, int? intTestId, string strCalcResults, string userId)
        {

            try
            {
                if (string.IsNullOrEmpty(userId))
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("Insert_Update_Calculation_Results");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("PlantCode", strPlantCd);
                    parameters.Add("RunId", intRunId);
                    parameters.Add("TestId", intTestId);
                    parameters.Add("CalculationXml", strCalcResults);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public ContentValues GetWeightCheckInputs(string PlantCd, int? RunId, int? TestId)
        {
            ContentValues inputs = new ContentValues();

            IDbCommand command = _db.CreateCommand("Get_Calculation_Data");
            using (command)
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("PlantCode", PlantCd);
                parameters.Add("RunId", RunId);
                parameters.Add("TestId", TestId);
                _db.CreateParameters(command, parameters);
                //_db.ExecuteNonQuery(command);
            }
            DataSet dsInput = _db.ExecuteDataSet(command);
            using (dsInput)
            {
                if (dsInput != null)
                {
                    #region Rename Dataset
                    dsInput.Tables[0].TableName = "PiTagInputs";
                    dsInput.Tables[1].TableName = "CalibrationInputs";
                    dsInput.Tables[2].TableName = "AdditionalInfoInputs";
                    dsInput.Tables[3].TableName = "FeedInputs";
                    dsInput.Tables[4].TableName = "OffGasInputs";
                    dsInput.Tables[5].TableName = "RunInfo";
                    dsInput.Tables[6].TableName = "CatalystInputs";
                    dsInput.Tables[7].TableName = "GLCInputs";
                    dsInput.Tables[8].TableName = "ProdSimDistInputs";
                    dsInput.Tables[9].TableName = "FeedSimDistInputs";
                    dsInput.Tables[10].TableName = "RunBoilingPointInputs";
                    dsInput.Tables[11].TableName = "ProdPhyProperties";
                    dsInput.Tables[12].TableName = "ProcessSpecification";
                    dsInput.Tables[13].TableName = "Online_GC_N2_Data";
                    dsInput.Tables[14].TableName = "TestInfo";
                    dsInput.Tables[15].TableName = "NirPtSpec";
                    dsInput.Tables[16].TableName = "PlantPressures";
                    dsInput.Tables[17].TableName = "TCCalibInputs";
                    #endregion

                    inputs.AddValue(RunSetupAlias.Plant_Cd, new ValueHolder() { Value = PlantCd });
                    inputs.AddValue(RunSetupAlias.Run_Id, new ValueHolder() { Value = RunId });
                    inputs.AddValue(RunSetupAlias.Test_Id, new ValueHolder() { Value = TestId });

                    #region Read Pi Tag Values
                    FieldInfo[] piAliases = typeof(PITagAlias).GetFields();
                    DataTable dtPiTags = dsInput.Tables["PiTagInputs"];
                    foreach (FieldInfo piTagAlias in piAliases)
                    {
                        string PiTagAliasValue = piTagAlias.GetValue(null) as string;
                        DataRow[] drPiTag = dtPiTags.Select("CALC_ALIAS_NM = '" + PiTagAliasValue + "'");
                        if (drPiTag.Length > 0)
                        {
                            string strReadingType = Convert.ToString(drPiTag[0]["INPUT_VARIABLE_TYP"]);
                            if (string.Compare(strReadingType, "Average", true) == 0) // Average Reading
                            {
                                inputs.AddValue(PiTagAliasValue, new ValueHolder() { Value = drPiTag[0]["AVERAGE_READING_MSR"].FormatDouble() });
                            }
                            else
                            {
                                inputs.AddValue(PiTagAliasValue + PiTagReadingType.InitialReading, new ValueHolder() { Value = drPiTag[0]["INITIAL_VALUE_MSR"].FormatDouble() });
                                inputs.AddValue(PiTagAliasValue + PiTagReadingType.FinalReading, new ValueHolder() { Value = drPiTag[0]["FINAL_VALUE_MSR"].FormatDouble() });
                            }

                        }

                    }
                    #endregion

                    #region Read TMf and Max meter Calibration Factors 
                    string[] calibrationAliases = new string[] { "TMF_Slope", "TMF_Intercept" };
                    DataTable dtCalibrations = dsInput.Tables["CalibrationInputs"];
                    foreach (string calibrationAlias in calibrationAliases)
                    {
                        string calibrationFactorNm = typeof(RunSetupAlias).GetField(calibrationAlias).GetValue(null) as string;
                        DataRow[] drCalibrationFactor = dtCalibrations.Select("CALIBRATION_FACTOR_NM = '" + calibrationFactorNm + "'");
                        if (drCalibrationFactor.Length > 0)
                        {
                            inputs.AddValue(calibrationFactorNm, new ValueHolder() { Value = drCalibrationFactor[0]["CALIBRATION_VALUE_MSR"].FormatDouble() });
                        }

                    }
                    #endregion

                    #region Read Addtional Info 
                    DataTable dtAddtionalInfo = dsInput.Tables["AdditionalInfoInputs"];
                    if (dtAddtionalInfo.Rows.Count > 0)
                    {
                        inputs.AddValue(RunSetupAlias.TC_Calibration_Offset, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["TC_CALIB_OFFSET_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Plant_Or_TC_Offset, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["PLANT_TC_OFFSET_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Hiese_Offset, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["HIESE_OFFSET_MSR"].FormatDouble() });
                        //inputs.AddValue(RunSetupAlias.H2S_In_Off_Gas, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["H2S_IN_OFF_GAS_MSR"].FormatDouble() });
                        //inputs.AddValue(Alias.MaxMeter_Density, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["MAX_METER_SCALE_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias._185F_Normalization_Factor, new ValueHolder() { Value = dtAddtionalInfo.Rows[0]["NORMALIZATION_FACTOR_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Feed_Wt_Calc_Source, new ValueHolder() { Value = Convert.ToString(dtAddtionalInfo.Rows[0]["FEED_CALCULATION_SOURCE_CD"]) });

                    }
                    else
                    {
                        inputs.AddValue(RunSetupAlias.TC_Calibration_Offset, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Plant_Or_TC_Offset, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Hiese_Offset, new ValueHolder() { Value = null });
                        //inputs.AddValue(RunSetupAlias.H2S_In_Off_Gas, new ValueHolder() { Value = null });
                        //inputs.AddValue(Alias.MaxMeter_Density, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias._185F_Normalization_Factor, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Feed_Wt_Calc_Source, new ValueHolder() { Value = string.Empty });
                    }

                    #endregion

                    #region Read TC Calibration Offset

                    DataTable dtTCCalibOffsetInputs = dsInput.Tables["TCCalibInputs"];
                    FieldInfo[] tcCalibAliases = typeof(TCCalibOffsetAlias).GetFields();

                    foreach (FieldInfo tcCalibAlias in tcCalibAliases)
                    {
                        string tcCalibAliasValue = tcCalibAlias.GetValue(null) as string;
                        DataRow[] drTCCalibOffset = dtTCCalibOffsetInputs.Select("Parameter_NM = '" + tcCalibAliasValue + "'");
                        if (drTCCalibOffset.Length > 0)
                        {
                            inputs.AddValue(tcCalibAliasValue, new ValueHolder() { Value = drTCCalibOffset[0]["PARAM_VALUE_MSR"].FormatDouble() });
                        }
                    }

                    #endregion

                    #region Read Feed Inputs
                    DataTable dtFeed = dsInput.Tables["FeedInputs"];
                    if (dtFeed.Rows.Count > 0)
                    {
                        inputs.AddValue(RunSetupAlias.S_In_Feed_Blend, new ValueHolder() { Value = dtFeed.Rows[0]["FEED_BLEND_S_CTNT_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.N_In_Feed_Blend, new ValueHolder() { Value = dtFeed.Rows[0]["FEED_BLEND_N_CTNT_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.DbDs_In_Feed_Blend, new ValueHolder() { Value = dtFeed.Rows[0]["FEED_BLEND_DBDS_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Cha_In_Feed_Blend, new ValueHolder() { Value = dtFeed.Rows[0]["FEED_BLEND_CHA_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.H_In_Feed, new ValueHolder() { Value = dtFeed.Rows[0]["FEED_H_CONTENT_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Feed_Specific_Gravity, new ValueHolder() { Value = dtFeed.Rows[0]["SPECIFIC_GRAVITY_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Feed_Density_at_Isco_Operating_Temp, new ValueHolder() { Value = dtFeed.Rows[0]["FD_DENSITY_ISCO_OPER_TMPR_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Dopant_Id, new ValueHolder() { Value = dtFeed.Rows[0]["DOPANT_ID"] });
                        inputs.AddValue(RunSetupAlias.Dopant_Used, new ValueHolder() { Value = dtFeed.Rows[0]["DOPANTS_USED"] });
                    }
                    else
                    {
                        inputs.AddValue(RunSetupAlias.S_In_Feed_Blend, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.N_In_Feed_Blend, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.DbDs_In_Feed_Blend, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Cha_In_Feed_Blend, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.H_In_Feed, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Feed_Specific_Gravity, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Dopant_Id, new ValueHolder() { Value = dtFeed.Rows[0]["DOPANT_ID"] });
                        inputs.AddValue(RunSetupAlias.Dopant_Used, new ValueHolder() { Value = dtFeed.Rows[0]["DOPANTS_USED"] });
                    }
                    #endregion

                    //Gas Volumns input
                    #region Read Off Gas Inputs
                    FieldInfo[] offGasAliases = typeof(OffGasAlias).GetFields();
                    DataTable dtOffGas = dsInput.Tables["OffGasInputs"];
                    ContentValues OffGasInputs = new ContentValues();
                    foreach (FieldInfo offGasAlias in offGasAliases)
                    {
                        string offGasAliasValue = offGasAlias.GetValue(null) as string;
                        DataRow[] drOffGas = dtOffGas.Select("COMPONENT_STANDARD_NM = '" + offGasAliasValue + "'");
                        if (drOffGas.Length > 0)
                        {
                            OffGasInputs.AddValue(offGasAliasValue, new ValueHolder() { Value = drOffGas[0]["GC_COMPONENT_VALUE_QTY"].FormatDouble() });
                        }
                    }
                    inputs.AddValue(LimsAlias.OffGas_Inputs, new ValueHolder() { Value = OffGasInputs });

                    #endregion 

                    #region Read run info
                    DataTable dtRunInfo = dsInput.Tables["RunInfo"];
                    if (dtRunInfo.Rows.Count > 0)
                    {
                        string strZeroHosTime = Convert.ToString(dtRunInfo.Rows[0]["ZERO_HOS_TM"]);
                        //ZERO HOS time is not entered, Run Start time is considered
                        if (string.IsNullOrEmpty(strZeroHosTime))
                        {
                            strZeroHosTime = Convert.ToString(dtRunInfo.Rows[0]["RUN_START_TM"]);
                        }

                        inputs.AddValue(RunSetupAlias.Zero_Hos_Time, new ValueHolder() { Value = strZeroHosTime });
                        inputs.AddValue(RunSetupAlias.Product_Objective, new ValueHolder() { Value = Convert.ToString(dtRunInfo.Rows[0]["RUN_OBJECTIVE_NM"]) });
                    }
                    else
                    {
                        inputs.AddValue(RunSetupAlias.Zero_Hos_Time, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Product_Objective, new ValueHolder() { Value = string.Empty });
                    }

                    #endregion

                    #region Read Test info
                    DataTable dtTestInfo = dsInput.Tables["TestInfo"];
                    if (dtTestInfo.Rows.Count > 0)
                    {
                        inputs.AddValue(TestAlias.WCStartTime, new ValueHolder() { Value = Convert.ToString(dtTestInfo.Rows[0]["TEST_START_TM"]) });
                        inputs.AddValue(TestAlias.WCEndTime, new ValueHolder() { Value = Convert.ToString(dtTestInfo.Rows[0]["TEST_END_TM"]) });
                        inputs.AddValue(Alias.MaxMeter_Density, new ValueHolder() { Value = dtTestInfo.Rows[0]["MAX_METER_SCALE_MSR"].FormatDouble() });
                        inputs.AddValue(Alias.EH_meter_weight, new ValueHolder() { Value = dtTestInfo.Rows[0]["MAX_METER_SCALE_MSR"].FormatDouble() });
                    }
                    else
                    {
                        inputs.AddValue(TestAlias.WCStartTime, new ValueHolder() { Value = null });
                        inputs.AddValue(TestAlias.WCEndTime, new ValueHolder() { Value = null });
                        inputs.AddValue(Alias.MaxMeter_Density, new ValueHolder() { Value = null });
                        inputs.AddValue(Alias.EH_meter_weight, new ValueHolder() { Value = null });
                    }

                    #endregion

                    #region Read Catalyst Inputs
                    DataTable dtCatInputs = dsInput.Tables["CatalystInputs"];
                    if (dtCatInputs.Rows.Count > 0)
                    {
                        inputs.AddValue(RunSetupAlias.Catalyst_Loading_Volume, new ValueHolder() { Value = dtCatInputs.Rows[0]["CATALYST_LOAD_VOLUME_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Catalyst_Loaded_Density, new ValueHolder() { Value = dtCatInputs.Rows[0]["CATALYST_LOAD_DENSITY_MSR"].FormatDouble() });
                        inputs.AddValue(RunSetupAlias.Catalyst_Piece_Density, new ValueHolder() { Value = dtCatInputs.Rows[0]["PIECE_DENSITY_MSR"].FormatDouble() });
                    }
                    else
                    {
                        inputs.AddValue(RunSetupAlias.Catalyst_Loading_Volume, new ValueHolder() { Value = null });
                        inputs.AddValue(RunSetupAlias.Catalyst_Piece_Density, new ValueHolder() { Value = null });
                    }
                    #endregion

                    //LP 690 inputs
                    #region Read Glc Inputs
                    FieldInfo[] offGlcAliases = typeof(GlcAlias).GetFields();
                    DataTable dtGlc = dsInput.Tables["GLCInputs"];
                    ContentValues glcInput = new ContentValues();
                    foreach (FieldInfo glcAlias in offGlcAliases)
                    {
                        string offGlcAliasValue = glcAlias.GetValue(null) as string;
                        DataRow[] drGlc = dtGlc.Select("COMPONENT_STANDARD_NM = '" + offGlcAliasValue + "'");
                        if (drGlc.Length > 0)
                        {
                            glcInput.AddValue(offGlcAliasValue, new ValueHolder() { Value = drGlc[0]["GC_COMPONENT_VALUE_QTY"].FormatDouble() });
                        }
                    }

                    inputs.AddValue(LimsAlias.GLC_Inputs, new ValueHolder() { Value = glcInput });
                    #endregion 

                    #region Read Liquid Sim Dist Values
                    List<double?> lSimDistValues = new List<double?>();
                    DataTable dtSimDist = dsInput.Tables["ProdSimDistInputs"];
                    if (dtSimDist.Rows.Count > 0)
                    {
                        for (int sdNum = 0; sdNum <= 100; sdNum++)
                        {
                            lSimDistValues.Add(dtSimDist.Rows[0]["SIM_DIST_" + sdNum + "_VOLUME_PCT"].FormatDouble());
                        }
                    }
                    inputs.AddValue(SimDistAlias.LiquidSimDistValues, new ValueHolder() { Value = lSimDistValues });
                    #endregion
                    #region Read Feed Sim Dist Values
                    List<double?> lfeedSimDistValues = new List<double?>();
                    DataTable dtFeedSimDist = dsInput.Tables["FeedSimDistInputs"];
                    if (dtFeedSimDist.Rows.Count > 0)
                    {
                        for (int sdNum = 0; sdNum <= 100; sdNum++)
                        {
                            lfeedSimDistValues.Add(dtFeedSimDist.Rows[0]["SIM_DIST_" + sdNum + "_VOLUME_PCT"].FormatDouble());
                        }
                    }
                    inputs.AddValue(SimDistAlias.FeedSimDistValues, new ValueHolder() { Value = lfeedSimDistValues });
                    #endregion

                    #region Read Run Boiling Point Cuts
                    List<double?> lBpCuts = new List<double?>();
                    DataTable dtRunBp = dsInput.Tables["RunBoilingPointInputs"];
                    int intRowCount = dtRunBp.Rows.Count;
                    if (intRowCount > 0)
                    {

                        for (int i = 0; i < intRowCount; i++)
                        {
                            if (i == 0) //For First Cut Range Take the IBP Also as Cut Point
                            {
                                lBpCuts.Add(dtRunBp.Rows[i]["IBP_MSR"].FormatDouble());
                            }
                            lBpCuts.Add(dtRunBp.Rows[i]["END_POINT_MSR"].FormatDouble());
                        }
                    }
                    inputs.AddValue(RunSetupAlias.Run_Boiling_Point_Cuts, new ValueHolder() { Value = lBpCuts });
                    #endregion

                    #region Read Prod Phy Properties
                    DataTable dtProdPhyProp = dsInput.Tables["ProdPhyProperties"];
                    if (dtProdPhyProp.Rows.Count > 0)
                    {

                        FieldInfo[] prodAliases = typeof(ProductPhysicalPropertyAlias).GetFields();
                        foreach (var prodAlias in prodAliases)
                        {
                            if (prodAlias.Name == "Lab_Liq_Prd_Specific_Gravity")
                            {
                                DataRow[] drLabSG = dtProdPhyProp.Select("LABEL_TXT = 'API' AND STREAM_NM = 'Liquid Product'");
                                if (drLabSG.Length > 0)
                                {
                                    inputs.AddValue(ProductPhysicalPropertyAlias.Lab_Liq_Prd_Specific_Gravity, new ValueHolder() { Value = drLabSG[0]["VALUE_MSR"].FormatDouble() });
                                }
                            }
                            else if (prodAlias.Name == "Nir_Liq_Prd_Specific_Gravity")
                            {
                                DataRow[] drNirSG = dtProdPhyProp.Select("LABEL_TXT = 'API' AND STREAM_NM = 'Nir Stream'");
                                if (drNirSG.Length > 0)
                                {
                                    inputs.AddValue(ProductPhysicalPropertyAlias.Nir_Liq_Prd_Specific_Gravity, new ValueHolder() { Value = drNirSG[0]["VALUE_MSR"].FormatDouble() });
                                }
                            }
                            else if (prodAlias.Name == "H2_NMR")
                            {
                                DataRow[] drNirHbyNMR = dtProdPhyProp.Select("LABEL_TXT = 'H Content by NMR'");
                                //if (TestId == 2 || TestId == 4)
                                //{
                                if (drNirHbyNMR.Length > 0)
                                {
                                    inputs.AddValue(ProductPhysicalPropertyAlias.H2_NMR, new ValueHolder() { Value = drNirHbyNMR[0]["VALUE_MSR"].FormatDouble() });
                                }
                                //}
                                //else if (TestId == 1)
                                //{
                                //    inputs.AddValue(ProductPhysicalPropertyAlias.H2_NMR, new ValueHolder() { Value = 0.14090 });
                                //}
                                //else if (TestId == 3)
                                //{
                                //    inputs.AddValue(ProductPhysicalPropertyAlias.H2_NMR, new ValueHolder() { Value = 0.14210 });                               		

                                //}
                            }
                            else
                            {
                                string labelTxt = prodAlias.GetValue(null) as string;
                                DataRow[] drProdPrp = dtProdPhyProp.Select("LABEL_TXT = '" + labelTxt + "'");
                                if (drProdPrp.Length > 0)
                                {
                                    inputs.AddValue(labelTxt, new ValueHolder() { Value = drProdPrp[0]["VALUE_MSR"].FormatDouble() });
                                }
                            }
                        }

                        //DataRow[] drHNMR = dtProdPhyProp.Select("LABEL_TXT = '"+ ProductPhysicalPropertyAlias.H2_NMR+"'");
                        //if (drHNMR.Length > 0)
                        //{
                        //    inputs.AddValue(ProductPhysicalPropertyAlias.H2_NMR, new ValueHolder() { Value = drHNMR[0]["VALUE_MSR"].FormatDouble() });
                        //}

                        //DataRow[] drLabSG = dtProdPhyProp.Select("LABEL_TXT = '" + ProductPhysicalPropertyAlias.Lab_Liq_Prd_Specific_Gravity + "' AND STREAM_NM = 'Liquid Product'");
                        //if (drLabSG.Length > 0)
                        //{
                        //    inputs.AddValue(ProductPhysicalPropertyAlias.Lab_Liq_Prd_Specific_Gravity, new ValueHolder() { Value = drLabSG[0]["VALUE_MSR"].FormatDouble() });
                        //}
                        //DataRow[] drNirSG = dtProdPhyProp.Select("LABEL_TXT = '" + ProductPhysicalPropertyAlias.Nir_Liq_Prd_Specific_Gravity + "' AND STREAM_NM = 'Nir Stream'");
                        //if (drNirSG.Length > 0)
                        //{
                        //    inputs.AddValue(ProductPhysicalPropertyAlias.Nir_Liq_Prd_Specific_Gravity, new ValueHolder() { Value = drNirSG[0]["VALUE_MSR"].FormatDouble() });
                        //}
                    }
                    #endregion

                    #region Read Process Specifications
                    DataTable dtProcSpec = dsInput.Tables["ProcessSpecification"];

                    string[] strProcessSpecsAliases = new string[] { "LHSV", "Gas_To_Oil_Rc", "Top_Block_Offset_Low", "Top_Block_Offset_High" };
                    foreach (string procSpecAlias in strProcessSpecsAliases)
                    {
                        FieldInfo alias = typeof(RunSetupAlias).GetField(procSpecAlias);
                        string strAliasValue = null;
                        if (alias != null)
                        {
                            strAliasValue = alias.GetValue(null) as string;
                        }
                        DataRow[] drSpec = dtProcSpec.Select("PROCESS_SPEC_PARAM_NM = '" + strAliasValue + "'");
                        if (drSpec.Length > 0)
                        {
                            inputs.AddValue(strAliasValue, new ValueHolder() { Value = drSpec[0]["PARAM_VALUE_MSR"].FormatDouble() });
                        }
                        else
                        {
                            inputs.AddValue(strAliasValue, new ValueHolder() { Value = null });
                        }
                    }
                    #endregion
                    #region Read NIR PT
                    DataTable dtNirPt = dsInput.Tables["NirPtSpec"];

                    string[] strNirPtAliases = new string[] { "NIR_Low_Target_API", "NIR_High_Target_API",
                    "NIR_Low_Target_Conv","NIR_High_Target_Conv","NIR_Control_Mode"};
                    foreach (string procNirPtAlias in strNirPtAliases)
                    {
                        FieldInfo alias = typeof(RunSetupAlias).GetField(procNirPtAlias);
                        string strAliasValue = null;
                        if (alias != null)
                        {
                            strAliasValue = alias.GetValue(null) as string;
                        }
                        DataRow[] drNirPt = dtNirPt.Select("PARAMETER_NM = '" + strAliasValue + "'");
                        if (drNirPt.Length > 0)
                        {
                            if (procNirPtAlias == "NIR_Control_Mode")
                            {
                                inputs.AddValue(strAliasValue, new ValueHolder() { Value = Convert.ToString(drNirPt[0]["PARAM_VALUE_TXT"]) });
                            }
                            else
                            {
                                inputs.AddValue(strAliasValue, new ValueHolder() { Value = drNirPt[0]["PARAM_VALUE_MSR"].FormatDouble() });

                            }
                        }
                        else
                        {
                            inputs.AddValue(strAliasValue, new ValueHolder() { Value = null });
                        }
                    }
                    #endregion

                    #region Read GC Count and N2 Sum/avg
                    DataTable dtQualityInputs = dsInput.Tables["Online_GC_N2_Data"];
                    if (dtQualityInputs.Rows.Count > 0)
                    {
                        List<double?> lN2_Data = new List<double?>();
                        for (int i = 0; i < dtQualityInputs.Rows.Count; i++)
                        {
                            lN2_Data.Add(dtQualityInputs.Rows[i]["GC_COMPONENT_ONLINE_VALUE_MSR_N2"].FormatDouble());
                        }
                        inputs.AddValue(Alias.N2_Data_For_Quality, new ValueHolder() { Value = lN2_Data });
                    }
                    #endregion
                    #region Read Recipes
                    //DataTable dtRecipes = dsInput.Tables["Recipes"];
                    //if (dtRecipes.Rows.Count > 0)
                    //{
                    //    DataRow[] drTargetPrdApi  = dtRecipes.Select("RECIPE_NUM = 4 AND RECIPE_TAG_CD = '"+Alias.Target_Prd_Api_Recipe_Tag+"'");
                    //    if (drTargetPrdApi.Length > 0)
                    //    {
                    //        inputs.AddValue(Alias.Target_Prd_Api_Recipe_Tag, new ValueHolder() { Value = drTargetPrdApi[0]["VALUE_TXT"].FormatDouble() });
                    //    }

                    //}
                    #endregion

                    #region Read Plant Pressures (high/Low)
                    DataTable dtPlantPressures = dsInput.Tables["PlantPressures"];
                    if (dtPlantPressures.Rows.Count > 0)
                    {
                        inputs.AddValue(Alias.Plant_Pressure_High, new ValueHolder() { Value = dtPlantPressures.Rows[0]["Plant_Pressure_High"].FormatDouble() });
                        inputs.AddValue(Alias.Plant_Pressure_Low, new ValueHolder() { Value = dtPlantPressures.Rows[0]["Plant_Pressure_Low"].FormatDouble() });
                    }
                    else
                    {
                        inputs.AddValue(Alias.Plant_Pressure_High, new ValueHolder() { Value = null });
                        inputs.AddValue(Alias.Plant_Pressure_Low, new ValueHolder() { Value = null });
                    }
                    #endregion

                    #region Read TC Calibration Offset data

                    FieldInfo[] tcAliases = typeof(TCCalibOffsetAlias).GetFields();
                    DataTable dtTCCalibdata = dsInput.Tables["TCCalibInputs"];
                    foreach (FieldInfo tcgAlias in tcAliases)
                    {
                        string TCAliasValue = tcgAlias.GetValue(null) as string;
                        DataRow[] drTCValue = dtTCCalibdata.Select("PARAMETER_NM = '" + TCAliasValue + "'");
                        if (drTCValue.Length > 0)
                        {
                            inputs.AddValue(TCAliasValue, new ValueHolder() { Value = drTCValue[0]["PARAM_VALUE_MSR"].FormatDouble() });
                        }
                        else
                        {
                            inputs.AddValue(TCAliasValue, new ValueHolder() { Value = null });

                        }

                    }

                    #endregion

                }
            }


            #region HardCoded WC Calc Inputs For CalcInput Reference (NOT TO BE DELETED)
            //Plant Calculation inputs
            //inputs.AddValue(PITagAlias.Reactor_Top_Control_Temp, new ValueHolder() { Value = 719.41 });
            //inputs.AddValue(PITagAlias.Reactor_Middle_Control_Temp, new ValueHolder() { Value = 719.29 });
            //inputs.AddValue(PITagAlias.Reactor_Bottom_Control_Temp, new ValueHolder() { Value = 719.34 });
            //inputs.AddValue(PITagAlias.Reactor_Catalyst_Inlet_Temp, new ValueHolder() { Value = 722.97 });
            //inputs.AddValue(PITagAlias.Reactor_Catalyst_Outlet_Temp, new ValueHolder() { Value = 721.30 });
            //inputs.AddValue(PITagAlias.HPS_Control_Pressure, new ValueHolder() { Value = 1999.97 });
            //inputs.AddValue(RunSetupAlias.TC_Calibration_Offset, new ValueHolder() { Value = 0.6939 });
            //inputs.AddValue(RunSetupAlias.Plant_Or_TC_Offset, new ValueHolder() { Value = 0 });
            //inputs.AddValue(RunSetupAlias.Hiese_Offset, new ValueHolder() { Value = 0 });

            //Gas Volumns input
            //inputs.AddValue(RunSetupAlias.H2S_In_Off_Gas, new ValueHolder() { Value = 0.84 });
            //inputs.AddValue(OffGasAlias.OffGas_H2, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_C1, new ValueHolder() { Value = 0.032 });
            //inputs.AddValue(OffGasAlias.OffGas_C2, new ValueHolder() { Value = 0.032 });
            //inputs.AddValue(OffGasAlias.OffGas_C2Equal, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_C3, new ValueHolder() { Value = 0.107 });
            //inputs.AddValue(OffGasAlias.OffGas_C3OLES, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_NC4, new ValueHolder() { Value = 0.123 });
            //inputs.AddValue(OffGasAlias.OffGas_IC4, new ValueHolder() { Value = 0.954 });
            //inputs.AddValue(OffGasAlias.OffGas_C4OLES, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_NC5, new ValueHolder() { Value = 0.055 });
            //inputs.AddValue(OffGasAlias.OffGas_IC5, new ValueHolder() { Value = 0.122 });
            //inputs.AddValue(OffGasAlias.OffGas_CC5, new ValueHolder() { Value = 0.001 });
            //inputs.AddValue(OffGasAlias.OffGas_C6S, new ValueHolder() { Value = 0.109 });
            //inputs.AddValue(OffGasAlias.OffGas_C7S, new ValueHolder() { Value = 0.061 });
            //inputs.AddValue(OffGasAlias.OffGas_C8S, new ValueHolder() { Value = 0.029 });
            //inputs.AddValue(OffGasAlias.OffGas_C9S, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_C10S, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_UNKNOWNS, new ValueHolder() { Value = 0.051 });
            //inputs.AddValue(OffGasAlias.OffGas_N2, new ValueHolder() { Value = 2.425 });
            //inputs.AddValue(OffGasAlias.OffGas_H2S, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_O2, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_CO, new ValueHolder() { Value = null });
            //inputs.AddValue(OffGasAlias.OffGas_CO2, new ValueHolder() { Value = null });
            //inputs.AddValue(PITagAlias.Barometric_Pressure, new ValueHolder() { Value = 756.7 });
            //inputs.AddValue(PITagAlias.Avg_WTM_Temperature, new ValueHolder() { Value = 88.099 });
            //inputs.AddValue(PITagAlias.WTM_Rate_Ini, new ValueHolder() { Value = 6592.42 });
            //inputs.AddValue(PITagAlias.WTM_Rate_Fin, new ValueHolder() { Value = 6604.37 });

            //Weight check Recovery inputs
            //inputs.AddValue(PITagAlias.H2_FLOW_RATE, new ValueHolder() { Value = 37.29 });
            //inputs.AddValue(RunSetupAlias.TMF_Slope, new ValueHolder() { Value = 0.050 });
            //inputs.AddValue(RunSetupAlias.TMF_Intercept, new ValueHolder() { Value = 0.024 });
            // inputs.AddValue(TestAlias.WCStartTime, new ValueHolder() { Value = "7/11/2011 11:22" });
            // inputs.AddValue(TestAlias.WCEndTime, new ValueHolder() { Value = "7/11/2011 17:22" });
            //inputs.AddValue(Alias.MaxMeter, new ValueHolder() { Value = 0.9404 });
            //inputs.AddValue(PITagAlias.Fresh_Feed_Rate + PiTagReadingType.InitialReading, new ValueHolder() { Value = 91842.98 });
            //inputs.AddValue(PITagAlias.Fresh_Feed_Rate + PiTagReadingType.FinalReading, new ValueHolder() { Value = 92009.88 });
            //inputs.AddValue(RunSetupAlias.S_In_Feed_Blend, new ValueHolder() { Value = 2.170 });
            //inputs.AddValue(RunSetupAlias.N_In_Feed_Blend, new ValueHolder() { Value = 0.08 });
            //inputs.AddValue(PITagAlias.Feed_Tank_Scale_Weight + PiTagReadingType.InitialReading, new ValueHolder() { Value = 14178.80 });
            //inputs.AddValue(PITagAlias.Feed_Tank_Scale_Weight + PiTagReadingType.FinalReading, new ValueHolder() { Value = 14017.60 });
            //inputs.AddValue(PITagAlias.Prod_Bottle_Tare_Weight, new ValueHolder() { Value = 155.16 });
            //inputs.AddValue(PITagAlias.Prod_Bottle_Gross_Weight, new ValueHolder() { Value = 300.30 });

            //Hos inputs
            //inputs.AddValue(RunSetupAlias.Catalyst_Loading_Volume, new ValueHolder() { Value = 20.0 });
            //inputs.AddValue(RunSetupAlias.Catalyst_Piece_Density, new ValueHolder() { Value = 1.34 });
            //inputs.AddValue(RunSetupAlias.DbDs_In_Feed_Blend, new ValueHolder() { Value = 6.068 });
            //inputs.AddValue(RunSetupAlias.Cha_In_Feed_Blend, new ValueHolder() { Value = 0.559 });

            //LP 690 inputs
            //inputs.AddValue(GlcAlias.Glc_Ethane, new ValueHolder() { Value = null });
            //inputs.AddValue(GlcAlias.Glc_Propane, new ValueHolder() { Value = null });
            //inputs.AddValue(GlcAlias.Glc_nButane, new ValueHolder() { Value = 0.003 });
            //inputs.AddValue(GlcAlias.Glc_iButane, new ValueHolder() { Value = 0.001 });
            //inputs.AddValue(GlcAlias.Glc_nPentane, new ValueHolder() { Value = 0.194 });
            //inputs.AddValue(GlcAlias.Glc_iPentane, new ValueHolder() { Value = 0.262 });
            //inputs.AddValue(GlcAlias.Glc_nhexane, new ValueHolder() { Value = 0.33 });
            //inputs.AddValue(GlcAlias.Glc_3Methylpentane, new ValueHolder() { Value = 0.225 });
            //inputs.AddValue(GlcAlias.Glc_22Dimethylbutane, new ValueHolder() { Value = 0.006 });
            //inputs.AddValue(GlcAlias.Glc_CY5_23DMC4_2MC5, new ValueHolder() { Value = 0.447 });
            //inputs.AddValue(GlcAlias.Glc_Cyclohexane, new ValueHolder() { Value = 0.702 });
            //inputs.AddValue(GlcAlias.Glc_Methylcyclopentane, new ValueHolder() { Value = 0.649 });
            //inputs.AddValue(GlcAlias.Glc_Benzene, new ValueHolder() { Value = 0.131 });
            //inputs.AddValue(GlcAlias.Glc_UnknownC6, new ValueHolder() { Value = 0.002 });
            //inputs.AddValue(GlcAlias.Glc_UnknownC7, new ValueHolder() { Value = 0.005 });
            //inputs.AddValue(GlcAlias.Glc_Heavies, new ValueHolder() { Value = 97.042 });
            //inputs.AddValue(GlcAlias.Glc_Unknown, new ValueHolder() { Value = null });

            //Sim Dist Values for Liquid Weight Calcs
            //List<double?> lSimDistValues = new List<double?>()
            //{
            //        131.7,153.3,180.3,192.6,206.6,215.2,225.7,241.9,245.8,256.3,
            //        268.2,275.7,286.5,292.3,301.6,312.1,320.7,330.1,
            //        335.8,344.5,354.2,360.3,368.2,375.1,382.3,387.3,
            //        394.5,400.3,407.1,413.2,419.4,425.1,432.3,
            //        439.2,445.6,453.2,459,466.9,474.8,482,489.2,
            //        496,504.3,511.9,519.4,527,535.3,543.2,550.4,
            //        559.4,566.6,575.2,582.8,591.1,599.7,607.6,616.6,625.6,634.6,643.6,651.9,
            //        660.9,669.9,677.5,686.5,694.4,702,710.2,717.1,
            //        725,732.6,738.3,745.5,752.4,757.8,764.2,
            //        770.7,775.8,781.9,788,793,799.2,805.3,810,
            //        816.1,822.6,828,834.8,840.9,847.8,855.3,
            //        862.9,870.8,879.4,888.4,899.2,911.1,925.5,943.2,
            //        970.2,993.9

            //};
            //#region Read Feed Sim Dist Values
            ////Sim Dist Values for Feed Calcs
            //List<double?> lfeedSimDistValues = new List<double?>();
            //lfeedSimDistValues.Add(258.8);
            //lfeedSimDistValues.Add(275.36);
            //lfeedSimDistValues.Add(361.76);
            //lfeedSimDistValues.Add(382.28);
            //lfeedSimDistValues.Add(384.08);
            //lfeedSimDistValues.Add(385.16);
            //lfeedSimDistValues.Add(386.96);
            //lfeedSimDistValues.Add(419.72);
            //lfeedSimDistValues.Add(449.6);
            //lfeedSimDistValues.Add(479.48);
            //lfeedSimDistValues.Add(507.56);
            //lfeedSimDistValues.Add(533.84);
            //lfeedSimDistValues.Add(556.16);
            //lfeedSimDistValues.Add(575.6);
            //lfeedSimDistValues.Add(591.08);
            //lfeedSimDistValues.Add(604.4);
            //lfeedSimDistValues.Add(618.08);
            //lfeedSimDistValues.Add(629.24);
            //lfeedSimDistValues.Add(640.76);
            //lfeedSimDistValues.Add(650.48);
            //lfeedSimDistValues.Add(659.84);
            //lfeedSimDistValues.Add(668.48);
            //lfeedSimDistValues.Add(676.04);
            //lfeedSimDistValues.Add(683.96);
            //lfeedSimDistValues.Add(691.16);
            //lfeedSimDistValues.Add(697.28);
            //lfeedSimDistValues.Add(703.76);
            //lfeedSimDistValues.Add(709.88);
            //lfeedSimDistValues.Add(715.28);
            //lfeedSimDistValues.Add(720.32);
            //lfeedSimDistValues.Add(726.08);
            //lfeedSimDistValues.Add(731.12);
            //lfeedSimDistValues.Add(735.44);
            //lfeedSimDistValues.Add(739.76);
            //lfeedSimDistValues.Add(744.44);
            //lfeedSimDistValues.Add(748.76);
            //lfeedSimDistValues.Add(752.72);
            //lfeedSimDistValues.Add(756.32);
            //lfeedSimDistValues.Add(759.92);
            //lfeedSimDistValues.Add(763.88);
            //lfeedSimDistValues.Add(767.48);
            //lfeedSimDistValues.Add(771.08);
            //lfeedSimDistValues.Add(773.96);
            //lfeedSimDistValues.Add(776.84);
            //lfeedSimDistValues.Add(780.08);
            //lfeedSimDistValues.Add(783.32);
            //lfeedSimDistValues.Add(786.56);
            //lfeedSimDistValues.Add(789.8);
            //lfeedSimDistValues.Add(792.32);
            //lfeedSimDistValues.Add(795.2);
            //lfeedSimDistValues.Add(798.08);
            //lfeedSimDistValues.Add(800.96);
            //lfeedSimDistValues.Add(803.84);
            //lfeedSimDistValues.Add(806.72);
            //lfeedSimDistValues.Add(809.24);
            //lfeedSimDistValues.Add(811.76);
            //lfeedSimDistValues.Add(814.28);
            //lfeedSimDistValues.Add(817.16);
            //lfeedSimDistValues.Add(820.04);
            //lfeedSimDistValues.Add(822.56);
            //lfeedSimDistValues.Add(825.44);
            //lfeedSimDistValues.Add(827.96);
            //lfeedSimDistValues.Add(830.48);
            //lfeedSimDistValues.Add(833);
            //lfeedSimDistValues.Add(835.88);
            //lfeedSimDistValues.Add(838.76);
            //lfeedSimDistValues.Add(841.28);
            //lfeedSimDistValues.Add(843.8);
            //lfeedSimDistValues.Add(846.68);
            //lfeedSimDistValues.Add(849.56);
            //lfeedSimDistValues.Add(852.44);
            //lfeedSimDistValues.Add(855.32);
            //lfeedSimDistValues.Add(858.2);
            //lfeedSimDistValues.Add(861.08);
            //lfeedSimDistValues.Add(863.96);
            //lfeedSimDistValues.Add(867.2);
            //lfeedSimDistValues.Add(870.44);
            //lfeedSimDistValues.Add(873.32);
            //lfeedSimDistValues.Add(876.2);
            //lfeedSimDistValues.Add(879.8);
            //lfeedSimDistValues.Add(883.04);
            //lfeedSimDistValues.Add(886.64);
            //lfeedSimDistValues.Add(889.88);
            //lfeedSimDistValues.Add(893.48);
            //lfeedSimDistValues.Add(897.44);
            //lfeedSimDistValues.Add(901.04);
            //lfeedSimDistValues.Add(905);
            //lfeedSimDistValues.Add(909.32);
            //lfeedSimDistValues.Add(913.64);
            //lfeedSimDistValues.Add(917.96);
            //lfeedSimDistValues.Add(923);
            //lfeedSimDistValues.Add(928.04);
            //lfeedSimDistValues.Add(933.44);
            //lfeedSimDistValues.Add(939.2);
            //lfeedSimDistValues.Add(946.04);
            //lfeedSimDistValues.Add(953.24);
            //lfeedSimDistValues.Add(962.24);
            //lfeedSimDistValues.Add(973.04);
            //lfeedSimDistValues.Add(987.44);
            //lfeedSimDistValues.Add(1010.48);
            //lfeedSimDistValues.Add(1032.08);




            //inputs.AddValue(SimDistAlias.FeedSimDistValues, new ValueHolder() { Value = lfeedSimDistValues });
            //#endregion
            //inputs.AddValue(SimDistAlias.SimDistValues, new ValueHolder() { Value = lSimDistValues });
            //LP Normalization inputs.
            //inputs.AddValue(RunSetupAlias._185F_Normalization_Factor, new ValueHolder() { Value = 1 });
            #endregion


            return inputs;

        }

        public bool InsertLogSheetPeriodReading(string strPlant, int? RunId, int? TestId)
        {
            try
            {
                IDbCommand command = _db.CreateCommand("INSERT_LOGSHEET_PERIOD");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("PlantCode", strPlant);
                    parameters.Add("RunId", RunId);
                    parameters.Add("TestId", TestId);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string SavePIData(string piData)
        {
            try
            {
                if (piData == null)
                {
                    return string.Empty;
                }
                using (IDbCommand command = _db.CreateCommand("[md].Upload_PI_Lims_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_cl_PI_xml", piData);
                    parameters.Add("@proc_cl_GC_xml", DBNull.Value);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Saved succssfully";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public string PerformCalculations(TestModel testModel, UserSession userSession)
        {
            TestCreation test = new TestCreation(testModel, userSession.User.EID);
            CalculationStatusReceiver receiver = new TestCreation(testModel, userSession.User.EID);
            try
            {
                CalculationFacade calcFacade = new CalculationFacade(test, receiver);
                //calcFacade.ExecuteCalculations(testModel.Plant, testModel.Run, testModel.Test);
                //InsertLogSheetPeriodReading(testModel.Plant, testModel.Run, testModel.Test);
                calcFacade.ExecuteCalculations(testModel.Plant, testModel.Run, testModel.Test, userSession);

                return "";
            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }

        /// <summary>
        /// Gets the data set.
        /// </summary>
        /// <param name="cmdName">Name of the CMD.</param>
        /// <param name="objParameters">The obj parameters.</param>
        /// <returns></returns>
        public DataSet GetDataSet(string cmdName, string PlantCd, string RunId, string TestId)
        {
            DataSet st = new DataSet();
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand(cmdName))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("@proc_vr_Plant_Cd", PlantCd);
                parameters.Add("@proc_in_Run_Id", RunId);
                parameters.Add("@proc_Test_Id", TestId);
                _db.CreateParameters(command, parameters);
                reader = _db.ExecuteReader(command);
                while (!reader.IsClosed)
                    st.Tables.Add().Load(reader);
                reader.Close();
            }
            ////Create the database command
            //if (null == objCmdBuilder)
            //{
            //    objDbHelper = DataLayerFactory.getDatabaseHelper();
            //    objCmdBuilder = DataLayerFactory.getCommandBuilder();
            //}
            //cmd = objCmdBuilder.getCommand(cmdName, objParameters);
            ////Execute the command against database					
            //return (DataSet)objDbHelper.executeDataset(cmd);
            return st;
        }


    }
}

                
       