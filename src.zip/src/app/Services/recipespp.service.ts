﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { AccoladeProjectModel,NPDProjectModel ,CapabilityProjectModel,CustomerProjectModel} from '../Models/Project/ProjectModel';
import { HttpActionService } from './httpaction.service';
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { KeyValue } from '../Models/usermodel';

@Injectable({
    providedIn: 'root'
})
export class RecipeSppService {    
    private GetAllDocumentsUrl = "/RecipeSpp/GetAllDocuments/";
    private DownloadFileUrl = "/RecipeSpp/DownloadFile/";
    
    constructor(private httpaction: HttpActionService) { }
   
    
    GetAllDocuments() {
      
        let params: URLSearchParams = new URLSearchParams();
       // params.set('projectId', projectId);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetAllDocumentsUrl, options);
    }

    DownLoadProjectDocuments(fileid:string) {

        let params: URLSearchParams = new URLSearchParams();
        params.set('fileId', fileid);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.DownloadFileUrl, options);
    }

    
}

