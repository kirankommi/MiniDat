﻿export class AnalysisMethodModel {
    MethodNumber: string;
    MethodName: string;
    UOMGroup: KeyValue;
    MethodDescription: string;
    LIMSOperation: string;
    CheckedSources: SourceName[];
    UOMGroupName: string;
    CheckedSourcesNames: string;
    Id: number;
    UOMSearch: string;
}

export class KeyValue {
    Key: string;
    Value: string;
}
export class SourceName {
    Name: string;
    Id: string;
    IsUsed: boolean;
}