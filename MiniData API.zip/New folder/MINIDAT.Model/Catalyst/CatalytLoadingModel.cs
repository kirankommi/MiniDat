﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace MINIDAT.Model.Catalyst
{    
    public class CatalytLoadingModel
    {

        public int? TemplateID { get; set; }
        public string TemplateName { get; set; }
        public string LoadingType { get; set; }       
        public List<Bed> Beds { get; set; }               
        public string StatusName { get; set; }
        public decimal? ReactorInternalDia { get; set; }
        public decimal? BedLength { get; set; }
        public decimal? BedVolume { get; set; }
        public KeyValue StatusCode { get; set; }        

    }  

    public class CatalytLoadingSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalytLoadingModel> _lstTemplates = new List<CatalytLoadingModel>();
        public IList<CatalytLoadingModel> LstTemplates { get { return _lstTemplates; } }
        
        public int RecordsFetched { get; set; }

    }

    public class Bed
    {
        
        public int RowId { get; set; }
        public int TemplateID { get; set; }
        public int BedNumber { get; set; }
        public decimal CatalystVolume { get; set; }
        public int Split { get; set; }
        public string DiluentDesignation { get; set; }
        public decimal DiluentVolume { get; set; }
        public int DiluentID { get; set; }

    }
}

