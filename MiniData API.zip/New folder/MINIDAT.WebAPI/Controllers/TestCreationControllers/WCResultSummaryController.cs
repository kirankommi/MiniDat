﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.DataViewer;
using MINIDAT.DataAccess.Repository.TestCreation;
using MINIDAT.Model;
using MINIDAT.Model.DataViewerModel;
using MINIDAT.Model.TestCreation;
using MINIDAT.WebAPI.Controllers.RunController;
using Newtonsoft.Json;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers.TestCreationControllers
{
    public class WCResultSummaryController : AppController
    {
        [HttpGet, ActionName("GetDataForWCResultSummary")]
        public HttpResponseMessage GetDataForDataViewer(string Plant, string Run, string Test, string Category)
        {
            WCResultSummaryRepository _wcResultSummaryRepository = new WCResultSummaryRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _wcResultSummaryRepository.getDataForWCResultSummary(Plant, Run, Test, Category, User.Identity.Name));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                //need to change
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.TestSearchError.ToString());
            }
        }
        [HttpPost, ActionName("ExportWC")]
        public Byte[] ExportWCData(DataViewerModel inputdata)
        {
            WCResultSummaryRepository _wcResultSummaryRepository = new WCResultSummaryRepository(new MINIDATDatabase());
            RunController.RunController _runController = new RunController.RunController();
            try
            {
                string[] categories;
                categories = inputdata.Category.Split(',');
                XSSFWorkbook workbook = new XSSFWorkbook();
                int _rowIndex = 7;
                /////////////////
                // Export Data //
                /////////////////
                WCExportPopup popupData = _wcResultSummaryRepository.exportWCRepository(inputdata.Plant,Convert.ToString(inputdata.Run), Convert.ToString(inputdata.Test), inputdata.Category, User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1));
                foreach(var cat in categories)
                {
                    List<WCExport> exportdata = new List<WCExport>();
                    inputdata.Category = cat;
                    ISheet sheet;
                    switch (inputdata.Category)
                    {
                        case "Plant Calculations":
                            exportdata = popupData.PlantCalculations;
                            break;
                        case "Normalized Gas Yields":
                            exportdata = popupData.NormalizedGasYields;
                            break;
                        case "Gas Volumes":
                            exportdata = popupData.GasVolumes;
                            break;
                        case "Gas Weights":
                            exportdata = popupData.GasWeights;
                            break;
                        case "Weight Recovery":
                            exportdata = popupData.WeightRecovery;
                            break;
                        case "Liquid Weights":
                            exportdata = popupData.LiquidWeights_LP690;
                            inputdata.Category = "Liquid Weights (LP 690)";
                            break;
                        case "Liquid Weights Percent":
                            exportdata = popupData.LiquidWeights_percent;
                            inputdata.Category = "Liquid Weights %'s (Sim Dist)";
                            break;
                        case "Liquid Weights(Sim Dist)":
                            exportdata = popupData.LiquidWeights_Simdist;
                            break;
                        case "Normalized Liquid Weight":
                            exportdata = popupData.NormalizedLiquidWeights;
                            inputdata.Category = "Normalized Liquid Weights";
                            break;
                        case "Raw Product Weights":
                            exportdata = popupData.RawProductWeights;
                            break;
                        case "Raw Product Weight Percent":
                            exportdata = popupData.RawProductWeights_percent;
                            inputdata.Category = "Raw Product Wt %'s";
                            break;
                        case "Mass Balance Adjusted Prod Wt Percent":
                            exportdata = popupData.MBAdjustedProductWt_percent;
                            inputdata.Category = "MB Adjusted Product Wt %'s";
                            break;
                        case "Dopant Adjustment":
                            exportdata = popupData.DopantAdjustments;
                            inputdata.Category = "Dopant Adjustments";
                            break;
                        case "Dopant Adjusted Mb":
                            exportdata = popupData.DAMassBalanceProductWt_perscent;
                            inputdata.Category = "DA Mass Balance Product Wt %'s";
                            break;
                        case "Product Ratios":
                            exportdata = popupData.ProductRatios;
                            break;
                        case "Feed Weight(Sim Dist)":
                            exportdata = popupData.FeedWeights;
                            inputdata.Category = "Feed Weights (Sim Dist)";
                            break;
                        case "Feed Weight Percent(Sim Dist)":
                            exportdata = popupData.FeedWeightsPercent;
                            inputdata.Category = "Feed Weight %'s  (Sim Dist)";
                            break;
                        case "Conversion Calculations":
                            exportdata = popupData.ConversionCalculation;
                            inputdata.Category = "Conversion";
                            break;
                        case "Quality Calculations":
                            exportdata = popupData.QualitCalculation;
                            break;
                        case "LP Product Properties":
                            exportdata = popupData.H2LPProductProperties;
                            break;
                        case "H By NIR Yields":
                            exportdata = popupData.H2ByNIR;
                            break;
                        case "H By NMR Yields":
                            exportdata = popupData.H2ByNMR;
                            break;
                    }
                    sheet = CreateSheetsForExport(workbook, inputdata.Category, inputdata.Plant, Convert.ToString(inputdata.Run), Convert.ToString(inputdata.Test));
                    if (exportdata.Count > 0)
                    {
                        var json = JsonConvert.SerializeObject(exportdata);
                        DataTable dt = (DataTable)JsonConvert.DeserializeObject(json, (typeof(DataTable)));
                        string exportDataviewer = "DataViewer";
                        _rowIndex = _runController.AddDataToExcel2(dt, _rowIndex, inputdata.Category, workbook, sheet, exportDataviewer);
                        _rowIndex = 7;
                    }

                }
                using (MemoryStream output = new MemoryStream())
                {
                    workbook.Write(output);
                    return output.ToArray();
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public ISheet CreateSheetsForExport(XSSFWorkbook workbook, string sheetName, string plant, string run, string Test)
        {
            RunController.RunController _runController = new RunController.RunController();
            var normalStyle = _runController.setTableStyle(workbook);
            ISheet sheet1 = workbook.CreateSheet(sheetName);
            for (int i = 0; i < 20; i++)
            {
                sheet1.AutoSizeColumn(i);
            }
            sheet1.SetColumnWidth(0, 6000);
            var _rowIndex = 0;

            var row = sheet1.CreateRow(_rowIndex++);
            _runController.SetTitle(sheet1, workbook, "Weight Check Result Summary");
            /////////////////Header Styling for table/////////////////////////////////////////
            var headerStyle = (XSSFCellStyle)workbook.CreateCellStyle();
            headerStyle.SetFillBackgroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.SetFillForegroundColor(new XSSFColor(new byte[3] { 217, 226, 243 }));
            headerStyle.FillPattern = FillPattern.SolidForeground;
            headerStyle.WrapText = true;
            headerStyle.BorderTop = BorderStyle.Thin;
            headerStyle.BorderBottom = BorderStyle.Thin;
            headerStyle.BorderLeft = BorderStyle.Thin;
            headerStyle.BorderRight = BorderStyle.Thin;
            headerStyle.Alignment = HorizontalAlignment.Center;
            XSSFFont hFont = (XSSFFont)workbook.CreateFont();
            hFont.FontHeightInPoints = 11;
            hFont.FontName = "Calibri";
            hFont.Boldweight = (short)FontBoldWeight.Bold;
            headerStyle.SetFont(hFont);
            //////////////////////////////////////////////////////////

            _rowIndex = _rowIndex + 3;
            row = sheet1.CreateRow(_rowIndex);
            row.SetCellValue(1, "Plant", headerStyle);
            row.SetCellValue(2, plant, normalStyle);
            row.SetCellValue(4, "Run", headerStyle);
            row.SetCellValue(5, run, normalStyle);
            row.SetCellValue(7, "Test", headerStyle);
            row.SetCellValue(8, Test, normalStyle);
            _rowIndex = _rowIndex + 3;
            row = sheet1.CreateRow(_rowIndex);

            return sheet1;
        }

    }

}
