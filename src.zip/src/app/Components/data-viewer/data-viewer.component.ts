import { Component, OnInit, Input } from '@angular/core';
import { TestCreationService } from 'src/app/Services/TestCreation/TestCreation.service';
import { DataViewerModel, DataViewerTableModel } from 'src/app/Models/DataViewer/DataViewerModel';
import * as Constants from '../../../app/Shared/globalconstants';
import { DataViewerService } from 'src/app/Services/DataViewerServices/data-viewer.service';
import { AppComponent } from 'src/app/app.component';
import { appService } from 'src/app/Services/app.service';
import * as DataViewerLists from '../../../app/Shared/DataViewerConstantLists';
import { KeyValue } from 'src/app/Models/usermodel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';

@Component({
  selector: 'app-data-viewer',
  templateUrl: './data-viewer.component.html',
  styleUrls: ['./data-viewer.component.css'],
  providers: [TestCreationService],
})
export class DataViewerComponent implements OnInit {
  DataViewObj: DataViewerModel;
  DataViewExportObj: DataViewerModel;
  plantListCols: any[] = [];
  lstPlants: any;
  flyoutHeaderPlant: string = "Plants";
  pHolderPlant: string = "Plant #";

  RunListCols: any[] = [];
  lstRuns: any;
  flyoutHeaderRun: string = "Run";
  pHolderRun: string = "Run #";

  constants: any = {};
  dataViewerLists: any = {};

  popuplist: any;
  selectedPopupList: KeyValue[];
  exportData: DataViewerLists.customExport[] = []
  exportSelectAll:boolean=false;

  constructor(private testCreationService: TestCreationService, private service: DataViewerService, private appComponent: AppComponent, private appService: appService, private alertMessage: AlertMessage) {
    this.constants = Constants;
    this.dataViewerLists = DataViewerLists;
    this.exportData = DataViewerLists.dataViewerExport;
  }

  showOverlay($event, exportFilter,DataViewerHeader) {
    exportFilter.style["position"] = "absolute";
    exportFilter.style["top"] = DataViewerHeader.offsetHeight + 150 + 'px';
    exportFilter.style["left"] = DataViewerHeader.offsetLeft + 90 + 'px';
    exportFilter.toggle($event, exportFilter);
  }
  ExportData(exportDialog: any) {
    let exportString = this.GetAndClearExportSelection(exportDialog);
   

    this.DataViewExportObj = new DataViewerModel();
    this.DataViewExportObj.Run = this.DataViewObj.Run;
    this.DataViewExportObj.Plant = this.DataViewObj.Plant;
    this.DataViewExportObj.User_Id = this.DataViewObj.User_Id;
    this.DataViewExportObj.Category = exportString;
    console.log(this.DataViewExportObj)
    this.service.GetExportData(this.DataViewExportObj)
    .subscribe(
    (data: any) => {
        debugger;
        if (data != null) 
        {
          let DocumentName =  "P"+this.DataViewExportObj.Plant + "_R" + this.DataViewExportObj.Run + ".xlsx";
          var byteCharacters = atob(data);
          var byteNumbers = new Array(byteCharacters.length);
          for (var i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          var byteArray = new Uint8Array(byteNumbers);
          var blob = new Blob([byteArray], { type: "" });
          var ua = window.navigator.userAgent;
          var msie = ua.indexOf("MSIE ");
          var chrome = ua.indexOf("Chrome");

          if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
              window.navigator.msSaveOrOpenBlob(blob, DocumentName);
          }
          else {
            var objectUrl = URL.createObjectURL(blob);
            var link = document.createElement("A");
            link.setAttribute("href", objectUrl);
            link.setAttribute("download", DocumentName);
            link.setAttribute("target", "_blank");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.constants.ExportSuccess });
        }
        else {
          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Results are missing for the selected analysis." });
        }
    },
    // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
    );

  }

  GetAndClearExportSelection(exportDialog) {
    debugger;
    let exportString = '';
    this.exportData.forEach(element => {
      element.childrens.forEach(child => {
        if (child.export) {
          if (exportString == '') {
            exportString = child.description
          } else {
            exportString += ',' + child.description
          }
          child.export = false;
        }
      })

    })
    if(exportDialog){
      exportDialog.visible = false;
    }
    this.exportSelectAll=false;
    return exportString;
  }

  ResetSelection(exportDialog) {
    let exportString = '';
    this.exportData.forEach(element => {
      element.childrens.forEach(child => {
        if (child.export) {
          if (exportString == '') {
            exportString = child.description
          } else {
            exportString += ',' + child.description
          }
          child.export = false;
        }
      })

    })
    this.exportSelectAll=false;
  }


  SelectAllExport(){
      this.exportData.forEach(element => {
        element.childrens.forEach(child => {
           child.export = !this.exportSelectAll;
         })
  
      })
   
   
  }



  @Input() isNotSearchable: boolean;
  flyoutState: string = 'out';

  toggleFlyout() {
    if (!this.isNotSearchable) {
      this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
      this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
    }
  }
  defaultUnit: string;
  ngOnInit() {
    this.DataViewObj = new DataViewerModel();
    this.getPlantFlyout();
    this.showTable = false;
    this.searchBy = "Plant Calculations";
    this.defaultUnit = "MOLE%";
    this.appService.getSessionData()
      .subscribe((data: any) => {
        if (data != null) {
          if (data.User != null && data.User != undefined) {
            this.userEid = data.User.EID;
          }
          else {
            document.getElementById('fdms-container').style.marginLeft = '0px';
          }
        }
      });
  }
  Reset(event: any) {
    if (event.target.id != "Edit") {
      this.DataViewObj.Run = null;
      this.DataViewObj.Plant = "";
    }
    this.showTable = false;
    let Dataexport = this.GetAndClearExportSelection("");
  }
  showTable: boolean = false;
  ViewData() {
    if (this.DataViewObj.Plant != null && this.DataViewObj.Run != null) {
      this.showTable = true;
      this.searchBy = "Plant Calculations";
      this.onSearchBy(this.searchBy);
    }
  }

  updateRunSelection(event, condition) {
    debugger;
    this.DataViewObj.Run = event.RunNumber;
  }
  updatePlantSelection(event, condition) {
    debugger;
    this.DataViewObj.Plant = event.Plantcode;
    this.getRunFlyout();
  }
  getRunFlyout() {
    debugger;
    this.RunListCols = [];
    this.lstRuns = [];
    this.DataViewObj.Run = null;
    this.RunListCols.push({ Key: "Plantcode", Value: "Plant #" });
    this.RunListCols.push({ Key: "RunNumber", Value: "Run #" });

    this.testCreationService.GetRunFlyout(this.DataViewObj.Plant)
      .subscribe(
        (data: any) => {
          debugger;
          this.lstRuns = data;
        },
        err => { }
        //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      );
  }
  getPlantFlyout() {
    debugger;

    this.plantListCols.push({ Key: "Plantcode", Value: "Plant #" });
    this.plantListCols.push({ Key: "Location", Value: "Location" });
    this.plantListCols.push({ Key: "BuildingNumber", Value: "Building Number" });

    this.testCreationService.GetPlantFlyout()
      .subscribe(
        (data: any) => {
          debugger;
          this.lstPlants = data.lstPlants;
        },
        err => { }
        //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      );
  }

  userEid: string;
  cols: any[] = [];
  TableDataArray: any[] = [];
  //TableDataArray: DataViewerTableModel[] = [];

  searchBy: string;
  searchMainTab: string = 'WC Caculation Result Summary';
  totalRecordsFetched: number = 0
  onSearchBy(by: string) {

    this.searchBy = by;
    this.DataViewObj.User_Id = this.userEid;
    //this.DataViewObj.Category = this.searchBy;
    //switch case for getting the sub categories
    switch (this.searchBy) {
      case "Normalized Gas Yields":
        console.log("It is a NORMALIZED GAS YIELDS.");
        this.selectedVal = "Normalized Gas Yields";
        this.entries = this.dataViewerLists.GasSubCategories;
        this.defaultUnit = "F";
        break;
      case "Liquid Weights":
        console.log("It is a LIQUID WEIGHTS");
        this.selectedVal = "Liquid Weights";
        this.entries = this.dataViewerLists.LiquidSubCategories;
        this.defaultUnit = "GRAMS";
        break;
      case "Raw Product Weights":
        console.log("It is a RAW PRODUCT WEIGHTS.");
        this.selectedVal = "Raw Product Weights";
        this.entries = this.dataViewerLists.YieldSubCategories;
        break;
      case "Feed Weight(Sim Dist)":
        console.log("Feed Weight(Sim Dist)");
        this.selectedVal = "Feed Weight(Sim Dist)";
        this.entries = this.dataViewerLists.FeedSubCategories;
        break;
      case "LP Product Properties":
        console.log("It is a LP PRODUCT PROPERTIES");
        this.selectedVal = "LP Product Properties";
        this.entries = this.dataViewerLists.NmrSubCategories
        break;
      default:
        console.log("No Categories");
        this.entries = [];
        break;
    }

    this.onSearchSubCategory(by);
  }

  tempArray: any[] = [];
  onSearchSubCategory(subCategory: string) {
    this.DataViewObj.Category = subCategory;
    this.exportData.forEach(element => {
      element.childrens.forEach(child => {
         child.export = false;
       })
    })
    this.exportData.map(x=>{x.childrens.map(y => {if(y.description == subCategory){y.export = true;}})});
    this.service.GetTableData(this.DataViewObj)
      .subscribe(
        (data: any) => {
          this.TableDataArray = [];
          this.cols = [];
          this.TableDataArray = data;
          this.totalRecordsFetched = data.length;
          debugger;
          console.log(this.TableDataArray);
          if (this.TableDataArray.length != 0) {
            Object.keys(this.TableDataArray[0]).forEach(item => {
              if (item == "PARAMETER_NM") {
                this.cols.push({ field: "PARAMETER_NM", header: "Parameter" });
              } else if (item == "UOM_GROUP_NM") {
                this.cols.push({ field: "UOM_GROUP_NM", header: "UOM" });
              } else {
                this.cols.push({ field: item, header: item });
              }
            })
            let test = this.cols.sort((a, b) => a.field - b.field);
            this.cols.splice(0, 0, this.cols[this.cols.length - 3]);
            this.cols.splice(1, 0, this.cols[this.cols.length - 2]);
            this.cols.splice(1, 0, this.cols[this.cols.length - 1]);
            this.cols.splice(this.cols.length - 3, 3);
            console.log(test);
          }

          // this.TableDataArray.sort((a, b) => a.Field - b.Field);

        });

  }

  selectedVal: string = "Normalized Gas Yields";
  entries: any[] = [];



}
