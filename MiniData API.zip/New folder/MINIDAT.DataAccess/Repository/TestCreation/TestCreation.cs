﻿using Calculations;
using MINIDAT.Calculation;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model.Test;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.TestCreation
{
    public class TestCreation: CalculationStatusReceiver
    {
        public SynchronizationContext objContext;
        public TestModel _test { get; set; }
        public string _userId { get; set; }
        public TestCreation(TestModel test, string userId)
        {
            this._test = test;
            this._userId = userId;
        }

        #region Calculation Receiver Members
        /// <summary>
        /// CalculationCompleted
        /// </summary>
        /// <param name="objResult"></param>
        public void CalculationCompleted(CalculationResult objResult)
        {
            DataSet wcResults = objResult.Result as DataSet;
            DataSet dsResults = new DataSet();
            DataTable dtTable = GenericMethods.CreateTable("Result");
            foreach (DataTable dtResult in wcResults.Tables)
            {
                dtTable.Merge(dtResult);
            }
            dsResults.Tables.Add(dtTable);
            string strCalcXml = dsResults.GetXml();
            try
            {
                ITestCreationRepository _testRepository = new TestCreationRepository(new MINIDATDatabase());
                //_testRepository.SaveCalculationResults(this._test.Plant, this._test.Run, this._test.Test, strCalcXml, this._userId);
                //objContext = SynchronizationContext.Current;
                //if (objContext != null)
                //{
                //    objContext.Send((object obj) =>
                //    {
                //        IsExecuting = false;
                //        if (true)
                //        {
                //            //OpenWcResultSummary();
                //            //SearchTests(test);
                //        }
                //    }, null);
                //}
            }
            catch (Exception ex)
            {
                throw ex;
                //if (objContext != null)
                //{
                //    objContext.Send((object obj) =>
                //    {
                //        IsExecuting = false;

                //    }, null);
                //}
            }

        }
        public bool isExecuting = false;

        /// <summary>
        /// IsExecuting
        /// </summary>
        public bool IsExecuting
        {
            get
            {
                return isExecuting;
            }
            set
            {
                isExecuting = value;
            }
        }

        /// <summary>
        /// ProgressUpdate
        /// </summary>
        /// <param name="dProgress"></param>
        public void ProgressUpdate(double dProgress)
        {

        }
        #endregion


    }
}
