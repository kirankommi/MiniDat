﻿using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.UOM;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace MINIDAT.DataAccess.UOM
{
    public class DefineDefaultUomPrecisionDAL
    {

        #region Private Members
        private UnitGroupDAL unitGroupDal = new UnitGroupDAL();

        #endregion Private Members

        #region GetVariableWithUomAndPrecision

        /// <summary>
        /// Get the intial Data for the Define Default Screen
        /// </summary>
        /// <param name="template">Template</param>
        /// <param name="module">Module</param>
        /// <returns>ObservableCollection of TemplateVariableEntity</returns>
        public ObservableCollection<TemplateVariableEntity> GetTemplateVariableInitialData(IList<UOMTemplate> Templates, IList<ModuleEntity> Modules)
        {
            try
            {
                ObservableCollection<TemplateVariableEntity> templateVariables = new ObservableCollection<TemplateVariableEntity>();
            Templates = Templates ?? new List<UOMTemplate>();
            Modules = Modules ?? new List<ModuleEntity>();
            #region setting up DBCommand with parameters
            Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
            using (DbCommand command = db.GetStoredProcCommand("Get_UOM_Template_Mstr_Sp"))
            {
                db.AddInParameter(command, "proc_vr_Template_NM", DbType.String, DBNull.Value);
                db.AddInParameter(command, "proc_in_Variable_Category_Id", DbType.Int32, DBNull.Value);
                db.AddInParameter(command, "Proc_in_Uom_Template_Id", DbType.Int32, DBNull.Value);
                db.AddInParameter(command, "proc_bl_Master_Data_Ind", DbType.Int32, 1);

                #endregion

                #region Execute and populate data
                IDataReader objSqlDr = db.ExecuteReader(command);
                if (objSqlDr != null)
                {

                    Templates.Add(new UOMTemplate { TemplateName = "Select" });
                    while (objSqlDr.Read())
                    {
                        UOMTemplate templateRecord = new UOMTemplate
                        {
                            TemplateName = Convert.ToString(objSqlDr["UOM_TEMPLATE_NM"]),
                            TemplateId = Convert.ToInt32(objSqlDr["UOM_TEMPLATE_ID_SQ"]),
                        }; Templates.Add(templateRecord);

                    }
                }

                objSqlDr.NextResult();
                Modules.Add(new ModuleEntity { ModuleName = "Select" });
                while (objSqlDr.Read())
                {
                    ModuleEntity ModuleRecord = new ModuleEntity
                    {
                        ModuleName = Convert.ToString(objSqlDr["VARIABLE_CATEGORY_NM"]),
                        ModuleId = Convert.ToInt32(objSqlDr["VARIABLE_CATEGORY_ID_SQ"]),
                    };
                    Modules.Add(ModuleRecord);
                }

                objSqlDr.NextResult();
                while (objSqlDr.Read())
                {
                    TemplateVariableEntity VariableRecord = new TemplateVariableEntity
                    {
                        VariableID = Convert.ToInt32(objSqlDr["UOM_VARIABLE_ID_SQ"]),
                        VariableName = Convert.ToString(objSqlDr["UOM_VARIABLE_NM"]),
                        DefaultUnitName = Convert.ToString(objSqlDr["DEFAULT_UNIT_NM"]),
                        UnitGroup = unitGroupDal.GetUnitGroupByName(Convert.ToString(objSqlDr["BASE_GRP_NM"])),
                    };

                    templateVariables.Add(VariableRecord);
                }
            }
            #endregion
            return templateVariables;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion GetVariableWithUomAndPrecision

        #region GetVariableWithUomAndPrecision

        /// <summary>
        /// Get the Variable list for given template and module
        /// </summary>
        /// <param name="template">Template</param>
        /// <param name="module">Module</param>
        /// <returns>ObservableCollection of TemplateVariableEntity</returns>
        public ObservableCollection<TemplateVariableEntity> GetTemplateVariableInfo(UOMTemplate template, ModuleEntity module)
        {
            try
            {
                ObservableCollection<TemplateVariableEntity> templateVariables = new ObservableCollection<TemplateVariableEntity>();

            #region setting up DBCommand with parameters
            Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
            using (DbCommand command = db.GetStoredProcCommand("Get_UOM_Template_Mstr_Sp"))
            {
                if (template != null)
                {
                    db.AddInParameter(command, "proc_vr_Template_NM", DbType.String, template.TemplateName);
                    db.AddInParameter(command, "Proc_in_Uom_Template_Id", DbType.Int32, template.TemplateId);
                }
                if (module != null)
                {
                    db.AddInParameter(command, "proc_in_Variable_Category_Id", DbType.Int32, module.ModuleId);
                }
                db.AddInParameter(command, "proc_bl_Master_Data_Ind", DbType.Int32, 0);

                #endregion

                #region Execute and populate data
                IDataReader objSqlDr = db.ExecuteReader(command);
                if (objSqlDr != null)
                {
                    while (objSqlDr.Read())
                    {
                        TemplateVariableEntity VariableRecord = new TemplateVariableEntity
                        {
                            VariableID = Convert.ToInt32(objSqlDr["UOM_VARIABLE_ID_SQ"]),
                            VariableName = Convert.ToString(objSqlDr["UOM_VARIABLE_NM"]),
                            DefaultUnitName = Convert.ToString(objSqlDr["DEFAULT_UNIT_NM"]),
                            UnitGroup = unitGroupDal.GetUnitGroupByName(Convert.ToString(objSqlDr["BASE_GRP_NM"])),
                            Precision = Convert.ToString(objSqlDr["VARIABLE_DECIMAL_PNT"]),
                        };
                        templateVariables.Add(VariableRecord);
                    }
                }
            }
            #endregion
            return templateVariables;
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }

        #endregion GetVariableWithUomAndPrecision

        #region UpdateVariables

        /// <summary>
        /// Update the Template Varibales
        /// </summary>
        /// <param name="variables">List of variables</param>
        /// <returns>true if update succeeded otherwise false</returns>
        public bool UpdateVariables(ObservableCollection<TemplateVariableEntity> variables, int TemplateId, string CurrentUserEid)
        {
            try
            {
                if (variables != null)
                {
                    #region Serializing the List as XML
                    XmlSerializer serializer = new XmlSerializer(variables.GetType());
                    StringBuilder strBuilder = new StringBuilder();
                    using (StringWriter strWriter = new StringWriter(strBuilder))
                    {
                        serializer.Serialize(strWriter, variables);
                    }
                    //strBuilder.Replace("utf-16", "utf-8");
                    #endregion

                    #region executing the db command
                    Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                    using (DbCommand command = db.GetStoredProcCommand("Update_Uom_Variable_Sp"))
                    {
                        db.AddInParameter(command, "proc_cl_Uom_variable_Xml", DbType.String, strBuilder.ToString());
                        db.AddInParameter(command, "Proc_in_Uom_Template_Id", DbType.Int32, TemplateId);
                        db.AddInParameter(command, "proc_dt_Created_By_User_Id", DbType.String, CurrentUserEid);
                        int intErrorCode = db.ExecuteNonQuery(command);

                        if (intErrorCode == 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                return false;
                #endregion
            }
            catch (Exception ex)
            {
                //LogManager.Error(ex);
                throw;
            }
        }
        #endregion UpdateVariables
    }
}
