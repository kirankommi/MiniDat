import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AlertMessage } from '../../services/alertmessage.service';
import * as  Constants from '../../Shared/globalconstants';
import { DownloadFromStream } from './downloadFromStream';
import { FileModel } from '../../Models/file.model';

@Component({
  templateUrl: "bulkupload.component.html",
    selector: "upload-bulk"
})
export class bulkUploadComponent implements OnInit {
    @Input()
    fileLst: FileModel[] = [];
    @Input() handler: uploadHandler;
    deleteIDs: number[] = [];


    uploadIconPath: string;
    downloadIconPath: string;
    detailsIconPathEn: string;
    detailsIconPathDis: string;
    deleteIconPathEn: string;
    deleteIconPathDis: string;

    constructor(private alertMessage: AlertMessage) {
        this.uploadIconPath = Constants.uploadIcon_black;
        this.downloadIconPath = Constants.downloadIcon;
        this.detailsIconPathEn = Constants.detailsIconEn;
        this.detailsIconPathDis = Constants.detailsIconDis;
        this.deleteIconPathEn = Constants.deleteIconEn;
        this.deleteIconPathDis = Constants.deleteIconDis;
    }

    ngOnInit(): void {
        this.handler.alertMessage = this.alertMessage;
    }

    onClick() {
        //alert(this.handler.uploadFileValidation(new FileModel()));
    }

    descChanged(file: FileModel, event) {
        file.isDirty = true;
    }

    bulkUpload(event: any) {
        let errorFileName = [];
        var files = event.srcElement.files;
        if (files.length != undefined) {
            for (var i = 0; i < files.length; i++) {
                let file = event.srcElement.files[i];
                if (this.handler.ValidateFile(file.name, file.size)) {
                    let fMdl: FileModel = new FileModel();
                    fMdl.FileSize = file.size;
                    fMdl.FileName = file.name;
                    fMdl.FileData = file;
                    fMdl.isDirty = true;
                    this.fileLst.push(fMdl);
                }
            }
        }
    }

    

    onDownload(file: FileModel, id: number) {
       
        //let file: FileModel = this.fileLst[id];
        if (file.FileData) {
            var reader = new FileReader();
            reader.readAsBinaryString(file.FileData);
            var blob = file.FileData;
            var ua = window.navigator.userAgent;
            var msie = ua.indexOf("MSIE ");
            var chrome = ua.indexOf("Chrome");

            if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                window.navigator.msSaveOrOpenBlob(blob, file.FileName);
            }
            else {
                var objectUrl = URL.createObjectURL(blob);
                //console.log("objectUrl  :   " + objectUrl);
                var link = document.createElement("A");
                link.setAttribute("href", objectUrl);
                //link.setAttribute("download", fileName + "." + contentType);
                link.setAttribute("download", file.FileName);
                link.setAttribute("target", "_blank");
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        } else {
            this.handler.downloadFile(file.UID).subscribe(data => {
                if (data != undefined && data != null) {
                  DownloadFromStream.DownloadFile(data.FileData, data.FileName, data.ContentType);
                }
            });
        }
    }
    onDeleteFile(i: number, UID: any) {
        if (!isNaN(parseInt(UID))) {
            this.deleteIDs.push(UID);
        }
        this.fileLst.splice(i, 1);
    }

    onUpload(event: any, id: any) {
        let file = this.fileLst[id];
        var files = event.srcElement.files;
        if (files.length > 0 && file != undefined && file != null) {
            if (this.handler.ValidateFile(event.srcElement.files[0].name, event.srcElement.files[0].size)) {
                file.FileName = files[0].name;
                file.FileSize = files[0].size;
                file.FileData = files[0];
                file.isDirty = true;
            }
        }
    }

    getSaveData(): any {
        let duplicateFiles: any[] = [];
        for (var i = 0; i < this.fileLst.length - 1; i++) {
            if (this.fileLst[i].FileName == this.fileLst[i + 1].FileName && this.fileLst[i].Description == this.fileLst[i + 1].Description) {
                duplicateFiles.push(this.fileLst[i].FileName);
            }
        }

        if (duplicateFiles.length > 0) {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: duplicateFiles.join(","), detail: "Duplicate files exist with same name and description." });
            return "Error";
        }
        else {
            return {
                files: this.fileLst, deleteIds: this.deleteIDs.join(',')
            };
        }
    }
}






export class uploadHandler {

    //uploadFileValidation: (file: FileModel) => boolean = () => {
    //  return false;
    //}

    public alertMessage: AlertMessage;
    fileDeletedMsg: string = "File Deleted Successfully";
    fileSizeMsg: string = "File Size limit Exceeded";
    fileTypeMsg: string = "Selected File type is not Allowed";
    fileNameError: string = "File name cannot exceed 100 characters !";

    constructor() {

    }

    public downloadFile: (fileID: number) => Observable<any>;

    ValidateFile: (fileName: string, fileSize: number) => boolean = (fileName: string, fileSize: number) => {
        let isValidType = false;
        let isValidSize = false;
        if (fileName != undefined && fileName != null && fileName.trim() != '') {
            //var type = fileName.split('.')[fileName.split('.').length - 1];
            var type = fileName.split('.')[fileName.split('.').length - 1].toLowerCase();
            if (type == "jpg" || type == "jpeg" || type == "png" || type == "doc" || type == "docx" || type == "xls" || type == "xlsx" || type == "pdf" || type == "ppt" || type == "pptx" || type == "csv" || type == "txt") {
                isValidType = true;
            }
            else {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileTypeMsg })
            }
            if (fileName.length > 100) {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileNameError })
                return false;
            }
            if (fileSize / 1048576 <= 6) {
                isValidSize = true;
            }
            else {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: fileName, detail: this.fileSizeMsg })
            }
        }
        return isValidType && isValidSize;
    }

}
