﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface INIRModelTemplateRepository : ICRUDRepository<NIRModelTemplateModel>
    {
        NIRModelTemplateSearchModel GetNIRModelTemplateData();
        List<NIRModelTemplateModel> SearchNIRTemplateData(NIRModelTemplateModel NIRModelTemplateModel);
        void SaveNIRModelTemplate(NIRModelTemplateModel NIRModelTemplateModel, string userId);
        string DeleteNIRModelTemplate(NIRModelTemplateModel NIRModelTemplateModel);
        List<FeedInfo> GetSelectedFeedList(string feedName);

    }
}
