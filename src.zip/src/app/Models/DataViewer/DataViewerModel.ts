export class DataViewerModel{
    Plant: string;
    Run: number;
    Test: number;
    Category:string;
    User_Id:string;
}
export class DataViewerTableModel{
    PARAMETER_NM:string;
    UOM_GROUP_NM:string;
    PARAM_DISPLAY_ORDER_NUM:any;
    RunTest_Id ?:any;
}