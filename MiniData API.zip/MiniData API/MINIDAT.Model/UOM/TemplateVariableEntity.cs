﻿using System.Xml.Serialization;


namespace MINIDAT.Model.UOM
{
    public class TemplateVariableEntity
    {

        #region Private_Members

        private int variableId;
        private string defaultPrecision;
        private string defaultUnitName;
        private UnitGroup unitGroup;
        private string variableName;

        #endregion Private_Members

        #region Public_Properties

        /// <summary>
        /// Get or set the Variable Id
        /// </summary>
        public int VariableID
        {
            get
            {
                return variableId;
            }
            set
            {
                variableId = value;
            }
        }

        /// <summary>
        /// Get or set the Default Precision
        /// </summary>
        public string Precision
        {
            get
            {
                return defaultPrecision;
            }
            set
            {
                defaultPrecision = value;
            }
        }

        /// <summary>
        /// Get or set the Unit Group Name
        /// </summary>
        [XmlIgnore]
        public UnitGroup UnitGroup
        {
            get
            {
                return unitGroup;
            }
            set
            {
                unitGroup = value;
            }
        }

        /// <summary>
        /// Get or set the Variable Name
        /// </summary>
        public string VariableName
        {
            get
            {
                return variableName;
            }
            set
            {
                variableName = value;
            }
        }

        /// <summary>
        /// Get or set the default unit name for the Variable
        /// </summary>
        public string DefaultUnitName
        {
            get
            {
                return defaultUnitName;
            }
            set
            {
                defaultUnitName = value;
            }
        }

        #endregion Public_Properties

    }
}
