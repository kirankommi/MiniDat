﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystShapeRepository : ICRUDRepository<CatalystShapeModel>
    {
        CatalystShapeSearchModel GetCatalystShapeData(CatalystShapeModel catalystType);
        string DeleteCatalystShapeData(CatalystShapeModel catalystType);
        void SaveCatalystShapeData(CatalystShapeModel _catalystType, string userId); 

    }
}
