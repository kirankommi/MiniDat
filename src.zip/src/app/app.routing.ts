import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CreateProjectComponent } from './Components/Project/CreateProject/createproject.component';
import { UnauthorizedAccessComponent } from './Components/UnauthorizedAccess/Unauthorized.component';
import { routeResolver } from './services/route/routeresolver';
import { FeedComponent } from './Components/Feed/Feed.component';
import { RecipeSppComponent } from './Components/RecipeSPPTemp/recipespp.component';
import { TestCreationComponent } from './Components/TestCreation/TestCreation.component';
import { DataViewerComponent } from './Components/data-viewer/data-viewer.component';
//import { RunFeedComponent } from './Components/Run/Run-Feed/RunFeed.component';
//import { GeneralInfoComponent } from './Components/Run/GeneralInfo/GeneralInfo.component';

const appRoutes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'unauthorizedUser',
    component: UnauthorizedAccessComponent
  },
  {
    path: 'Manage',
    loadChildren: './Components/Manage/manage.module#manageModule'
  },
  {
    path: 'Experiment',
    loadChildren:'./Components/DOE/experiment.module#experimentModule'
  },
  {
    path: 'Catalyst',
    loadChildren: './Components/Catalyst/catalyst.module#catalystModule'
  },
  {
    path: 'Project',
    loadChildren: './Components/Project/project.module#projectModule'
  },
  {
    path:'minisq',
    loadChildren:'./Components/minisQ/minisQ.module#MinisQModule'

  },
  {
    path: 'Feed',
    component: FeedComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
      path: 'Recipe',
      component: RecipeSppComponent
      
  },
  {
      path: 'Run',
      loadChildren: './Components/RunSetup/run.module#runModule'
  },
  {
      path: 'PlantData',
      loadChildren:'./Components/TestCreation/TestCreation.module#TestCreationModule'
      //component: TestCreationComponent
  },
  {
    path: 'CheckRawData',
    loadChildren:'./Components/CheckRawData/CheckRawData.module#checkRawDataModule'
    //component: TestCreationComponent
  },
  {
    path: 'DataViewer', 
      component: DataViewerComponent,
    //loadChildren: './Components/data-viewer/data-viewer.module#DataViewerModule',
    resolve: {
      UOM: routeResolver
    } // use it when necessary
 
},
  //{
  //    path: 'RunFeed',
  //    component: RunFeedComponent,
  //    resolve: {
  //        UOM: routeResolver
  //    }
  //},
  //{
  //    path: 'GeneralInfo',
  //    component: GeneralInfoComponent
  //},
];

export const appRoutingProviders: any[] = []
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, { useHash: true });
