﻿import { Component, OnInit, ViewChild, ElementRef, Renderer, Input, Output, EventEmitter } from '@angular/core';
import { messageModalUtility } from '../../Shared/message-modal.utility';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as Constants from '../../Shared/globalconstants';
import { AlertMessage } from '../../services/alertmessage.service';
import { KeyValue } from '../../Models/UserModel';
import { AppComponent } from '../../app.component';

import { LIMSResultService } from '../../services/CatalystServices/limscomponent.service';

@Component({
    //moduleId: module.id,
    selector: 'view-lims',
    templateUrl: 'viewlims.component.html',
    providers: [AlertMessage, LIMSResultService]
})

export class ViewLimsComponent implements OnInit {
    @Input() analysisMethods: any;
    @Input() limsValidations: any;
    @Input() catalystId: number;
    @Output() limsEvent = new EventEmitter();
    selectedTab: any;    ISDropDown: boolean;
    //ISValid: boolean;
    validation: any;
    autoMapMissingsCount: number;
    options: ValidationInterfaceI[];
    //selectedOption: string = 'U';
    selectedValues = [];
    // LimsValidations = {};
    Quality: any;
    selectedValue: string;
    isLoading: boolean = false;
    constructor(private appComponent: AppComponent, private alertMessage: AlertMessage,
        private limsComponentService: LIMSResultService) {
        this.ISDropDown = false;

    }
    ngAfterViewInit()
    {
        
    }
    ngOnInit() {
        this.selectedTab = {};
        //debugger;
        if (this.analysisMethods && this.analysisMethods.length > 0) {
            this.analysisMethods.forEach((x: any) => {
                x.DisplayUnit = {};
                x.methodUnits = [];
            });
            this.options = [{ key: 'U', value: 'Unknown' }, { key: 'G', value: 'Good' }, { key: 'B', value: 'Bad' }];
            this.validation = [];
            this.selectedValue = 'U';
            this.GetComponents(this.analysisMethods[0].Id, this.analysisMethods[0].AnalysisMethodSource);
        }
        this.checkAutoMappingMissings();
    }

    onExit() {
        this.limsEvent.emit();
    }

    getSHeight() {
        return (window.innerHeight * 63 / 100) + "px";
    }

    CompValidationchange(event: any, sample: any, component: any) {
        if (event && sample && component) {
            let sampleId = sample.substr(0, sample.lastIndexOf('_'));
            let validationObj = this.limsValidations.filter((x: any) => x.ValidationName == event)[0];
            if (validationObj) {
                let sampleObj = component.Samples.filter((x: any) => x.LimsSampleId == sampleId)[0];
                sampleObj.validation = validationObj;
                component[sample] = validationObj;
            }
        }
    }

    SampleValidationChange(event: any, sample: any, method: any) {
        if (event && sample && method) {
            let validationObj = this.limsValidations.filter((x: any) => x.ValidationName == event)[0];
            if (validationObj) {
                method.Components.forEach((comp: any) => {
                    comp.Samples.forEach((x: any) => {
                        if (x.LimsSampleId == sample) {
                            x.validation = validationObj
                        }
                        comp[x.LimsSampleId + "_valid"] = validationObj;
                    });
                });
            }
        }
    }

    CompUOMchange(event: any, component: any) {
        if (event && component) {
            this.appComponent.isLoading = true;
            let unit = component.compUnits.filter((x: any) => x.DisplayText == event)[0];
            if (unit) {
                //let precision = this.GetPrecison(component.compUnitGrpNm);
                component.Samples.forEach((x: any) => {
                    if (x.BaseValue != null && x.BaseValue != undefined) {
                        let precision = x.Precision;
                        x.TargetValue = this.convertToTargetunit(unit, x.BaseValue);
                        if (x.TargetValue == undefined) x.TargetValue = 0;
                        x.TargetValue = parseFloat(x.TargetValue).toFixed(precision);
                        x.TargetValue = isNaN(x.TargetValue) ? '' : x.TargetValue;
                    }
                    component[x.LimsSampleId] = x.TargetValue;
                });
            }
            this.appComponent.isLoading = false;
        }
    }
    RowMethodUOMchange(event: any, method: any, ri: number, compUnits: any) {
        if (event && method) {
            //  let unit = method.methodUnits.filter((x: any) => x.DisplayText == event)[0];
            let unit = compUnits.filter(function (x) { return x.DisplayText == event; })[0];
            if (unit && method.Components && method.Components[0]) {
                // let precision = this.GetPrecison(method.Components[0].compUnitGrpNm);
                let comp = method.Components[ri];

                comp.Samples.forEach((x: any) => {
                    if (x.BaseValue) {
                        let precision = x.Precision;
                        x.TargetValue = this.convertToTargetunit(unit, x.BaseValue);
                        x.TargetValue = parseFloat(x.TargetValue).toFixed(precision);
                        x.TargetValue = isNaN(x.TargetValue) ? '' : x.TargetValue;
                    }
                    comp[x.LimsSampleId] = x.TargetValue;
                });
            }
        }
    }
    MethodUOMchange(event: any, method: any) {
        if (event && method) {
            this.appComponent.isLoading = true;
            let unit = method.methodUnits.filter((x: any) => x.DisplayText == event)[0];
            if (unit && method.Components && method.Components[0]) {
                let precision = this.GetPrecison(method.Components[0].compUnitGrpNm);
                method.Components.forEach((comp: any) => {
                    comp.Samples.forEach((x: any) => {
                        if (x.BaseValue) {
                            x.TargetValue = this.convertToTargetunit(unit, x.BaseValue);
                            x.TargetValue = parseFloat(x.TargetValue).toFixed(precision);
                            x.TargetValue = isNaN(x.TargetValue) ? '' : x.TargetValue;
                        }
                        comp[x.LimsSampleId] = x.TargetValue;
                    });
                });
                this.appComponent.isLoading = false;
            }
            else {
                this.appComponent.isLoading = false;
            }
        }
    }

    GetPrecison(unitGroupName: string) {
        let variable = Constants.UomVariables.filter((x: any) => x.UnitGroupName == unitGroupName)[0];
        if (variable != null) {
            return variable.Precision;
        }
        return 6;
    }

    convertToTargetunit(unit: any, unitValue: any) {
        if (unit && unitValue) {
            if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
                return (unit.Slope / unitValue) - unit.Intercept;
            }
            else {
                return (unitValue - unit.Intercept) / unit.Slope;
            }
        }
    }

    GetComponents(analysisId: any, methodSource: string) {
        this.selectedTab = { AnalysisId: analysisId, AnalysisSource: methodSource };
        let analysisMethod = this.analysisMethods.filter((x: any) => x.Id == analysisId)[0];
        analysisMethod.compCols = [];
        analysisMethod.Components = [];
        analysisMethod.DisplayUnit = {};
        analysisMethod.methodUnits = [];
        this.options = [{ key: 'U', value: 'Unknown' }, { key: 'G', value: 'Good' }, { key: 'B', value: 'Bad' }];
        if (this.catalystId && analysisId && methodSource && analysisMethod && analysisMethod.Components && analysisMethod.Components.length <= 0) {
            //this.appComponent.isLoading = true;
            let propCols: any = [
                { field: 'ComponentName', header: 'Component Name', isDropDown: false, isUOM: false, isSampleId: false, style: { 'width': '5%' }, ValidationCode: 'U' }
            ];
            let validationCols: any = [
                { field: 'SampleId', header: 'SampleId', isDropDown: true, isUOM: false, isSample: false, isSampleId: false, style: { 'width': '5%' } }
            ];
            this.limsComponentService.GetMethodComponents(this.catalystId, analysisId, methodSource)
                .subscribe(
                (data: any) => {
                    debugger;
                    //console.log(methodSource);
                    //console.log(data);
                    switch (methodSource) {
                        case 'Property':
                            this.isLoading = true;
                            let phyComps = this.MapPropertyComponents(data);
                            let DBValidationCodes = [];
                            this.validation = [];
                            //console.log(phyComps);
                            if (phyComps && phyComps[0]) {

                                phyComps.forEach((phyComp: any) => {
                                    phyComp.SampleNames.forEach((x: any) => {
                                        if (propCols.filter((p: any) => p.field == x.SampleId).length == 0) {

                                            propCols.push({ field: x.SampleId, header: x.SampleId.toString(), isDropDown: true, isUOM: false, isSample: true, isSampleId: false, style: { 'width': '5%' }, ValidationCode: x.ValidationCode.ValidationCode });//ValidationCode: x.ValidationCode.ValidationCode
                                            propCols.push({ field: x.SampleId + "_valid", header: "Validate", isDropDown: true, isUOM: false, isSample: false, isSampleId: false, isValidate: true, style: { 'width': '5%' } });
                                        }
                                    })
                                });
                            }
                            propCols.push({ field: 'UOM', header: 'UOM', isDropDown: true, isUOM: true, isSample: false, isSampleId: false, style: { 'width': '5%' } });
                            analysisMethod.compCols = propCols;
                            analysisMethod.Components = phyComps;
                            analysisMethod.Components.forEach((Component: any) => {
                                Component.Samples.forEach((sample: any) => {                                   
                                    let varri = this.validation.filter(i => i.SampleId == sample.LimsSampleId && i.ComponentName == sample.ComponentName )[0];
                                    if (!varri) {
                                        this.validation.push({ Validation: sample.validation.ValidationName, SampleId: sample.LimsSampleId, ComponentName: sample.ComponentName });
                                    }
                                });

                            }); //today 1st Feb
                            //analysisMethod.compCols.forEach((x: any) => {
                            //    if ((x.field == x.header) && (x.field != 'UOM') && (x.field != 'ComponentName')) {

                            //        this.validation.push({ Validation: x.ValidationCode, SampleId: x.header });//
                            //    }
                            //});//today 1stfeb
                            this.isLoading = false;
                            break;
                        case 'GC':
                        case 'Sim Dist':
                            //data.splice(0, 1);
                            let gcComps = this.MapPropertyComponents(data);
                            //console.log(gcComps);
                            if (gcComps && gcComps[0]) {
                                gcComps[0].Samples.forEach((x: any) => {
                                    propCols.push({ field: x.LimsSampleId, header: x.LimsSampleId.toString(), isSampleId: true, validation: x.validation, style: { 'width': '5%' } });
                                });
                                analysisMethod.DisplayUnit = gcComps[0].compDisplayUnit;
                                analysisMethod.methodUnits = gcComps[0].compUnits;
                            }
                            propCols.push({ field: 'UOM', header: 'UOM', isDropDown: true, isUOM: true, isSample: false, isSampleId: false, style: { 'width': '5%' } });
                            analysisMethod.compCols = propCols;
                            analysisMethod.Components = gcComps;
                            //console.log(analysisMethod);
                            break;
                    }
                   // this.appComponent.isLoading = false;
                },
                err => {
                    this.isLoading = false;
                    //this.appComponent.isLoading = false;
                    //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                });
        }
    }
    DropDownValidate(event: any, col: any, comp: any) {

        debugger;

        this.validation.forEach((validate: any) => {
            console.log("SampleID:" + validate.SampleId);
            if ((validate.SampleId == col.header) && (validate.ComponentName == comp.ComponentName)) {
                switch (event) {
                    case "U": {
                        validate.Validation = "Unknown";
                        this.selectedValue = "Unknown";
                    }
                    case "G":
                        {
                            validate.Validation = "Good";
                            this.selectedValue = "Good";
                        }
                    case "B": {
                        validate.Validation = "Bad";
                        this.selectedValue = "Bad";
                    }
                }
                console.log("ValidationCode:" + validate.Validation);
                console.log("SelectedValue:" + this.selectedValue);
            }
        });
        let k = this.validation;



    }
    MapPropertyComponents(data: any) {
        let components = data;
        let methodComponents: any = [];
        components.forEach((x: any) => {
            let comp = { ComponentId: x.ComponentId, ComponentName: x.Component, compUnits: x.PropertyUnitGroup.Units, compDisplayUnit: x.PropertyDisplayUnit, compUnitGrpNm: x.PropertyUnitGroup.UnitGroupName };
            let samples: any = [];
            let sampleNames: any = [];
            let arrayNames: any = [];
            x.LimsSampleValues.forEach((y: any) => {
                if (y.LimsID != 0) {
                    let arr: Array<string> = y.Precision.split('.');
                    let _precision = 2;
                    if (arr.length == 2) {
                        _precision = arr[1].length;
                    }

                    let sample = { BaseValue: y.BaseValue, LimsSampleId: y.LimsSampleId, validation: {}, TargetValue: y.TargetValue, Precision: _precision, ComponentName: comp.ComponentName };
                    sample.validation = (y.SelectedValidation) ? y.SelectedValidation : this.limsValidations.filter((s: any) => s.ValidationCode == "U")[0];
                    samples.push(sample);
                    sampleNames.push({ SampleId: y.LimsSampleId, ValidationCode: sample.validation });



                    comp[y.LimsSampleId] = y.BaseValue;
                    comp[y.LimsSampleId + "_valid"] = y.SelectedValidation;
                }
            });
            comp["Samples"] = samples;
            comp["SampleNames"] = sampleNames;
            comp["ArrayNames"] = arrayNames;
            this.CompUOMchange(comp.compDisplayUnit.DisplayText, comp);

            //this.DropDownValidate(sampleNames, comp);
            methodComponents.push(comp);
        });
        return methodComponents;
    }

    Reset() {
        if (this.selectedTab && this.selectedTab.AnalysisId && this.selectedTab.AnalysisSource) {
            this.GetComponents(this.selectedTab.AnalysisId, this.selectedTab.AnalysisSource);
        }
    }

    Save() {
        this.appComponent.isLoading = true;
        let analysisMethod = this.MapUpdateModal();
        if (analysisMethod && analysisMethod.SampleList && analysisMethod.SampleList.length > 0) {
            this.limsComponentService.UpdateLimsResults(analysisMethod)
                .subscribe(
                (data: any) => {
                    this.alertMessage.displayMessage({ severity: (data > 1) ? Constants.severitySuccess : Constants.severityWarn, summary: '', detail: (data > 1) ? "Details Saved Successfully" : "Details has not Saved" })
                    this.appComponent.isLoading = false;
                },
                err => {
                    this.appComponent.isLoading = false;
                    // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                });
        }
        this.appComponent.isLoading = false;
    }


    MapUpdateModal() {
        let methodDetails = this.analysisMethods.filter((x: any) => x.Id == this.selectedTab.AnalysisId)[0];
        let sampleDetails: any = [];
        let analysisMethod = { MethodSource: methodDetails.AnalysisMethodSource, CatalystId: this.catalystId, SampleList: sampleDetails };

        if (methodDetails.AnalysisMethodSource != "Property" && methodDetails.Components && methodDetails.Components[0]) {
            methodDetails.Components[0].Samples.forEach((x: any) => {
                sampleDetails.push({
                    CatalystId: this.catalystId,
                    MethodId: methodDetails.Id,
                    MethodName: methodDetails.Name,
                    MethodSource: methodDetails.AnalysisMethodSource,
                    SampleId: x.LimsSampleId,
                    ValidationCode: x.validation.ValidationCode
                });
            });
        }
        else {
            methodDetails.Components.forEach((x: any) => {
                let qualityCheck = [];
                debugger;
                x.Samples.forEach((s: any) => {
                    sampleDetails.push({
                        CatalystId: this.catalystId,
                        MethodId: methodDetails.Id,
                        MethodName: methodDetails.Name,
                        MethodSource: methodDetails.AnalysisMethodSource,
                        SampleId: s.LimsSampleId,
                        ValidationCode: s.validation.ValidationCode,
                        ComponentName: x.ComponentName,
                    });
                });
                this.validation.forEach((k: any) => {
                    sampleDetails.forEach((v: any) => {
                        if ((k.SampleId == v.SampleId) && (k.ComponentName == v.ComponentName)) {
                            if (k.Validation == "Unknown")
                                v.ValidationCode = "U";
                            else if (k.Validation == "Good")
                                v.ValidationCode = "G";
                            else if (k.Validation == "Bad")
                                v.ValidationCode = "B";

                        }
                    });
                });//AFTER sampleDetails array is created, we are modifying the validationCode value

                //sampleDetails.forEach()
            });
        }

        if (sampleDetails && sampleDetails.length > 0) {
            analysisMethod.SampleList = sampleDetails;
        }
        return { MethodSource: methodDetails.AnalysisMethodSource, CatalystId: this.catalystId, SampleList: sampleDetails };
    }
    checkAutoMappingMissings() {
        //this.limsComponentService.getMissingCount(this.feedId.toString()).subscribe(d => {
        //    this.autoMapMissingsCount = +d;
        //})
    }
}
export interface ValidationInterfaceI {
    key: string;
    value: string;
}
