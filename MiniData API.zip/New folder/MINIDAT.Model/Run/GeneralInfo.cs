﻿using MINIDAT.Model.Catalyst;
using System.Collections.Generic;
using System.Linq;

namespace MINIDAT.Model.Run
{
    public class GeneralInfoModel
    {       
        public string ModeType { get; set; }
        public string FeedCondition { get; set; }
        public string NetworkNumber { get; set; }
        public string projectMgr { get; set; }
        public string Technician1 { get; set; }
        public string Technician2 { get; set; }
        public string Technician1EID { get; set; }
        public string Technician2EID { get; set; }
        public string RunDescription { get; set; }
    }

   
}
