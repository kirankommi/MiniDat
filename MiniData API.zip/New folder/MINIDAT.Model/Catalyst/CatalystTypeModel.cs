﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystTypeModel
    {
        public int? CatalystTypeID { get; set; }
        public string CatalystType { get; set; }
        public string Description { get; set; }
        public string StatusName { get; set; } 
        public KeyValue StatusCode { get; set; }    

    }
    public class CatalystTypeSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalystTypeModel> _lstcatalystTypes = new List<CatalystTypeModel>();
        public IList<CatalystTypeModel> LstcatalystTypes { get { return _lstcatalystTypes; } }

        public int RecordsFetched { get; set; }

    }
}
