import { AppComponent } from '../app.component';
import * as Constants from '../Shared/globalconstants';
import { AlertMessage } from './alertmessage.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { CanActivate } from '@angular/router';
import { HttpActionService } from './httpaction.service';
import { appService } from './app.service';

@Injectable()
export class RouterAuthService implements CanActivate {

  constructor(private app: appService, private router: Router) {
    }
    getPathWithOutQueryString(url: string) {
        return url.split('?')[0];
    }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean {
        let currentUrl = state.url.toLocaleLowerCase();
        let rootData: any = route.data;
        if (rootData && rootData.authMatch) {
            currentUrl = rootData.authMatch;
        } else if (route.children) {
            route.children.forEach((x: any) => {
                if (x.data && x.data.authMatch) {
                    currentUrl = x.data.authMatch;
                }
            })
        }
        currentUrl = this.getPathWithOutQueryString(currentUrl);
        let promise: Promise<boolean> = new Promise((resolve, reject) => {
            this.app.getSessionData().subscribe((data: any) => {
                if (data.Privileges.filter(x => currentUrl.toLowerCase() == ('/' + x.Action).toLowerCase()).length > 0) {
                    resolve(true);
                } else {
                    let alertMessage = new AlertMessage();
                    alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: "You are not authorized to access this page" })
                    this.router.navigateByUrl('/');
                    resolve(false);
                }

            })
        });
        return promise;
    }

}
