﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Manage.Mode
{
    public class SPPModel
    {
        public List<SPPModelInfo> lstModelInfo { get; set; }
    }
    public class SPPModelInfo
    {
        public int? PairNumber { get; set; }
        public double? RampRate { get; set; }
        public string SoakValue { get; set; }
        public int? SoakTime { get; set; }
        public int? RampReciepeNumber { get; set; }
        public int? SoakReciepeNumber { get; set; }
        public string Description { get; set; }
    }
}
