﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class TC_Calibration
    {     
        public string ParameterName { get; set; }
        public double? Value { get; set; }
        public string ParameterUOM { get; set; }
        public string ParameterType { get; set; }
        public int? OffSetNum { get; set; }
        //public string CalibrationchangeDate { get; set; }
        public DateTime? CalibrationDate { get; set; }
    }
}
