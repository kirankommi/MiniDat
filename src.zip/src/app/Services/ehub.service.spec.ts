import { TestBed, inject } from '@angular/core/testing';

import { EhubService } from './ehub.service';

describe('EhubService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EhubService]
    });
  });

  it('should be created', inject([EhubService], (service: EhubService) => {
    expect(service).toBeTruthy();
  }));
});
