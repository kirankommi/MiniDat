﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystFamilyModel, KeyValue } from '../../Models/Catalyst/CatalystFamilyModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystFamilyService {
    private getCatalystFamilydata = "/CatalystFamily/SearchCatalystFamilydata/";
    private saveCatalystFamilydata = "/CatalystFamily/SaveCatalystFamilyInformation/";
    private deleteCatalystFamilydata = "/CatalystFamily/DeleteCatalystFamilyInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystFamilyInformatin(catalystFamily: CatalystFamilyModel) {

        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystFamily, this.getCatalystFamilydata);
    }

    saveCatalystFamilyInformation(catalystFamily: CatalystFamilyModel)
    {
        return this.httpaction.post(catalystFamily, this.saveCatalystFamilydata);
    }

    deleteCatalystFamily(catalystFamily: CatalystFamilyModel)
    {
        debugger;
        return this.httpaction.post(catalystFamily, this.deleteCatalystFamilydata);
    }    
}
