import { Injectable } from '@angular/core';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { DataViewerModel } from 'src/app/Models/DataViewer/DataViewerModel';

@Injectable({
  providedIn: 'root'
})
export class DataViewerService {

  private GetTableDataViewer: string = "/DataViewer/GetDataForDataViewer";
  private ExportDataViewer: string = "/DataViewer/ExportDataViewer";
  constructor(private httpAction: HttpActionService) { }

  GetTableData(dataviewInput:DataViewerModel) {
    let params: URLSearchParams = new URLSearchParams();
    // params.set('projectId', projectId);
    params.set('Category', dataviewInput.Category);
    params.set('Plant', dataviewInput.Plant);
    params.set('User_Id', dataviewInput.User_Id);
    params.set('Run', dataviewInput.Run.toString());
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.get(this.GetTableDataViewer,options);
  }
  GetExportData(dataviewInput:DataViewerModel) {
    let params: URLSearchParams = new URLSearchParams();
    params.set('Category', dataviewInput.Category);
    params.set('Plant', dataviewInput.Plant);
    params.set('User_Id', dataviewInput.User_Id);
    params.set('Run', dataviewInput.Run.toString());
    let options = new RequestOptions(Constants.getParamOptions(params));
    return this.httpAction.post(dataviewInput,this.ExportDataViewer);
  }
}
