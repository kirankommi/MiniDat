﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	AppCache.cs
 	Project Title			:	FCCDAT,MINIDAT
	Author(s)				:	Goldy Manikoth
	Created Date			:	5 Jan 2012
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MINIDAT.Model.UOM;
using MINIDAT.DataAccess.UOM;
using MINIDAT.Framework.Serializer;

namespace MINIDAT.DataAccess.Common
{
    /// <summary>
    /// Application cache class
    /// </summary>
    public class AppCache
    {
       // public ILog logger = LogManager.GetLogger(typeof(AppCache));

        #region Private Variables
        //private static IList<UnitGroup> _groups = new List<UnitGroup>(); 
        private static bool _unitLoaded;
        public delegate void UnitGroupsLoadedArgsHandler(object sender, UnitGroupsLoadedArgs e);

        public static event UnitGroupsLoadedArgsHandler OnUnitGroupsLoaded;

        #endregion

        /// <summary>
        /// Gets the unit groups.
        /// </summary>
        /// <value>The unit groups.</value> 
        private static IList<UnitGroup> _unitGroups = new List<UnitGroup>();
        public static IList<UnitGroup> UnitGroups { get { return _unitGroups; } } 

        private IList<string> _rules = new List<string>();
        public IList<string> Rules { get { return _rules; } }
        /// <summary>
        /// Sets the unit groups.
        /// </summary>
        public static void SetUnitGroups()
        {
            //get the data from Datalayer
            UnitGroupDAL group = new UnitGroupDAL();
            _unitGroups = group.GetAllUnitGroup();
            //set the status to loaded
            AppCache.IsUnitGroupsLoaded = true;
            //string data=Serializer.ConvertToXML<UnitGroup>(_groups);
        }
      

        /// <summary>
        /// Gets the name of the group by.
        /// </summary>
        /// <param name="groupName">Name of the group.</param>
        /// <returns></returns>
        public static UnitGroup GetGroupByName(string groupName)
        {
            UnitGroup group = null;
           
            if (AppCache.IsUnitGroupsLoaded)
            {
                //get the Unit group by querying the cache group data
                group = (from c in AppCache.UnitGroups where c.UnitGroupName == groupName select c).FirstOrDefault();
            }
            return group;
        }


        /// <summary>
        /// Gets the group by code.
        /// </summary>
        /// <param name="groupCode">The group code.</param>
        /// <returns></returns>
        public static UnitGroup GetGroupByCode(string groupCode)
        {
            UnitGroup group = null;

            if (AppCache.IsUnitGroupsLoaded)
            {
                //get the Unit group by querying the cache group data
                group = (from c in AppCache.UnitGroups where c.UnitGroupCD == groupCode select c).FirstOrDefault();
            }
            return group;
        }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is unit groups loaded.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is unit groups loaded; otherwise, <c>false</c>.
        /// </value>
        public static bool IsUnitGroupsLoaded
        {
            get
            {
                return _unitLoaded;
            }
            set
            {
                _unitLoaded = value;
                if (_unitLoaded)
                {
                    UnitGroupsLoadedArgs myArgs = new UnitGroupsLoadedArgs("Unit Groups Loaded.");
                    if (OnUnitGroupsLoaded != null)
                    {
                        OnUnitGroupsLoaded(_unitLoaded, myArgs);
                    }
                }

            }
        }
    }

    public class UnitGroupsLoadedArgs : EventArgs
    {
        private string message;

        public UnitGroupsLoadedArgs(string message)
        {
            this.message = message;
        }

        // This is a straightforward implementation for 
        // declaring a public field
        public string Message
        {
            get
            {
                return message;
            }
        }
    }
    
}
