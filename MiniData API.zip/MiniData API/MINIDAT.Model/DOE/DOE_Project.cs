﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DOE
{
    public class DOE_Project
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string NW1 { get; set; }
        public string NW2 { get; set; }
        public string NW3 { get; set; }
        public string  TechLead { get; set; }

    }
}
