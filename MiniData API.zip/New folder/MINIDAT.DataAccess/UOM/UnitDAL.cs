﻿using MINIDAT.Model.UOM;
using System.Collections.Generic;


namespace MINIDAT.DataAccess.UOM
{
    public class UnitDAL
    {
        public Unit GetUnitFromListByName(string unitName, IList<Unit> units)
        {
            if (units != null)
            {
                foreach (Unit unit in units)
                {
                    if (unit.UnitName == unitName)
                    {
                        return unit;
                    }
                }
            }
            return null;
        }
    }
}
