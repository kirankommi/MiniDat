﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           CustomerLocationRepository.cs
Project Title:      FeedStockDAT
Created on:         5-June-2017
Requirements Tag:   Repository for Managing Customer Location
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */



using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using MINIDAT.Model.Manage.CustomerLocation;
using MINIDAT.Models.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FDMS.DataAccess.Repository.Manage
{
    public class CustomerLocationRepository : ICustomerLocationRepository
    {

        private IDatabase _db;
        public CustomerLocationRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public void Add(CustomerLocationModel _model)
        {

        }

        public bool Delete(CustomerLocationModel _model)
        {
            if (_model == null) throw new ArgumentNullException("_model");
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("proc_vr_Customer_Nm", _model.CustomerId);
                parameters.Add("proc_vr_Customer_Alias_Nm", _model.CustomerAliasName);
                using (IDbCommand cmd = _db.CreateCommand("Delete_Customer_Alias_Sp"))
                {
                    _db.CreateParameters(cmd, parameters);
                    _db.ExecuteNonQuery(cmd);
                }
                return true;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {

            }
        }

        public IList<CustomerLocationModel> List(ICriteria _criteria)
        {
            if (_criteria == null) throw new ArgumentNullException("_criteria");
            IDataReader _reader = null;
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                //parameters.Add("EMPLOYEE_ID", _userCriteria.EmployeeID);
                //parameters.Add("LAST_NM", _userCriteria.LastName);
                //parameters.Add("FIRST_NM", _userCriteria.FirstName);
                //parameters.Add("MIDDLE_NM", _userCriteria.MiddleName);
                //parameters.Add("EMAIL_ID", _userCriteria.EmailID);
                //parameters.Add("NW_DOMAIN_NM", _userCriteria.NWDomainName);
                //parameters.Add("USER_STATUS_CD", _userCriteria.UserStatusCode);

                using (IDbCommand cmd = _db.CreateCommand("Search_User"))
                {
                    _db.CreateParameters(cmd, parameters);
                    _reader = _db.ExecuteReader(cmd);
                    List<CustomerLocationModel> _list = new List<CustomerLocationModel>();
                    return _list;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {
                if (_reader != null)
                {
                    _reader.Close();
                    //_reader.Dispose();
                }
            }
        }

        public void Update(CustomerLocationModel _model)
        {

        }


        public bool SaveCustomerData(CustomerLocationModel customer, string currentUser)
        {
            try
            {
                if (!string.IsNullOrEmpty(currentUser))
                {
                    string EID = currentUser.Substring(currentUser.IndexOf("\\") + 1);


                    //Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                    //DbCommand command = db.GetStoredProcCommand("Insert_User_Sp");

                    if (customer == null) throw new ArgumentNullException("customer");
                    using (IDbCommand command = _db.CreateCommand("Insert_Update_Customer_location_Sp"))
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("proc_vr_CustomerId", customer.CustomerId);
                        parameters.Add("proc_vr_Customer_Nm", customer.CustomerName);
                        parameters.Add("proc_vr_Customer_Alias_Nm", customer.CustomerAliasName);
                        parameters.Add("proc_vr_Customer_OldAlias_Nm", customer.CustomerOldAliasName);
                        parameters.Add("proc_vr_Created_User_Id", EID);
                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                        return true;
                    }
                }
                return false;
            }
            catch (Exception Ex)
            {
                LogManager.Error(Ex);
                throw;
            }
        }

        public CustomerLocationSearchModel GetCustomerData(CustomerLocationModel customer)
        {
            CustomerLocationSearchModel customersearchModel = new CustomerLocationSearchModel();
            IDataReader reader = null;
            try
            {
                if (customer == null) throw new ArgumentNullException("customer");
                using (IDbCommand command = _db.CreateCommand("Search_Customer_location_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_CustomerName", customer.CustomerName == null ? null : customer.CustomerName);
                    parameters.Add("proc_vr_Customer_Alias_Nm", customer.CustomerAliasName == null ? null : customer.CustomerAliasName);
                    parameters.Add("proc_vr_LocationId", Convert.ToInt32(customer.LocationId));

                    _db.CreateParameters(command, parameters);
                    customersearchModel.Customers.Clear();
                    reader = _db.ExecuteReader(command);

                    while (reader.Read())
                    {
                        CustomerLocationModel newCustomer = new CustomerLocationModel()
                        {
                            CustomerId = (reader["CUST_ID_SQ"] != DBNull.Value) ? Convert.ToInt32(reader["CUST_ID_SQ"]) : 0,
                            CustomerName = Convert.ToString(reader["CUST_NM"]),
                            CustomerAliasName = Convert.ToString(reader["CUST_ALIAS_NM"]),
                            CustomerUopNum = (reader["UOP_CUST_NUM"] != DBNull.Value) ? Convert.ToInt32(reader["UOP_CUST_NUM"]) : 0,
                            City = Convert.ToString(reader["CITY_NM"]),
                            Country = Convert.ToString(reader["COUNTRY_NM"]),
                            State = Convert.ToString(reader["STATE_NM"]),
                            CreatedBy = Convert.ToString(reader["CREATED_BY_USER_ID"]),
                            LocationId = (reader["CUST_LOCATION_ID"] != DBNull.Value) ? Convert.ToInt32(reader["CUST_LOCATION_ID"]) : 0,

                        };
                        customersearchModel.Customers.Add(newCustomer);
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        customersearchModel.RecordsFetched = Convert.ToInt32(reader["TOTAL_RECORDS"]);
                    }
                    return customersearchModel;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                    //reader.Dispose();
                }
            }
        }

        public CustomerLocationMasterModel GetMasterData()
        {
            CustomerLocationMasterModel customerMasterModel = new CustomerLocationMasterModel();
            IDataReader reader = null;
            try
            {
                using (IDbCommand command = _db.CreateCommand("Master_Customer_location_Sp"))
                {
                    customerMasterModel.Customer.Clear();
                    customerMasterModel.Location.Clear();
                    reader = _db.ExecuteReader(command);

                    while (reader.Read())
                    {
                        CustomerMaster newCustomer = new CustomerMaster()
                        {
                            Id = Convert.ToInt32(reader["CUST_ID_SQ"]),
                            Name = Convert.ToString(reader["CUST_NM"]),
                            LocationId = Convert.ToInt32(reader["CUST_LOCATION_ID"]),
                            City = Convert.ToString(reader["CITY_NM"]),
                            Country = Convert.ToString(reader["COUNTRY_NM"]),
                        };
                        customerMasterModel.Customer.Add(newCustomer);
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        LocationMaster newCustomer = new LocationMaster()
                        {
                            LocationId = Convert.ToInt32(reader["LOCATION_ID_SQ"]),
                            State = Convert.ToString(reader["STATE_NM"]),
                            Country = Convert.ToString(reader["COUNTRY_NM"]),
                            City = Convert.ToString(reader["CITY_NM"])
                        };
                        customerMasterModel.Location.Add(newCustomer);
                    }
                    return customerMasterModel;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                    //reader.Dispose();
                }
            }
        }

        public void CreateNewCustomer(CustomerLocationModel customer,string currentUserId)
        {
            try
            {
                if (customer == null) throw new ArgumentNullException("customer");
                using (IDbCommand command = _db.CreateCommand("Insert_New_Customer_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Customer_Nm", customer.CustomerName);
                    if(!string.IsNullOrEmpty(customer.CustomerAliasName))
                        parameters.Add("proc_vr_Customer_Alias_Nm", customer.CustomerAliasName);
                    parameters.Add("proc_vr_Customer_Location_Id", customer.LocationId);
                    parameters.Add("proc_vr_Created_By_User_Id", currentUserId);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }

            }
            catch (Exception Ex)
            {
                LogManager.Error(Ex);
                throw;
            }
        }
    }
}
