export interface IUser {
    name: string;
    displayName: string;
    isLoginned: boolean;
    isAdmin: boolean;
}
