import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';


@Component({
    selector: 'nirSpec',
    templateUrl: 'NIRSpecs.component.html',
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})
export class NIRSpecsComponent implements OnInit {
    // run1: RunModel;
    NIRModelID: any;
    run: RunSetupModel;

    constructor(private nirService: RunService, public runDataService: RunDataService, private runComponent: RunComponent) { }
    ngOnInit() {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel);
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "6", Value: "NIR Specs", Groupcd: 0 })
    }

    
}

