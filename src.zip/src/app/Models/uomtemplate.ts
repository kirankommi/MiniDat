﻿export class UomTemplate {
    TemplateID: string;
    TemplateName: string;
    ApplicationId: number;
    DatName: string;
    IsDefault: string;

}

export class TemplateVariable {
    ID: string;
    Name: string;
    Uom: Group;
    UomGroup: UomGroup;
    UomDrop: Group[];
    Precision: string;
}

export class UomGroup {
    UOMGroupCD: string;
    UOMGroupName: string;
}

export class Group {
    ID: string;
    Name: string;
}

export class Module {
    ID: string;
    Name: string;
}
export class VariableCategory {
    ID: string;
    Name: string;
    }

export class TemplateData {
    Template: UomTemplate;
    Variables: TemplateVariable[];
    module: Module;

    //constructor(template: UomTemplate, variables: TemplateVariable[]) {
    //    this.Template = template;
    //    this.Variables = variables;
    //}
}