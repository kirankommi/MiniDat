﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystAliasSSModel
    {
        public int? CatalystAliasSSID { get; set; }
        public string CatalystAliasSSName { get; set; }     
        public string StatusName { get; set; }
        public string Size { get; set; }
        public string Shape { get; set; }
        public KeyValue StatusCode { get; set; }
        public KeyValue Sizecd { get; set; }
        public KeyValue Shapecd { get; set; }

    }
    public class CatalystAliasSSSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<KeyValue> sizes = new List<KeyValue>();
        public IList<KeyValue> lstSizes { get { return sizes; } }

        private IList<KeyValue> shapes = new List<KeyValue>();
        public IList<KeyValue> lstShapes { get { return shapes; } }

        private IList<CatalystAliasSSModel> _lstcatalystAliasSSs = new List<CatalystAliasSSModel>();
        public IList<CatalystAliasSSModel> LstcatalystAliasSSs { get { return _lstcatalystAliasSSs; } }

        public int RecordsFetched { get; set; }

    }
}
