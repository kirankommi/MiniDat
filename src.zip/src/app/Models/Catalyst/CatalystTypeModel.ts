﻿export class CatalystTypeModel {
    CatalystTypeID: number;
    CatalystType: string;  
    StatusName: string;
    Description: string; 
    StatusCode: KeyValue;  
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
