﻿import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
    //moduleId: module.id,
    selector: 'fdms-calendar',
    templateUrl: 'calendar.html'
})

export class CalendarDirective {
    @Input() disabledFlag: boolean;
    private currentSelectedItem: any;   
    @Output() inputValueChange = new EventEmitter();
    public bsConfig: any;
    @Input() set inputValue(machineItem: any) {
        this.currentSelectedItem = machineItem;
        this.inputValueChange.emit(machineItem);
    }

    get inputValue(): any {
        return this.currentSelectedItem;
    }
    constructor() {
        this.bsConfig = "{ containerClass: 'theme-dark-blue' }";
    }

   


}
