import { Component, OnInit, DoCheck, AfterViewInit, AfterContentInit } from '@angular/core';
import { SessionService } from './Shared/session.service';
import { Router, ActivatedRoute, RouterOutlet, NavigationEnd } from '@angular/router';
import { MenuType, MenuModel } from './Components/NavBar/navbar.metadata';
import { FormControl } from '@angular/forms';
import { Http } from '@angular/http';
import { environment } from '../environments/environment';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { appService } from './Services/app.service';
import { Message } from 'primeng/primeng';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import * as Constants from './Shared/globalconstants';
import { CardModule } from 'primeng/card';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [MessageService]
})
export class AppComponent implements OnInit, DoCheck {
  _toggleSideMenu: boolean = false;
  public menuItems: MenuModel[];
  public brandMenu: MenuModel;
  routes: MenuModel[] = [];
  isOverlay: boolean = false;
  isTopLoad: boolean = false;
  isLoading: boolean = false;


  msgs: Message[] = [];
  url: string;

  constructor(private route: ActivatedRoute,
    private router: Router, private _SessionService: SessionService, private http: Http, private appService: appService, private messageService: MessageService) {
  }
  ngDoCheck() {
    this.msgs = Constants.Msgs;
    this.isLoading = Constants.IsLoading;
    this.messageService.add(this.msgs[0]);
    Constants.ClearMsgs();
  }
  ngOnInit() {
    this.isLoading = true;
    this.routes = [
      { title: '', action: '', menuType: MenuType.BRAND, subMenu: [], menuOrder: 1 }
    ];

    this.GetUserData();


  }


  GetUserData() {
    this.brandMenu = this.routes.filter((menuItem: any) => menuItem.menuType === MenuType.BRAND)[0];
    var self = this;
    this.appService.getSessionData()
      .subscribe((data: any) => {
        if (data.User == null || data.User == undefined) {
          this.router.navigateByUrl('/unauthorizedUser');
        }
        this.isLoading = false;
      },
        (err: any) => {
          this.isLoading = false;
        });
  }

  toggleSideMenu() {
    if (this._toggleSideMenu) {
      document.getElementById('fdms-container').style.marginLeft = '270px';
    }
    else {
      document.getElementById('fdms-container').style.marginLeft = '0px';
    }
    this._toggleSideMenu = !this._toggleSideMenu;

    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 1000);
  }


}
