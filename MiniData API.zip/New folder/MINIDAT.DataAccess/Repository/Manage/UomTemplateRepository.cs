﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	UOMTemplateRepository.cs
 	Project Title			:	FDMS
	Author(s)				:	Pranavi Lingamallu
	Created Date			:	1 jun 2017
	Requirements Tag		:	FR72.2 - Define Default UOM and Precision - 1016 (View Model)
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Common;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Serializer;
using MINIDAT.Manage.UOMTemplate;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Model;
using MINIDAT.Framework.Common;
using MINIDAT.Model.UOM;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class UomTemplateRepository : IUomTemplateRepository
    {
        private IDatabase _db;

        public UomTemplateRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public IList<Application> GetApplications()
        {
            var systems = new List<Application>();
            using (IDbCommand command = _db.CreateCommand("GetSourceSystems_Sp"))
            {
                IDataReader reader = _db.ExecuteReader(command);               
                //  systems.Add(new Application() { Id = 0, Name = "Select", Description = "Select" });
                while (reader.Read())
                {
                    Application system = new Application()
                    {
                        Id = Convert.ToInt32(reader["SRC_SYSTEM_ID"]),
                        Name = reader["SRC_SYSTEM_NM"].ToString(),
                        Description = reader["SRC_SYSTEM_DESC"].ToString()
                    };
                    systems.Add(system);
                }

                reader.Close();
            }
            return systems;
        }
        /// <summary>
        /// search the template data
        /// </summary>
        /// <param name="template"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public IList<UOMTemplateModel> GetTemplateData(UOMTemplateModel template, string userId)
        {
            try
            {
                IList<UOMTemplateModel> TemplateArray = new List<UOMTemplateModel>();
                if ((template == null) || (string.IsNullOrEmpty(userId)))
                {
                    return TemplateArray;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                using (IDbCommand command = _db.CreateCommand("Search_Templates_Sp_OneDAT"))
                {
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_template_name", template.TemplateName);
                    parameters.Add("proc_vr_appId", ApplicationSettings.AppId);
                    parameters.Add("proc_vr_user", Eid);
                    //parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);
                    _db.CreateParameters(command, parameters);

                    //db.AddInParameter(command, "proc_vr_template_name", DbType.String, template.TemplateName == null ? null : template.TemplateName);
                    //db.AddInParameter(command, "proc_vr_user", DbType.String, Eid);

                    IDataReader reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        UOMTemplateModel newTemplate = new UOMTemplateModel()
                        {
                            ApplicationId = Convert.ToInt32(reader["SRC_SYSTEM_ID"]),
                            DatName = reader["SRC_SYSTEM_DESC"].ToString(),
                            TemplateID = reader["UOM_TEMPLATE_ID_SQ"].ToString(),
                            TemplateName = reader["UOM_TEMPLATE_NM"].ToString(),
                            IsDefault = (reader["UOM_TEMPLATE_ID"] == DBNull.Value) ? "N" : "Y",
                        };
                        TemplateArray.Add(newTemplate);
                    }

                    reader.Close();
                }
                return TemplateArray;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        /// <summary>
        /// get template variable data
        /// </summary>
        /// <param name="templateID"></param>
        /// <returns></returns>

        public IList<TemplateVariable> GetVariableData(string templateID)

        {
            try
            {
                IList<TemplateVariable> VariableArray = new List<TemplateVariable>();


                using (IDbCommand command = _db.CreateCommand("Get_Variables_Sp"))
                {

                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_templateid", templateID);
                    _db.CreateParameters(command, parameters);

                    //db.AddInParameter(command, "proc_vr_templateid", DbType.String, templateID);


                    using (IDataReader reader = _db.ExecuteReader(command))
                    {

                        while (reader.Read())
                        {
                            TemplateVariable newVariable = new TemplateVariable()
                            {
                                // UomGroup = reader["UOM_GROUP_NM"].ToString(),
                                Precision = reader["PRECISION"].ToString()
                            };

                            UOMGroup uomgrp = new UOMGroup()
                            {
                                UOMGroupCD = reader["UOM_GROUP_CD"].ToString(),
                                UOMGroupName = reader["UOM_GROUP_NM"].ToString(),
                            };

                            newVariable.UomGroup = uomgrp;

                            Group aGroup = new Group()
                            {
                                ID = reader["DEFAULT_UOM_ID"].ToString(),
                                Name = reader["UOM_UNIT_NM"].ToString(),
                            };

                            newVariable.Uom = aGroup;

                            //Unit DefaultUnit = new Model.UOM.Unit() { DisplayText = Convert.ToString(reader["UOM_UNIT_DISPLAY_NM"]), UnitName = Convert.ToString(reader["UOM_UNIT_NM"]) };
                            Model.UOM.UnitGroup unitGroup = AppCache.GetGroupByCode(Convert.ToString(reader["UOM_GROUP_CD"]));

                            List<Group> uomArray = new List<Group>();

                            foreach (var unit in unitGroup.Units)
                            {
                                Group newGroup = new Group()
                                {
                                    ID = unit.UnitId.ToString(),
                                    Name = unit.UnitName
                                };

                                uomArray.Add(newGroup);
                            }

                            ((List<Group>)newVariable.UomDrop).AddRange(uomArray);

                            VariableArray.Add(newVariable);
                        }
                    }
                }
                return VariableArray;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete template data
        /// </summary>
        /// <param name="template"></param>

        public void DeleteTemplateData(UOMTemplateModel template)
        {
            try
            {
                if (template == null)
                {
                    return;
                }

                IDbCommand command = _db.CreateCommand("Delete_Template_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_id", template.TemplateID);
                    parameters.Add("@proc_vr_app_id", template.ApplicationId);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// save template data
        /// </summary>
        /// <param name="template"></param>
        /// <param name="userId"></param>


        public void SaveTemplateData(UOMTemplateModel template, string userId)
        {
            try
            {
                if ((template == null) || (string.IsNullOrEmpty(userId)))
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                IDbCommand command = _db.CreateCommand("[Insert_Update_UOM_Template_Sp_OneDAT]");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();                   
                    parameters.Add("proc_vr_template_name", template.TemplateName);
                    parameters.Add("proc_vr_template_id", template.TemplateID);
                    parameters.Add("proc_vr_user", Eid);
                    parameters.Add("src_system_id", template.ApplicationId);
                    _db.CreateParameters(command, parameters);                   
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }
        /// <summary>
        /// save template variable data
        /// </summary>
        /// <param name="template"></param>
        /// <param name="variables"></param>
        /// <param name="userId"></param>
        public void SaveVariables(UOMTemplateModel template, IList<TemplateVariable> variables, string userId)
        {
            try
            {
                if ((template == null) || (string.IsNullOrEmpty(userId)))
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                string variable = Serializer.ConvertToXML(variables);

                //Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                IDbCommand command = _db.CreateCommand("Update_Variables_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_id", template.TemplateID);
                    parameters.Add("proc_vr_variables_xml", variable);
                    parameters.Add("proc_vr_user", Eid);
                    _db.CreateParameters(command, parameters);
                    //db.AddInParameter(command, "proc_vr_template_id", DbType.String, template.TemplateID == null ? null : template.TemplateID);
                    //db.AddInParameter(command, "proc_vr_variables_xml", DbType.String, variable == null ? null : variable);
                    //db.AddInParameter(command, "proc_vr_user", DbType.String, Eid);
                    _db.ExecuteNonQuery(command);
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }
        /// <summary>
        /// makes default uom
        /// </summary>
        /// <param name="uomtemplate"></param>
        /// <param name="userId"></param>
        public void MakeDefault(UOMTemplateModel uomtemplate, string userId)
        {
            try
            {
                if ((uomtemplate == null) || (string.IsNullOrEmpty(userId)))
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                //Database db = DatabaseFactory.CreateDatabase(ApplicationSettings.Connection);
                IDbCommand command = _db.CreateCommand("Make_Default_OneDAT_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_id", uomtemplate.TemplateID);
                    parameters.Add("proc_vr_user", Eid);
                    parameters.Add("src_system_id", uomtemplate.ApplicationId);
                    _db.CreateParameters(command, parameters);
                    //db.AddInParameter(command, "proc_vr_template_id", DbType.String, template.TemplateID == null ? null : template.TemplateID);
                    //db.AddInParameter(command, "proc_vr_user", DbType.String, Eid);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public IList<Module> GetModuleData(string templateID)
        {
            try
            {
                IDbCommand command = _db.CreateCommand("Get_Modules_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();                    
                    parameters.Add("proc_vr_templateid", templateID);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }                              
                List<Module> ModuleArray = new List<Module>();
                Module select = new Module()
                {
                    ID = "Select",
                    Name = "Select"
                };

                ModuleArray.Add(select);

                IDataReader reader = _db.ExecuteReader(command);
                while (reader.Read())
                {
                    Module newModule = new Module()
                    {
                        ID = reader["VARIABLE_CATEGORY_ID_SQ"].ToString(),
                        Name = reader["VARIABLE_CATEGORY_NM"].ToString()
                    };

                    ModuleArray.Add(newModule);
                }

                return ModuleArray;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Variable> GetVariableData(string templateID, string moduleID)
        {
            try
            {

                List<Variable> VariableArray = new List<Variable>();

                IDbCommand command = _db.CreateCommand("Get_UOM_Template_Variables_Sp");

                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_templateid", templateID);
                    parameters.Add("proc_vr_moduleid", moduleID);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                IDataReader reader = _db.ExecuteReader(command);
                while (reader.Read())
                    {
                        Variable newVariable = new Variable()
                        {
                            ID = reader["UOM_VARIABLE_ID_SQ"].ToString(),
                            Name = reader["UOM_VARIABLE_NM"].ToString(),
                            UomGroup = reader["UOM_GROUP_CD"].ToString(),
                            Precision = reader["VARIABLE_DECIMAL_PNT"].ToString()
                        };

                        Group aGroup = new Group()
                        {
                            ID = reader["DEFAULT_UOM_ID"].ToString(),
                            Name = reader["UOM_UNIT_NM"].ToString(),
                        };

                        newVariable.Uom = aGroup;

                        //Unit DefaultUnit = new Model.UOM.Unit() { DisplayText = Convert.ToString(reader["UOM_UNIT_DISPLAY_NM"]), UnitName = Convert.ToString(reader["UOM_UNIT_NM"]) };
                        UnitGroup unitGroup = AppCache.GetGroupByCode(Convert.ToString(reader["UOM_GROUP_CD"]));

                        List<Group> uomArray = new List<Group>();

                        foreach (var unit in unitGroup.Units)
                        {
                            Group newGroup = new Group()
                            {
                                ID = unit.UnitId.ToString(),
                                Name = unit.UnitName
                            };

                            uomArray.Add(newGroup);
                        }

                        newVariable.UomDrop = uomArray;    
                        VariableArray.Add(newVariable);
                    }
                return VariableArray;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void SaveUOMVariables(UOMTemplateModel template, Module module, List<TemplateVariable> variables, string userId)
        {
            try
            {
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                string variable = Serializer.ConvertToXML(variables);
                IDbCommand command = _db.CreateCommand("Insert_Update_Variables_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_id", template.TemplateID == null ? null : template.TemplateID);
                    parameters.Add("proc_vr_module_id", module.ID == null ? null : module.ID);
                    parameters.Add("proc_vr_variables_xml", variable == null ? null : variable);
                    parameters.Add("proc_vr_user", Eid);
                    parameters.Add("src_system_id", ApplicationSettings.AppId);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }                

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void Update(UOMTemplateModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(UOMTemplateModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<UOMTemplateModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(UOMTemplateModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
