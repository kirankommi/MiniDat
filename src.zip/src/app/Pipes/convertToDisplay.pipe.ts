import { Pipe, PipeTransform, ViewChild } from '@angular/core';

@Pipe({
  name: 'convertToDisplay'
})
export class convertToDisplayPipe implements PipeTransform {
  private defaultUnit: any;
  private displayValue: any;
  private precision: number;

  transform(value: any, uom: any) {
    this.displayValue = value;
    value = parseFloat(value);
    if (uom && !isNaN(value)) {
      this.defaultUnit = uom;
      this.precision = !isNaN(parseInt(uom.Precision)) ? uom.Precision : this.precision;
      if (this.defaultUnit.UnitName == "API" || this.defaultUnit.UnitName == "BAUME" || this.defaultUnit.UnitName == "BAUME<5") {
        this.displayValue = (this.defaultUnit.Slope / value) - this.defaultUnit.Intercept;
      }
      else {
        this.displayValue = (value - this.defaultUnit.Intercept) / this.defaultUnit.Slope;
      }
      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
    }
    return this.displayValue;
  }

  GetPrecison() {
    if (this.defaultUnit.Precision != null) {
      return this.defaultUnit.Precision;
    }
    else {
      return !isNaN(this.precision) ? this.precision : 6;
    }
  }
}
