﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace MINIDAT.Manage.UOMTemplate
{
    public class UOMTemplateModel
    {
        public string TemplateID { get; set; }
        public string TemplateName { get; set; }
        public string IsDefault { get; set; }
        public int ApplicationId { get; set; }
        public string DatName { get; set; }
    }

    public class TemplateVariable
    {
        private IList<Group> uomdrop = new List<Group>();
        public Group Uom { get; set; }
        public UOMGroup UomGroup { get; set; }
        [XmlIgnore]
        public IList<Group> UomDrop { get { return (uomdrop); } }
        public string Precision { get; set; }
        public string ID { get; set; }
        public string Name { get; set; }
    }

    public class UOMGroup
    {
        public string UOMGroupCD { get; set; }
        public string UOMGroupName { get; set; }
    }

    public class Group
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }

    public class TemplateData
    {
        private IList<TemplateVariable> variables = new List<TemplateVariable>();
        public UOMTemplateModel Template { get; set; }
        public Module Module { get; set; }
        public IList<TemplateVariable> Variables { get { return variables; } }
    }
    public class Application
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int? OrderNum { get; set; }
    }
    public class Module
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }

    public class Variable
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public Group Uom { get; set; }
        [XmlIgnore]
        public string UomGroup { get; set; }
        [XmlIgnore]
        public List<Group> UomDrop { get; set; }
        public string Precision { get; set; }
    }

}
