import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { TestCreationModel } from '../../Models/TestCreation/TestCreationModel';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { TestParameter } from 'src/app/Models/TestCreation/TestParam';

@Injectable()
export class TestCreationService {
    private GetTestCreationUrl = "/TestCreation/GetTest";
    private GetPlantFlyoutUrl = "/TestCreation/GetPlantsFlyout";
    private GetRunFlyoutUrl = "/TestCreation/GetRuns";
    private SaveTestCreationUrl = "/TestCreation/SaveTestCreation";
    private SaveTestURL2 = "/TestCreation/SaveTestInformation"
    private DeleteTestCreationUrl = "/TestCreation/deleteTestData";
    private SearchTestCreationUrl = "/TestCreation/SearchTestCreation";
    private GetLIMSInfoUrl = "/TestCreation/GetLimsInformation/"; 
    private GetPIInfoUrl = "/TestCreation/GetPIInformation/"; 
    private CalculationUrl = "/TestCreation/Calculate/"; 
    constructor(private httpaction: HttpActionService) {}
    GetTestDetails() {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetTestCreationUrl, options);
    }
    GetPlantFlyout() {
        return this.httpaction.get(this.GetPlantFlyoutUrl, Constants.options);
    }
    GetRunFlyout(Plantcd: string) {
        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('PlantCd', Plantcd);
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetRunFlyoutUrl, options);
    }
    SearchTestdata(testData: TestCreationModel) {
        return this.httpaction.post(testData, this.SearchTestCreationUrl)
    }
    //new
    SaveTestInformation(_test: TestCreationModel) {
        debugger;
        return this.httpaction.post(_test, this.SaveTestURL2);
    }
    deleteTestData(testModel: TestCreationModel) {
        debugger;
        return this.httpaction.post(testModel, this.DeleteTestCreationUrl);
    }
    GetLimsInformation(param: TestParameter) {
        return this.httpaction.post(param, this.GetLIMSInfoUrl);
    }
    GetPIInformation(param: TestParameter) {
        return this.httpaction.post(param, this.GetPIInfoUrl);
    }
    Calculate(test: TestCreationModel) {
        debugger;
        return this.httpaction.post(test, this.CalculationUrl);
    }
}
