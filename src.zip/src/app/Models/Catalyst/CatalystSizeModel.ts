﻿export class CatalystSizeModel {
    CatalystSizeID: number;
    CatalystSizeName: string;  
    StatusName: string;  
    StatusCode: KeyValue;  
}

export class KeyValue
{
    Key: string;
    Value: string;
    Groupcd: number;
}
