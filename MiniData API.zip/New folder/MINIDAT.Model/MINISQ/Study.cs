﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.MINISQ
{
    public class Study
    {
        public List<MINIDAT.Model.DOE.Run> Runs { get; set; }
        public MINIDAT.Model.DOE.Run this[int runID]
        {
            get
            {
                return this.Runs.First(q => q.RUN_ID == runID);
            }
        }
    }
    public class ReOrderedRuns
    {
        public List<MINIDAT.Model.DOE.Run> Runs { get; set; }
        public int? DragIndex { get; set; }
        public int? DropIndex { get; set; }
        public int? Plant { get; set; }
        public string UserId { get; set; }
        public bool IsDragged { get; set; }

    }
}
