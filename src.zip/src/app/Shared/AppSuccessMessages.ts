import { SuccessMessage } from './SuccessMessage';
export class AppSuccessMessages {
    SuccessMessages: SuccessMessage[] = [{ Id: "Save", Title: "", Details: "Save.", Error: null },
        { Id: "UploadSuccess", Title: "Success", Details: "Uploaded Successfully", Error: null },
        { Id: "CrudeDelete", Title: "Success", Details: "Deleted Successfully", Error: null },
        { Id: "QueryDelete", Title: "Success", Details: "Deleted Successfully", Error: null },
        { Id: "FeedMappingSaved", Title: "Success", Details: "Feed Record Saved Successfully", Error: null },
        { Id: "LimsComponentSaved", Title: "", Details: "Lims Component Saved Successfully", Error: null },
        { Id: "SaveSuccess", Title: "", Details: "Saved Successfully", Error: null },
        { Id: "AutoMapOperationSuccess", Title: "", Details: "LIMS Operation maping in created in Manage>LIMS Analysis Method master list", Error: null },
        { Id: "AutoMapComponentSuccess", Title: "", Details: "LIMS Component maping in created in Manage>LIMS Component master list", Error: null },
        { Id: "DeleteTSProcessUnitSamples", Title: "", Details: "Record Deleted Successfully", Error: null },
      { Id: "SaveTSProcessUnitSamples", Title: "", Details: "Record Saved Successfully.", Error: null },
      { Id: "DOESave", Title: "Experiment", Details: "Experiment Saved Successfully.", Error: null },
      { Id: "DOEDelete", Title: "Experiment", Details: "Experiment deleted Successfully.", Error: null }

    ];

    public getSuccessMessage(id: string) {
        if (this.SuccessMessages && this.SuccessMessages.length > 0) {
            var msg = this.SuccessMessages.filter(x => x.Id == id)[0];
            if (msg) {
                return msg;
            }
            else {
                return new SuccessMessage();
            }

        }

    }
}
