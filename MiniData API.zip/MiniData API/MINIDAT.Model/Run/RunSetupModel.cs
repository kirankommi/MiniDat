﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class RunSetupModel
    {
        public RunMasterDataModel MasterData { get; set; }
        public RunSetUpMetaData MetaData { get; set; }
        public List<NIRModel> lstNIRSpec { get; set; }
        public List<AnalyticalInfoModel> lstAnalyticalSamples { get; set; }
        public GeneralInfoModel GeneralInfo { get; set; }
        public FeedModel FeedInfo { get; set; }
        public AdditionalInfoModel AdditionalInfo { get; set; }
        public List<BoilingPointModel> lstRunCutBoilingPoints { get; set; }
        public List<RunCatalyst> Cataysts { get; set; }
        public List<BedDetails> Beds { get; set; }
        public List<TC_Calibration> lstTC_Calibrations { get; set; }
        public List<TMF_Calibration> lstTMF_Calibrations { get; set; }
        public List<ProcessSpecModel> lstProcessSpec { get; set; }
        //public List<KeyValue> Technicians { get; set; }
        //public List<KeyValue> lstStreams { get; set; }
        //public List<KeyValue> LstAnalysisMethods { get; set; }
        //public List<KeyValue> LstLoadingDensiyTypes { get; set; }
        //public List<KeyValue> LstNormalizationFactors { get; set; }
        //public List<KeyValue> LstFeedSource { get; set; }

        //public IEnumerable<dynamic> ModeMaster { get; set; }
        public IEnumerable<dynamic> RecipeInfo { get; set; }

        public ExportPopupSummary PopupSummary { get; set; }
    }
}
