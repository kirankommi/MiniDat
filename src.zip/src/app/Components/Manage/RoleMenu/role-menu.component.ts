import { Component, ElementRef } from '@angular/core';
import { TreeView } from './treeview.component';
import { RoleSummary } from './rolesummary.component';
import { TreeNode, Message } from 'primeng/primeng';
//import Constants = require('../../../Shared/globalconstants');
import * as  Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { AppComponent } from '../../../app.component';
import { RoleModel, KeyValue } from '../../../models/RoleModel';
import { RoleMenuService } from '../../../Services/role-menu.service';

@Component({
    //moduleId: module.id,
    selector: '',
    templateUrl: 'role-menu.component.html',
    providers: [RoleMenuService, AlertMessage]
})
export class RoleMenuComponent {
    title: string;
    isCollapsed = false;
    roleList: any;
    applicationList: any;
    menus: any[];
    privileges: any[];
    roleMenuData: RoleModel;
    selectedRoleCode: string;
    selectedApplicationCode: string;
    userRoleCode: string;
    selectedRole: string
    setStyles: boolean;
    IsallowedSave: boolean=false; 
    roleMenu: TreeNode[];
    msgs: Message[] = [];
    privilegesSaved: string = "Privileges Saved Sucessfully";
    requiredMsg: string = "Please select the Role"
    IsallowedChange: boolean = true;
    constructor(private roleMenuService: RoleMenuService, private appComponent: AppComponent,
        public el: ElementRef, private alertMessage: AlertMessage) { }

    ngOnInit() {
        this.roleMenuData = new RoleModel();
        this.title = "Manage - Role Menu Assignment"; 
        this.getRoles();
    }

    onCollapse() {
        let treeSection = this.el.nativeElement.querySelector('#div-tree');

        if (this.isCollapsed) {
            if (treeSection != null && treeSection != Constants.Undefined) {
                treeSection.style.height = '70%';
            }
        } else {
            if (treeSection != null && treeSection != Constants.Undefined) {
                treeSection.style.height = '85%';
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    getRoles() {
        this.roleMenuService.getRoles()
            .subscribe(
            (data: any) => {
                debugger;

                this.roleList = data.Roles;
                this.applicationList = data.ApplicationList;
                //if (Constants.UserSessionData != Constants.Undefined) { 
                //    this.userRoleCode = Constants.UserSessionData.RoleCode.Key;
                //} 
                this.selectedRoleCode = Constants.Select;
                // this.selectedApplicationCode = Constants.Select; 
                if (data.ApplicationList.length > 0) {
                    this.selectedApplicationCode = data.ApplicationList[0].ApplicationId;
                }
                else {
                    this.selectedApplicationCode = "5";
                }
                
            },
           // err => this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details})
            );
    }
    onAppchange() {  
        if (this.selectedRoleCode != "Select")
        {
            this.roleMenuService.getRolePrivileges(this.selectedRoleCode, this.selectedApplicationCode)
                .subscribe(
                (data: any) => {
                    this.menus = (data != null) ? data : [];
                    this.privileges = [];
                    this.privileges = (data != null) ? data.Items : [];
                },
                //err => this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details})
                );
        }
      
    }
    onRolechange() { 
        this.selectedRole = this.roleList.filter((x: any) => x.RoleCode == this.selectedRoleCode)[0].RoleName; 
        this.roleMenuService.getRolePrivileges(this.selectedRoleCode, this.selectedApplicationCode)
            .subscribe(
            (data: any) => {
                this.menus = (data != null) ? data : [];
                this.privileges = [];
                this.privileges = (data != null) ? data.Items : [];
            },
            //err => this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details})
            );
    }

    onSavePrivileges() {
        if (this.selectedRoleCode != Constants.Select && this.selectedApplicationCode != Constants.Select) { 
            this.roleMenuData.RoleCode = this.selectedRoleCode;
            this.roleMenuData.AppCode = this.selectedApplicationCode;
            this.roleMenuService.saveRolePrivileges(this.menus, this.selectedRoleCode, this.selectedApplicationCode) 
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.privilegesSaved });
                        //TODO
                        //this.appComponent.GetUserData();
                    }
                },
                (err: any) => { }
                //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: this.requiredMsg });
        }
    }

    onReset() {
        debugger;
        this.selectedRoleCode = Constants.Select;
       // this.selectedApplicationCode = Constants.Select; 
        if (this.applicationList && this.applicationList.length > 0) {
            this.selectedApplicationCode = this.applicationList[0].ApplicationId;
        }
        this.privileges = [];
    }
    ngDoCheck() {
        if (Constants.UserPrivileges.length > 1) {

            for (let i in Constants.UserPrivileges) {

                if (Constants.UserPrivileges[i].Action.toUpperCase() == "MANAGE/ROLEMENU" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                    this.IsallowedSave = true;
                }
            }

        }
    }
}
