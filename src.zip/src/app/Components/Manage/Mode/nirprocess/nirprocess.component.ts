import { Component, OnInit } from '@angular/core';
import { NIRService } from '../../../../Services/nirservice';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-nirprocess',
  templateUrl: './nirprocess.component.html',
  providers: [NIRService, AlertMessage, HttpActionService, ConfirmationService]
})
export class NIRProcessComponent implements OnInit {

  constructor(private nirService: NIRService, private route: ActivatedRoute) { }
  nirCols:any[];
  nirSpecData: any;
  processSpecData: any;
  ConversionPoint: string;
  sub: any;
  templateId: number;
  heatBoxStreamValue: string="ON";
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.templateId = params['field'];
    });
    if (this.templateId > 8) {
      this.heatBoxStreamValue = "OFF";
    }
    // while (this.templateId > 12) {
    //   this.templateId = this.templateId - 12;
    // }
    this.getNIRData();
  }
  
  getNIRData() {
    this.nirService.getNIRInformation(this.templateId)
      .subscribe(
        (data: any) => {
          debugger;
          this.nirSpecData = data.lstNIRSpecModel;
          this.processSpecData = data.lstProcessSpecModel;
          this.ConversionPoint = data.ConversionCutPoint;
        },
        err => { }
      );
  }
 
}
