import { Injectable, ReflectiveInjector } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class sharedService {
  isNAN(value: any) {
    debugger;
    return isNaN(value);
  }

}
