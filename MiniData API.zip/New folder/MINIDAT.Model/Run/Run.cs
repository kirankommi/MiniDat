﻿using System.Collections.Generic;
using MINIDAT.Model.Manage;

namespace MINIDAT.Model.Run
{
    public class RunModel
    {
        public int? ID { get; set; }
        public string Plant { get; set; }
        public int? RunNum { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ZeroHOSTime { get; set; }
        public string RunDescription { get; set; }
        public string Status { get; set; }
        public int DOERun { get; set; }
        public List<NIRModel> lstNIRSpec { get; set; }
        public List<AnalyticalInfoModel> lstAnalyticalSamples { get; set; }
        public GeneralInfoModel GeneralInfo { get; set; }
        public FeedModel FeedInfo { get; set; }
        public AdditionalInfoModel AdditionalInfo { get; set; }
        //public RunCatalystSearchModel CatalystInfo { get; set; }
        public List<BoilingPointModel> lstRunCutBoilingPoints { get; set; }
        public List<RunCatalyst> Cataysts { get; set; }
        public List<BedDetails> Beds { get; set; }
        public List<TC_Calibration> lstTC_Calibrations { get; set; }
        public List<TMF_Calibration> lstTMF_Calibrations { get; set; }
        public List<ProcessSpecModel> lstProcessSpec { get; set; }
        public List<KeyValue> Technicians { get; set; }
        public List<KeyValue> lstStreams { get; set; }
        public List<KeyValue> LstAnalysisMethods { get; set; }
        public List<KeyValue> LstLoadingDensiyTypes { get; set; }
        public List<KeyValue> LstNormalizationFactors { get; set; }
        public List<KeyValue> LstFeedSource { get; set; }
        public int? RunId { get; set; }
        public ExportPopupSummary PopupSummary {get; set;}

       
        public RunModel()
        {
            lstNIRSpec = new List<NIRModel>();
            lstAnalyticalSamples = new List<AnalyticalInfoModel>();
            GeneralInfo = new GeneralInfoModel();
            FeedInfo = new FeedModel();
            lstRunCutBoilingPoints = new List<BoilingPointModel>();
            lstTC_Calibrations = new List<TC_Calibration>();
            lstTMF_Calibrations = new List<TMF_Calibration>();
            PopupSummary = new ExportPopupSummary();
        }
    }
    public class RunMasterDataModel
    {
        public List<KeyValue> Technicians { get; set; }
        public List<KeyValue> lstStreams { get; set; }
        public List<KeyValue> LstAnalysisMethods { get; set; }
        public List<KeyValue> LstLoadingDensiyTypes { get; set; }
        public List<KeyValue> LstNormalizationFactors { get; set; }
        public List<KeyValue> LstFeedSource { get; set; }
        public List<BoilingPointModel> LstStdBoilingPoints { get; set; }
        public List<KeyValue> LstStreams { get; set; }
        public List<KeyValue> LstFrequency { get; set; }
        public List<FeedInfo> lstFlyoutFeeds { get; set; }

    }
}
