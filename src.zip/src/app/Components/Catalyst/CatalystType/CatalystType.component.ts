﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystTypeService } from '../../../Services/CatalystServices/CatalystType.service';
import { CatalystTypeModel, KeyValue } from '../../../models/Catalyst/CatalystTypeModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({  
    templateUrl: 'CatalystType.component.html',
    providers: [CatalystTypeService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystTypeComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystType: CatalystTypeModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    catalystTypeList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    catalystTypeSaved: string = "Catalyst Type Details Saved Successfully";
    catalystTypeDeleted: string = "Catalyst Type Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   

    constructor(private catalystTypeService: CatalystTypeService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {       
        this.catalystType = new CatalystTypeModel();
        this.catalystType.CatalystTypeID = null;
        this.catalystType.Description = null;
        this.catalystType.CatalystType = null;   
        this.getcatalystTypesList();
        this.title = Constants.ManageCatalystType;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystType.CatalystTypeID = event.data.CatalystTypeID;
        this.catalystType.CatalystType = event.data.CatalystType;
        this.catalystType.Description = event.data.Description;             
        this.catalystType.StatusName = event.data.StatusCode.Key;    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getcatalystTypesList()
    {       
        this.catalystTypeService.getCatalystTypeInformation(this.catalystType)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystTypeList = data.LstcatalystTypes;              
                this.Statuses = data.lstStatus;            
                this.totalRecords = data.RecordsFetched;              
                if (this.catalystType.StatusName == undefined || this.catalystType.StatusName == null)
                { this.catalystType.StatusName = Constants.Select; }               
                
            },
            err =>{}               
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystType()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.catalystTypeService.saveCatalystTypeInformation(this.catalystType)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystTypeSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(catalystType: CatalystTypeModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteCatalystTypeInfo(catalystType);}
        });
    }

    deleteCatalystTypeInfo(catalystType: CatalystTypeModel)
    {
        debugger;     
        this.catalystTypeService.deleteCatalystType(catalystType)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.catalystTypeDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }           
            );
    }   

    onReset() {
        debugger;
        this.catalystType = new CatalystTypeModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.catalystType.Description = null;       
        this.getcatalystTypesList();      
        this.selectedApplicationCode = "5";      
        
    }

    isDataValid()
    {
        debugger;
        if (this.catalystType == null || !this.catalystType.CatalystType
            || this.catalystType.StatusName == "Select"
            || !this.catalystType.Description)
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {       
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1)
            {
                for (let i in Constants.UserPrivileges)
                {                   
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000022" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
