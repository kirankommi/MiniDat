import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, RunCatalystSearchModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import { KeyValue } from '../../../Models/KeyValue';
import * as Constants from '../../../Shared/globalconstants';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';


@Component({
    selector: 'runBolingPoint',
    templateUrl: './RunBoilingPoints.component.html',
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})

export class RunBoilingPointComponent implements OnInit {
    // run1: RunModel;
    run: RunSetupModel;
    streamCols: KeyValue[];
    addIconPath = Constants.addIcon;
    deleteIconPathEn = Constants.deleteIconEn;
    count: number = 0;
    oldValue: number = 0;
    constants: any = {};
    lstStdboilingPoints: any;
    selectedRow: any;
    pagetitle: any;
    runSaved: string = "Boiling Point Informaiton Saved Successfully";
    boilingPointsInfoCopied: string = "Standard Boiling Point Informaiton Copied Successfully";

    constructor(private runService: RunService, public runDataService: RunDataService, private alertMessage: AlertMessage, private runComponent: RunComponent) { this.constants = Constants; }
    ngOnInit() {
        debugger;
        this.runDataService.currentMessage.subscribe(runmodel => { this.run = runmodel });
        this.getInformation();

        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "2", Value: "Boiling Point", Groupcd: 0 });
    }
    getInformation() {
        if (this.run.MetaData.ModeType != null && this.run.MetaData.ModeType != undefined) {
            this.pagetitle = "Standard Boiling Points" + " " + "[" + this.run.MetaData.ModeType + "]";
        }
        else {
            this.pagetitle = "Standard Boiling Points";
        }
 
    }

    resetRowId() {

        if (this.run.lstRunCutBoilingPoints != null && this.run.lstRunCutBoilingPoints.length > 0) {
            var maxRowId = 0;
            for (var i = 0; i < this.run.lstRunCutBoilingPoints.length; i++) {
                this.run.lstRunCutBoilingPoints[i].RowId = maxRowId;
                maxRowId = i + 1;

            }
            this.count = maxRowId;
        }
    }
    captureOldValue(event) {
        this.oldValue = Number(event.target.value);
    }



    updateValue(event: any, value: any, rowId: any, unit: any, index: any) {
        debugger;
        let currentvalue = Number(event.target.value);
        let yieldCutInitBP, yieldCutEndBP, nextYieldCutInitBP, nextYieldCutEndBP;
        if (this.oldValue != currentvalue) {

            if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
                currentvalue = unit.Slope / (currentvalue + unit.Intercept);
                yieldCutInitBP = undefined != this.run.lstRunCutBoilingPoints[index].InitialBoilingPoint ? Math.round((unit.Slope / this.run.lstRunCutBoilingPoints[index].InitialBoilingPoint) - unit.Intercept) : "";
                yieldCutEndBP = Math.round((unit.Slope / currentvalue) - unit.Intercept);
                nextYieldCutEndBP = undefined != this.run.lstRunCutBoilingPoints[index + 1] ? Math.round(((unit.Slope / this.run.lstRunCutBoilingPoints[index + 1].EndBoilingPoint) - unit.Intercept)) : "";
            }
            else {
                currentvalue = currentvalue * unit.Slope + unit.Intercept;
                yieldCutInitBP = undefined != this.run.lstRunCutBoilingPoints[index].InitialBoilingPoint ? Math.round(((this.run.lstRunCutBoilingPoints[index].InitialBoilingPoint) - unit.Intercept) / unit.Slope) : "";
                yieldCutEndBP = Math.round(((currentvalue) - unit.Intercept) / unit.Slope);
                nextYieldCutEndBP = undefined != this.run.lstRunCutBoilingPoints[index + 1] ? Math.round(((this.run.lstRunCutBoilingPoints[index + 1].EndBoilingPoint) - unit.Intercept) / unit.Slope) : "";
            }

            this.run.lstRunCutBoilingPoints[index].EndBoilingPoint = currentvalue;
            this.run.lstRunCutBoilingPoints[index].YieldCutLabel = yieldCutInitBP + '-' + yieldCutEndBP + unit.DisplayText;//Index
            if (undefined != this.run.lstRunCutBoilingPoints[index + 1]) {
                this.run.lstRunCutBoilingPoints[index + 1].InitialBoilingPoint = currentvalue;  //Index    
                this.run.lstRunCutBoilingPoints[index + 1].YieldCutLabel = yieldCutEndBP + '-' + nextYieldCutEndBP + unit.DisplayText;
            }

        }
    }

    AddNewRow(event: any, EBP: any, rowId: any, index: any) {
        debugger;
        this.run.lstRunCutBoilingPoints.splice(index + 1, 0, { RowId: rowId + 1, InitialBoilingPoint: EBP, EndBoilingPoint: null, YieldCutLabel: null, BoilingPointType: null });
        this.resetRowId();
    }
    AddNewRowatbottom(unit: any) {
        debugger;
        let prevYildCUt: string;
        let initBP: number;
        let finalBP: number;
        let currentYieldCut: string;
        this.count++;
        this.run.lstRunCutBoilingPoints.push({ RowId: this.run.lstRunCutBoilingPoints.length + 1, InitialBoilingPoint: null, EndBoilingPoint: null, YieldCutLabel: null, BoilingPointType: null });
        this.resetRowId();
        this.selectedRow = this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 1];

        if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
            this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].YieldCutLabel = Math.round(unit.Slope / (this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].InitialBoilingPoint) - unit.Intercept) + '-' + Math.round(unit.Slope / (this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].EndBoilingPoint) - unit.Intercept) + unit.DisplayText;//Index
        }
        else {
            this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].YieldCutLabel = Math.round((this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].InitialBoilingPoint - unit.Intercept) / unit.Slope) + '-' + Math.round((this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].EndBoilingPoint - unit.Intercept) / unit.Slope) + unit.DisplayText;//Index
        }
        this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 1].InitialBoilingPoint = this.run.lstRunCutBoilingPoints[this.run.lstRunCutBoilingPoints.length - 2].EndBoilingPoint;
    }
    onRowSelect($event) {
        debugger;
    }
    CopyfromStandard() {
        debugger;
        this.run.lstRunCutBoilingPoints = [];
        this.run.lstRunCutBoilingPoints = JSON.parse(JSON.stringify(this.run.MasterData.LstStdBoilingPoints));
        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.boilingPointsInfoCopied });
    }
    onDeleteRow(event: any, InitialBoilingPoint: any, rowId: any, index: any) {
        this.run.lstRunCutBoilingPoints = this.run.lstRunCutBoilingPoints.filter((i: any) => i.RowId != rowId);
        this.resetRowId();
    }
    getRuncutBoilingPointInformation(PlantCd: string, RunId: string, ModeType: string) {
        debugger;
        this.run.lstRunCutBoilingPoints = JSON.parse(JSON.stringify(this.run.MasterData.LstStdBoilingPoints));

        if (this.run.lstRunCutBoilingPoints == null || this.run.lstRunCutBoilingPoints == undefined || this.run.lstRunCutBoilingPoints.length == 0) {
            this.run.lstRunCutBoilingPoints = JSON.parse(JSON.stringify(this.run.MasterData.LstStdBoilingPoints));
        }
        else {
            this.run.lstRunCutBoilingPoints = this.run.lstRunCutBoilingPoints;

        }
        this.runService.GetRunBoilingPointsInfo(PlantCd, RunId, ModeType)
            .subscribe(
                (data: any) => {
                    debugger;
                    if (data == null || data == undefined || data.length == 0) {
                        this.run.lstRunCutBoilingPoints = JSON.parse(JSON.stringify(this.run.MasterData.LstStdBoilingPoints));
                    }
                    else {
                        this.run.lstRunCutBoilingPoints = data;

                    }


                },
                err => { }
            );
    }
    
    onReset() {
        debugger;
        this.getRuncutBoilingPointInformation(this.run.MetaData.Plant, this.run.MetaData.RunId, this.run.MetaData.ModeType);
        this.runDataService.changeMessage(this.run);
    }
}

