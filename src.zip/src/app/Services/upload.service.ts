﻿import { Injectable } from '@angular/core';
import { AppComponent } from '../app.component';
import * as Constants from '../Shared/globalconstants';
import { Observable } from 'rxjs/Rx';
import { HttpActionService } from './httpaction.service';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';


@Injectable()

export class UploadService {
    progress: any;
    progressObserver: any;
    private UploadFeedFileUrl: string = "/Project/UploadFile/";
    private DownloadFeedFileUrl: string = "/Project/DownloadFile/";
    private GetProjectAllDocumentsUrl: string = "/Project/GetProjectAllDocuments/";
    private deleteFileUrl: string = "/Project/DeleteFile/";

    
    constructor(private appComponent: AppComponent, private httpaction: HttpActionService, private http: Http) { }

    UploadFile(postData: any, files: File[], progressId: any): Observable<any> {
        
        return Observable.create((observer: any) => {
            this.appComponent.isLoading = true;

            let formData: FormData = new FormData(),
                xhr: XMLHttpRequest = new XMLHttpRequest();
            xhr.withCredentials = true;

            for (let i = 0; i < files.length; i++) {
                formData.append("uploads[]", files[i], files[i].name);
            }

            if (postData !== "" && postData !== undefined && postData !== null) {
                for (var property in postData) {
                    if (postData.hasOwnProperty(property)) {
                        formData.append(property, postData[property]);
                    }
                }
            }

            xhr.onreadystatechange = () => {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        observer.next(JSON.parse(xhr.response));
                        observer.complete();
                        this.appComponent.isLoading = false;
                    } else {
                        this.appComponent.isLoading = false;
                        observer.error(xhr.response);
                    }
                }
            };

            xhr.upload.onprogress = (event) => {
                if (document.getElementById("bar" + progressId) != null) {
                    document.getElementById("bar" + progressId).style.width = (Math.round(event.loaded / event.total * 100)) + "%";
                }
                if (document.getElementById("circle" + progressId) != null) {
                    document.getElementById("circle" + progressId).style.transform = "scaleY(" + ((Math.round(event.loaded / event.total * 100)) / 100) + ")";
                }
            };

            xhr.open('POST', Constants.apiBaseUrl + this.UploadFeedFileUrl, true);
            var serverFileName = xhr.send(formData);
            return serverFileName;
        });
    }

    DownloadFile(fileId: number, projectId: number) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('fileId', fileId.toString());
        params.set('projectId', projectId.toString());
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.DownloadFeedFileUrl, options);
    }


    GetProjectAllDocuments( projectId: number) {
        let params: URLSearchParams = new URLSearchParams();       
        params.set('projectId', projectId.toString());
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.GetProjectAllDocumentsUrl, options);
    }
    DeleteFile(file: any) {
        return this.httpaction.post(file, this.deleteFileUrl);
    }
}