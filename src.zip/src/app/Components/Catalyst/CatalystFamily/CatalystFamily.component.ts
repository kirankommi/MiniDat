﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystFamilyService } from '../../../Services/CatalystServices/CatalystFamily.service';
import { CatalystFamilyModel, KeyValue } from '../../../models/Catalyst/CatalystFamilyModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../../Directives/uomcontrol.component';

@Component({
    //moduleId: module.id,
    templateUrl: 'CatalystFamily.component.html',
    providers: [CatalystFamilyService, AlertMessage, HttpActionService, ConfirmationService]
})

export class CatalystFamilyComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    catalystFamily: CatalystFamilyModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean;
    insertUpdate: boolean = false;
    @ViewChild('roleTable') dataTableComponent: any;
    selComponentType: string;    
    pieceDensityMinUomObj: any = {};
    pieceDensityMaxUomObj: any = {};  
    loiMinUomObj: any = {};
    loiMaxUomObj: any = {};
    sulfurMinUomObj: any = {};
    sulfurMaxUomObj: any = {};
    catalystFamilyList: any;     
    Statuses: KeyValue[];
    catalystTypes: KeyValue[];
    applications: KeyValue[];
    filteredapplications: KeyValue[];
    sortField: string;
    sortOrder: number;   
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    NotModifiable: boolean = false;    
    modeSaved: string = "Catalyst Family Details Saved Successfully";
    modeDeleted: string = "Catalyst Family Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;

    constructor(private catalystFamilyService: CatalystFamilyService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;      
    }

    ngOnInit()
    {
        debugger;
        this.catalystFamily = new CatalystFamilyModel();
        this.catalystFamily.CommercialName = null;
        this.catalystFamily.ProgramName = null;
        //this.catalystFamily.FamilyIndicator = "C"; //Default bind to commercial
        this.getCatalystFamilyList(true);
        this.title = Constants.ManageCatalystFamily;      
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }  

    getCatalystApplications()  
    {
        debugger;  
        if (this.catalystFamily.CatalystType != 0)    
        {
            this.filteredapplications = this.applications.filter((e: any) => (e.Groupcd == this.catalystFamily.CatalystType));
            this.filteredapplications.push({ Key: '0', Value: Constants.Select, Groupcd: 0 });
            this.filteredapplications = this.filteredapplications.sort(function (obj1, obj2) { return obj1.Groupcd - obj2.Groupcd; });

        }
        else
        {
            this.filteredapplications = this.applications;
        }       
    }

    BindCatalystType()
    {
        debugger;
        var number = this.catalystFamily.ApplicationName;
        var application = this.applications.filter((e: any) => (e.Key == this.catalystFamily.ApplicationName));
        this.catalystFamily.CatalystType = this.applications.filter((e: any) => (e.Key == this.catalystFamily.ApplicationName))[0].Groupcd;
       

        //this.catalystFamilyService.getCatalystTypebyApplication(this.catalystFamily.ApplicationName)
        //    .subscribe(
        //    (data: any) => {
        //        debugger;
        //        this.catalystFamilyList = data.LstcatalystFamily;                
        //    },
        //    err => { }
        //    //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
        //    );
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.catalystFamily.CommercialName = event.data.CommercialName;
        this.catalystFamily.ProgramName = event.data.ProgramName;    
        this.catalystFamily.CatalystType = event.data.CatalystTypecd.Key;
        //this.getCatalystApplications();
        this.catalystFamily.ApplicationName = event.data.CatalystApplicaton.Key;
        this.catalystFamily.StatusName = event.data.StatusCode.Key;
        this.catalystFamily.PieceDensityMinSpec = event.data.PieceDensityMinSpec;
        this.catalystFamily.PieceDensityMaxSpec = event.data.PieceDensityMaxSpec;
        this.catalystFamily.LOIMinSpec = event.data.LOIMinSpec;
        this.catalystFamily.LOIMaxSpec = event.data.LOIMaxSpec;
        this.catalystFamily.SulfurMinSpec = event.data.SulfurMinSpec;
        this.catalystFamily.SulfurMaxSpec = event.data.SulfurMaxSpec;
        this.catalystFamily.CatalystFamilyID = event.data.CatalystFamilyID;
        this.catalystFamily.FamilyIndicator = event.data.FamilyIndicatorcd.Key;       
        this.catalystFamily.SDSNumber = event.data.SDSNumber;   
      
    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getCatalystFamilyList(isInit: boolean)
    {
        debugger;      
        this.catalystFamily.IsInitialLoad = isInit;
        this.catalystFamilyService.getCatalystFamilyInformatin(this.catalystFamily)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.catalystFamilyList = data.LstcatalystFamily;              
                this.Statuses = data.lstStatus;
                this.applications = data.lstCatalystApplications;
                this.filteredapplications = [];
                this.filteredapplications = this.applications;
                //this.filteredapplications.push({ Key: '0', Value: Constants.Select, Groupcd: 0 })
                this.catalystTypes = data.lstCatalystTypes;
                this.totalRecords = data.RecordsFetched;
                if (this.catalystFamily.ApplicationName == undefined || this.catalystFamily.ApplicationName == null)
                { this.catalystFamily.ApplicationName = 0; }   
                if (this.catalystFamily.CatalystType == undefined || this.catalystFamily.CatalystType == null)
                { this.catalystFamily.CatalystType = 0; }
                if (this.catalystFamily.StatusName == undefined || this.catalystFamily.StatusName == null)
                { this.catalystFamily.StatusName = Constants.Select; }               
                
            },
            err =>{}
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onAppchange()
    {
        //
    }

    SaveCatalystFamily()
    {
        debugger;
        let response: any;
        if (this.catalystFamily.FamilyIndicator == null || this.catalystFamily.FamilyIndicator == undefined)
        { this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RadioBoxCheckRequired });}
        else if (this.catalystFamily.FamilyIndicator == "C" && (this.catalystFamily.CommercialName == null || this.catalystFamily.CommercialName == undefined))
        { this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.CommercialNameRequired });}
        else if (this.catalystFamily.FamilyIndicator == "P" && (this.catalystFamily.ProgramName == null || this.catalystFamily.ProgramName == undefined))
        { this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.ProgramNameRequired });}
        else if (this.isDataValid())
        {                          
            this.catalystFamily.AppCode = this.selectedApplicationCode;
            this.catalystFamily.CanEdit = "Y";          

            this.catalystFamilyService.saveCatalystFamilyInformation(this.catalystFamily)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        //this.onReset()
                        this.getCatalystFamilyList(true);
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.modeSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(mode: CatalystFamilyModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteModeInfo(mode);}
        });
    }

    deleteModeInfo(catalystFamily: CatalystFamilyModel)
    {
        debugger;
        catalystFamily.AppCode = this.selectedApplicationCode;

        this.catalystFamilyService.deleteCatalystFamily(catalystFamily)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.modeDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }   

    onReset() {
        debugger;
        this.catalystFamily = new CatalystFamilyModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.catalystFamily.SDSNumber = null;
        
        this.getCatalystFamilyList(true);      
        this.selectedApplicationCode = "5";      
        //this.catalystFamily.FamilyIndicator = "C";
    }

    isDataValid()
    {
        debugger;
        if (this.catalystFamily == null || this.catalystFamily.CatalystType == 0 || this.catalystFamily.StatusName == "Select" || !this.catalystFamily.SDSNumber
            || (this.catalystFamily.PieceDensityMinSpec == null || this.catalystFamily.PieceDensityMinSpec == undefined)
            || (this.catalystFamily.PieceDensityMinSpec == null || this.catalystFamily.PieceDensityMinSpec == undefined)
            || (this.catalystFamily.LOIMinSpec == null || this.catalystFamily.LOIMinSpec == undefined)
            || (this.catalystFamily.LOIMaxSpec == null || this.catalystFamily.LOIMaxSpec == undefined)
            //|| (this.catalystFamily.SulfurMaxSpec == null || this.catalystFamily.SulfurMaxSpec == undefined)
            //|| (this.catalystFamily.SulfurMinSpec == null || this.catalystFamily.SulfurMinSpec == undefined)
            || (this.catalystFamily.FamilyIndicator == "C" && (this.catalystFamily.CommercialName == undefined || this.catalystFamily.CommercialName == null))
            || (this.catalystFamily.FamilyIndicator == "P" && (this.catalystFamily.ProgramName == undefined || this.catalystFamily.ProgramName == null))
          )
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {
        //debugger;
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    //if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "ROLE" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000015" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                    {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
