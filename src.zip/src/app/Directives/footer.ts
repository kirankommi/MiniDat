import { Component, OnInit } from '@angular/core';
import { Message } from 'primeng/primeng';
import { appService } from '../Services/app.service';

@Component({
    //moduleId: module.id,
    selector: 'fdms-footer',
    templateUrl: 'footer.html'
})

export class FooterDirective implements OnInit {
    version: string
    constructor(private appService: appService) {

    }
    ngOnInit() {
        this.GetVersion();
    }
    GetVersion() {
        this.appService.getVersion().subscribe((data: any) => {
            if (data != null) {
                this.version = data;
            }
        },
            (error: any) => { });
    }
}
