﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DOE
{
    public class Study
    {
        private DOE_Project project = new DOE_Project();

        public DOE_Project Project
        {
            get { return project; }
            set { project = value; }
        }

        public int? IDSQ { get; set; }

        public string Name { get; set; }
        public string ApprochingGate { get; set; }
        public string SpecialistNM { get; set; }
        public string SpecialistID { get; set; }
        public double? Estimation { get; set; }
        public string Objective { get; set; }
        public string Strategy { get; set; }
        public string DOEQuestion { get; set; }
        public string Conclusion { get; set; }
        public string FinalDate { get; set; }
        public string CreatedEID { get; set; }
        public string CreatedName { get; set; }

        public List<Run> Runs { get; set; }
        public List<FileInfo> File_List { get; set; }

        public Run this[int runID]
        {
            get
            {
                return this.Runs.First(q => q.RUN_ID == runID);
            }
        }
    }

    public class SaveModel
    {
        public Study DOE { get; set; }
        public string DeleteIds { get; set; }
    }

    public class FileInfo
    {
        public string FileName { get; set; }
        public int UID { get; set; }
        public string Description { get; set; }
        public bool isDirty { get; set; }
    }
}
