﻿using System;
using System.Data;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Collections;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Configuration;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Models.Interfaces;
using System.Collections.Generic;

namespace MINIDAT.DataAccess
{
    public class MINIDATDatabase : IDatabase
    {
        private Database _db;
        public MINIDATDatabase()
        {
            var connectionKey = ConfigurationManager.AppSettings["ConnectionString"];
            string connectionString = ConfigurationManager.ConnectionStrings[connectionKey].ConnectionString;
            _db = new SqlDatabase(connectionString);
            
        }
        public Database Instance
        {
            get
            {
                return _db;
            }
            set
            {
                _db = value;
            }
        }
        public IDbCommand CreateCommand(string sql, bool isStoredProcedure)
        {
            IDbCommand cmd = null;
            if (isStoredProcedure)
            {
                cmd = _db.GetStoredProcCommand(sql);
            }
            else
            {
                cmd = _db.GetSqlStringCommand(sql);
            }            
            return cmd;
        }
        public IDbCommand CreateCommand(string sql)
        {
            return CreateCommand(sql, true);
        }

        public int ExecuteNonQuery(IDbCommand cmd)
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            try
            {
                using (cmd)
                {
                    return _db.ExecuteNonQuery((DbCommand)cmd);
                }
            }
            finally
            {
                cmd.Connection.Close();
            }
        }
        public IDataReader ExecuteReader(IDbCommand cmd)
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            using (cmd)
            {
                return _db.ExecuteReader((DbCommand)cmd);
            }
        }

        public DataSet ExecuteDataSet(IDbCommand cmd)
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            using (cmd)
            {
                return _db.ExecuteDataSet((DbCommand)cmd);
            }
        }

        public object ExecuteScalar(IDbCommand cmd)
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            try
            {
                using (cmd)
                {
                    return _db.ExecuteScalar((DbCommand)cmd);
                }
            }
            finally
            {
                cmd.Connection.Close();
            }
        }
        public void CreateParameters(IDbCommand cmd, IDictionary parameterValues)
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            if (parameterValues == null) throw new ArgumentNullException("parameterValues");
            for (IEnumerator iter = parameterValues.GetEnumerator(); iter.MoveNext();)
            {
                DictionaryEntry parameter = (DictionaryEntry)iter.Current;
                if (parameter.Value == null) continue;
                IDbDataParameter cmdParam = cmd.CreateParameter();
                cmdParam.ParameterName = parameter.Key.ToString();
                cmdParam.Value = parameter.Value;
                cmd.Parameters.Add(cmdParam);
            }
        }

        public IList<T> ExecuteReaderToList<T>(IDbCommand cmd) where T : IModel, new()
        {
            if (cmd == null) throw new ArgumentNullException("cmd");
            using (cmd)
            {
                var reader = _db.ExecuteReader((DbCommand)cmd);
                var data = new List<T>();
                while (reader.Read())
                {
                    var x = new T();
                    ((IModel)x).CreateModelFromReader(reader);
                    data.Add(x);
                }
                reader.Dispose();
                return data;
            }
        }
    }
}
