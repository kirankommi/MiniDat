import { Component, OnInit, ViewChild, ElementRef, Renderer } from '@angular/core';
import { UserService } from '../../../Services/user.service';
import { UserModel, KeyValue, ApplicationModel } from '../../../Models/UserModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import { AlertMessage } from '../../../services/alertmessage.service';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { AppComponent } from '../../../app.component';
import * as Constants from '../../../Shared/globalconstants';
import { appService } from 'src/app/Services/app.service';

@Component({
    //moduleId: module.id,
    templateUrl: 'user.component.html',
    providers: [UserService, AlertMessage, ConfirmationService]
})

export class UserComponent implements OnInit {
    title: string;
    userId: string;
    privilege: string;
    userList: UserModel[];
    toListValues: ApplicationModel[] = [];
    totalRecords: number;
    userData: UserModel;
    roles: KeyValue[];
    statuses: KeyValue[];
    departments: KeyValue[];
    applications: KeyValue[];
    sortField: string;
    sortOrder: number;
    check: boolean;
    InsertUpdateCheck: boolean = false;
    IsallowedSave: boolean = false;
    setStyles: boolean;
    isCollapsed = false;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    userSaved: string = "User Details Saved Successfully";
    userDeleted: string = "User Deleted Successfully";
    selectedRole: any[];
    sourceList: any[];
    ApplicationId: any;
    @ViewChild('userTable') dataTableComponent: any;
    insertUpdate: boolean = false;
    flyoutUserHeader: string = "LDAP User Details";
    pHolderUser: string = "LDAP User Details";
    ngOnInit() {

        this.userList = [];
        this.userData = new UserModel();
        this.getUsers();
        this.userData.DepartmentName = Constants.Select;
        this.userData.StatusName = Constants.Select;
        this.title = Constants.ManageUser;
        this.userData.UserRoleDetails = [];
        this.sourceList = [];
        this.title = Constants.ManageUser;
        this.getApplicationId();
    }
    getApplicationId() {
        this.appservice.getSessionData().subscribe(q => {
            this.ApplicationId = q.User.ApplicationId;
        });
    }
    constructor(private userService: UserService, public el: ElementRef, public renderer: Renderer,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private appComponent: AppComponent,
        private confirmationService: ConfirmationService, public appservice: appService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
        this.selectedRole = [];

    }

    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    ngDoCheck() {
        if (!this.check) {
            if (Constants.UserSessionData != Constants.Undefined) {
                if (Constants.UserPrivileges.length > 1) {
                    debugger;
                    for (let i in Constants.UserPrivileges) {
                        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000004" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                            this.IsallowedSave = true;
                        }
                    }
                    this.check = true;
                }
            }
        }
    }

    depchange(event: any) {
    }

    onCollapse() {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any) {
        let result: any;
        this.toListValues.forEach((x: any) => { x.IsChecked = false; x.RoleName == Constants.Select });
        this.userData.UserRoleDetails = [];
        this.userData.DepartmentName = (event.data.DepartmentCode.Key != "") ? event.data.DepartmentCode.Key : Constants.Select;
        this.userData.StatusName = event.data.StatusCode.Key;
        this.userData.EID = event.data.EID;
        this.InsertUpdateCheck = true;
        this.insertUpdate = true;
        this.userData.FirstName = event.data.FirstName;
        this.userData.LastName = event.data.LastName;
        this.userData.Phone = event.data.Phone;
        this.userData.EmailId = event.data.EmailId;
        result = event.data.RoleCode.Key.split(',');
        for (var i = 0; i < result.length; i++) {
            let app = this.toListValues.filter((x: any) => x.ApplicationName == result[i])[0];
            let appRoles = this.roles.filter((x: any) => x.Value == result[i + 1])[0];
            if (app != null && appRoles != null) {
                this.userData.UserRoleDetails.push({ ApplicationName: app.ApplicationName, RoleName: appRoles.Key, ApplicationId: app.ApplicationId, IsChecked: true, IsallowedCheck: true, RoleCd: "" })
            }
            if (app != null) {
                app.IsChecked = true;
                if (result[i + 1] != null) {
                    app.RoleName = this.roles.filter((x: any) => x.Value == result[i + 1])[0].Key;
                }
                else {
                    app.RoleName = Constants.Select;
                }

            }

        }

    }

    onRowUnselect($event: any) { }

    getUsers() {

        this.toListValues = [];
        this.userData.UserRoleDetails = [];
        this.userService.getUsers(this.userData)
            .subscribe(
                (data: any) => {
                    debugger;
                    this.toListValues = [];
                    this.userList = data.Users;
                    if (data.Applications.length > 0) {
                        for (let iz of data.Applications) {
                            this.toListValues.push({ ApplicationName: iz.Value, RoleName: Constants.Select, ApplicationId: iz.Key, RoleCd: "", IsChecked: false, IsallowedCheck: true });
                        }
                        let app = this.toListValues.find(item => item.ApplicationId == this.ApplicationId);
                        if (app != null) {
                            app.IsChecked = true;
                            app.IsallowedCheck = false;
                            this.userData.UserRoleDetails.push({ ApplicationName: app.ApplicationName, RoleName: Constants.Select, ApplicationId: app.ApplicationId, RoleCd: "", IsChecked: true, IsallowedCheck: false })
                        }
                    }
                    this.roles = data.Roles;
                    this.departments = data.Departments;
                    this.applications = data.Applications;
                    this.statuses = data.Status;
                    this.totalRecords = data.RecordsFetched;
                    this.sortField = (data.Users != null && data.Users.length > 0) ? data.Users[0].SortColumn : "";
                    this.sortOrder = (data.Users != null && data.Users.length > 0) ? data.Users[0].SortOrder : "";
                },
                (err: any) => { }
                //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    saveUser() {

        if (this.isDataValid()) {
            //email regex validation added......
            let emailRegexPattern = /^\S+@(([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6})$/;
            if (!emailRegexPattern.test(this.userData.EmailId)) {
                this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'Invalid EmailId', detail: "Emaild pattern is not recognized !" })
                return false;
            }

            this.userData.DepartmentCode = this.departments.filter(x => x.Key == this.userData.DepartmentName)[0];
            this.userData.StatusCode = this.statuses.filter(x => x.Key == this.userData.StatusName)[0];
            this.userData.EID = this.userData.EID.charAt(0).toUpperCase() + this.userData.EID.slice(1);
            if (this.InsertUpdateCheck == true) {
                this.userData.OldUserId = this.userData.EID;
            }
            else {
                this.userData.OldUserId = "";
            }
            this.userData.FirstName = this.userData.FirstName.charAt(0).toUpperCase() + this.userData.FirstName.slice(1);
            this.userData.LastName = this.userData.LastName.charAt(0).toUpperCase() + this.userData.LastName.slice(1);

            this.userService.saveUserData(this.userData)
                .subscribe(
                    (data: any) => {
                        if (data == Constants.Success || data == true) {
                            this.userData.OldUserId = '';
                            this.InsertUpdateCheck = false;
                            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.userSaved });
                            this.onReset();
                            this.appComponent.GetUserData();
                        }
                    },
                    (err: any) => { }
                    //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }
    testPromise() {
        return new Promise((resolve, reject) => {
            resolve(true);
        });
    }

    onDelete(userData: UserModel) {
        this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteUser(userData); }
        });

    }

    deleteUser(userData: UserModel) {
        console.log(userData);
        this.userService.deleteUserData(userData)
            .subscribe(
                (data: any) => {
                    console.log(data);
                    if (data == "Delete") {
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.userDeleted });
                        this.onReset();
                    }
                    else {
                        console.log(data);
                        this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: "Could not delete the User. Please remove all the dependency for the user and try again." });
                    }
                },
                (err: any) => { }
                //    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onReset() {
        this.userData = new UserModel();
        this.userData.DepartmentName = Constants.Select;
        this.userData.StatusName = Constants.Select;
        this.sortField = "";
        this.sortOrder = 0;
        this.getUsers();
        this.dataTableComponent.reset();
        this.sourceList = [];
        this.InsertUpdateCheck = false;
        this.insertUpdate = false;
    }
    updateSelection(src: any) {
        var idx = -1;
        var idxCheck = -1;
        if (this.InsertUpdateCheck == true) {
            if (this.userData.UserRoleDetails.length > 0) {
                for (var j = 0; j < this.userData.UserRoleDetails.length; j++) {
                    if (this.userData.UserRoleDetails[j].ApplicationId == src.ApplicationId) {
                        idxCheck = j;
                    }
                }
                if (idxCheck > -1) {
                    this.userData.UserRoleDetails.splice(idxCheck, 1);

                }
                else {
                    this.userData.UserRoleDetails.push(src);
                }
            }
        }
        else if (this.InsertUpdateCheck == false) {

            if (this.sourceList.length > 0) {
                for (var i = 0; i < this.sourceList.length; i++) {
                    if (this.sourceList[i].ApplicationId == src.ApplicationId) {
                        idx = i;
                    }

                }
                // is currently selected
                if (idx > -1) {
                    this.sourceList.splice(idx, 1);
                }

                // is newly selected
                else {
                    this.sourceList.push(src);
                }
            }
            else {
                this.sourceList.push(src);
            }
            this.userData.UserRoleDetails = this.sourceList;

        }

    }

    isDataValid() {
        debugger;
        if (this.userData == null || !this.userData.EID ||
            !this.userData.FirstName || !this.userData.LastName || !this.userData.EmailId
            || !this.userData.StatusName || this.userData.StatusName == Constants.Select) {
            return false;
        }
        else if (this.userData.UserRoleDetails == undefined || this.userData.UserRoleDetails.length == 0) {
            return false;
        }
        else if (this.userData.UserRoleDetails.length > 0) {
            for (var i = 0; i < this.userData.UserRoleDetails.length; i++) {
                if (this.userData.UserRoleDetails[i].IsChecked && (this.userData.UserRoleDetails[i].RoleName == Constants.Select || this.userData.UserRoleDetails[i].RoleName == undefined || this.userData.UserRoleDetails[i].RoleName == null)) {
                    return false;
                }
            }
        }
        return true;
    }

    getDelPath() {
        if (!this.IsallowedSave) {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;
    }
    rolechange(event: any) {
        let app: any;
        if (this.userData.UserRoleDetails.length > 0) {
            for (var j = 0; j < this.userData.UserRoleDetails.length; j++) {
                app = this.userData.UserRoleDetails.filter((x: any) => x.ApplicationName == event.ApplicationName)[0];
                if (app != null) {
                    app.RoleName = event.RoleName;
                    this.userData.RoleName = app.RoleName;
                }
            }
        }
    }
    updateLDAPSelection(event, condition)
    {
        debugger;
        if (event.CellChange) {
            this.userData.EID = event.Value;
        }
        else {
            this.userData.EID = event.EID;
            //this.userData.FirstName = event.FirstName;
            //this.userData.LastName = event.GivenName;
            this.userData.FirstName = event.GivenName;
            this.userData.LastName = event.FirstName;
            this.userData.EmailId = event.Mail;
        }
    }
}

