import { Component, OnInit } from '@angular/core';
import { SPPService } from '../../../../Services/sppservice';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { ActivatedRoute } from '@angular/router';
import * as  Constants from '../../../../Shared/globalconstants';
@Component({
  selector: 'app-spp',
  templateUrl: './spp.component.html',
  providers: [SPPService, AlertMessage, HttpActionService, ConfirmationService]
})
export class SPPComponent implements OnInit {

  sppList: any;
  cols: any;
  spList: any;
  sub: any;
  templateId: any;
  maxValues: any[] = [];
  constructor(private sppService: SPPService, private route: ActivatedRoute, private alertMessage: AlertMessage) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.templateId = params['field'];
    });
    // while (this.templateId > 12) {
    //   this.templateId = this.templateId - 12;
    // }
    this.cols = [
      { field: 'PairNumber', header: 'Pair #', rowspan: "1" },
      { field: 'RampRate', header: 'Ramp Rate', rowspan: "1" },
      { field: 'SoakValue', header: 'Soak Value', rowspan: "1" },
      { field: 'SoakTime', header: 'Soak Time', rowspan: "1" },
      { field: 'RampReciepeNumber', header: 'Ramp Recipe #', rowspan: "1" },
      { field: 'SoakReciepeNumber', header: 'Soak Recipe #', rowspan: "1" },
      { field: 'Description', header: 'Description', rowspan: "2" }
    ];
    this.maxValues = [
      { MaxValue: "Max Values ►", LabelText: "Max Value" },
      { MaxValue: "1000", LabelText: "RampRate" },
      { MaxValue: "1000", LabelText: "SoakValue" },
      { MaxValue: "7200", LabelText: "SoakTime" },
      { MaxValue: "25", LabelText: "RampReciepeNumber" },
      { MaxValue: "25", LabelText: "SoakReciepeNumber" },
      { MaxValue: "Description", LabelText: "Description" }
    ];
    this.getSPPData();
  }

  getSPPData() {
    this.sppService.getSPPInformation(this.templateId)
      .subscribe(
        (data: any) => {
          this.spList = data.lstModelInfo;
        },
        err => {
          this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Error', detail: 'Some thing went wrong' });
        }
      );
  }
  getColor() {
    return 'white';
  }
  getColumnBorder(vCol: string) {
    if (vCol === 'Description') {
      return "0px solid white";
    }
  }
}
