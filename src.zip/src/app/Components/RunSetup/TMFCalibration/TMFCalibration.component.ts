import { Component, OnInit } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel } from '../../../models/Run/RunModel';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { HttpActionService } from 'src/app/Services/httpaction.service';
import { ConfirmationService } from 'primeng/primeng';
import { RunDataService } from "../run.data.service";
import * as Constants from '../../../Shared/globalconstants';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
  selector: 'tmfCalibration',
  templateUrl: 'TMFCalibration.component.html',
  providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})
export class TMFCalibrationComponent implements OnInit
{
    // run1: RunModel; 
    oldValue: number = 0;
    runSaved: string = "Run TMF Calibration Information Saved Successfully";
    check: boolean = false;
    IsallowedSave: boolean = true;
    run: RunSetupModel;        
      
    constructor(private runService: RunService, public runDataService: RunDataService, private alertMessage: AlertMessage, private confirmationService: ConfirmationService, private runComponent: RunComponent) { } 
  ngOnInit()
  {
      debugger;
      this.runDataService.currentMessage.subscribe(runmodel => this.run = runmodel)     
      if (this.run.lstTMF_Calibrations == null || this.run.lstTMF_Calibrations == undefined || this.run.lstTMF_Calibrations.length == 0) {
          this.run.lstTMF_Calibrations = null;
      }
      this.runComponent.exportData.selectedPopupList = [];
      this.runComponent.exportData.selectedPopupList.push({ Key: "7", Value: "TMS & Mass Flow Meter Calibration", Groupcd: 0 });

  }

  getTMFCalibrationData(PlantCd: string, RunId: string)
  {
      this.runService.GetTMFCalibrationInformation(PlantCd, RunId)
      .subscribe(
          (data: any) =>
          {
            debugger;
            this.run.lstTMF_Calibrations = data;  
            this.runDataService.changeMessage(this.run);             
        },
        err => { }        
      );
  }
  updateValue(event: any, value: any, rowId: any, unit: any, index: any)
  {
      debugger;
      if (event.target.value == "") {
          this.run.lstTMF_Calibrations[index].Value = null;
      }
      else {
          let currentvalue = Number(event.target.value);
          if (this.oldValue != currentvalue) {
              if (unit.UnitName == "API" || unit.UnitName == "BAUME" || unit.UnitName == "BAUME<5") {
                  this.run.lstTMF_Calibrations[index].Value = unit.Slope / (currentvalue + unit.Intercept);
              }
              else {
                  this.run.lstTMF_Calibrations[index].Value = currentvalue * unit.Slope + unit.Intercept;
              }
          }
      }

  }
  captureOldValue(event) {
      this.oldValue = Number(event.target.value);
  }
  onReset() {
      this.getTMFCalibrationData(this.run.MetaData.Plant, this.run.MetaData.RunId);
      this.runDataService.changeMessage(this.run);      
  }

  ngDoCheck() {
      if (!this.check) {
          if (Constants.UserPrivileges.length > 1) {
              for (let i in Constants.UserPrivileges)
              {
                  if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000067" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                  {
                      this.IsallowedSave = true;
                      this.check = true;
                  }
              }
          }
      }

  }
}

