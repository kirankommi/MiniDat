﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystFamilyModel
    {
        public int? CatalystFamilyID { get; set; }        
        public string ProgramName { get; set; }        
        public string CommercialName { get; set; }
        public int? ApplicationName { get; set; }
        public int? CatalystType { get; set; }
        public string StatusName { get; set; }
        //public string CatalystApplicatonName { get; set; }
        //public string CatalystTypeName { get; set; }
        public decimal? PieceDensityMinSpec { get; set; }
        public decimal? PieceDensityMaxSpec { get; set; }
        public decimal? LOIMinSpec { get; set; }
        public decimal? LOIMaxSpec { get; set; }
        public decimal? SulfurMinSpec { get; set; }
        public decimal? SulfurMaxSpec { get; set; }
        public string SDSNumber { get; set; }
        public string FamilyIndicator { get; set; }
        public KeyValue StatusCode { get; set; }
        public KeyValue CatalystApplicaton { get; set; }
        public KeyValue CatalystTypecd { get; set; }
        public KeyValue FamilyIndicatorcd { get; set; }
        public bool IsInitialLoad { get; set; }
    }
     public class CatalystFamilySearchModel
    {
        private IList<KeyValue> _catalystTypes= new List<KeyValue>();
        public IList<KeyValue> lstCatalystTypes { get { return _catalystTypes; } }

        private IList<KeyValue> _catalystApplications = new List<KeyValue>();  
        public IList<KeyValue> lstCatalystApplications { get { return _catalystApplications; } }
        
        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<CatalystFamilyModel> _lstcatalystFamily= new List<CatalystFamilyModel>();
        public IList<CatalystFamilyModel> LstcatalystFamily { get { return _lstcatalystFamily; } }


        public int RecordsFetched { get; set; }

    }
}
