﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { DiluentModel, KeyValue } from '../../Models/Catalyst/DiluentModel';
import { CatalystLoading, Bed, ReactorModel } from '../../models/Catalyst/CatalystLoadingModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class TemplateService
{
    private getLoadingTemplates = "/CatalystLoading/SearchLoadingTemplates/";
    private saveLoadingData = "/CatalystLoading/SaveLoadingInformation/";
    private deleteTemplatedata = "/CatalystLoading/DeleteTemplateInfo/";  
    private getReactorBedInfo: string = "/CatalystLoading/GetReactorBedDetails/";

    constructor(private httpaction: HttpActionService) { }

    searchLoadingTemplates(catalystLoading: CatalystLoading)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystLoading, this.getLoadingTemplates);
    }

    saveLoadingInformation(catalystLoading: CatalystLoading)
    {
        return this.httpaction.post(catalystLoading, this.saveLoadingData);
    }

    deleteTemplateInfo(catalystLoading: CatalystLoading)
    {
        debugger;
        return this.httpaction.post(catalystLoading, this.deleteTemplatedata);
    }
    GetReactorBedDetails(templateId: number) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('TemplateId', templateId.toString());
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getReactorBedInfo, options);
    }    
}
