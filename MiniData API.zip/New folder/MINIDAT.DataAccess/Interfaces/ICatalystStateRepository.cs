﻿using MINIDAT.Model.Catalyst;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface ICatalystStateRepository : ICRUDRepository<CatalystStateModel>
    {
        CatalystStateSearchModel GetCatalystStateData(CatalystStateModel catalystType);
        string DeleteCatalystStateData(CatalystStateModel catalystType);
        void SaveCatalystStateData(CatalystStateModel _catalystType, string userId); 

    }
}
