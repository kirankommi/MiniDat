export class RunMetaData {
    
    Plant: string;
    RunNum: string;
    RunId: string;
    StartDate: string;
    ZeroHOSTime: string;
    EndTime: string;
    RunStatus: string;
    ProjectMgr: string;
    NetworkNumber: string;
    PlantLocation: string;

    FeedId: string;
    FeedDensity: number;
    FeedCondition: string;

    NIRModelID: string;
    NIRNetConv_High: number;
    NIRNetConv_Low: number;

    ModeType: string;
    ModeId: string;
    CatalystVolume: number;
    FeedISCOTemp: number;

    lstDoeCataystinfo: any[];
    FeedUOP: string;
    FeedAnalyticalDensity: number;
    ModeLHSV: number;
    ModeSCFB: number;
    ModePressure: number;
    SulfidingType: number;
}