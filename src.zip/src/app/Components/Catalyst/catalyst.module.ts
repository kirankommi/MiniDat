import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CatalystFamilyComponent } from './CatalystFamily/CatalystFamily.component';
import { DiluentComponent } from './Diluent/Diluent.component';
import { CatalaystLoadingComponent } from './CatalystLoading/CatalaystLoading.component';
import { CatalystComponent } from './Catalyst.component';
import { ViewLimsComponent } from './viewlims.component';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { CatalystTypeComponent } from './CatalystType/CatalystType.component';
import { CatalystSizeComponent } from './CatalystSize/CatalystSize.component';
import { CatalystAliasSSComponent } from './CatalystAliasSS/CatalystAliasSS.component';
import { CatalystScaleComponent } from './CatalystScale/CatalystScale.component';
import { CatalystStateComponent } from './CatalystState/CatalystState.component';
import { CatalystShapeComponent } from './CatalystShape/CatalystShape.component';

const route: Routes = [
  {
    path: 'Family',
    component: CatalystFamilyComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'LoadingTemplate',
    component: CatalaystLoadingComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'Diluent',
    component: DiluentComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'Pool',
    component: CatalystComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
    path: 'Pool/:catalystId',
    component: CatalystComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
      path: 'CatalystType',
      component: CatalystTypeComponent,
      resolve: {
          UOM: routeResolver
      }
  },
    {
        path: 'CatalystSize',
        component: CatalystSizeComponent,
        resolve: {
            UOM: routeResolver
        }
  },
    {
        path: 'CatalystAliasSS',
        component: CatalystAliasSSComponent,
        resolve: {
            UOM: routeResolver
        }
    },
    {
        path: 'CatalystScale',
        component: CatalystScaleComponent,
        resolve: {
            UOM: routeResolver
        }
    },
    {
        path: 'CatalystState',
        component: CatalystStateComponent,
        resolve: {
            UOM: routeResolver
        }
    },
    {
        path: 'CatalystShape',
        component: CatalystShapeComponent,
        resolve: {
            UOM: routeResolver
        }
    }];


@NgModule({
  imports: [sharedModule, RouterModule.forChild(route)],
  declarations: [CatalystFamilyComponent,
    DiluentComponent,
    CatalystFamilyComponent,
    CatalaystLoadingComponent,
    CatalystComponent,
    ViewLimsComponent,
    CatalystTypeComponent,
    CatalystSizeComponent,
    CatalystAliasSSComponent,
    CatalystScaleComponent,
    CatalystStateComponent,
    CatalystShapeComponent]
})
export class catalystModule {

}
