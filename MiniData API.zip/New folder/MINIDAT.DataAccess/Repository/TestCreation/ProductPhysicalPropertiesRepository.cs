﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model;
using MINIDAT.Model.TestCreation;
using MINIDAT.Model.UOM;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.TestCreation
{
    public class ProductPhysicalPropertiesRepository : IProductPhysicalPropertiesRepository
    {
        private IDatabase _db;
        public ProductPhysicalPropertiesRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public ProductPhysicalPropertiesDropdownModel getDropdownData(ProductPhysicalPropertiesInput input)
        {

            //var tempList = new List<string> { "Unchecked","stream1", "stream2", "stream3" };

            //ProductPhysicalPropertiesDropdownModel objRecord = new ProductPhysicalPropertiesDropdownModel()
            //{
            //    Streams = tempList,
            //    ValidationIndicatorList = tempList
            //};
            //return objRecord;

            try
            {
                List<Streams> streamList = new List<Streams>();
                List<ValidationIndicator> validationIndicatorList = new List<ValidationIndicator>();

                ProductPhysicalPropertiesDropdownModel objRecord = new ProductPhysicalPropertiesDropdownModel();
                IDataReader reader = null;

                using (IDbCommand command = _db.CreateCommand("[md].[Get_Prod_Physical_Stream_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", input.PlantCd);
                    parameters.Add("@proc_in_Run_Num", input.RunId);
                    parameters.Add("@proc_in_Test_Num", input.TestId);
                    _db.CreateParameters(command, parameters);
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        Streams stream = new Streams()
                        {
                            StreamId = Convert.ToString(reader["STREAM_ID"]),
                            StreamName = Convert.ToString(reader["STREAM_NM"]),
                            SortOrder = Convert.ToString(reader["SORT_ORDER"])

                        };
                        streamList.Add(stream);
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        ValidationIndicator validIndicator = new ValidationIndicator()
                        {
                            ValidationId = Convert.ToString(reader["VALIDATION_IND"]),
                            ValidationName = Convert.ToString(reader["VALIDATION_IND_NM"]),

                        };
                        validationIndicatorList.Add(validIndicator);

                    }
                    objRecord.StreamList = streamList;
                    objRecord.ValidationIndicatorList = validationIndicatorList;
                    reader.NextResult();
                    reader.Close();
                    return objRecord;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<ProductPhysicalPropertiesModel> getUIDataRepo(ProductPhysicalPropertiesInput input, string userName, IList<UnitGroup> unitGroups)
        {
            try
            {
                List<ProductPhysicalPropertiesModel> obj = new List<ProductPhysicalPropertiesModel>();
                IDataReader reader = null;

                using (IDbCommand command = _db.CreateCommand("[md].[Get_Product_Phy_Prop_Dtl_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", input.PlantCd);
                    parameters.Add("@proc_in_Run_Num", input.RunId);
                    parameters.Add("@proc_in_Test_Num", input.TestId);
                    parameters.Add("@proc_in_Stream_Id", Convert.ToInt32(input.StreamId));
                    parameters.Add("@proc_ch_Show_All_Ind", input.AllVariableChecked == true ? "Y" : "N");
                    string Eid = userName.Substring(userName.IndexOf("\\") + 1);
                    parameters.Add("@proc_vr_user_Id", Eid);
                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        //if (!reader.IsDBNull(0))
                        //{
                        var physicalPropertyUnitGroup = (unitGroups != null) ? unitGroups.FirstOrDefault(p => p.UnitGroupName == Convert.ToString(reader["UOM_GROUP_NM"])) : null;
                        var physicalPropertyDefaultUnit = physicalPropertyUnitGroup != null ? physicalPropertyUnitGroup.Units.First(w => w.DisplayText.ToLower() == Convert.ToString(reader["DEFAULT_UNIT_DISPLAY_NM"]).ToLower()) : null;
                        ProductPhysicalPropertiesModel objRecord = new ProductPhysicalPropertiesModel()
                        {
                            StreamId = Convert.ToInt32(reader["STREAM_ID"]),
                            SampleId = Convert.ToInt32(reader["SAMPLE_ID"]),
                            PropertyId = Convert.ToInt32(reader["PROPERTY_ID_SQ"]),
                            PropertyLabel = Convert.ToString(reader["LABEL_TXT"]),
                            AnalysisMethodId = Convert.ToInt32(reader["ANALYSIS_METHOD_ID_SQ"]),
                            AnalysisMethodName = Convert.ToString(reader["ANALYSIS_METHOD_NM"]),
                            AnalysisMethodNumber = Convert.ToString(reader["ANALYSIS_METHOD_NUM"]),
                            // UOM = Convert.ToString(reader["DEFAULT_UNIT_DISPLAY_NM"]),
                            UOM = physicalPropertyDefaultUnit,
                            UOMlist = physicalPropertyUnitGroup,
                            Precision = Convert.ToString(reader["VARIABLE_DECIMAL_PNT"]),                                                //Value = Convert.ToInt32(reader["VALUE_MSR"]),
                            BaseValue = (reader["VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(reader["VALUE_MSR"]),

                            Text = Convert.ToString(reader["VALUE_TXT"]),
                            ValidationIndicator = Convert.ToString(reader["VALIDATION_IND"]),
                            LIMSOperation = Convert.ToString(reader["LIMS_OPERATION_NM"]),
                            LIMSOperationId = Convert.ToString(reader["LIMS_OPERATION_ID"])

                        };

                        var targetValue = physicalPropertyDefaultUnit != null ? (physicalPropertyDefaultUnit.convertToTargetunit(objRecord.BaseValue)) : null;
                        objRecord.TargetValue = targetValue!=null? (Convert.ToString(Math.Round(Convert.ToDouble(targetValue), Convert.ToInt32(objRecord.Precision), MidpointRounding.AwayFromZero))):null;
                       

                        obj.Add(objRecord);
                        // }

                    }

                    reader.NextResult();
                    reader.Close();
                    return obj;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }



        }


        public void savePhysicalPropertiesRepo(SaveProductPhysicalPropertiesInput data,string userName)
        {
            try
            {
                if (data != null)
                {
                    string xmlData = Serializer.ConvertToXML<List<ProductPhysicalPropertyItemViewModel>>(data.ArrayOfProductPhysicalPropertyItemViewModel);
                    IDbCommand command = _db.CreateCommand("[md].[Insert_Update_Prod_Phy_Prop_Sp]");
                    using (command)
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("@proc_vr_Plant_Cd", data.PlantCd);
                        parameters.Add("@proc_in_Run_Id", data.RunId);
                        parameters.Add("@proc_in_Test_Id", data.TestId);
                        parameters.Add("@proc_in_Stream_Id",Convert.ToInt32(data.StreamId));
                        parameters.Add("@proc_cl_Prod_Prop_Xml", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                        string Eid = userName.Substring(userName.IndexOf("\\") + 1);
                        parameters.Add("@proc_vr_user_Id", Eid);

                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw ex;
            }
        }

    }
}



//List<ProductPhysicalPropertiesModel> obj = new List<ProductPhysicalPropertiesModel>();
//var allVariable = "true";
//int i = 0;
//if (allVariable == "true")
//{
//    while (i < 10)
//    {
//        ProductPhysicalPropertiesModel objRecord = new ProductPhysicalPropertiesModel()
//        {
//            SampleId = 2312123 + i,
//            AnalysisMethodId = 1 + i,
//            AnalysisMethodName = "H content by NMR",
//            AnalysisMethodNumber = "D 242",
//            PropertyId = 1 + i,
//            PropertyLabel = "H content by NMR",
//            UOM = "Wt%",
//            Value = 12 + i,
//            Text = "",
//            ValidationIndicator = (i % 2 == 0) ? "Unchecked" : "stream1",
//        };
//        obj.Add(objRecord);
//        i++;
//    }
//}
//else if (allVariable == "false")
//{
//    while (i < 5)
//    {
//        ProductPhysicalPropertiesModel objRecord = new ProductPhysicalPropertiesModel()
//        {
//            SampleId = 2312123 + i,
//            AnalysisMethodId = 1 + i,
//            AnalysisMethodName = "H content by NMR",
//            AnalysisMethodNumber = "D 242",
//            PropertyId = 1 + i,
//            PropertyLabel = "H content by NMR",
//            UOM = "Wt%",
//            Value = 12 + i,
//            Text = "",
//            ValidationIndicator = (i % 2 == 0) ? "Unchecked" : "stream1",


//        };
//        obj.Add(objRecord);
//        i++;
//    }
//}

//return obj;




