import { TestBed, inject } from '@angular/core/testing';

import { DataViewerService } from './data-viewer.service';

describe('DataViewerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DataViewerService]
    });
  });

  it('should be created', inject([DataViewerService], (service: DataViewerService) => {
    expect(service).toBeTruthy();
  }));
});
