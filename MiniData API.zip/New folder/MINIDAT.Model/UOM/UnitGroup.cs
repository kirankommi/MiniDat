﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.UOM
{
    public class UnitGroup
    {
        #region Private Members
        private string unitGroupName;
        private Unit baseUnit;
      //  private List<Unit> units = new List<Unit>();
        #endregion

        /// <summary>
        /// Get or set the name of unit Group
        /// </summary>
        public string UnitGroupName
        {
            get
            {
                return unitGroupName;
            }
            set
            {
                unitGroupName = value;
            }

        }

        public string UnitGroupCD { get; set; }
        /// <summary>
        /// Get or set the Base Unit for the unit group Group
        /// </summary>
        public Unit BaseUnit
        {
            get
            {
                return baseUnit;
            }
            set
            {
                baseUnit = value;
            }
        }

        /// <summary>
        /// Get or Set the List of Units for the Unit Group
        /// </summary>
        /// 
        private IList<Unit> _units = new List<Unit>();
        public IList<Unit> Units { get { return _units; } }
        //public List<Unit> Units
        //{
        //    get
        //    {
        //        return units;
        //    }
        //    set
        //    {
        //        units = value;
        //    }
        //}

        public void AddUnits(IList<Unit> units)
        {
            _units = units;
        }
        /// <summary>
        /// Convert the target unit value to base unit
        /// </summary>
        /// <param name="targetUnitValue"></param>
        /// <returns></returns>
        double? ConvertToBaseUnit(double? targetUnitValue)
        {
            return baseUnit.convertToBaseUnit(targetUnitValue); ;
        }

        /// <summary>
        /// Convert the base unit value to target unit
        /// </summary>
        /// <param name="baseUnitValue"></param>
        /// <returns></returns>
        double? ConvertToTargetUnit(double? baseUnitValue)
        {
            return baseUnit.convertToTargetunit(baseUnitValue); ;
        }

        #region /*****************Added by Jithender for Calculation framework Needs***********/
        public Unit GetUnit(string unitName)
        {

            foreach (Unit unit in this.Units)
            {
                if (unit.UnitName.Equals(unitName))
                    return unit;
            }

            return null;
        }
        #endregion /*****************Added by Jithender for Calculation framework Needs***********/
    }
}
