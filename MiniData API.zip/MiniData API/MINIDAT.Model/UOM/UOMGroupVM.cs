﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.UOM
{
    public class UOMGroupVM
    {
        public int DefaultUOMId { get; set; }
        public string UOMUnitName { get; set; }
        public string UOMGroupCode { get; set; }
        public string UOMGroupName { get; set; }
        public int Precision { get; set; }
        public string UOMUnitDisplayName { get; set; }
    }
}
