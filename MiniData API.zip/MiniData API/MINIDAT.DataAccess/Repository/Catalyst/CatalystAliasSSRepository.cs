﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystAliasSS.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystAliasSSRepository : ICatalystAliasSSRepository
    {
        private IDatabase _db;
        public CatalystAliasSSRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystAliasSSSearchModel GetCatalystAliasSSData(CatalystAliasSSModel catalystAliasSS)
        {
            try
            {
                CatalystAliasSSSearchModel catalystAliasSSarr = new CatalystAliasSSSearchModel();
                if (catalystAliasSS == null)
                {
                    return catalystAliasSSarr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystAliasSS_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystAliasSS", string.IsNullOrEmpty(Convert.ToString(catalystAliasSS.CatalystAliasSSName)) ? (object)null : catalystAliasSS.CatalystAliasSSName);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystAliasSS.StatusName == "Select" ? null : catalystAliasSS.StatusName) ? (object)null : catalystAliasSS.StatusName);
                    parameters.Add("proc_in_size", string.IsNullOrEmpty(catalystAliasSS.Size== "0" ? null : catalystAliasSS.Size) ? (object)null : catalystAliasSS.Size);
                    parameters.Add("proc_in_shape", string.IsNullOrEmpty(catalystAliasSS.Shape == "0" ? null : catalystAliasSS.Shape) ? (object)null : catalystAliasSS.Shape);
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystAliasSSarr.LstcatalystAliasSSs.Clear();
                                      
                    while (reader.Read())
                    {
                        ((List<KeyValue>)catalystAliasSSarr.lstSizes).Add(new KeyValue()
                        {
                            Key = reader["SIZE_CD"].ToString(),
                            Value = reader["SIZE_NM"].ToString()
                        });
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)catalystAliasSSarr.lstShapes).Add(new KeyValue()
                        {
                            Key = reader["SHAPE_CD"].ToString(),
                            Value = reader["SHAPE_NM"].ToString()
                        });
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        CatalystAliasSSModel _catalystAliasSS = new CatalystAliasSSModel()
                        {
                            CatalystAliasSSID = Convert.ToInt32(reader["CATALYST_ALIAS_SS_ID_SQ"]),
                            CatalystAliasSSName = reader["CATALYST_ALIAS_SS_NM"].ToString(),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            Sizecd  = new KeyValue() { Key = reader["SIZE_CD"].ToString(), Value = reader["SIZE_NM"].ToString() },
                            Shapecd = new KeyValue() { Key = reader["SHAPE_CD"].ToString(), Value = reader["SHAPE_NM"].ToString() }
                        };
                        catalystAliasSSarr.LstcatalystAliasSSs.Add(_catalystAliasSS);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystAliasSSarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystAliasSSarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystAliasSSarr.lstStatus).AddRange(statuses);                  
                    return catalystAliasSSarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystAliasSSData(CatalystAliasSSModel catalystAliasSS)
        {
            try
            {
                if (catalystAliasSS == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystAliasSS_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystAliasSS_ID", string.IsNullOrEmpty(Convert.ToString(catalystAliasSS.CatalystAliasSSID)) ? (object)null : catalystAliasSS.CatalystAliasSSID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystAliasSSData(CatalystAliasSSModel _catalystAliasSS, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystAliasSS == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystAliasSS_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystAliasSS_Id", _catalystAliasSS.CatalystAliasSSID);
                    parameters.Add("proc_vr_catalystAliasSSNm", _catalystAliasSS.CatalystAliasSSName);                     
                    parameters.Add("proc_vr_Status_Nm", _catalystAliasSS.StatusName);
                    parameters.Add("proc_vr_Shape_Cd", _catalystAliasSS.Shape);
                    parameters.Add("proc_vr_Size_Cd", _catalystAliasSS.Size);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystAliasSSModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystAliasSSModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystAliasSSModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystAliasSSModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
