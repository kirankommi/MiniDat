﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Model;
using MINIDAT.Model.Manage.Mode;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class SPPRepository : ISPPRepository
    {
        /// <summary>
        /// 
        /// </summary>
        private IDatabase _db;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dbInstance"></param>
        public SPPRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public SPPModel getSPPTemplateData(string mode)
        {
            try
            {
                SPPModel sppModel = new SPPModel();

                if (String.IsNullOrEmpty(mode))
                {
                    return sppModel;
                }

                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_SPP_ModeTemplateValues_sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@mode", mode);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    List<SPPModelInfo> lstModelInfo = new List<SPPModelInfo>();
                    while (reader.Read())
                    {

                        SPPModelInfo sppModelInfo = new SPPModelInfo()
                        {
                            PairNumber = Convert.ToInt32(reader["PAIR_NUM"]),
                            RampRate = reader["1"].FormatDouble(),
                            SoakValue = reader["2"].ToString(),
                            SoakTime = Convert.ToInt32(reader["3"]),
                            RampReciepeNumber = Convert.ToInt32(reader["4"]),
                            SoakReciepeNumber = Convert.ToInt32(reader["5"]),
                            Description = reader["DESCRIPTION"].ToString()
                        };
                        lstModelInfo.Add(sppModelInfo);
                    }
                    sppModel.lstModelInfo = lstModelInfo;
                }

                //using (StreamReader r = new StreamReader(@"C:\Share\Code\spp.json"))
                //{
                //    string json = r.ReadToEnd();
                //    sppModel = JsonConvert.DeserializeObject<SPPModel>(json);
                //}
                return sppModel;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        
    }
}
