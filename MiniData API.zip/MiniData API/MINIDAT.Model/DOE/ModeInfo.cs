﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DOE
{
    public class ModeInfo
    {
        public int? ModeID { get; set; }
        public string ModeNumber { get; set; }
        public string Description { get; set; }
        public string ModeType { get; set; }
        public string ControlName { get; set; }
        public string SulfidingType { get; set; }
        public double? Pressure { get; set; }
        public double? LHSV { get; set; }
        public double? SCFB { get; set; }
        public double? Sort { get; set; }
        public int? Conditions { get; set; }
        public double? SoakTime { get; set; }

        private List<double?> _conversion = new List<double?>();

        public string DOEModelNumber { get; set; }

        public List<double?> Conversion
        {
            get { return _conversion; }
            set { _conversion = value; }
        }

    }
}
