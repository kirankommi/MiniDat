import { Component, OnInit, Input, ElementRef, Renderer, EventEmitter, Output, ViewChild } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { AppComponent } from '../app.component';
import { TooltipModule } from 'primeng/primeng';
@Component({
  //moduleId: module.id,
  selector: 'input-flyout',
  templateUrl: 'inputflyout.component.html',
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ],
})

export class InputFlyoutComponent implements OnInit {
  @Input() flyoutdata: any = [];
  @Input() flyouttempdata: any = [];
  @Input() iconStyle: string='fa fa-search-plus fa-fw';
  @Input() iconToolTip:string='Search';
  private _inputValue: string;
  @Input() set inputValue(value: any) {
    this._inputValue = value;
    this.inputValueChange.emit(value);
  }

  get inputValue(): any {
    return this._inputValue;
  }


  @Output() inputValueChange = new EventEmitter();
  @Input() fTitle: string;
  @Input() pHolder: string;
  @Input() colList: string[];
  @Input() eventSource: string;
  @Input() isNotSearchable: boolean;
  @Input() isEditable: boolean = false;
  @Output() inputEvent = new EventEmitter();
  @Output() inputTextChange = new EventEmitter();
  @Input() canToggelFlyoutOnMouseEnter: boolean = false;
  flyoutState: string = 'out';
  @Input() datalist: any[];
  @ViewChild('searchFlyout') search: ElementRef;
  constructor(private appComponent: AppComponent) {

  }

  ngOnInit() {
  }

  toggleFlyoutOnMouseEnter() {
    if (this.canToggelFlyoutOnMouseEnter) {
      const _searchContainer = document.getElementsByClassName('component-data-filter-container');
      if (_searchContainer) {
        const _searchContainerItemWraper = _searchContainer[0].firstElementChild;
        if (_searchContainerItemWraper) {
          (<HTMLInputElement>_searchContainerItemWraper.firstElementChild).focus();
        }
      }
      //this.search.el.nativeElement.focus();
      if (!this.isNotSearchable) {
        this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
        this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
      }
    }
  }
  toggleFlyout() {
    if (!this.isNotSearchable) {
      this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
      this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
    }
  }


  onRowSelect(event: any) {
    this.flyoutState = 'out';
    this.appComponent.isOverlay = false;
    if (event == "Close") {

    }
    else {
      this.inputEvent.emit(event);
    }
  }
}
