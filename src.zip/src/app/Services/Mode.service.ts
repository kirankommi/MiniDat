﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { ModeModel, KeyValue } from '../Models/ModeModel';
import * as Constants from '../Shared/globalconstants';
import { HttpActionService } from './httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ModeService {
    private getModedata = "/Mode/SearchModedata/";
    private saveModedata = "/Mode/SaveModeInformation/";
    private deleteModedata = "/Mode/DeleteModeInformation/";
    private getPlantsList = "/Mode/GetPlantsList/"

    constructor(private httpaction: HttpActionService) { }

    getModeInformatin(modeData: ModeModel) {

        debugger;      
        let options = new RequestOptions(Constants.options)
        //return this.httpaction.get(this.getPITagdata, options);
        return this.httpaction.post(modeData, this.getModedata);
    }

    saveModeInformation(modeData: ModeModel)
    {
        return this.httpaction.post(modeData, this.saveModedata);
    }

    deleteMode(modeData: ModeModel)
    {
        debugger;
        return this.httpaction.post(modeData, this.deleteModedata);
    }
    getModesList(modeData: ModeModel)
    {
        debugger;
        return this.httpaction.post(modeData, this.getPlantsList);
    }
}
