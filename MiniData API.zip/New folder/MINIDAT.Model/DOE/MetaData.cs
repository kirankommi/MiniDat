﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Catalyst;
using MINIDAT.Model.Manage;

namespace MINIDAT.Model.DOE
{
    public class Plant
    {
        public string Name { get; set; }
        public string Key { get; set; }
        public string Location { get; set; }
    }

    public class Status
    {
        public string StatusTxt { get; set; }
        public string ColorCD { get; set; }

    }

    public class DOEMode : ModeModel
    {
        public int Duration { get; set; }
    }

    public class FeedInfo
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        public bool HasDopant { get; set; }
        public string BookNum { get; set; }
        public string UOPNum { get; set; }
        public double? DensityMsr { get; set; }
    }

    public class MasterData
    {
        string select = "Select";
        public List<Plant> PlantList { get; set; }

        public List<Status> Statuses { get; set; }
        public List<DOE_Project> Projects { get; set; }
        public List<Study> StudyLst { get; set; }

        public List<DOEMode> Modes { get; set; }
        public List<FeedInfo> Feeds { get; set; }
        public ColumnsPreferences ColumnPref {get;set;}   
        public MasterData()
        {
            PlantList = new List<Plant>() { new Plant() { Key = select, Name = select } };
            this.Statuses = new List<Status>();
            this.Projects = new List<DOE_Project>();
            this.StudyLst = new List<Study>();
            this.Modes = new List<DOEMode>();
            this.Feeds = new List<FeedInfo>();
            this.ColumnPref = new ColumnsPreferences();
        }
    }

    public class PoolMasterData
    {
        public List<KeyValue> Statuses { get; set; }
        public List<KeyValue> Specialists { get; set; }
    }

    public class PoolModel
    {
        public int StudyID { get; set; }
        public string Project { get; set; }
        public string Study { get; set; }
        public string Specialist { get; set; }
        public string FromCreated { get; set; }
        public string ToCreated { get; set; }
        public string FromClosed { get; set; }
        public string ToClosed { get; set; }
        public string Status { get; set; }
        public int FileCount { get; set; }
    }
    public class ColumnsPreferences
    {
        public string ColumnPreferences { get; set; }
        public string UserId { get; set; }
        public string ModuleName { get; set; }
    }
}
