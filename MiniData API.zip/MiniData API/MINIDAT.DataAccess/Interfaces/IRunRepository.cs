﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	IRunRepository.cs
                                                Project Title			:	MINIDAT
                                                Author(s)				:	E561777
                                                Created Date			:	9th July 2019
                                                Requirements Tag		:	Run Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.Model.Run;
using System.Collections.Generic;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IRunRepository
    {
        List<NIRModel> GetNIRModelInformation(string Plant_cd, int ModeId);
        List<ProcessSpecModel> GetProcessSpecInformation(string Plant_cd, string runID);
        List<BoilingPointModel> GetRunCutBoilingPointsInfo(string Plantcd, string runID, string ModeType);
        List<AnalyticalInfoModel> GetAnalyticalSamplingInfo(string Plant_cd, string runID);
        FeedModel GetFeedInfo(string runID);
        GeneralInfoModel GetGeneralInfo(string Plant_cd, string runID);
        void SaveRunInformation(RunModel run, string userId);
        RunMasterDataModel GetRunMasterDetails(string Plant_cd, string Mode_Type);
        RunCatalystSearchModel GetRunCatalystDetails(string runID);
        List<TC_Calibration> GetTCCalibrationInformation(string Plant_cd, string runID);
        List<TMF_Calibration> GetTMFCalibrationInformation(string Plant_cd, string runID);
        AdditionalInfoModel GetAdditionalInfo(string Plant_cd, string runID);
        void SaveRunFeedInformation(GeneralInfoModel feed);
        FeedModel GetSavedRunFeedDetails(string runID);

        void SaveWeightChecks(RunMode runMode, string userId);

        void SaveRecipeData(dynamic recipe, string userId, int runId);
        RunExport GetExportData(string userId, int runId);
    }
}
