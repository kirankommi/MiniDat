﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using System.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.TestCreation;
using MINIDAT.Framework.Serializer;
using System.Dynamic;

namespace MINIDAT.DataAccess.Repository.TestCreation
{
    public class LogSheetRepository : ILogSheetRepository
    {
        private IDatabase _db;
        public LogSheetRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public DataSet GetLogSheetDetails(PeriodReadingModel periodReadingModel, string userId)
        {
            try
            {
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_Logsheet_Time_SP]"))
                {
                    DataSet ds = new DataSet();
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", periodReadingModel.PlantCd);
                    parameters.Add("@proc_in_Run_Id", periodReadingModel.RunId);
                    parameters.Add("@proc_in_Test_Id", periodReadingModel.TestId);
                    parameters.Add("@proc_ch_Show_All_Ind", "Y");
                    parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                    //parameters.Add("@proc_vr_User_Id", "H118265");
                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);

                    DataTable dtValidation = new DataTable("Validation");//Validation table
                    dtValidation.Columns.Add("VALIDATION_IND");
                    dtValidation.Columns.Add("VALIDATION_IND_NM");

                    DataTable dtLogSheet = new DataTable("LogSheet");//LogSheet master table
                    dtLogSheet.Columns.Add("Log Reading Label");
                    dtLogSheet.Columns.Add("PI Tag Name");
                    dtLogSheet.Columns.Add("LabelOrder");
                    dtLogSheet.Columns.Add("UOM");
                    dtLogSheet.Columns.Add("UnitOrder");

                    DataTable dtDynamicCols = new DataTable("DynamicCols");// dynamic columns table
                    dtDynamicCols.Columns.Add("LOGSHEET_KEY_ID_SQ");
                    dtDynamicCols.Columns.Add("READING_TM");
                    dtDynamicCols.Columns.Add("VALIDATION_IND");

                    DataTable dtMsr = new DataTable("Msr"); //msr value table
                    dtMsr.Columns.Add("LOGSHEET_KEY_ID");
                    dtMsr.Columns.Add("LOG_READING_LABEL_TXT");
                    dtMsr.Columns.Add("LOG_VALUE_MSR");

                    DataTable dtAllVariables = new DataTable("AllVariables"); // all variables table
                    dtAllVariables.Columns.Add("Log Reading Label");
                    dtAllVariables.Columns.Add("PI Tag Name");
                    dtAllVariables.Columns.Add("LabelOrder");
                    dtAllVariables.Columns.Add("UnitOrder");
                    dtAllVariables.Columns.Add("UOM");

                    while (reader.Read())
                    {
                        dtValidation.Rows.Add(Convert.ToString(reader["VALIDATION_IND"]), Convert.ToString(reader["VALIDATION_IND_NM"]));
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        dtDynamicCols.Rows.Add(Convert.ToString(reader["LOGSHEET_KEY_ID_SQ"]), Convert.ToString(reader["READING_TM"]), Convert.ToString(reader["VALIDATION_IND"]));
                    }

                    reader.NextResult();

                    while (reader.Read())
                    {
                        dtMsr.Rows.Add(Convert.ToString(reader["LOGSHEET_KEY_ID"]), Convert.ToString(reader["LOG_READING_LABEL_TXT"]), Convert.ToString(reader["LOG_VALUE_MSR"]));
                    }

                    reader.NextResult();

                    dtLogSheet.Rows.Add("Validation");
                    dtLogSheet.Rows.Add("Log Sheet Key");

                    while (reader.Read())
                    {
                        dtLogSheet.Rows.Add(reader["LOG_READING_LABEL_TXT"], reader["PI_TAG_NM"], reader["LABEL_READ_ORDER_NUM"], reader["UOM_GROUP_NM"], reader["LABEL_READ_ORDER_NUM"]);
                    }

                    foreach (DataRow dtDynamicColsrow in dtDynamicCols.Rows)
                    {
                        string key = dtDynamicColsrow["LOGSHEET_KEY_ID_SQ"].ToString();
                        string validation = dtDynamicColsrow["VALIDATION_IND"].ToString();

                        dtLogSheet.Columns.Add(dtDynamicColsrow["READING_TM"].ToString());

                        foreach (DataRow dtLogSheetrow in dtLogSheet.Rows)
                        {
                            string text = dtLogSheetrow["Log Reading Label"].ToString();

                            for (int j = dtLogSheet.Columns.Count - 1; j < dtLogSheet.Columns.Count; j++)
                            {
                                if(dtLogSheetrow[0].ToString() == "Log Sheet Key")
                                {
                                    dtLogSheetrow[j] = key;
                                }
                                else if (dtLogSheetrow[0].ToString() == "Validation")
                                {
                                    dtLogSheetrow[j] = validation;
                                }

                                foreach (DataRow dtMsrrow in dtMsr.Rows)
                                {
                                    if (dtMsrrow["LOGSHEET_KEY_ID"].ToString() == key && dtMsrrow["LOG_READING_LABEL_TXT"].ToString() == text)
                                    {
                                        dtLogSheetrow[j] = dtMsrrow["LOG_VALUE_MSR"].ToString();
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    foreach (DataRow dtLsRow in dtLogSheet.Rows)
                    {
                        if (dtLsRow[5].ToString() == null || dtLsRow[5].ToString() == "")
                        {
                            dtAllVariables.Rows.Add(dtLsRow[0], dtLsRow[1], dtLsRow[2], dtLsRow[3], dtLsRow[4]);
                        }
                    }

                    reader.Close();
                    ds.Tables.Add(dtLogSheet);
                    ds.Tables.Add(dtValidation);
                    ds.Tables.Add(dtAllVariables);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<LogSheetPeriodReadingModel> GetLogSheetPeriodReadingDetails(PeriodReadingModel periodReadingModel, string userId)
        {
            try
            {
                List<LogSheetPeriodReadingModel> _lstLogSheetPeriodReading = new List<LogSheetPeriodReadingModel>();
                IDataReader objReader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Get_Logsheet_Period_Reading_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", periodReadingModel.PlantCd);
                    parameters.Add("@proc_nm_Run_ID", periodReadingModel.RunId);
                    parameters.Add("@proc_nm_Test_ID", periodReadingModel.TestId);
                    parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                    //parameters.Add("@proc_vr_User_Id", "H118265");
                    _db.CreateParameters(command, parameters);

                    objReader = _db.ExecuteReader(command);
                    while (objReader.Read())
                    {
                        LogSheetPeriodReadingModel objLogSheetModel = new LogSheetPeriodReadingModel();
                        {
                            objLogSheetModel.LogReadingLabel = Convert.ToString(objReader["LOG_READ_LABEL_TXT"]);
                            objLogSheetModel.InputVariableType = objReader["INPUT_VARIABLE_TYP"].ToString();
                            objLogSheetModel.UOM = objReader["DEFAULT_UNIT_NM"].ToString();
                            objLogSheetModel.AverageReadingValueMsr = (objReader["AVERAGE_READING_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["AVERAGE_READING_MSR"]);
                            objLogSheetModel.InitialReadingValueMsr = (objReader["INITIAL_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["INITIAL_VALUE_MSR"]);
                            objLogSheetModel.FinalReadingValueMsr = (objReader["FINAL_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["FINAL_VALUE_MSR"]);
                            objLogSheetModel.ParamterDefaultUnitName = objReader["PARAM_DEFAULT_UNIT"].ToString();
                        };
                        _lstLogSheetPeriodReading.Add(objLogSheetModel);
                    }
                    objReader.Close();
                    return _lstLogSheetPeriodReading;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        public void SavePeriodReading(PeriodReadingModel periodReadingModel, string userId)
        {
            try
            {
                string PlantCd = periodReadingModel.PlantCd;
                int RunId = periodReadingModel.RunId;
                int TestId = periodReadingModel.TestId;
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                string xmlData = Serializer.ConvertToXML<LogSheetPeriodReadingModel>(periodReadingModel.PeriodReadingList);
                IDbCommand command = _db.CreateCommand("[md].Update_Logsheet_Period_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_Plant_Cd", PlantCd);
                    parameters.Add("proc_nm_Run_Id", RunId);
                    parameters.Add("proc_nm_Test_Id", TestId);
                    parameters.Add("proc_vr_User_Id", Eid);
                    parameters.Add("proc_cl_logsheet_xml", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public void SaveLogSheet(dynamic LogSheet,string plantCd, string userId)
        {
            try
            {
                if (LogSheet != null)
                {
                    string validString = Convert.ToString(LogSheet);
                    IDbCommand command = _db.CreateCommand("[dbo].Update_Logsheet_Reading_Sp");
                    using (command)
                    {
                        IDictionary parameters = new Dictionary<string, object>();
                        parameters.Add("@proc_vr_Plant_Cd", plantCd);
                        parameters.Add("@proc_cl_Logsheet_Json", string.IsNullOrEmpty(validString) ? (object)null : validString);
                        parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                        _db.CreateParameters(command, parameters);
                        _db.ExecuteNonQuery(command);
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw ex;
            }
        }

        public string GetLogSheetKey(LogSheetKeyModel LogSheetKeyModel, string userId)
        {
            try
            {
                IDbCommand command = _db.CreateCommand("[dbo].Get_Plant_Logsheet_Key_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_nm_Logsheet_Key_Id", LogSheetKeyModel.LogSheetKey);
                    parameters.Add("@proc_vr_Plant_Cd", LogSheetKeyModel.PlantCd);
                    parameters.Add("@proc_dt_Reading_Tm", Convert.ToDateTime(LogSheetKeyModel.ReadingTime));
                    parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteScalar(command);
                }

                return "Success";
            }

            catch (Exception ex)
            {
                LogManager.Error(ex);
                return ex.Message;
            }
        }

        public List<LogSheetPeriodReadingModel> ExportLogSheetPeriodReadingDetails(PeriodReadingModel periodReadingModel, string userId)
        {
            try
            {
                List<LogSheetPeriodReadingModel> _lstLogSheetPeriodReading = new List<LogSheetPeriodReadingModel>();
                IDataReader objReader = null;
                using (IDbCommand command = _db.CreateCommand("[md].[Export_Logsheet_Period_Reading_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("@proc_vr_Plant_Cd", periodReadingModel.PlantCd);
                    parameters.Add("@proc_nm_Run_ID", periodReadingModel.RunId);
                    parameters.Add("@proc_nm_Test_ID", periodReadingModel.TestId);
                    parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                    _db.CreateParameters(command, parameters);

                    objReader = _db.ExecuteReader(command);
                    while (objReader.Read())
                    {
                        LogSheetPeriodReadingModel objLogSheetModel = new LogSheetPeriodReadingModel();
                        {
                            objLogSheetModel.LogReadingLabel = Convert.ToString(objReader["LOG_READ_LABEL_TXT"]);
                            objLogSheetModel.InputVariableType = objReader["INPUT_VARIABLE_TYP"].ToString();
                            objLogSheetModel.UOM = objReader["DEFAULT_UNIT_NM"].ToString();
                            objLogSheetModel.AverageReadingValueMsr = (objReader["AVERAGE_READING_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["AVERAGE_READING_MSR"]);
                            objLogSheetModel.InitialReadingValueMsr = (objReader["INITIAL_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["INITIAL_VALUE_MSR"]);
                            objLogSheetModel.FinalReadingValueMsr = (objReader["FINAL_VALUE_MSR"] == DBNull.Value) ? (double?)null : Convert.ToDouble(objReader["FINAL_VALUE_MSR"]);
                            objLogSheetModel.ParamterDefaultUnitName = objReader["PARAM_DEFAULT_UNIT"].ToString();
                        };
                        _lstLogSheetPeriodReading.Add(objLogSheetModel);
                    }
                    objReader.Close();
                    return _lstLogSheetPeriodReading;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public IEnumerable<dynamic> ExportLogsheetTimeReading(PeriodReadingModel periodReadingModel, string userId)
        {
            IDataReader reader = null;
            using (IDbCommand command = _db.CreateCommand("[md].[Export_Logsheet_Time_SP]"))
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("@proc_vr_Plant_Cd", periodReadingModel.PlantCd);
                parameters.Add("@proc_in_Run_Id", periodReadingModel.RunId);
                parameters.Add("@proc_in_Test_Id", periodReadingModel.TestId);
                parameters.Add("@proc_ch_Show_All_Ind", 'N');
                parameters.Add("@proc_vr_User_Id", userId.Substring(userId.IndexOf("\\") + 1));
                _db.CreateParameters(command, parameters);

                using (reader = _db.ExecuteReader(command))
                {
                    while (reader.Read())
                    {
                        yield return GetDynamicData(reader);
                    }
                }
            }
        }
        private dynamic GetDynamicData(IDataReader reader)
        {
            var expandoObject = new ExpandoObject() as IDictionary<string, object>;
            for (int i = 0; i < reader.FieldCount; i++)
            {
                expandoObject.Add(reader.GetName(i), reader[i]);
            }
            return expandoObject;
        }
    }
}
