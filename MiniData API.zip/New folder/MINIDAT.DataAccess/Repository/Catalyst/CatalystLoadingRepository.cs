﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageDiluent.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;
using MINIDAT.Framework.Serializer;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystLoadingRepository : ICatalystLoadingRepository
    {
        private IDatabase _db;
        public CatalystLoadingRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="CATACT", Value="Active"},
                     new KeyValue() {Key="CATINACT", Value="Inactive"}
                };      

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalytLoadingSearchModel GetLoadingTemplateData(CatalytLoadingModel loaingTemplate)
        {
            try
            {
                CatalytLoadingSearchModel loadingarr = new CatalytLoadingSearchModel();
                if (loaingTemplate == null)
                {
                    return loadingarr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_Loading_Template_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_Name", string.IsNullOrEmpty(Convert.ToString(loaingTemplate.TemplateName)) ? (object)null : loaingTemplate.TemplateName);
                    parameters.Add("proc_vr_template_description", string.IsNullOrEmpty(Convert.ToString(loaingTemplate.LoadingType)) ? (object)null : loaingTemplate.LoadingType);                      
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(loaingTemplate.StatusName == "Select" ? null : loaingTemplate.StatusName) ? (object)null : loaingTemplate.StatusName);                   
                    parameters.Add("proc_nm_Internal_dia_Msr", loaingTemplate.ReactorInternalDia);
                    parameters.Add("proc_nm_bed_length_Msr", loaingTemplate.BedLength);
                    parameters.Add("proc_nm_bed_Volume_Msr", loaingTemplate.BedVolume);
                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    loadingarr.LstTemplates.Clear();

                   //reader.NextResult();
                    while (reader.Read())
                    {
                        CatalytLoadingModel _template = new CatalytLoadingModel()
                        {
                            TemplateID= Convert.ToInt32(reader["CATALYST_LOADING_TEMPLATE_ID_SQ"]),
                            TemplateName = reader["CATALYST_LOADING_TEMPLATE_NM"].ToString(),  
                            LoadingType = reader["LOAD_TYPE"].ToString(),
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            ReactorInternalDia = (reader["INTERNAL_DIAMETER_MSR"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["INTERNAL_DIAMETER_MSR"]),
                            BedLength = (reader["BED_LENGTH_MSR"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["BED_LENGTH_MSR"]),                           
                            BedVolume = (reader["BED_VOLUME_MSR"] == DBNull.Value) ? 0 : Convert.ToDecimal(reader["BED_VOLUME_MSR"])
                        };
                        loadingarr.LstTemplates.Add(_template);
                    }                   
                    reader.NextResult();
                    reader.NextResult();
                    while (reader.Read())
                    {
                        loadingarr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    loadingarr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)loadingarr.lstStatus).AddRange(statuses);                  
                    return loadingarr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteLoadingTemplateDataData(CatalytLoadingModel loadingTemplate)
        {
            try
            {
                if (loadingTemplate == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_Loading_Template_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_ID", string.IsNullOrEmpty(Convert.ToString(loadingTemplate.TemplateID)) ? (object)null : loadingTemplate.TemplateID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// save role
        /// </summary>
        /// <param name="PITag"></param>
        /// <param name="userId"></param>

        public void SaveLoadingTemplateData(CatalytLoadingModel _loadingTemplate, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _loadingTemplate == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                string xmlData = Serializer.ConvertToXML<Bed>(_loadingTemplate.Beds);
                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_Loading_Template_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_template_Id", _loadingTemplate.TemplateID);
                    parameters.Add("proc_vr_template_Name", string.IsNullOrEmpty(_loadingTemplate.TemplateName) ? (object)null : _loadingTemplate.TemplateName);                  
                    parameters.Add("proc_vr_Status_Nm", string.IsNullOrEmpty(_loadingTemplate.StatusName) ? (object)null : _loadingTemplate.StatusName);
                    parameters.Add("proc_nm_reactor_Internal_dia_Msr", _loadingTemplate.ReactorInternalDia);
                    parameters.Add("proc_nm_bed_volume_Msr", _loadingTemplate.BedVolume);
                    parameters.Add("proc_nm_bed_length_Msr", _loadingTemplate.BedLength);
                    parameters.Add("proc_bed_info_xml", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }
        public List<Bed> GetReactorBedDetails(string templateID)
        {
            List<Bed> lstbeds = new List<Bed>();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("templateID", templateID);
            using (IDbCommand cmd = _db.CreateCommand("[catalyst].Get_Reactor_Bed_Details_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                var bed = new Bed();
                while (reader.Read())
                {
                    bed = new Bed();
                    bed.RowId = Convert.ToInt32(reader["RowId"]);
                    bed.BedNumber = Convert.ToInt32(reader["BED_NUM"]);
                    bed.TemplateID = Convert.ToInt32(reader["TEMPLATE_ID_SQ"]);
                    bed.Split = Convert.ToInt32(reader["SPLIT_NM"]);
                    bed.DiluentDesignation = Convert.ToString(reader["DILUENT_NM"]);
                    bed.DiluentVolume = Convert.ToDecimal(reader["DILUENT_VOLUME_MSR"]);
                    bed.CatalystVolume = Convert.ToDecimal(reader["CATALYST_VOLUME_MSR"]);
                    bed.DiluentID = Convert.ToInt32(reader["DILUENT_ID"]);
                    lstbeds.Add(bed);
                }
                reader.Close();
                return lstbeds;
            }
        }

        public void Update(CatalytLoadingModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalytLoadingModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalytLoadingModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalytLoadingModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
