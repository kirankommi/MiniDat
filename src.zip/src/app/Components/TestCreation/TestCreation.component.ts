import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { messageModalUtility } from '../../Shared/message-modal.utility';
import * as Constants from '../../Shared/globalconstants';
import { AlertMessage } from '../../services/alertmessage.service';
import { HttpActionService } from '../../services/httpaction.service';
import { AppComponent } from '../../app.component';
//import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { PlantFlyoutModel } from '../../Models/PITagInfoModel';
import { TestCreationModel, KeyValue, RunFlyoutModel } from '../../Models/TestCreation/TestCreationModel';
import { TestCreationService } from '../../Services/TestCreation/TestCreation.service';
import { TestParameter } from 'src/app/Models/TestCreation/TestParam';
import { Router } from '@angular/router';
import { DataViewerModel } from 'src/app/Models/DataViewer/DataViewerModel';

@Component({
    selector: 'TestCreation',
    templateUrl: './TestCreation.component.html',
    providers: [TestCreationService],
    styles: [`
            .dot {
              height: 25px;
              width: 25px;
              background-color: #bbb;
              border-radius: 20%;
              display: inline-block;
            }
        `]
})
export class TestCreationComponent implements OnInit {
    TestData: TestCreationModel;
    IsallowedSave: boolean = false;
    check: boolean = false;

    plantListCols: any[] = [];
    lstPlants: any;
    flyoutHeaderPlant: string = "Plants";
    pHolderPlant: string = "Plant #";
    constants: any = {};
    RunListCols: any[] = [];
    lstRuns: any;
    flyoutHeaderRun: string = "Run";
    pHolderRun: string = "Run #";
    TestSaved = "Test Saved Succesfully";
    TestDeleted = "Test Deleted";
    WCQuality: KeyValue[];

    lstTests: any;
    lineOutInd: boolean;

    //timepickerIcon :string;
    title: string;
    totalRecords: number;
    disableButtonsToViewData: boolean = true;

    constructor(private testCreationService: TestCreationService, public el: ElementRef, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private router: Router
        //, private confirmationService: ConfirmationService
    ) {
        //this.timepickerIcon = Constants.timePicker;
        this.constants = Constants;
    }

    ngOnInit() {
        this.TestData = new TestCreationModel();
        this.title = Constants.TestCreation;
        this.getMasterData();
        this.getPlantFlyout();
        this.onReset();

    }
    ngDoCheck() {

        if (!this.check) {
            if (Constants.UserSessionData != Constants.Undefined) {
                if (Constants.UserPrivileges.length > 1) {
                    for (let i in Constants.UserPrivileges) {
                        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000032" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                            this.IsallowedSave = true;
                            this.check = true;
                        }
                    }

                }
            }
        }
    }
    onRowSelect(event: any) {
        debugger;
        //this.TestData = event.data;
        this.TestData.Plant = event.data.Plant;
        this.TestData.Run = event.data.Run;
        this.TestData.RunTestIdsq = event.data.RunTestIdsq;
        this.TestData.Test = event.data.Test;
        this.TestData.TestStartTime = this.convert_date_to_string(new Date(event.data.TestStartTime));
        this.TestData.TestEndTime = this.convert_date_to_string(new Date(event.data.TestEndTime));
        this.TestData.WCName = event.data.WCName;
        this.TestData.TestComment = event.data.TestComment;
        this.TestData.LineOut = event.data.LineOut;
        this.TestData.PIData = event.data.PIData;
        this.TestData.PiReTransmitTime = event.data.PiReTransmitTime;
        this.TestData.AutoGenerateInd = event.data.AutoGenerateInd;
        this.TestData.LIMSData = event.data.LIMSData;
        this.TestData.LimsReTransmitTime = event.data.LimsReTransmitTime;
        this.TestData.LastCalculatedOn = event.data.LastCalculatedOn;
        this.TestData.IsInitialLoad = event.data.IsInitialLoad;
        this.disableButtonsToViewData = false;
    }
    onReset() {
        this.TestData = new TestCreationModel();
        this.TestData.Plant = null;
        this.TestData.Run = null;
        this.lstRuns = [];
        this.TestData.Test = null;
        this.TestData.TestComment = "";
        this.TestData.WCName = "A";
        //this.TestData.TestStartTime = ""; //new
        //this.TestData.TestStartTime = null;
        //this.TestData.TestEndTime = null;
        this.searchTest(true);
        this.disableButtonsToViewData = true;
    }
    getPlantFlyout() {
        debugger;

        this.plantListCols.push({ Key: "Plantcode", Value: "Plant #" });
        this.plantListCols.push({ Key: "Location", Value: "Location" });
        this.plantListCols.push({ Key: "BuildingNumber", Value: "Building Number" });

        this.testCreationService.GetPlantFlyout()
            .subscribe(
                (data: any) => {
                    debugger;
                    this.lstPlants = data.lstPlants;
                },
                err => { }
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    updatePlantSelection(event, condition) {
        debugger;
        this.TestData.Plant = event.Plantcode;
        this.getRunFlyout();
    }
    getRunFlyout() {
        debugger;
        this.RunListCols = [];
        this.lstRuns = [];
        this.TestData.Run = null;
        this.RunListCols.push({ Key: "Plantcode", Value: "Plant #" });
        this.RunListCols.push({ Key: "RunNumber", Value: "Run #" });

        this.testCreationService.GetRunFlyout(this.TestData.Plant)
            .subscribe(
                (data: any) => {
                    debugger;
                    this.lstRuns = data;
                },
                err => { }
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    updateRunSelection(event, condition) {
        debugger;
        this.TestData.Run = event.RunNumber;
    }
    getMasterData() {
        debugger;
        this.testCreationService.GetTestDetails()
            .subscribe(
                (data: any) => {

                    this.TestData = data.lstTests;
                    this.WCQuality = data.lstwcQuality;
                    console.log(this.TestData);
                    if (this.TestData.WCName == undefined || this.TestData.WCName == null) {
                        this.TestData.WCName = 'A';
                    }
                });
    }
    find() {
        this.searchTest(false);
    }
    searchTest(isInit: boolean) {
        debugger;
        this.TestData.IsInitialLoad = isInit;
        var test = new TestCreationModel();
        const testKeys = Object.keys(this.TestData);
        testKeys.forEach(element => {
            test[element] = this.TestData[element];
        })
        this.testCreationService.SearchTestdata(test).subscribe((data: any) => {
            debugger;
            this.totalRecords = data.RecordsFetched;
            for (let i in data.lstTests) {

                //data[i].TestStartTime = new Date(data[i].TestStartTime);
                //data[i].TestEndTime = new Date(data[i].TestEndTime);
                //data[i].LimsReTransmitTime = new Date(data[i].LimsReTransmitTime);
                //data[i].PiReTransmitTime = new Date(data[i].PiReTransmitTime);
                //data[i].LineOut = data[i].LineOut == "Y" ? true : false;
                data.lstTests[i].LineOut = data.lstTests[i].LineOut == "Y" ? true : false;
            }
            this.lstTests = data.lstTests;
        });
    }
    isDataValidate() {
        if (this.TestData.Plant == "" || this.TestData.Plant == null ||
            this.TestData.Run == null ||
            this.TestData.Test == null ||
            this.TestData.TestStartTime == null ||
            this.TestData.TestEndTime == null ||
            this.TestData.WCName == "A"//default select value -> 'A'
            //|| ((this.TestData.Plant==""||this.TestData.Plant == null) && this.TestData.Run!=null )
        ) {
            return false;
        }
        return true;
    }
    callRunFlyout() {
        if (this.TestData.Plant == "" || this.TestData.Plant == null) {
            return false;
        }
        return true;
    }
    //new
    SaveTestInformation() {
        if (this.isDataValidate()) {
            debugger;
            var test = new TestCreationModel();
            const testKeys = Object.keys(this.TestData);
            testKeys.forEach(element => {
                test[element] = this.TestData[element];
            })
            //console.log(typeof test.TestStartTime);
            //console.log(this.convert_date_to_string(test.TestStartTime));
            this.testCreationService.SaveTestInformation(test)
                .subscribe(
                    (data: any) => {
                        debugger;
                        if (data == Constants.Success) {
                            //this.onReset()
                            this.searchTest(true);
                            this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.TestSaved });
                        }
                        else if (data == "InvalidTestStartTime") {
                            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Invalid Test Start Time' });
                        }
                        else if (data == "InvalidTestEndTime") {
                            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Invalid Test End Time' });
                        }
                        else if (data == "InvalidTestStartEndTime") {
                            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Start Time is Greater Than End Time', });
                        }

                        // else{
                        //     this.alertMessage.displayMessage({severity: Constants.severityWarn, summary: '', detail: 'Invalid DateTime'});
                        // }
                    },
                    err => { }
                    // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }

    }
    onDelete(testmodel: TestCreationModel) {
        this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) {
                this.deleteNIRTemplateInfo(testmodel);
                this.searchTest(true);
            }
        });
    }
    // getLimsInformation() {
    //     // let testParams: TestParameter = {
    //     //     Plant: "73",
    //     //     Run: "141",
    //     //     Test: "23",
    //     //     StartTime: "2010-09-05 11:14:43",
    //     //     EndTime: "2010-09-05 17:14:48"
    //     // };
    //     // this.testCreationService.GetLimsInformation(testParams)
    //     //     .subscribe(
    //     //         (data: any) => {
    //     //             debugger;
    //     //             if (data == Constants.Success) {
    //     //                 this.searchTest(true);
    //     //                 this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.TestSaved });
    //     //             }
    //     //             else if (data == "InvalidTestStartTime") {
    //     //                 this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Invalid Test Start Time' });
    //     //             }
    //     //             else if (data == "InvalidTestEndTime") {
    //     //                 this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Invalid Test End Time' });
    //     //             }
    //     //             else if (data == "InvalidTestStartEndTime") {
    //     //                 this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: 'Start Time is Greater Than End Time', });
    //     //             }

    //     //             // else{
    //     //             //     this.alertMessage.displayMessage({severity: Constants.severityWarn, summary: '', detail: 'Invalid DateTime'});
    //     //             // }
    //     //         },
    //     //         err => { }
    //     //         // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
    //     //     );
    // }
    runCalculations() {
        var test = new TestCreationModel();
        const testKeys = Object.keys(this.TestData);
        testKeys.forEach(element => {
            test[element] = this.TestData[element];
        })
        this.testCreationService.Calculate(test)
            .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.onReset();
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: "Calculated Successfully" });
                    }
                },
                err => {
                    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                }

            );
    }
    getLIMSandPIData(test: TestCreationModel, index: number) {
        debugger;
        let testParams: TestParameter =
        {
            Plant: test.Plant,
            Run: test.Run.toString(),
            Test: test.Test.toString(),
            StartTime: test.TestStartTime,
            EndTime: test.TestEndTime,
            ServerName: test.PlantLocation == "LOC_1" ? "piranha" : "IE99DMZPI01",
            TimeZone: test.PlantLocation == "LOC_1" ? "Central Standard Time" : "India Standard Time",
        };
        // this.getLimsInformation(testParams);
        // this.getPIData(testParams);
        // this.searchTest(false);
    }
    getPIData(testParams: TestParameter) {
        this.testCreationService.GetPIInformation(testParams)
            .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: "Updated PI data" });
                    }
                },
                err => {
                    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                }

            );
    }
    getLimsInformation(testParams: TestParameter) {
        this.testCreationService.GetLimsInformation(testParams)
            .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Success', detail: "Updated LIMS data" });
                    }
                },
                err => {
                    this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Error', detail: err.Details })
                }

            );
    }

    deleteNIRTemplateInfo(testmodel: TestCreationModel) {
        debugger;

        this.testCreationService.deleteTestData(testmodel)
            .subscribe(
                (data: any) => {
                    if (data == "Delete") {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.TestDeleted });
                    }
                    else {
                        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }
    handleChange(rowData: TestCreationModel, e) {
        debugger;
        this.lineOutInd = e.checked;
        this.TestData = rowData;
        this.TestData.LineOut = e.checked;
        this.SaveTestInformation();
        // if (e.checked) {
        //    this.TestData.LineOut = e.checked;
        //    this.SaveTestInformation();
        // }
        // else {
        //     this.TestData.LineOut = e.checked;
        // }   


    }
    convert_date_to_string(inputDate: Date) {
        debugger;
        var startdate = new Date(inputDate);
        var day = startdate.getDate();       // yields date
        var month = startdate.getMonth() + 1;// yields month (add one as '.getMonth()' is zero indexed)
        var year = startdate.getFullYear();  // yields year
        var hour = startdate.getHours();     // yields hours 
        var minute = startdate.getMinutes(); // yields minutes
        var second = startdate.getSeconds(); // yields seconds
        //var startDateString = year + "/" + month + "/" + day + " " + hour + ':' + minute + ':' + second;
        var startDateString = month + "/" + day + "/" + year + " " + hour + ":" + minute;
        console.log(startDateString)
        return startDateString;
    }
    calculateAll() {
        this.router.navigateByUrl('/PlantData/TestCreation/CalculateAllWC/');
    }

    checkRawData() {
        localStorage.setItem('TestStartTime', this.TestData.TestStartTime);
        localStorage.setItem('TestEndTime', this.TestData.TestEndTime);
        this.router.navigateByUrl('/CheckRawData/CheckRawData/' + this.TestData.Plant + '/' + this.TestData.Run + '/' + this.TestData.Test);
    }

    WCResultSummary() {
        debugger;
        this.router.navigateByUrl('/PlantData/TestCreation/WCResultSummary/' + this.TestData.Plant + '/' + this.TestData.Run + '/' + this.TestData.Test);
    }
}
