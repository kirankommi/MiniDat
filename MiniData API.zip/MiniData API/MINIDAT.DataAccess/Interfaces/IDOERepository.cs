﻿namespace MINIDAT.DataAccess.Interfaces
{
    using MINIDAT.Model.DOE;
    using MINIDAT.Model.FileBrowser;
    using System.Collections.Generic;

    public interface IDOERepository
    {
        MasterData GetMasterData();
        string SaveDOE(SaveModel study);

        Study GetDOEInformation(int studyID);

        PoolMasterData GetPoolMasterData();

        List<PoolModel> SearchDOE(PoolModel doe);

        string DeleteDOE(int strudyID);

        string UploadFiles(List<DoeFileModel> Files, string DeleteIDs, int studyID, string UserID);
        DoeFileModel GetDocument(string fileId, string studyID);

        List<DOEFile> BrowseFiles();
    }
}
