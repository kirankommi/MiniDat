﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.UOM;
using MINIDAT.Manage.UOMTemplate;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Repository.Manage
{
    public class UOMRepository : IUomRepository
    {
        private IDatabase _db;
        public UOMRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        public IList<Group> GetAll(string templateID)
        {
            try
            {
                IList<Group> groupArray = new List<Group>();


                using (IDbCommand command = _db.CreateCommand("Get_Variables_Sp"))
                {

                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_templateid", templateID);
                    _db.CreateParameters(command, parameters);
                    using (IDataReader reader = _db.ExecuteReader(command))
                    {
                        while (reader.Read())
                        {
                            Group group = new Group();
                          //  group.Precision = Convert.ToInt32(reader["PRECISION"]);
                            group.ID = reader["UOM_GROUP_CD"].ToString();
                            group.Name= reader["UOM_GROUP_NM"].ToString();
                            //  group.DefaultUOMId = Convert.ToInt32(reader["DEFAULT_UOM_ID"].ToString());
                            //  group.UOMUnitName = reader["UOM_UNIT_NM"].ToString();
                            groupArray.Add(group);
                        }
                    }
                }
                return groupArray;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
