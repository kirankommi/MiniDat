﻿using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Manage;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;
using System.Xml.Serialization;
using MINIDAT.Framework.Serializer;



namespace MINIDAT.DataAccess.Repository.Manage
{
    public class NIRModelTemplateRepository : INIRModelTemplateRepository
    {
        private IDatabase _db;
        public NIRModelTemplateRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="N", Value="Inactive"},
                    new KeyValue() {Key="Y", Value="Active"},
                };
        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>

        public NIRModelTemplateSearchModel GetNIRModelTemplateData()
        {
            try
            {
                NIRModelTemplateSearchModel NirModelarr = new NIRModelTemplateSearchModel();
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[dbo].[Get_NIRModelTemplate_Information_Sp]"))
                {
                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        ((List<KeyValue>)NirModelarr.lstModelTypes).Add(new KeyValue()
                        {
                            Key = reader["MODEL_TYPE_ID_SQ"].ToString(),
                            Value = reader["MODEL_TYPE"].ToString(),
                            //Groupcd = Convert.ToInt32(reader["MODEL_TYPE_ID_SQ"])
                        });
                    }

                    reader.NextResult();
                    while (reader.Read())
                    {
                        NirModelarr.Feeds.Add(new FeedInfo()
                        {
                            ID = Convert.ToInt32(reader["FEED_ID_SQ"]),
                            Name = Convert.ToString(reader["FEED_NM"]),
                            Desc = Convert.ToString(reader["FEED_DESC"]),
                            BookNum = Convert.ToString(reader["FEED_BOOK_NUM"]),
                            UOPNum = Convert.ToString(reader["FEED_UOP_NUM"]),
                            HasDopant = Convert.ToBoolean(reader["HasDopant"]),
                            DensityMsr = Convert.ToString(reader["DENSITY_MSR"]).FormatDoubleWithPrecision(3)
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        ((List<KeyValue>)NirModelarr.lstConversionTypes).Add(new KeyValue()
                        {
                            Key = reader["CONVERSION_TYPE_ID_SQ"].ToString(),
                            Value = reader["CONVERSION_TYPE"].ToString()
                        });
                    }
                    reader.NextResult();

                    while (reader.Read())
                    {
                        ((List<KeyValue>)NirModelarr.lstPlantsTested).Add(new KeyValue()
                        {
                            Key = reader["PLANT_KEY"].ToString(),
                            Value = reader["PLANT_CD"].ToString()
                        });
                    }
                    reader.NextResult();
                    while (reader.Read())
                    {
                        NirModelarr.DateLastRun = reader["EST_END_DT"].ToString();
                    }
                    reader.NextResult();
                    ((List<KeyValue>)NirModelarr.Status).AddRange(statuses);
                    return NirModelarr;

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<NIRModelTemplateModel> SearchNIRTemplateData(NIRModelTemplateModel NIRModelTemplate)
        {
            try
            {

                string selectedPlants = String.Empty;
                string feedNames = String.Empty;
                for (int i = 0; i < NIRModelTemplate.selectedplants.Count; i++)
                {
                    if (i == 0)
                    {
                        selectedPlants += selectedPlants + NIRModelTemplate.selectedplants[i].Value;

                    }
                    else
                    {
                        selectedPlants += ", " + NIRModelTemplate.selectedplants[i].Value;
                    }

                }
                
                for (int i = 0; i < NIRModelTemplate.lstFeedNames.Length; i++)
                {
                    if (i == 0)
                    {
                        feedNames += feedNames + NIRModelTemplate.lstFeedNames[i];

                    }
                    else
                    {
                        feedNames += "/" + NIRModelTemplate.lstFeedNames[i];
                    }

                }

                List<NIRModelTemplateModel> NirModelarr = new List<NIRModelTemplateModel>();
                IDataReader reader = null;
                using (IDbCommand command = _db.CreateCommand("[dbo].[Search_NIRModelTemplate_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_in_modeltype", (NIRModelTemplate.NIRModelType == 0 ? null : NIRModelTemplate.NIRModelType));
                    parameters.Add("proc_in_conversionType", (NIRModelTemplate.ConversionType == 0 ? null : NIRModelTemplate.ConversionType));
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(NIRModelTemplate.StatusName == "Select" ? null : NIRModelTemplate.StatusName) ? (object)null : NIRModelTemplate.StatusName);
                    parameters.Add("proc_in_modelId", NIRModelTemplate.ModelID);
                    parameters.Add("proc_in_conversionCutPoint", NIRModelTemplate.ConversionCutPoint);
                    parameters.Add("proc_in_low", NIRModelTemplate.Low);
                    parameters.Add("proc_in_high", NIRModelTemplate.High);
                    parameters.Add("proc_in_sigmaError", NIRModelTemplate.SigmaError);
                    //parameters.Add("proc_in_plantsTested", (NIRModelTemplate.plantsTestedKey == 0 ? null : NIRModelTemplate.plantsTestedKey));
                    parameters.Add("proc_in_lstOfPlantsTested", selectedPlants);
                    parameters.Add("proc_in_lstOfFeedsSelected", feedNames);
                    parameters.Add("IsInitialLoad", (NIRModelTemplate.IsInitialLoad==true?'Y':'N'));
                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    while (reader.Read())
                    {
                        NIRModelTemplateModel _nirModelTemplateModel = new NIRModelTemplateModel
                        {
                            ModelTypecd = new KeyValue() { Key = reader["MODEL_TYPE_ID_SQ"].ToString(), Value = reader["MODEL_TYPE_NM"].ToString() },
                            ConversionTypecd = new KeyValue() { Key = reader["CONVERSION_TYPE_ID_SQ"].ToString(), Value = reader["CONVERSION_TYPE_NM"].ToString() },
                            StatusCode = new KeyValue() { Key = reader["ACTIVE_IND"].ToString(), Value = reader["ACTIVE_IND"].ToString() },
                            Low = (reader["LOW_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["LOW_MSR"]),
                            High = (reader["HIGH_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["HIGH_MSR"]),
                            SigmaError = (reader["ERROR_EST_MSR"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["ERROR_EST_MSR"]),
                            ModelID = Convert.ToString(reader["MODEL_ID_NUM"]),
                            ConversionCutPoint = (reader["CONVERSION_CUT_POINT"] == DBNull.Value) ? (decimal?)null : Convert.ToDecimal(reader["CONVERSION_CUT_POINT"]),
                            plantsSelectedlist = Convert.ToString(reader["PLANT"]),
                            feedSelectedList = Convert.ToString(reader["FEED"]),
                            ActiveInd = Convert.ToString(reader["ACTIVE_IND"]),
                            NIRModelSQID = Convert.ToInt32(reader["MODEL_SQ_ID"]),
                            selectedPlantKeyList = Convert.ToString(reader["PLANT_KEY"]),


                        };
                        NirModelarr.Add(_nirModelTemplateModel);
                    }
                }
                return NirModelarr;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }


        public void SaveNIRModelTemplate(NIRModelTemplateModel NIRModelTemplateModel, string userId)
        {


            try
            {
                string feedNames = String.Empty;
                string feedIds = String.Empty;
                string selectedPlants = String.Empty;

                for (int i = 0; i < NIRModelTemplateModel.selectedplants.Count; i++)
                {
                    if (i == 0)
                    {
                        selectedPlants += selectedPlants + NIRModelTemplateModel.selectedplants[i].Key;

                    }
                    else
                    {
                        selectedPlants += "," + NIRModelTemplateModel.selectedplants[i].Key;
                    }

                }
                NIRModelTemplateModel.plantsSelectedlist = selectedPlants;

                for (int i = 0; i < NIRModelTemplateModel.lstFeedIds.Length; i++)
                {
                    if (i == 0)
                    {
                        feedIds += feedIds + NIRModelTemplateModel.lstFeedIds[i];

                    }
                    else
                    {
                        feedIds += "/" + NIRModelTemplateModel.lstFeedIds[i];
                    }

                }
                NIRModelTemplateModel.feedSelectedList = feedIds;
                //for (int i = 0; i < NIRModelTemplateModel.lstFeedNames.Length; i++)
                //{
                //    if (i == 0)
                //    {
                //        feedNames += feedNames + NIRModelTemplateModel.lstFeedNames[i];

                //    }
                //    else
                //    {
                //        feedNames += "," + NIRModelTemplateModel.lstFeedNames[i];
                //    }

                //}

                if (string.IsNullOrEmpty(userId) || NIRModelTemplateModel == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);
                //string xmlData = Serializer.ConvertToXML<FeedInfo>(NIRModelTemplateModel.Feeds);
                IDbCommand command = _db.CreateCommand("[md].InsertUpdateNIRModelTemplate_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    //parameters.Add("@nirModelIdSq", string.IsNullOrEmpty(NIRModelTemplateModel.NIRModelSQID) ? (object)null : npdModel.TechnicalTeamLead)
                    parameters.Add("@paramModelTypeId", NIRModelTemplateModel.NIRModelType);
                    parameters.Add("@paramModelIdNum", NIRModelTemplateModel.ModelID);
                    parameters.Add("@paramConversionCutPointmsr", NIRModelTemplateModel.ConversionCutPoint.HasValue ? NIRModelTemplateModel.ConversionCutPoint : (object)DBNull.Value);
                    //parameters.Add("@paramConversionCutPointmsr", NIRModelTemplateModel.ConversionCutPoint);
                    parameters.Add("@paramConversionTypeId", NIRModelTemplateModel.ConversionType);
                    parameters.Add("@paramLowMsr", NIRModelTemplateModel.Low);
                    parameters.Add("@paramHighMsr", NIRModelTemplateModel.High);
                    parameters.Add("@paramErrorEstimateMsr", NIRModelTemplateModel.SigmaError.HasValue ? NIRModelTemplateModel.SigmaError : (object)DBNull.Value);
                    parameters.Add("@paramStatusInd", string.IsNullOrEmpty(NIRModelTemplateModel.StatusName == "Select" ? null : NIRModelTemplateModel.StatusName) ? (object)null : NIRModelTemplateModel.StatusName);
                    parameters.Add("@paramFeedIdList", feedIds);
                    parameters.Add("@paramPlantKeyList", selectedPlants);
                    parameters.Add("@paramCreatedByUserId", Eid);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public string DeleteNIRModelTemplate(NIRModelTemplateModel NIRModelTemplateModel)
        {
            try
            {
                if (NIRModelTemplateModel == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[md].Delete_NIR_Model_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_NIR_Model_id", string.IsNullOrEmpty(Convert.ToString(NIRModelTemplateModel.NIRModelSQID)) ? (object)null : NIRModelTemplateModel.NIRModelSQID);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        public List<FeedInfo> GetSelectedFeedList(string feedName)
        {
            List<FeedInfo> lstFeedNames = new List<FeedInfo>();

            return lstFeedNames;
        }


        public void Update(NIRModelTemplateModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(NIRModelTemplateModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<NIRModelTemplateModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(NIRModelTemplateModel _model)
        {
            throw new NotImplementedException();
        }


    }
}
