import { Component, OnInit, Input, OnDestroy, ViewChild } from "@angular/core";
import * as  Constants from '../../Shared/globalconstants';
import { uploadHandler } from '../../Directives/bulkupload/bulkupload.component';
import { FileModel } from '../../Models/file.model';
import { doeMediatorService } from '../../services/doeservices/doemediator.service';
import { KeyValue } from '../../Models/KeyValue';
import { appService } from '../../Services/app.service';
import { AlertMessage } from '../../Services/alertmessage.service';
import { errorModel } from './errorModel';
import { bulkUploadComponent } from '../../Directives/bulkupload/bulkupload.component';
import { reject } from "q";
import { debug } from "util";
import { doeService } from "../../services/doeservices/doe.service";
import { Observable } from "rxjs";

@Component({
  templateUrl: "basicInformation.component.html",
  selector: "basic-Info"
})
export class basicInformationComponent implements OnInit, OnDestroy {

  phandler: uploadHandler;
  files: FileModel[] = [];
  projectFlyoutColumns: KeyValue[];
  studyFlyoutColumns: KeyValue[];
  studyDtl: any = {};
  public error: errorModel = new errorModel();

  @ViewChild("uploadCtrl")
  uploadCtrl: bulkUploadComponent;

  ngOnInit(): void {
    this.reset();
    this.mS.onRuoteIntialized.subscribe((data) => {
      if (data != "create") {
        this.studyDtl = data.studyDtl;
        this.files = data.studyDtl.File_List ? data.studyDtl.File_List : [];
      }
      else {
        this.reset();
      }
    });
    this.phandler = new uploadHandler();
    this.phandler.downloadFile = this.onDownload.bind(this);
  }

  ngOnDestroy() {
  }

  constructor(public mS: doeMediatorService, public appservice: appService, public alertMessage: AlertMessage, private service: doeService) {

    this.mS.getBasicInformation = this.getSaveData.bind(this);

    this.studyFlyoutColumns = [
      {
        Key: "Name",
        Value: "Study Name"
      },
      {
        Key: "SpecialistNM",
        Value: "Specialist"
      },
      {
        Key: "Objective",
        Value: "Objective"
      },
      {
        Key: "DOEQuestion",
        Value: "DOE Question"
      },
    ];

    this.projectFlyoutColumns = [
      {
        Key: "Name",
        Value: "Project Name"
      },
      {
        Key: "NW1",
        Value: "Network Number 1"
      },
      {
        Key: "NW2",
        Value: "Network Number 2"
      },
      {
        Key: "NW3",
        Value: "Network Number 3"
      }
    ];

  }

  onDownload(fileId: number): Observable<any> {
    return this.service.DownloadFile(fileId, this.studyDtl.IDSQ);
  }


  getSave(files: any) {
    debugger;
  }

  updateLDAPSelection(event: any, condition: any) {
    if (event.CellChange) {
      this.studyDtl.SpecialistID = event.EID;
      this.studyDtl.SpecialistNM = event.DisplayName;
    }
    else {
      this.studyDtl.SpecialistID = event.EID;
      this.studyDtl.SpecialistNM = event.DisplayName;
    }
  }

  onProjectSelection(event, condition) {
    this.mS.projectName = event.Name;
    this.studyDtl.Project.Name = event.Name;
    this.studyDtl.Project.ID = event.ID;
    this.studyDtl.Project.NW1 = event.NW1;
    this.studyDtl.Project.NW2 = event.NW2;
    this.studyDtl.Project.NW3 = event.NW3;
    this.studyDtl.Project.TechLead = event.TechLead;
  }

  onStudySelection(event, condition) {
    let selectedStudy = JSON.parse(JSON.stringify(event));
    this.studyDtl.Project = selectedStudy.Project;
    this.studyDtl.Objective = selectedStudy.Objective;
    this.studyDtl.DOEQuestion = selectedStudy.DOEQuestion;
    this.studyDtl.Strategy = selectedStudy.Strategy;
  }

  reset() {
    this.error = new errorModel();
    this.studyDtl = {
      "Project": {
      }
    };
    this.appservice.getSessionData().subscribe(q => {
      this.studyDtl.SpecialistID = q.User.EID;
      this.studyDtl.SpecialistNM = q.User.DisplayName;
    });
  }

  validate(): boolean {
    this.error = new errorModel();
    if (this.studyDtl) {
      if (!this.studyDtl.Project.Name) {
        this.error.Messages = this.error.Messages + "Project Name is required." + " \n";
        this.error.Count++;
        this.error.Fields["project"] = true;
      }
      if (!this.studyDtl.Name) {
        this.error.Messages = this.error.Messages + "Study Name is required." + " \n";
        this.error.Count++;
        this.error.Fields["study"] = true;
      }
      if (!this.studyDtl.SpecialistNM) {
        this.error.Messages = this.error.Messages + "Specialist Name is required." + " \n";
        this.error.Count++;
        this.error.Fields["SpecialistNM"] = true;
      }
      if (!this.studyDtl.DOEQuestion) {
        this.error.Messages = this.error.Messages + "DOE Question is required." + " \n";
        this.error.Count++;
        this.error.Fields["DOEQuestion"] = true;
      }
    }
    if (this.error.Count > 0) {
      this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Basic Information', detail: this.error.Messages });
      return false;
    }
    return true;
  }

  getSaveData() {
    return new Promise((resolve, reject) => {
      let uploadData: any = this.uploadCtrl.getSaveData();
      if (this.validate() && uploadData != "Error") {
        return resolve({ Info: this.studyDtl, Files: uploadData.files.filter(q => q.isDirty == true), deleteIds: uploadData.deleteIds });
      }
      return resolve("error");
    });
  }


}
