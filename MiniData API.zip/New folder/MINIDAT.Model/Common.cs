﻿namespace MINIDAT.Model
{
    public class KeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public string Default { get; set; }
        public int Groupcd { get; set; }
    }

    public static class Constants
    {
        public const string SUCCESS = "success";
        public const string Coma= ",";
    }

    public enum ErrroMessges
    {
        InvalidLIMSID,
        NoLIMSDATAOnSearch,
        RoleInUse,
        UserAlreadyExists,
        UserSaveError,
        UnKnownError,
        FixedRole,
        NullSampleData,
        NullWorkItemData,
        ErrorWhenSampleSearch,        
        ErrorWhenLIMSGetResultSearch,
        ProjectSaveError,
        ProjectSearchError,
        ProjectAccoladeLoadError,
        AccoladeProjectAlreadyExists,
        ProjectDeleteError,
        ProjectInUseDeleteError,
        CatalystDeleteError,
        CatalystInUseDeleteError,
        CatalystSearchError,
        CatalystSaveError,
        CatalystSaveDuplicateKeyError,
        RunSaveError,
        TestResultsSearchError,
        TestSearchError,
        TestDataLoadError,
        NullPlantCode,
        CatalystLoadingInUse,
        LoadingTemplateInUse

    }
    public enum SuccessMessges
    {
        SampleMessage

    }

    public enum WarningMessges
    {
        SampleMessage,
    }
}
