﻿using System.Collections.Generic;

namespace MINIDAT.Model.Manage
{
    public class ModeModel
    {
        public int? ModeID { get; set; }
        public int? ModeNumber { get; set; }
        public string Description { get; set; }        
        public string ModeType { get; set; }
        public string ControlName { get; set; }
        public string SulfidingType { get; set; }
        public decimal? Pressure { get; set; }
        public decimal? LHSV { get; set; }
        public decimal? SCFB { get; set; }
        public int? Conditions { get; set; }
        public string CanEdit { get; set; }       

    }
     public class ModeSearchModel
    {
        private IList<KeyValue> _modetypes = new List<KeyValue>();
        public IList<KeyValue> lstModeTypes { get { return _modetypes; } }

        private IList<KeyValue> _controlNames = new List<KeyValue>();
        public int RecordsFetched { get; set; }
        public IList<KeyValue> lstControlNames { get { return _controlNames; } }

        private IList<KeyValue> _sulfidingTypes = new List<KeyValue>();
        public IList<KeyValue> lstSulfidingTypes { get { return _sulfidingTypes; } }

        private IList<ModeModel> _modes= new List<ModeModel>();
        public IList<ModeModel> lstModes { get { return _modes; } }

        private IList<ApplicationModel> _applications = new List<ApplicationModel>();
        public IList<ApplicationModel> ApplicationList { get { return _applications; } }

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> Status { get { return status; } }
    }
}
