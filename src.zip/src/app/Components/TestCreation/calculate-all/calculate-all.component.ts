import { Component, OnInit, Input } from '@angular/core';
import * as Constants from '../../../../app/Shared/globalconstants';
import { ActivatedRoute, Router } from '@angular/router';
import { TestCreationService } from 'src/app/Services/TestCreation/TestCreation.service';
import { CalculateAllModel, CalculateAllTableModel } from 'src/app/Models/TestCreation/CalculateAllModel';
import { AppComponent } from 'src/app/app.component';
import { AlertMessage } from 'src/app/Services/alertmessage.service';
import { appService } from 'src/app/Services/app.service';
import { KeyValue } from 'src/app/Models/usermodel';

@Component({
  selector: 'app-calculate-all',
  templateUrl: './calculate-all.component.html',
  styleUrls: ['./calculate-all.component.css'],
  providers: [TestCreationService],
})
export class CalculateAllComponent implements OnInit {
  constants: any = {};
  userEid: string;

  CalculateAllData: CalculateAllModel= new CalculateAllModel();

  plantListCols: any[] = [];
  lstPlants: any;
  flyoutHeaderPlant: string = "Plants";
  pHolderPlant: string = "Plant #";

  RunListCols: any[] = [];
  lstRuns: any;
  flyoutHeaderRun: string = "Run";
  pHolderRun: string = "Run #";

  @Input() isNotSearchable: boolean;
  flyoutState: string = 'out';

  constructor(private route: ActivatedRoute,private router: Router,private testCreationService: TestCreationService,private appComponent: AppComponent, private appService: appService, private alertMessage: AlertMessage) { 
    this.constants = Constants;
  }

  ngOnInit() {
    this.getPlantFlyout();
    this.appService.getSessionData()
      .subscribe((data: any) => {
        if (data != null) {
          if (data.User != null && data.User != undefined) {
            this.userEid = data.User.EID;
          }
          else {
            document.getElementById('fdms-container').style.marginLeft = '0px';
          }
        }
      });
  }
  updateRunSelection(event, condition) {
    debugger;
    this.CalculateAllData.Run = event.RunNumber;
  }
  updatePlantSelection(event, condition) {
    debugger;
    this.CalculateAllData.Plant = event.Plantcode;
    this.getRunFlyout();
  }
  GoBack(){
    this.router.navigateByUrl('/PlantData/TestCreation')
  }
  toggleFlyout() {
    if (!this.isNotSearchable) {
      this.appComponent.isOverlay = (this.flyoutState == 'out') ? true : false;
      this.flyoutState = this.flyoutState === 'out' ? 'in' : 'out';
    }
  }
  getRunFlyout() {
    debugger;
    this.RunListCols = [];
    this.lstRuns = [];
    this.CalculateAllData.Run = null;
    this.RunListCols.push({ Key: "Plantcode", Value: "Plant #" });
    this.RunListCols.push({ Key: "RunNumber", Value: "Run #" });

    this.testCreationService.GetRunFlyout(this.CalculateAllData.Plant)
      .subscribe(
        (data: any) => {
          debugger;
          this.lstRuns = data;
        },
        err => { }
        //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      );
  }
  getPlantFlyout() {
    debugger;

    this.plantListCols.push({ Key: "Plantcode", Value: "Plant #" });
    this.plantListCols.push({ Key: "Location", Value: "Location" });
    this.plantListCols.push({ Key: "BuildingNumber", Value: "Building Number" });

    this.testCreationService.GetPlantFlyout()
      .subscribe(
        (data: any) => {
          debugger;
          this.lstPlants = data.lstPlants;
        },
        err => { }
        //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
      );
  }


}
