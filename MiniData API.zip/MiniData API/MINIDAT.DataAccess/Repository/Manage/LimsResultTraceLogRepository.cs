﻿using MINIDAT.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model.Manage.LIMSAnalysisMethod;
using System.Data;
using MINIDAT.Model;
using System.Collections;

namespace FDMS.DataAccess.Repository.Manage
{
    public class LimsResultTraceLogRepository : ILimsResultTraceLogRepository
    {
        private IDatabase _db;
        public LimsResultTraceLogRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }
        //public IList<LimsResultTraceLog> GetAll(string type, string feedId)
        //{
        //    IList<LimsResultTraceLog> list = new List<LimsResultTraceLog>();
        //    try
        //    {
        //        using (IDbCommand cmd = _db.CreateCommand("getLimsResultTraceLog"))
        //        {
        //            IDbDataParameter cmdParam = cmd.CreateParameter();
        //            cmdParam.ParameterName = "type";
        //            cmdParam.Value = type;
        //            cmd.Parameters.Add(cmdParam);

        //            IDbDataParameter cmdSampleId = cmd.CreateParameter();
        //            cmdSampleId.ParameterName = "feedId";
        //            cmdSampleId.Value = feedId;
        //            cmd.Parameters.Add(cmdSampleId);

        //            IDataReader reader = _db.ExecuteReader(cmd);
        //            while (reader.Read())
        //            {
        //                var log = new LimsResultTraceLog();
        //               // log.TraceLogIdSQ = Convert.ToInt32(reader["LIMS_RESULT_TRACE_LOG_ID_SQ"]);
        //               // log.SampleId = Convert.ToString(reader["SAMPLE_ID"]);
        //               // log.UserSampleId = Convert.ToString(reader["USER_SAMPLE_ID"]);
        //                log.LimsOperationName = Convert.ToString(reader["lims_operation_nm"]);
        //                log.ComponentName = Convert.ToString(reader["component_nm"]);
        //                log.UOM = Convert.ToString(reader["UOM"]);
        //                log.Status = Convert.ToString(reader["STATUS"]);
        //             //   log.CreatedByUserID = Convert.ToString(reader["CREATED_BY_USER_ID"]);
        //                //if (reader["SAMPLE_DT"] != DBNull.Value)
        //                //    log.SampleDate = Convert.ToDateTime(reader["SAMPLE_DT"]);
        //                //if (reader["CREATED_ON_DT"] != DBNull.Value)
        //                //    log.CreatedOnDate = Convert.ToDateTime(reader["CREATED_ON_DT"]);
        //                list.Add(log);
        //            }
        //            reader.Close();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogManager.Error(ex);
        //        throw;
        //    }
        //    return list;
        //}

        public int getMissingOperationAndComponentCountByFeedId(string feedId)
        {
            int count = 0;
            try
            {
                using (IDbCommand cmd = _db.CreateCommand("getMissingOperationAndComponentCountByFeedId_Sp"))
                {
                    IDbDataParameter cmdParam = cmd.CreateParameter();
                    cmdParam.ParameterName = "feedId";
                    cmdParam.Value = feedId;
                    cmd.Parameters.Add(cmdParam);

                    count = (int)_db.ExecuteScalar(cmd);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            return count;
        }

        public void SaveComponents(string data, string User)
        {
            int count = 0;
            try
            {
                using (IDbCommand command = _db.CreateCommand("Insert_Update_Bulk_Lims_Component_Sp"))
                {

                    IDictionary parameters = new Dictionary<string, object>();

                    string EID = string.Empty;
                    if (User != null && !string.IsNullOrEmpty(User))
                    {
                        EID = User.Substring(User.IndexOf("\\") + 1);
                    }
                    parameters.Add("@proc_var_components", data);
                    parameters.Add("@proc_vr_Created_By_Id", EID);
                    _db.CreateParameters(command, parameters);
                    count = _db.ExecuteNonQuery(command);
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public void SaveOperations(string data, string User)
        {

            int count = 0;
            try
            {
                using (IDbCommand command = _db.CreateCommand("Insert_Update_Bulk_Analysis_Method_Sp"))
                {

                    IDictionary parameters = new Dictionary<string, object>();

                    string EID = string.Empty;
                    if (User != null && !string.IsNullOrEmpty(User))
                    {
                        EID = User.Substring(User.IndexOf("\\") + 1);
                    }
                    parameters.Add("@proc_vr_analysis_Methods", data);
                    parameters.Add("@proc_vr_Created_By_User_Id", EID);
                    _db.CreateParameters(command, parameters);
                    count = _db.ExecuteNonQuery(command);
                }

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
