﻿using System.Collections.Generic;

namespace MINIDAT.Model.Manage
{
    public class RoleModel
    {   
        
        public KeyValue StatusCode { get; set; }
        public string RoleName { get; set; }
        public string RoleCode { get; set; }
        public string RoleDescription { get; set; }
        public string ApplicationName { get; set; }
        public string Appcode { get; set; }
        //Search Parameters

        public string StatusName { get; set; }
        public string CanDelete { get; set; }

        //Pagination Parameters
        public int TotalRecords { get; set; }
        public int CurrentPage { get; set; }
        public int RecordsPerPage { get; set; }
        public string SortOrder { get; set; }
        public string SortColumn { get; set; }

    }
    public class ApplicationModel {
        public string ApplicationId { get; set; }
        public string ApplicationName { get; set; }
    }
    public class RoleSearchModel
    {
        private IList<KeyValue> status = new List<KeyValue>();
        public int RecordsFetched { get; set; }
        public IList<KeyValue> Status { get { return status; } }
        //public IList<RoleModel> Roles { get; set; }

        private IList<RoleModel> _roles = new List<RoleModel>();
        public IList<RoleModel> Roles { get { return _roles; } }

        private IList<ApplicationModel> _applications = new List<ApplicationModel>();
        public IList<ApplicationModel> ApplicationList { get { return _applications; } }
    }
}
