export class TestParameter {
    Plant: string;
    Run: string;
    Test: string;
    StartTime: string;
    EndTime: string;
    ServerName: string;
    TimeZone: string;
}