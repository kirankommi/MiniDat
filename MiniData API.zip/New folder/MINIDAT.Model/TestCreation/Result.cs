﻿using PIAPIDataService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.TestCreation
{
    public class Result
    {

        public string Plant;
        public bool HasError;
        public string ErrorDescription;
        public PIData Data;

    }
}
