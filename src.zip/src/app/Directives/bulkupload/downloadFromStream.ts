export class DownloadFromStream {
  static DownloadFile(fileData: any, fileName: string, contentType: any) {
    var byteCharacters = atob(fileData);
    var byteNumbers = new Array(byteCharacters.length);
    for (var i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);
    var blob = new Blob([byteArray], { type: "" });
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    var chrome = ua.indexOf("Chrome");

    if (msie > -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      window.navigator.msSaveOrOpenBlob(blob, fileName);
    }
    else {
      var objectUrl = URL.createObjectURL(blob);
      //console.log("objectUrl  :   " + objectUrl);
      var link = document.createElement("A");
      link.setAttribute("href", objectUrl);
      //link.setAttribute("download", fileName + "." + contentType);
      link.setAttribute("download", fileName);
      link.setAttribute("target", "_blank");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
}
