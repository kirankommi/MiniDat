﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class CatalystStateModel
    {
        public int? CatalystStateID { get; set; }
        public string CatalystState { get; set; }     
        public string StatusName { get; set; }
        public string SRIndicator { get; set; }      
        public KeyValue StatusCode { get; set; }
        public KeyValue SRIndicatorcd { get; set; }     

    }
    public class CatalystStateSearchModel
    {

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<KeyValue> srIdicators = new List<KeyValue>();
        public IList<KeyValue> lstSRIndicators { get { return srIdicators; } }     

        private IList<CatalystStateModel> _lstcatalystStates = new List<CatalystStateModel>();
        public IList<CatalystStateModel> LstcatalystStates { get { return _lstcatalystStates; } }

        public int RecordsFetched { get; set; }

    }
}
