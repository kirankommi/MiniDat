﻿using MINIDAT.DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MINIDAT.Model;
using MINIDAT.Models.Interfaces;
using Microsoft.Practices.EnterpriseLibrary.Data;
using MINIDAT.Framework.Common;
using System.Data.Common;
using System.Data;
using MINIDAT.Model.Project;
using System.Collections;
using MINIDAT.Model.Session;
using MINIDAT.Framework.Serializer;
using MINIDAT.Model.Catalyst;

namespace MINIDAT.DataAccess.Repository.Project
{
    public class ProjectRepository : IProjectRepository
    {

        private IDatabase _db;
        public ProjectRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        public bool DeleteProject(int projectId)
        {
            try
            {
                if (projectId == null) throw new ArgumentNullException("Project Id");
                if (UserSession.Instance.User.EID == null) throw new ArgumentNullException("user");
                IDbCommand command = _db.CreateCommand("Delete_Project_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_Project_id", projectId);
                    parameters.Add("proc_User_Id", UserSession.Instance.User.EID);
                    _db.CreateParameters(command, parameters);
                    int cnt = _db.ExecuteNonQuery(command);
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public List<AccoladeProjectModel> GetAccoladeProjects(string projectType)
        {
            try
            {
                #region setting up DBCommand with parameters
                List<AccoladeProjectModel> list = new List<AccoladeProjectModel>();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("GetAccoladeProjects"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_var_project_type_cd", projectType);
                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        AccoladeProjectModel accProj = new AccoladeProjectModel
                        {
                            DW_ProjectId = Convert.ToInt32(objSqlDr["DW_PROJECT_ID_SQ"]),
                            AccoladeProjectCd = Convert.ToString(objSqlDr["PROJECT_CD"]),
                            ProjectName = Convert.ToString(objSqlDr["PROJECT_NM"]),
                            ProjectDesc = Convert.ToString(objSqlDr["PROJECT_DESC"]),
                            CurrentPhaseNameCd = Convert.ToString(objSqlDr["CURRENT_PHASE_NM_CD"]),
                            CurrentPhasePriorityCd = Convert.ToString(objSqlDr["CURRENT_PHASE_PRIORITY_CD"]),
                            UOPNetworkNumber1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                            UOPNetworkNumber2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                            UOPNetworkNumber3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                            ProjectTypeId = Convert.ToInt32(objSqlDr["PROJECT_TYPE_ID"]),
                            UOPSegmentId = Convert.ToString(objSqlDr["UOP_SEGMENT_ID"]),
                            PTE = Convert.ToDecimal(objSqlDr["PTE_PERCNT"]),
                            CAS = Convert.ToDecimal(objSqlDr["CAS_PERCNT"]),
                            StatusCd = Convert.ToString(objSqlDr["PROJECT_STATUS"]),
                            isExists = Convert.ToString(objSqlDr["isExists"]),
                            TechLead = Convert.ToString(objSqlDr["TECH_LEAD"]),
                            Gate2 = ((objSqlDr["2"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["2"]).ToString("MM/dd/yyyy")),
                            Gate3 = ((objSqlDr["3"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["3"]).ToString("MM/dd/yyyy")),
                            Gate4 = ((objSqlDr["4"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["4"]).ToString("MM/dd/yyyy")),
                            Gate5 = ((objSqlDr["5"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["5"]).ToString("MM/dd/yyyy")),
                            Gate6 = ((objSqlDr["6"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["6"]).ToString("MM/dd/yyyy")),
                        };
                        list.Add(accProj);
                    }
                }
                return list;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        public ProjectMasterDataModel GetProjectDetails(string projectType)
        {
            try
            {
                #region setting up DBCommand with parameters
                ProjectMasterDataModel mstr = new ProjectMasterDataModel();
                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("GetProjectDetails"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_var_project_type_cd", projectType);
                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    mstr.CurrentPhaseNames = new List<KeyValue>();
                    mstr.CurrentPhaseNames.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.CurrentPhasePriorities = new List<KeyValue>();
                    mstr.CurrentPhasePriorities.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.Status = new List<KeyValue>();
                    mstr.Status.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.PPPriorities = new List<KeyValue>();
                    mstr.PPPriorities.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.UopSEGs = new List<KeyValue>();
                    mstr.UopSEGs.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.CASs = new List<KeyValue>();
                    mstr.CASs.Add(new KeyValue { Key = "-1", Value = "Select" });
                    mstr.PTEs = new List<KeyValue>();
                    mstr.PTEs.Add(new KeyValue { Key = "-1", Value = "Select" });
                    mstr.BusinessGroup = new List<KeyValue>();
                    mstr.BusinessGroup.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.BusinessJustification = new List<KeyValue>();
                    mstr.BusinessJustification.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.BusinessObjective = new List<KeyValue>();
                    mstr.BusinessObjective.Add(new KeyValue { Key = "0", Value = "Select" });
                    mstr.Application = new List<KeyValue>();
                    mstr.Application.Add(new KeyValue { Key = "0", Value = "Select" });

                    while (objSqlDr.Read())
                    {
                        KeyValue phase = new KeyValue();
                        phase.Key = Convert.ToString(objSqlDr["PROJECT_PHASE_CD"]);
                        phase.Value = Convert.ToString(objSqlDr["PROJECT_PHASE_NM"]);
                        mstr.CurrentPhaseNames.Add(phase);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue pp = new KeyValue();
                        pp.Key = Convert.ToString(objSqlDr["PROJECT_PRIORITY_CD"]);
                        pp.Value = Convert.ToString(objSqlDr["PROJECT_PRIORITY_NM"]);
                        mstr.CurrentPhasePriorities.Add(pp);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue status = new KeyValue();
                        status.Key = Convert.ToString(objSqlDr["PROJECT_STATSU_CD"]);
                        status.Value = Convert.ToString(objSqlDr["PROJECT_STATUS_NM"]);
                        mstr.Status.Add(status);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue pppri = new KeyValue();
                        pppri.Key = Convert.ToString(objSqlDr["PP_PRIORITY_CD"]);
                        pppri.Value = Convert.ToString(objSqlDr["PP_PRIORITY_NM"]);
                        mstr.PPPriorities.Add(pppri);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue uopseg = new KeyValue();
                        uopseg.Key = Convert.ToString(objSqlDr["UOP_SEGMENT_CD"]);
                        uopseg.Value = Convert.ToString(objSqlDr["UOP_SEGMENT_NM"]);
                        mstr.UopSEGs.Add(uopseg);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue CAS = new KeyValue();
                        KeyValue PTE = new KeyValue();
                        CAS.Key = Convert.ToString(objSqlDr["CASPTE_CD"]);
                        CAS.Value = Convert.ToString(objSqlDr["CASPTE_NM"]);
                        PTE.Key = Convert.ToString(objSqlDr["CASPTE_CD"]);
                        PTE.Value = Convert.ToString(objSqlDr["CASPTE_NM"]);
                        mstr.CASs.Add(CAS);
                        mstr.PTEs.Add(PTE);
                    }


                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue bjust = new KeyValue();
                        bjust.Key = Convert.ToString(objSqlDr["BUSINESS_JUSTIFY_CD"]);
                        bjust.Value = Convert.ToString(objSqlDr["BUSINESS_JUSTIFY_NM"]);
                        mstr.BusinessJustification.Add(bjust);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue bobj = new KeyValue();
                        bobj.Key = Convert.ToString(objSqlDr["BUSINESS_OBJECTION_CD"]);
                        bobj.Value = Convert.ToString(objSqlDr["BUSINESS_OBJECTION_NM"]);
                        mstr.BusinessObjective.Add(bobj);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue bgrp = new KeyValue();
                        bgrp.Key = Convert.ToString(objSqlDr["BUSINESS_GROUP_CD"]);
                        bgrp.Value = Convert.ToString(objSqlDr["BUSINESS_GROUP_NM"]);
                        mstr.BusinessGroup.Add(bgrp);
                    }

                    objSqlDr.NextResult();
                    while (objSqlDr.Read())
                    {
                        KeyValue app = new KeyValue();
                        app.Key = Convert.ToString(objSqlDr["APPLICATION_CD"]);
                        app.Value = Convert.ToString(objSqlDr["APPLICATION_NM"]);
                        mstr.Application.Add(app);
                    }
                }
                return mstr;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        

        public virtual int SaveProject(ProjectModel project)
        {
            throw new NotImplementedException();
        }

        public virtual List<ProjectModel> SearchProjectDetails(ProjectModel project)
        {
            throw new NotImplementedException();
        }
        public void InsertProjectDocument(FileImport _doc)
        {
            if (_doc == null) throw new ArgumentNullException("_doc");
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("Project_Id", _doc.ProjectId);
                parameters.Add("FILE_NM", _doc.FileName);
                parameters.Add("FILE_DESC", _doc.Description);
                parameters.Add("CONTENT_TYPE", _doc.ContentType);
                parameters.Add("DATA", _doc.getData());
                parameters.Add("CREATED_BY_USER_ID", _doc.CreatedByUserID);
                using (IDbCommand cmd = _db.CreateCommand("InsertUpdateProjectDocument_sp"))
                {
                    _db.CreateParameters(cmd, parameters);
                    var fileId = _db.ExecuteScalar(cmd);
                    _doc.FileId = Convert.ToInt32(fileId);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {

            }
        }

        public FileImport GetProjectDocument(string fileId, string projectId)
        {
            var doc = new FileImport();
            IDictionary parameters = new Dictionary<string, object>();
            parameters.Add("FILE_ID", fileId);
            parameters.Add("Project_Id", projectId);
            using (IDbCommand cmd = _db.CreateCommand("Get_Project_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                while (reader.Read())
                {
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.ProjectId = Convert.ToInt32(reader["PROJECT_ID"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    doc.FileData = (byte[])reader["DATA"];
                    doc.UID = Convert.ToInt32(reader["FILE_ID_SQ"]);
                }
                reader.Close();
                return doc;
            }
        }

        public List<FileImport> GetProjectAllDocuments(string projectId)
        {
            List<FileImport> docs = new List<FileImport>();
            IDictionary parameters = new Dictionary<string, object>();          
            parameters.Add("Project_Id", projectId);
            using (IDbCommand cmd = _db.CreateCommand("Get_Project_All_Document_Sp"))
            {
                _db.CreateParameters(cmd, parameters);
                IDataReader reader = null;
                reader = _db.ExecuteReader(cmd);
                var doc = new FileImport();
                while (reader.Read())
                {
                    doc = new FileImport();
                    doc.RowId = Convert.ToInt32(reader["RowId"]);
                    doc.ProjectId = Convert.ToInt32(reader["PROJECT_ID"]);
                    doc.FileId = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    doc.FileName = Convert.ToString(reader["FILE_NM"]);
                    doc.ContentType = Convert.ToString(reader["CONTENT_TYPE"]);
                    doc.Description = Convert.ToString(reader["FILE_DESC"]);
                    //doc.FileData = (byte[])reader["DATA"];
                    doc.UID = Convert.ToInt32(reader["FILE_ID_SQ"]);
                    docs.Add(doc);
                }
                reader.Close();
                return docs;
            }
        }
        public int DeleteDocument(FileImport doc)
        {
            if (doc == null) throw new ArgumentNullException("doc");
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                parameters.Add("Project_ID", doc.ProjectId);
                parameters.Add("FILE_ID", doc.FileId);
                using (IDbCommand cmd = _db.CreateCommand("DeleteProjectDocument_sp"))
                {
                    _db.CreateParameters(cmd, parameters);
                    var result = _db.ExecuteNonQuery(cmd);
                    return result;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
            finally
            {

            }
        }


        public string UploadFiles(List<FileImport> Files, string DeleteIDs, int projectID, string UserID)
        {
            foreach (FileImport file in Files)
            {
                using (IDbCommand cmd = _db.CreateCommand("[Insert_Update_Project_Document_sp]"))
                {
                    IDataReader rdr = null;
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("@proc_vr_ProjectID", projectID);
                    parameters.Add("proc_xml_doe_file", file.getData());
                    parameters.Add("proc_vr_FileName", file.FileName);
                    parameters.Add("proc_vr_Description", file.Description);
                    parameters.Add("proc_vr_content_Type", file.ContentType);
                    parameters.Add("proc_id_File_ID", file.UID);
                    parameters.Add("CREATED_BY_USER_ID", UserID);
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                }
            }
            if (!String.IsNullOrEmpty(DeleteIDs)&& DeleteIDs.Split(',').Length > 0)
            {
                using (IDbCommand cmd = _db.CreateCommand("[Delete_Project_Documents_sp]"))
                {
                    IDataReader rdr = null;
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("proc_vr_ProjectID", projectID);
                    parameters.Add("proc_ary_DeleteIDs", DeleteIDs);
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                }
            }
            return "Uploaded";
        }
    }

    public class NPDProjectRepository : ProjectRepository
    {
        private IDatabase _db;
        public NPDProjectRepository(IDatabase dbInstance) : base(dbInstance)
        {
            _db = dbInstance;
        }
        public override int SaveProject(ProjectModel project)
        {
            NPDProjectModel npdModel = project as NPDProjectModel;
           
            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                string xmlData = Serializer.ConvertToXML<FileImport>(npdModel.ProjectFiles);
                parameters.Add("@proc_var_proj_id_sq", npdModel.ProjectId);                
                parameters.Add("@proc_var_proj_cd", string.IsNullOrEmpty(npdModel.AccoladeProjectCd) ? (object)null : npdModel.AccoladeProjectCd);
                parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(npdModel.ProjectName) ? (object)null : npdModel.ProjectName);
                parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(npdModel.Description) ? (object)null : npdModel.Description);
                parameters.Add("@proc_var_current_phase_nm_cd", string.IsNullOrEmpty(npdModel.CurrentPhaseNameCd) ? (object)null : npdModel.CurrentPhaseNameCd);
                parameters.Add("@proc_var_current_phase_prio_cd", string.IsNullOrEmpty(npdModel.CurrentPhasePriorityCd) ? (object)null : npdModel.CurrentPhasePriorityCd); 
                //if (string.IsNullOrEmpty(npdModel.CurrentPhaseNameCd))
                //{
                //    parameters.Add("@proc_var_current_phase_nm_cd",  DBNull.Value );                
                //}
                //else {
                //    parameters.Add("@proc_var_current_phase_nm_cd", npdModel.CurrentPhaseNameCd);
                //}
                parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(npdModel.NetworkNumber1) ? (object)null : npdModel.NetworkNumber1);
                parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(npdModel.NetworkNumber2) ? (object)null : npdModel.NetworkNumber2);
                parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(npdModel.NetworkNumber3) ? (object)null : npdModel.NetworkNumber3);
                parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(npdModel.TechnicalTeamLead) ? (object)null : npdModel.TechnicalTeamLead);                
                parameters.Add("@proc_var_proj_Type_cd", "NPD");
                parameters.Add("@proc_var_uop_seg_id", npdModel.UOPSegmentId );
                
                parameters.Add("@proc_var_pte", (npdModel.PTEPerc <= 0) ? 0 : npdModel.PTEPerc);
                parameters.Add("@proc_var_cas", (npdModel.CASPerc <= 0) ? 0 : npdModel.CASPerc);                
                parameters.Add("@proc_var_proj_status", npdModel.StatusCd);
                parameters.Add("@proc_var_application_id", DBNull.Value);
                parameters.Add("@proc_var_sfdc", DBNull.Value);
                parameters.Add("@proc_var_business_just_cd", DBNull.Value);
                parameters.Add("@proc_var_business_obj_cd", DBNull.Value);                
                parameters.Add("@proc_var_business_group_cd", DBNull.Value);
                parameters.Add("@proc_var_dw_project_Id", (npdModel.DwProjectId==0) ? (object)null : npdModel.DwProjectId);                
                parameters.Add("@proc_var_pp_priority_Cd", string.IsNullOrEmpty(npdModel.PPPriorityCd) ? (object)null : npdModel.PPPriorityCd);           
                parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);                                
                parameters.Add("@proc_var_User", UserSession.Instance.User.EID);
                parameters.Add("@proc_var_gate2", string.IsNullOrEmpty(npdModel.Gate2) ? (object)null : Convert.ToDateTime(npdModel.Gate2).ToString("MM/dd/yyyy"));
                parameters.Add("@proc_var_gate3", string.IsNullOrEmpty(npdModel.Gate3) ? (object)null : Convert.ToDateTime(npdModel.Gate3).ToString("MM/dd/yyyy"));
                parameters.Add("@proc_var_gate4", string.IsNullOrEmpty(npdModel.Gate4) ? (object)null : Convert.ToDateTime(npdModel.Gate4).ToString("MM/dd/yyyy"));
                parameters.Add("@proc_var_gate5", string.IsNullOrEmpty(npdModel.Gate5) ? (object)null : Convert.ToDateTime(npdModel.Gate5).ToString("MM/dd/yyyy"));
                parameters.Add("@proc_var_gate6", string.IsNullOrEmpty(npdModel.Gate6) ? (object)null : Convert.ToDateTime(npdModel.Gate6).ToString("MM/dd/yyyy"));
                parameters.Add("@INPUT_FILE_XML", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);

                IDataReader rdr = null;
                using (IDbCommand cmd = _db.CreateCommand("Insert_Update_Project"))
                {
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                    if (rdr.Read())
                    {                       
                            return Convert.ToInt32(rdr["PROJECT_ID"]);                       
                    }
                    else
                    {
                        return -1;
                    }

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);                
                throw;
            }

            
        }

        public override List<ProjectModel> SearchProjectDetails(ProjectModel project)
        {
            try
            {
                NPDProjectModel npdModel = project as NPDProjectModel;
                List<ProjectModel> npdProjectList = new List<ProjectModel>();

                #region setting up DBCommand with parameters

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("Search_Project_Details"))
                {
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("@proc_var_proj_cd", string.IsNullOrEmpty(npdModel.AccoladeProjectCd) ? (object)null : npdModel.AccoladeProjectCd);
                    parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(npdModel.ProjectName) ? (object)null : npdModel.ProjectName);
                    parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(npdModel.Description) ? (object)null : npdModel.Description);
                    parameters.Add("@proc_var_current_phase_nm_cd", npdModel.CurrentPhaseNameCd == "0" ? (object)null : npdModel.CurrentPhaseNameCd);
                    parameters.Add("@proc_var_current_phase_prio_cd", npdModel.CurrentPhasePriorityCd == "0" ? (object)null : npdModel.CurrentPhasePriorityCd);
                    parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(npdModel.NetworkNumber1) ? (object)null : npdModel.NetworkNumber1);
                    parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(npdModel.NetworkNumber2) ? (object)null : npdModel.NetworkNumber2);
                    parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(npdModel.NetworkNumber3) ? (object)null : npdModel.NetworkNumber3);
                    parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(npdModel.TechnicalTeamLead) ? (object)null : npdModel.TechnicalTeamLead);
                    parameters.Add("@proc_var_proj_Type_Cd", "NPD");
                    parameters.Add("@proc_var_uop_seg_id", npdModel.UOPSegmentId == 0 ? (object)null : npdModel.UOPSegmentId);
                    parameters.Add("@proc_var_pte", npdModel.PTEPerc == -1 ? (object)null : npdModel.PTEPerc);
                    parameters.Add("@proc_var_cas", npdModel.CASPerc == -1 ? (object)null : npdModel.CASPerc);
                    parameters.Add("@proc_var_proj_status", npdModel.StatusCd == "0" ? (object)null : npdModel.StatusCd);

                    parameters.Add("@proc_var_pp_priority_Cd", npdModel.PPPriorityCd == "0" ? (object)null : npdModel.PPPriorityCd);
                    parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);
                    //parameters.Add("@proc_var_User", UserSession.Instance.User.EID);
                    parameters.Add("@proc_var_gate2", string.IsNullOrEmpty(npdModel.Gate2) ? (object)null : npdModel.Gate2);
                    parameters.Add("@proc_var_gate3", string.IsNullOrEmpty(npdModel.Gate3) ? (object)null : npdModel.Gate3);
                    parameters.Add("@proc_var_gate4", string.IsNullOrEmpty(npdModel.Gate4) ? (object)null : npdModel.Gate4);
                    parameters.Add("@proc_var_gate5", string.IsNullOrEmpty(npdModel.Gate5) ? (object)null : npdModel.Gate5);
                    parameters.Add("@proc_var_gate6", string.IsNullOrEmpty(npdModel.Gate6) ? (object)null : npdModel.Gate6);

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        NPDProjectModel accProj = new NPDProjectModel
                        {
                            ProjectId = Convert.ToInt32(objSqlDr["PROJECT_ID_SQ"]),
                            AccoladeProjectCd = Convert.ToString(objSqlDr["PROJECT_CD"]),
                            ProjectName = Convert.ToString(objSqlDr["PROJECT_NM"]),
                            Description = Convert.ToString(objSqlDr["PROJECT_DESC"]),
                            CurrentPhaseNameCd = Convert.ToString(objSqlDr["CURRENT_PHASE_NM_CD"]),
                            CurrentPhaseName = Convert.ToString(objSqlDr["PROJECT_CURRENT_PHASE_NAME"]),
                            CurrentPhasePriorityCd = Convert.ToString(objSqlDr["CURRENT_PHASE_PRIORITY_CD"]),
                            CurrentPhasePriorityName = Convert.ToString(objSqlDr["CURRENT_PHASE_PRIORITY_NM"]),
                            NetworkNumber1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                            NetworkNumber2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                            NetworkNumber3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                            TechnicalTeamLead = Convert.ToString(objSqlDr["TECH_LEAD"]),
                            ProjectTypeId = Convert.ToInt32(objSqlDr["PROJECT_TYPE_ID"]),
                            UOPSegmentId = (objSqlDr["UOP_SEGMENT_ID"] == DBNull.Value) ? (int?)null : Convert.ToInt32(objSqlDr["UOP_SEGMENT_ID"]),
                            UOPSegmentName = Convert.ToString(objSqlDr["UOP_SEGMENT_NM"]),
                            PTEPerc = (objSqlDr["PTE_PERCNT"] == DBNull.Value) ? -1 : Convert.ToDouble(objSqlDr["PTE_PERCNT"]),
                            // PTEPerc = Convert.ToDouble(objSqlDr["PTE_PERCNT"]),
                            //CASPerc = Convert.ToDouble(objSqlDr["CAS_PERCNT"]),
                            CASPerc = (objSqlDr["CAS_PERCNT"] == DBNull.Value) ? -1 : Convert.ToDouble(objSqlDr["CAS_PERCNT"]),
                            DwProjectId = (objSqlDr["DW_PROJECT_ID"] == DBNull.Value) ? (int?)null : Convert.ToInt32(objSqlDr["DW_PROJECT_ID"]),
                            StatusCd = Convert.ToString(objSqlDr["PROJECT_STATUS_CD"]),
                            StatusName = Convert.ToString(objSqlDr["PROJECT_STATUS_NM"]),
                            PPPriorityCd = Convert.ToString(objSqlDr["PP_PRIORITY_CD"]),
                            PPPriorityName = Convert.ToString(objSqlDr["PP_PRIORITY_NM"]),
                            Gate2 = ((objSqlDr["2"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["2"]).ToString("MM/dd/yyyy")),
                            Gate3 = ((objSqlDr["3"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["3"]).ToString("MM/dd/yyyy")),
                            Gate4 = ((objSqlDr["4"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["4"]).ToString("MM/dd/yyyy")),
                            Gate5 = ((objSqlDr["5"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["5"]).ToString("MM/dd/yyyy")),
                            Gate6 = ((objSqlDr["6"] == DBNull.Value) ? null : Convert.ToDateTime(objSqlDr["6"]).ToString("MM/dd/yyyy")),
                        };
                        npdProjectList.Add(accProj);
                    }
                }
                return npdProjectList;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        
        
    }

    public class CapabilityProjectRepository: ProjectRepository
    {
        private IDatabase _db;
        public CapabilityProjectRepository(IDatabase dbInstance) : base(dbInstance)
        {
            _db = dbInstance;
        }
        public override int SaveProject(ProjectModel project)
        {
            CapabilityProjectModel capModel = project as CapabilityProjectModel;

            try
            {
                IDictionary parameters = new Dictionary<string, object>();
               
                string xmlData = Serializer.ConvertToXML<FileImport>(capModel.ProjectFiles);
                parameters.Add("@proc_var_proj_id_sq", capModel.ProjectId);
                parameters.Add("@proc_var_proj_cd", string.IsNullOrEmpty(capModel.AccoladeProjectCd) ? (object)null : capModel.AccoladeProjectCd);
                parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(capModel.ProjectName) ? (object)null : capModel.ProjectName);
                parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(capModel.Description) ? (object)null : capModel.Description);
                //parameters.Add("@proc_var_current_phase_nm_cd", string.IsNullOrEmpty(capModel.CurrentPhaseNameCd) ? (object)null : capModel.CurrentPhaseNameCd);
                parameters.Add("@proc_var_current_phase_prio_cd", string.IsNullOrEmpty(capModel.CurrentPhasePriorityCd) ? (object)null : capModel.CurrentPhasePriorityCd);
               
                parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(capModel.NetworkNumber1) ? (object)null : capModel.NetworkNumber1);
                parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(capModel.NetworkNumber2) ? (object)null : capModel.NetworkNumber2);
                parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(capModel.NetworkNumber3) ? (object)null : capModel.NetworkNumber3);
                parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(capModel.TechnicalTeamLead) ? (object)null : capModel.TechnicalTeamLead);
                
                parameters.Add("@proc_var_proj_Type_cd", "CAPEX");
                parameters.Add("@proc_var_uop_seg_id", capModel.UOPSegmentId);

                parameters.Add("@proc_var_pte", (capModel.PTEPerc <= 0) ? 0 : capModel.PTEPerc);
                parameters.Add("@proc_var_cas", (capModel.CASPerc <= 0) ? 0 : capModel.CASPerc);
                parameters.Add("@proc_var_proj_status", capModel.StatusCd);
                parameters.Add("@proc_var_application_id", DBNull.Value);
                parameters.Add("@proc_var_sfdc", DBNull.Value);
                parameters.Add("@proc_var_business_just_cd", DBNull.Value);
                parameters.Add("@proc_var_business_obj_cd", DBNull.Value);
                parameters.Add("@proc_var_business_group_cd", DBNull.Value);
                parameters.Add("@proc_var_dw_project_Id", (capModel.DwProjectId == 0) ? (object)null : capModel.DwProjectId);
                parameters.Add("@proc_var_pp_priority_Cd", string.IsNullOrEmpty(capModel.PPPriorityCd) ? (object)null : capModel.PPPriorityCd);
                parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);
                parameters.Add("@proc_var_User", UserSession.Instance.User.EID);
                parameters.Add("@INPUT_FILE_XML", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                IDataReader rdr = null;
                using (IDbCommand cmd = _db.CreateCommand("Insert_Update_Project"))
                {
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                    if (rdr.Read())
                    {
                        return Convert.ToInt32(rdr["PROJECT_ID"]);
                    }
                    else
                    {
                        return -1;
                    }

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }


        }

        public override List<ProjectModel> SearchProjectDetails(ProjectModel project)
        {
            try
            {
                CapabilityProjectModel capModel = project as CapabilityProjectModel;
                List<ProjectModel> npdProjectList = new List<ProjectModel>();

                #region setting up DBCommand with parameters

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("Search_Project_Details"))
                {
                    IDictionary parameters = new Dictionary<string, object>();

                    parameters.Add("@proc_var_proj_cd", string.IsNullOrEmpty(capModel.AccoladeProjectCd) ? (object)null : capModel.AccoladeProjectCd);
                    parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(capModel.ProjectName) ? (object)null : capModel.ProjectName);
                    parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(capModel.Description) ? (object)null : capModel.Description);                   
                    parameters.Add("@proc_var_current_phase_prio_cd", capModel.CurrentPhasePriorityCd == "0" ? (object)null : capModel.CurrentPhasePriorityCd);
                    parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(capModel.NetworkNumber1) ? (object)null : capModel.NetworkNumber1);
                    parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(capModel.NetworkNumber2) ? (object)null : capModel.NetworkNumber2);
                    parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(capModel.NetworkNumber3) ? (object)null : capModel.NetworkNumber3);
                    parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(capModel.TechnicalTeamLead) ? (object)null : capModel.TechnicalTeamLead);
                    parameters.Add("@proc_var_proj_Type_Cd", "CAPEX");
                    parameters.Add("@proc_var_uop_seg_id", capModel.UOPSegmentId == 0 ? (object)null : capModel.UOPSegmentId);
                    parameters.Add("@proc_var_pte", capModel.PTEPerc == -1 ? (object)null : capModel.PTEPerc);
                    parameters.Add("@proc_var_cas", capModel.CASPerc == -1 ? (object)null : capModel.CASPerc);
                    parameters.Add("@proc_var_proj_status", capModel.StatusCd == "0" ? (object)null : capModel.StatusCd);

                    parameters.Add("@proc_var_pp_priority_Cd", capModel.PPPriorityCd == "0" ? (object)null : capModel.PPPriorityCd);
                    parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);                   
                    

                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        CapabilityProjectModel accProj = new CapabilityProjectModel
                        {
                            ProjectId = Convert.ToInt32(objSqlDr["PROJECT_ID_SQ"]),
                            AccoladeProjectCd = Convert.ToString(objSqlDr["PROJECT_CD"]),
                            ProjectName = Convert.ToString(objSqlDr["PROJECT_NM"]),
                            Description = Convert.ToString(objSqlDr["PROJECT_DESC"]),                            
                            CurrentPhasePriorityCd = Convert.ToString(objSqlDr["CURRENT_PHASE_PRIORITY_CD"]),
                            CurrentPhasePriorityName = Convert.ToString(objSqlDr["CURRENT_PHASE_PRIORITY_NM"]),
                            NetworkNumber1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                            NetworkNumber2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                            NetworkNumber3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                            TechnicalTeamLead = Convert.ToString(objSqlDr["TECH_LEAD"]),
                            ProjectTypeId = Convert.ToInt32(objSqlDr["PROJECT_TYPE_ID"]),
                            UOPSegmentId = (objSqlDr["UOP_SEGMENT_ID"] == DBNull.Value) ? (int?)null : Convert.ToInt32(objSqlDr["UOP_SEGMENT_ID"]),
                            PTEPerc = (objSqlDr["PTE_PERCNT"] == DBNull.Value) ? -1 : Convert.ToDouble(objSqlDr["PTE_PERCNT"]),
                            // PTEPerc = Convert.ToDouble(objSqlDr["PTE_PERCNT"]),
                            //CASPerc = Convert.ToDouble(objSqlDr["CAS_PERCNT"]),
                            CASPerc = (objSqlDr["CAS_PERCNT"] == DBNull.Value) ? -1 : Convert.ToDouble(objSqlDr["CAS_PERCNT"]),
                            DwProjectId = (objSqlDr["DW_PROJECT_ID"] == DBNull.Value) ? (int?)null : Convert.ToInt32(objSqlDr["DW_PROJECT_ID"]),
                            StatusCd = Convert.ToString(objSqlDr["PROJECT_STATUS_CD"]),
                            StatusName = Convert.ToString(objSqlDr["PROJECT_STATUS_NM"]),
                            PPPriorityCd = Convert.ToString(objSqlDr["PP_PRIORITY_CD"]),
                            PPPriorityName = Convert.ToString(objSqlDr["PP_PRIORITY_NM"]),                            
                        };
                        npdProjectList.Add(accProj);
                    }
                }
                return npdProjectList;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

    }

    public class CustomerProjectRepository : ProjectRepository
    {
        private IDatabase _db;
        public CustomerProjectRepository(IDatabase dbInstance) : base(dbInstance)
        {
            _db = dbInstance;
        }
        public override int SaveProject(ProjectModel project)
        {
            CustomerProjectModel cusModel = project as CustomerProjectModel;

            try
            {
                IDictionary parameters = new Dictionary<string, object>();
                string xmlData = Serializer.ConvertToXML<FileImport>(cusModel.ProjectFiles);
                parameters.Add("@proc_var_proj_id_sq", cusModel.ProjectId);
                parameters.Add("@proc_var_proj_cd", DBNull.Value);
                parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(cusModel.ProjectName) ? (object)null : cusModel.ProjectName);
                parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(cusModel.Description) ? (object)null : cusModel.Description);
                parameters.Add("@proc_var_current_phase_nm_cd", DBNull.Value);
                parameters.Add("@proc_var_current_phase_prio_cd", DBNull.Value);
                
                parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(cusModel.NetworkNumber1) ? (object)null : cusModel.NetworkNumber1);
                parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(cusModel.NetworkNumber2) ? (object)null : cusModel.NetworkNumber2);
                parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(cusModel.NetworkNumber3) ? (object)null : cusModel.NetworkNumber3);
                parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(cusModel.TechnicalTeamLead) ? (object)null : cusModel.TechnicalTeamLead);
                parameters.Add("@proc_var_proj_Type_cd", "CUSTMAN");
                parameters.Add("@proc_var_uop_seg_id", DBNull.Value);

                parameters.Add("@proc_var_pte",  0 );
                parameters.Add("@proc_var_cas",  0 );
                parameters.Add("@proc_var_proj_status", cusModel.StatusCd);
                parameters.Add("@proc_var_application_id", string.IsNullOrEmpty(cusModel.ApplicationCd) ? (object)null : cusModel.ApplicationCd);
                parameters.Add("@proc_var_sfdc", string.IsNullOrEmpty(cusModel.SFDC) ? (object)null : cusModel.SFDC);
                parameters.Add("@proc_var_business_just_cd", cusModel.BusinessJustificationCd == "0" ? (object)null : cusModel.BusinessJustificationCd);
                parameters.Add("@proc_var_business_obj_cd", string.IsNullOrEmpty(cusModel.BusinessObjectiveCd) ? (object)null : cusModel.BusinessObjectiveCd);
                parameters.Add("@proc_var_business_group_cd", string.IsNullOrEmpty(cusModel.BusinessGroupCd) ? (object)null : cusModel.BusinessGroupCd);
                parameters.Add("@proc_var_dw_project_Id", DBNull.Value);
                parameters.Add("@proc_var_pp_priority_Cd", string.IsNullOrEmpty(cusModel.PPPriorityCd) ? (object)null : cusModel.PPPriorityCd);
                parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);
                parameters.Add("@proc_var_User", UserSession.Instance.User.EID);
                parameters.Add("@INPUT_FILE_XML", string.IsNullOrEmpty(xmlData) ? (object)null : xmlData);
                IDataReader rdr = null;
                using (IDbCommand cmd = _db.CreateCommand("Insert_Update_Project"))
                {
                    _db.CreateParameters(cmd, parameters);
                    rdr = _db.ExecuteReader(cmd);
                    if (rdr.Read())
                    {
                        return Convert.ToInt32(rdr["PROJECT_ID"]);
                    }
                    else
                    {
                        return -1;
                    }

                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }


        }

        public override List<ProjectModel> SearchProjectDetails(ProjectModel project)
        {
            try
            {
                CustomerProjectModel cusModel = project as CustomerProjectModel;
                List<ProjectModel> npdProjectList = new List<ProjectModel>();

                #region setting up DBCommand with parameters

                IDataReader objSqlDr = null;
                using (IDbCommand command = _db.CreateCommand("Search_Project_Details"))
                {
                    IDictionary parameters = new Dictionary<string, object>();

                    
                    parameters.Add("@proc_var_proj_nm", string.IsNullOrEmpty(cusModel.ProjectName) ? (object)null : cusModel.ProjectName);
                    parameters.Add("@proc_var_proj_desc", string.IsNullOrEmpty(cusModel.Description) ? (object)null : cusModel.Description);                    
                    parameters.Add("@proc_var_network_number1", string.IsNullOrEmpty(cusModel.NetworkNumber1) ? (object)null : cusModel.NetworkNumber1);
                    parameters.Add("@proc_var_network_number2", string.IsNullOrEmpty(cusModel.NetworkNumber2) ? (object)null : cusModel.NetworkNumber2);
                    parameters.Add("@proc_var_network_number3", string.IsNullOrEmpty(cusModel.NetworkNumber3) ? (object)null : cusModel.NetworkNumber3);
                    parameters.Add("@proc_var_proj_Tech_Lead", string.IsNullOrEmpty(cusModel.TechnicalTeamLead) ? (object)null : cusModel.TechnicalTeamLead);
                    parameters.Add("@proc_var_proj_Type_Cd", "CUSTMAN");                    
                    parameters.Add("@proc_var_proj_status", cusModel.StatusCd == "0" ? (object)null : cusModel.StatusCd);
                    parameters.Add("@proc_var_pp_priority_Cd", cusModel.PPPriorityCd == "0" ? (object)null : cusModel.PPPriorityCd);
                    parameters.Add("@proc_var_src_system_Id", ApplicationSettings.AppId);                    
                    parameters.Add("@proc_var_application_id", cusModel.ApplicationCd == "0" ? (object)null : cusModel.ApplicationCd);
                    parameters.Add("@proc_var_sfdc", string.IsNullOrEmpty(cusModel.SFDC) ? (object)null : cusModel.SFDC);
                    parameters.Add("@proc_var_business_just_cd", cusModel.BusinessJustificationCd == "0" ? (object)null : cusModel.BusinessJustificationCd);
                    parameters.Add("@proc_var_business_obj_cd", cusModel.BusinessObjectiveCd == "0" ? (object)null : cusModel.BusinessObjectiveCd);
                    parameters.Add("@proc_var_business_group_cd", cusModel.BusinessGroupCd == "0" ? (object)null : cusModel.BusinessGroupCd);



                    _db.CreateParameters(command, parameters);
                    objSqlDr = _db.ExecuteReader(command);
                    while (objSqlDr.Read())
                    {

                        CustomerProjectModel accProj = new CustomerProjectModel
                        {
                            ProjectId = Convert.ToInt32(objSqlDr["PROJECT_ID_SQ"]),
                         
                            ProjectName = Convert.ToString(objSqlDr["PROJECT_NM"]),
                            Description = Convert.ToString(objSqlDr["PROJECT_DESC"]),                         
                            NetworkNumber1 = Convert.ToString(objSqlDr["UOP_NW_NUM1"]),
                            NetworkNumber2 = Convert.ToString(objSqlDr["UOP_NW_NUM2"]),
                            NetworkNumber3 = Convert.ToString(objSqlDr["UOP_NW_NUM3"]),
                            TechnicalTeamLead = Convert.ToString(objSqlDr["TECH_LEAD"]),
                            ProjectTypeId = Convert.ToInt32(objSqlDr["PROJECT_TYPE_ID"]),                        
                            StatusCd = Convert.ToString(objSqlDr["PROJECT_STATUS_CD"]),
                            StatusName = Convert.ToString(objSqlDr["PROJECT_STATUS_NM"]),
                            PPPriorityCd = Convert.ToString(objSqlDr["PP_PRIORITY_CD"]),
                            PPPriorityName = Convert.ToString(objSqlDr["PP_PRIORITY_NM"]),
                            BusinessGroupCd = Convert.ToString(objSqlDr["BUS_GROUP_CD"]),
                            BusinessGroupName=Convert.ToString(objSqlDr["BUSINESS_GROUP_NM"]),
                            BusinessJustificationCd = String.IsNullOrEmpty(Convert.ToString(objSqlDr["BUS_JSTY_CD"]))?"0": Convert.ToString(objSqlDr["BUS_JSTY_CD"]),
                            BusinessObjectiveCd = Convert.ToString(objSqlDr["BUS_OBJT_CD"]),
                            ApplicationCd = Convert.ToString(objSqlDr["APPLICATION_ID"]),
                            SFDC = Convert.ToString(objSqlDr["SFDC"]),
                            


                        };
                        npdProjectList.Add(accProj);
                    }
                }
                return npdProjectList;

                #endregion
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

    }
}
