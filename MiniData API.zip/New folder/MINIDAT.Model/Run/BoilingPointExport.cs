﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class BoilingPointExport
    {
        public double? InitialBoilingPoint { get; set; }
        public double? EndBoilingPoint { get; set; }
        public string YieldCutLabel { get; set; }
        public string InitialBoilingPointUOM { get; set; }
        public string EndBoilingPointUOM { get; set; }
    }
}
