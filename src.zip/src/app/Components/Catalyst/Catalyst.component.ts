﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { CatalystService } from '../../Services/CatalystServices/Catalyst.service';
import { LIMSResultService } from '../../Services/CatalystServices/limscomponent.service';
import { CatalystMasterDataModel, CatalystModel, CatalystFamily, CatalystAlias, CatalystShape } from '../../models/Catalyst/CatalystModel';
import { messageModalUtility } from '../../Shared/message-modal.utility';
import * as Constants from '../../Shared/globalconstants';
import { AlertMessage } from '../../services/alertmessage.service';
import { HttpActionService } from '../../services/httpaction.service';
import { AppComponent } from '../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../Directives/uomcontrol.component';
import { KeyValue } from '../../Models/KeyValue';
import { ActivatedRoute } from '@angular/router';
@Component({
    //moduleId: module.id,
    templateUrl: 'Catalyst.component.html',
    providers: [CatalystService, AlertMessage, HttpActionService, ConfirmationService, LIMSResultService]
})

export class CatalystComponent implements OnInit {

    selectedRow: CatalystModel;
    public catalyst: CatalystModel;
    public catalysts: CatalystModel[];
    public catalystMasterData: CatalystMasterDataModel;

    public myDatepicker: any;
    public bsConfig: any;
    public catalystAlias: CatalystAlias[];
    public catalystShapes: CatalystShape[];
    //addIconPath = Constants.addIcon;
    //uploadIconPath = Constants.uploadIcon;
    //downloadIconPath = Constants.downloadIcon;
    //detailsIconPathEn = Constants.detailsIconEn;
    //detailsIconPathDis = Constants.detailsIconDis;
    //deleteIconPathEn = Constants.deleteIconEn;
    //deleteIconPathDis = Constants.deleteIconDis;

    catSaved: string = "Catalyst Details Saved Successfully.";
    catDeleted: string = "Catalyst Deleted Successfully.";
    canEdit: boolean = false;
    check: boolean = false;
    FamilyListColumns: KeyValue[];
    LeaderListColumns: KeyValue[];
    displayViewLims: boolean = false;
    analysisMethods: any = [];
    limsValidations: any;
    limsToggle: boolean = true;
    sub: any;
    catalystId: any;
    title: string = "CREATE OR FIND CATALYST";
    constructor(private catalystService: CatalystService, private route: ActivatedRoute, private alertMessage: AlertMessage, private messageService: messageModalUtility, private limsComponentService: LIMSResultService) {
        this.bsConfig = "{ containerClass: 'theme-dark-blue' }";

    }

    private reset() {

        this.catalyst = new CatalystModel();
        this.catalyst.ActiveInd = "0";
        this.catalyst.AnalyticalStatusCd = "0";
        this.catalyst.AnalyticalStatusName = "Sample ID Not Found";
        this.catalyst.AnalyticalStatusNameTemp = "Sample ID Not Found";
        this.catalyst.ApparentBedDensity = null;

        this.catalyst.CatalystAliasId = 0;
        this.catalyst.CatalystAliasName = "";
        this.catalyst.CatalystDescription = "";
        this.catalyst.CatalystDesignation = "";
        this.catalyst.CatalystFamilyId = 0;
        this.catalyst.CatalystFamilyName = "";
        this.catalyst.CatalystId = 0;
        this.catalyst.CatalystLeaderCd = "";
        this.catalyst.CatalystLeaderName = "";
        this.catalyst.CatalystPieceDensity = null;
        this.catalyst.CatalystScaleId = 0;
        this.catalyst.CatalystScaleName = "";
        this.catalyst.CatalystShapeId = 0;
        this.catalyst.CatalystShapeName = "";
        this.catalyst.CatalystSizeId = 0;
        this.catalyst.CatalystSizeName = "";
        this.catalyst.CatalystStateId = 0;
        this.catalyst.CatalystStateName = "";
        this.catalyst.CatalystTypeId = 0;
        this.catalyst.CatalystTypeName = "";

        this.catalyst.VibratedBedDensity = null;
        this.catalyst.LOIAt500Msr = null;
        this.catalyst.ReferenceCatalystInd = false;
        this.catalyst.RegenCatalystInd = false
        this.catalyst.BulkLocationInd = false;
        this.catalyst.GroundInd = false;
        this.catalyst.AnalyticalApproveInd = false;
        this.catalyst.LIMSs = [];
        this.searchCatalyst(true);
        this.displayViewLims = false;
        this.analysisMethods = [];
        this.limsValidations = [];
        this.limsToggle = true;

        //this.catalystService.gettest()
        //    .subscribe(
        //    (data: any) => {

        //        debugger;
        //    });
    }

    ngOnInit() {
        debugger;
        this.sub = this.route.params.subscribe(params => {
            this.catalystId = params['catalystId'];
            if (this.catalystId != undefined) {
            this.catalystId= this.catalystId.replace(/\$/gi, " ");
                
            }
        });
        this.reset();
        this.catalystMasterData = new CatalystMasterDataModel();
        this.catalystMasterData.CatalystAlias = [];
        this.catalystMasterData.CatalystFamilys = [];
        this.catalystMasterData.CatalystLeaders = [];
        this.catalystMasterData.CatalystScale = [];
        this.catalystMasterData.CatalystShapes = [];
        this.catalystMasterData.CatalystSizes = [];
        this.catalystMasterData.CatalystState = [];
        this.catalystMasterData.CatalystTypes = [];
        this.getCatalystMasterList();
        this.fillFlyoutColumns();
        this.find();
    }
    //TODO
    ngDoCheck() {

        if (!this.check) {
            if (Constants.UserSessionData != Constants.Undefined) {
                if (Constants.UserPrivileges.length > 1) {
                    for (let i in Constants.UserPrivileges) {
                        if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000014" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                            this.canEdit = true;
                            this.check = true;
                        }
                    }

                }
            }
        }
    }
    getCatalystMasterList() {

        this.catalystService.GetCatalystDetails()
            .subscribe(
                (data: any) => {

                    this.catalystMasterData = data;

                });
    }



    validateCatalyst() {
        if (this.catalyst) {
            var message = "";
            if (!this.catalyst.CatalystDesignation) {
                if (message) message = message + " \n";
                message = message + "ID/Designation is required.";
            }

            if (!this.catalyst.CatalystFamilyName) {
                if (message) message = message + " \n";
                message = message + "Catalyst FamilyName is required.";
            }


            if (this.catalyst.CatalystTypeId == 0) {
                if (message) message = message + " \n";
                message = message + "Catalyst Type is required.";
            }
            if (this.catalyst.CatalystShapeId == 0) {
                if (message) message = message + " \n";
                message = message + "Catalyst Shape is required.";
            }
            if (this.catalyst.CatalystSizeId == 0) {
                if (message) message = message + " \n";
                message = message + "Catalyst Size is required.";
            }
            if (this.catalyst.CatalystStateId == 0) {
                if (message) message = message + " \n";
                message = message + "Catalyst State is required.";
            }
            if (!this.catalyst.CatalystLeaderName) {
                if (message) message = message + " \n";
                message = message + "Catalyst Leader is required.";
            }
            if (this.catalyst.CatalystScaleId == 0) {
                if (message) message = message + " \n";
                message = message + "Catalyst Scale is required.";
            }
            //debugger;
            //if (!this.catalyst.VibratedBedDensity) {
            //    if (message) message = message + " \n";
            //    message = message + "Catalyst Vibrated Bed Density is required.";
            //}
            //if (!this.catalyst.CatalystPieceDensity) {
            //    if (message) message = message + " \n";
            //    message = message + "Catalyst Piece Density is required.";
            //}
            //if (!this.catalyst.LOIAt500Msr) {
            //    if (message) message = message + " \n";
            //    message = message + "Catalyst LOI @ 500C is required.";
            //}

            //if (!this.catalyst.CatalystDescription) {
            //    if (message) message = message + " \n";
            //    message = message + "Catalyst Description is required.";
            //}
            if (message) {
                this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: message })
                return false;
            }
            else {
                return true;
            }
        } else {

            return false;
        }
    }
    saveCatalyst() {
        // debugger;
        if (this.validateCatalyst()) {
            this.catalystService.SaveCatalystDetails(this.catalyst)
                .subscribe(
                    (data: any) => {
                        // debugger;
                        //this.reset();
                        this.catalyst.CatalystId = data;
                        this.searchCatalyst(true);
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Save Catalyst', detail: this.catSaved });
                    });
        }
    }

    find() {
        if (this.catalystId != undefined) {
            this.catalyst.CatalystDesignation = this.catalystId;
            this.searchCatalyst(false);
        }
        else {
            this.searchCatalyst(false);
        }
    }
    searchCatalyst(isInit: boolean) {
        this.catalyst.IsInitialLoad = isInit;
        this.catalystService.SearchCatalystDetails(this.catalyst).subscribe((data: any) => {
            this.catalysts = data;

        });


    }
    onRowSelect(event) {

        if (this.selectedRow) {
            this.catalyst = this.selectedRow;
            this.catalystService.GetCatalystSampleIds(this.catalyst.CatalystId.toString())
                .subscribe(
                    (data: any) => {
                        this.catalyst.LIMSs = data;
                    });
        }
    }

    onRowUnselect($event: any) {

    }

    onDelete(catalyst: CatalystModel) {

        if (catalyst && catalyst.CatalystId > 0) {
            this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
                result = result == Constants.ConfirmTrue; //casting string to boolean
                if (result) { this.deleteCatalyst(catalyst); }
            });
        }

    }


    deleteCatalyst(catalyst: CatalystModel) {

        this.catalystService.DeleteCatalyst(catalyst.CatalystId.toString())
            .subscribe(
                (data: any) => {
                    this.reset();
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Delete Catalyst', detail: this.catDeleted });
                });

    }


    updateFamilySelection(event, condition) {
        debugger;

        this.catalyst.CatalystFamilyId = event.CatalystFamilyId;
        this.catalyst.CatalystFamilyName = event.CatalystFamilyName;
        this.catalyst.CatalystTypeId = event.CatalystTypeId;
    }
    updateCatalystLeaderSelection(event, condition) {
        this.catalyst.CatalystLeaderCd = event.Key;
        this.catalyst.CatalystLeaderName = event.Value;
    }
    fillFlyoutColumns() {
        debugger;

        this.FamilyListColumns = [];

        //this.FamilyListColumns.push({ Key: "CatalystFamilyId", Value: "Catalyst Family ID" });
        this.FamilyListColumns.push({ Key: "CatalystFamilyName", Value: "Catalyst Family Name" });

        this.LeaderListColumns = [];
        this.LeaderListColumns.push({ Key: "Key", Value: "Leader EID" });
        this.LeaderListColumns.push({ Key: "Value", Value: "Leader Full Name" });


    }

    getLIMSSampleIDs() {
        this.catalystService.GetLimsSampleIdsByUserSample(this.catalyst.CatalystDesignation, this.catalyst.CatalystId.toString())
            .subscribe(
                (data: any) => {
                    if (this.catalyst.LIMSs.length == 0) {
                        this.catalyst.LIMSs = data;
                    }
                    else if (this.catalyst.LIMSs.length > 0) {
                        debugger;
                        //chk if any sample already exists if yes just ignore
                        data.forEach(s => {
                            var sample = this.catalyst.LIMSs.filter(
                                alias => alias.SampleId === s.SampleId);

                            if (sample.length == 0) {
                                this.catalyst.LIMSs.push(s);
                            }
                        })


                    }
                });
    }

    onChipAdd(event) {
        debugger;
        this.catalyst.LIMSs.pop();
        var splitted_Space = event.value.split(" ");
        var splitted_Coma = event.value.split(",");
        if (splitted_Space.length > 0 || splitted_Coma.length > 0) {
            if (splitted_Space.length > splitted_Coma.length) {
                splitted_Space.forEach(s => {
                    this.catalyst.LIMSs.push({ CatalystId: 0, SampleId: s });
                });
            }
            else {
                splitted_Coma.forEach(s => {
                    this.catalyst.LIMSs.push({ CatalystId: 0, SampleId: s });
                });
            }
        }
        else {
            this.catalyst.LIMSs.push({ CatalystId: 0, SampleId: event.value });
        }
    }
    onChipRemove(originalEvent) {

    }
    OnAliasChanged(event) {

        if (parseInt(event) == 0) {
            this.catalyst.CatalystShapeId = 0;
            this.catalyst.CatalystSizeId = 0;
            //this.catalyst.CatalystAliasId = 0;
        }
        if (parseInt(event) > 0) {
            this.catalystAlias = this.catalystMasterData.CatalystAlias.filter(
                alias => alias.CatalystAliasId === parseInt(event));
            if (this.catalystAlias && this.catalystAlias.length > 0) {
                this.catalyst.CatalystShapeId = this.catalystAlias[0].CatalystShapeId;
                this.catalyst.CatalystSizeId = this.catalystAlias[0].CatalystSizeInd;
                //this.catalyst.CatalystAliasId = this.catalystAlias[0].CatalystAliasId;

            }
        }
    }

    shapeChanged(shapeid) {

        if (parseInt(shapeid) == 0) {
            //this.catalyst.CatalystShapeId = 0;
            //this.catalyst.CatalystSizeId = 0;
            this.catalyst.CatalystAliasId = 0;
        }
        if (parseInt(shapeid) > 0 && this.catalyst.CatalystSizeId > 0) {
            this.catalystAlias = this.catalystMasterData.CatalystAlias.filter(
                alias => alias.CatalystShapeId == parseInt(shapeid) && alias.CatalystSizeInd == this.catalyst.CatalystSizeId);
            if (this.catalystAlias && this.catalystAlias.length > 0) {
                //this.catalyst.CatalystShapeId = this.catalystAlias[0].CatalystShapeId;
                //this.catalyst.CatalystSizeId = this.catalystAlias[0].CatalystSizeInd;
                this.catalyst.CatalystAliasId = this.catalystAlias[0].CatalystAliasId;
            }
            else {
                this.catalyst.CatalystAliasId = 0;
            }
        }
    }
    OnSizeChanged(event) {

        if (parseInt(event) == 0) {
            //this.catalyst.CatalystShapeId = 0;
            //this.catalyst.CatalystSizeId = 0;
            this.catalyst.CatalystAliasId = 0;
        }
        if (parseInt(event) > 0 && this.catalyst.CatalystShapeId > 0) {
            this.catalystAlias = this.catalystMasterData.CatalystAlias.filter(
                alias => alias.CatalystSizeInd == parseInt(event) && alias.CatalystShapeId == this.catalyst.CatalystShapeId);
            if (this.catalystAlias && this.catalystAlias.length > 0) {
                //this.catalyst.CatalystShapeId = this.catalystAlias[0].CatalystShapeId;
                //this.catalyst.CatalystSizeId = this.catalystAlias[0].CatalystSizeInd;
                this.catalyst.CatalystAliasId = this.catalystAlias[0].CatalystAliasId;
            }
            else {
                this.catalyst.CatalystAliasId = 0;
            }
        }
    }
    onReset() {
        this.reset();
    }
    OnViewLims() {
        if (this.catalyst && this.catalyst.CatalystId && this.catalyst.CatalystId > 0 && this.catalyst.LIMSs && this.catalyst.LIMSs.filter(x => x.SampleId != undefined && x.SampleId != null && x.SampleId.trim() != '').length > 0) {
            this.limsComponentService.GetViewLimsMaster(this.catalyst.CatalystId)
                .subscribe(
                    (data: any) => {
                        debugger;
                        this.analysisMethods = [];
                        this.analysisMethods = data.AnalysisMethods;
                        this.limsValidations = data.Validations;
                        if (this.analysisMethods.length > 0) {
                            this.displayViewLims = true;
                        }
                        else {
                            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: "Please verify Sample ID (or) kindly try again after 30 Seconds" })
                        }
                    },
                    err => { }
                    //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: "Please insert Sample ID's to View Results" })
        }
    }

    onExitLims(event: any) {
        this.displayViewLims = false;
    }
    handleAnalyticalStatusChange(e) {

        if (this.catalyst.CatalystId > 0) {

            if (e.checked) {
                this.catalyst.AnalyticalStatusNameTemp = this.catalyst.AnalyticalStatusName;
                this.catalyst.AnalyticalStatusName = "Good/Approved";
            }
            else {
                this.catalyst.AnalyticalStatusName = this.catalyst.AnalyticalStatusNameTemp;
            }
        }
    }

    OnShapeChanged(event, item) {
        if (parseInt(event) == 0) {
            this.catalyst.CatalystSizeId = 0
            this.catalyst.CatalystAliasId = 0;
            this.catalyst.CatalystVoidFraction = null;
            this.catalyst.CatalystVoidFractionCrushed = null;
        }
        if (parseInt(event) > 0) {
            this.shapeChanged(event);
            this.catalystShapes = this.catalystMasterData.CatalystShapes.filter(
                shape => shape.CatalystShapeId === parseInt(event));
            if (this.catalystShapes && this.catalystShapes.length > 0) {
                this.catalyst.CatalystVoidFraction = this.catalystShapes[0].CatalystVoidFraction;
                this.catalyst.CatalystVoidFractionCrushed = this.catalystShapes[0].CatalystVoidFractionCrushed;
            }
        }
    }
}
