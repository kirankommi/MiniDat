﻿using MINIDAT.Model.DataViewerModel;
using System;
using System.Collections.Generic;

namespace MINIDAT.DataAccess.Interfaces
{
   public interface IDataViewerRepository
    {
        IEnumerable<dynamic> getDataForDataViewer(string Plant, string Run, string Category, string User_Id);
    }
}
