import { Component, OnInit, ViewChild, ElementRef, Renderer } from '@angular/core';
import { RoleService } from '../../../Services/Role.service';
import { RoleModel, KeyValue } from '../../../models/RoleModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    templateUrl: 'Role.component.html',
    providers: [RoleService, AlertMessage, HttpActionService, ConfirmationService]
})

export class RoleComponent implements OnInit {
    title: string;
    RoleList: any;
    totalRecords: number;
    applicationList: any;
    RoleData: RoleModel;
    statuses: KeyValue[];
    sortField: string;
    sortOrder: number;
    IsallowedSave: boolean=false; 
    selectedApplicationCode: string;
    setStyles: boolean;
    isCollapsed = false;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    IsallowedChange: boolean = true;
    roleSaved: string = "Role Details Saved Successfully";
    roleDeleted: string = "Role Deleted Successfully";

    @ViewChild('roleTable') dataTableComponent: any;

    constructor(private roleService: RoleService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    ngOnInit() {
        this.RoleData = new RoleModel();        
        this.getRoles();
        this.RoleData.StatusName = Constants.Select;
        this.title = Constants.ManageRole;
    }


    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divRole > p-datatable > div > div.ui-datatable-scrollable-body');
            let parentDiv = this.el.nativeElement.querySelector('#roleGrid');
            if (datatable != null && datatable != Constants.Undefined && parentDiv != null && parentDiv != Constants.Undefined && parentDiv.offsetHeight > 0) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';   // (parentDiv.offsetHeight * 80 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse() {
        let parentDiv = this.el.nativeElement.querySelector('#roleGrid');
        let datatable = this.el.nativeElement.querySelector('#divRole > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';   // (parentDiv.offsetHeight * 80 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any) {
        this.RoleData.StatusName = event.data.StatusCode.Key;
        this.RoleData.RoleName = event.data.RoleName;
        this.RoleData.RoleDescription = event.data.RoleDescription;
        this.RoleData.RoleCode = event.data.RoleCode;
    }

    onRowUnselect($event: any) {

    }

    getRoles() {
        debugger;
        this.roleService.getRoles(this.RoleData)
            .subscribe(
            (data: any) => {
                this.RoleList = data.Roles;
                this.statuses = data.Status;
                this.totalRecords = data.RecordsFetched;

                this.applicationList = data.ApplicationList;

                if (data.ApplicationList.length > 0) {
                    this.selectedApplicationCode = data.ApplicationList[0].ApplicationId;
                }
                else {
                    this.selectedApplicationCode = "5";
                }


                this.sortField = (data.Roles != null && data.Roles.length > 0) ? data.Roles[0].SortColumn : "";
                this.sortOrder = (data.Roles != null && data.Roles.length > 0) ? data.Roles[0].SortOrder : "";
            },
            err =>{}
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onAppchange()
    {
        //
    }

    saveRole() {
        let response: any;
        if (this.isDataValid()) {
            debugger;
            this.RoleData.StatusCode = this.statuses.filter(x => x.Key == this.RoleData.StatusName)[0];
            this.RoleData.AppCode = this.selectedApplicationCode;
            this.roleService.saveRoleData(this.RoleData)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success)
                    {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.roleSaved });
                        this.appComponent.GetUserData();
                    }
                    else {
                        this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(roleData: RoleModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteRole(roleData);}
        });
    }

    deleteRole(roleData: RoleModel) {
        roleData.AppCode = this.selectedApplicationCode;

        this.roleService.deleteRoleData(roleData)
            .subscribe(
            (data: any) => {
                if (data == "Delete") {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.roleDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onReset() {
        this.RoleData = new RoleModel();
        this.RoleData.StatusName = Constants.Select;
        this.sortField = "";
        this.sortOrder = 0;
        this.getRoles();
        this.dataTableComponent.reset();
        this.selectedApplicationCode = "3";
    }

    isDataValid() {
        if (this.RoleData == null || !this.RoleData.RoleName || !this.RoleData.StatusName || this.RoleData.StatusName == "Select") {
            return false;
        }
        return true;
    }

    getDelPath(CanDelete: string)
    {
        debugger;
        //if (roleCode === 'ROL_1' || roleCode === 'ROL_2' || roleCode === 'ROL_3' || roleCode === 'ROL_4' || roleCode === 'ROL_5' || roleCode === 'ROL_6') 
        if (!this.IsallowedSave ||CanDelete === 'N')
        {
            debugger;
            return this.disabledDeleteIconPath;
        }
        else
        {
            return this.deleteIconPath;
        }
       
    }

    ngDoCheck() {
        if (Constants.UserPrivileges.length > 1) {
            for (let i in Constants.UserPrivileges)
            {                
                if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "MANAGE/ROLE" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE")
                {
                    debugger;
                    this.IsallowedSave = true;
                }
            }
        }
    }
    
}
