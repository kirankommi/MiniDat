﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{    
    public class RunCatalyst
    {
        public Int32 CatalystIdSQ { get; set; }
        public string CatalystId { get; set; }
        public string CatalystFamilyName { get; set; }
        public string CatalystShape { get; set; }
        public string CatalystSize { get; set; }
        public string Crushed { get; set; }
        public string CatalystDescription { get; set; }      
        public double? CustomBedDensity { get; set; }
        public double? VibratedBedDensity { get; set; }
        public double? CalculatedBedDensity { get; set; }
        public double? Voidfraction { get; set; }
        public double? PieceDensity { get; set; }       
        public KeyValue LoadingDensityType { get; set; }
        public string LoadingDensityTypeName { get; set; }

    }  

    public class RunCatalystSearchModel
    {      
        private IList<RunCatalyst> _lstCatalysts = new List<RunCatalyst>();
        public IList<RunCatalyst> LstCatalysts { get { return _lstCatalysts; } }

        private IList<BedDetails> _lstbeds = new List<BedDetails>();
        public IList<BedDetails> LstBeds { get { return _lstbeds; } }

        public bool ISDirty { get; set; }

    }

    public class BedDetails
    {
        
        public int BedId { get; set; }
        public string CatalystId { get; set; }     
        public int? BedNumber { get; set; }
        public double? CatalystVolume { get; set; }
        public int Split { get; set; }
        public string DiluentDesignation { get; set; }
        public double? DiluentVolume { get; set; }   

    }
}

