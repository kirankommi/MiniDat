﻿import { FeedInfo } from '../NIRModelTemplateModel';
export class RunModel {
    public ID: number;
    public Plant: string;
    public RunNum: number;
    public RunId: string;
    public PlantLocation: string;
    public StartDate: string;
    public EndDate: string;
    public ZeroHOSTime: string;
    public RunDescription: string;
    public Status: string;
    public ModeType: string;
    public ModeId: string;
    public NIRModelID: string;
    public HighTgtConversion: number;
    public LowTgtConversion: number;
    public RecipeMaster: any;
    public DOERun: number;
    public lstNIRSpec: NIRModel[];
    public lstProcessSpec: ProcessSpecModel[];
    public lstAnalyticalSamples: AnalyticalInfoModel[];
    public lstRunCutBoilingPoints: BoilingPointModel[];
    public FeedInfo: FeedModel;
    public GeneralInfo: GeneralInfoModel;
    public Recipe: any;
    public RunModedata: RunModeData;
    public NIRTemp: any=[];
    //public CatalystInfo: RunCatalystSearchModel;   
    public PopUpSummary: ExportPopupSummary; 

    public Cataysts: RunCatalyst[];
    public Beds: BedDetails[];

    public AdditionalInfo: AdditionalInfoModel;
    public lstTC_Calibrations: TC_Calibration[];
    public lstTMF_Calibrations: TMF_Calibration[];

    public selectedPopupList: KeyValue[];

    // *******************  Master Data**************************//
    public lstStreams: KeyValue[];
    public LstAnalysisMethods: KeyValue[];
    public LstLoadingDensiyTypes: KeyValue[];
    public LstNormalizationFactors: KeyValue[];
    public LstFeedSource: KeyValue[];
    public LstStdBoilingPoints: BoilingPointModel[];
    public LstStreams: KeyValue[];
    public LstFrequency: KeyValue[];
    public RunFeedId: string;
    public FeedDensity: number;
    public CatalystVolume: number;
    public FeedISCOTemp: number;

    public lstDoeCataystinfo: any[];
    public FeedUOP: string;
    public FeedAnalyticalDensity: number;
    public ModeLHSV: number;
    public ModeSCFB: number;
    public ModePressure: number;
    public SulfidingType: number;
    public lstFlyoutFeeds: FeedInfo[];
}
export class FeedModel {

    UOPNumber: string;
    Name: string;
    API: number;
    Density: number;
    RelativeDensity: number;
    H2InFeed: number;
    SulfurInSweetFeed: number;
    NitrogenInSweetFeed: number;
    SulfurInFeedBlend: number;
    NitrogenInFeedBlend: number;
    Blendcomponents: FeedBlend[];
    AnalysisMethods: AnalysisMethod[];
    FeedId: string;
    FeedID: string;
    StatusCode: KeyValue;
    StatusName: string;
    TotalBlendWeight: number;
    TotalBlendWeightpct: number;
    ISDirty: boolean;
    DopantStoichiometry: StoichiometryModel[];

}
export class KeyValue {
    Key: string;
    Value: string;
    Groupcd: number;
}
export class GeneralInfoModel {
    public ModeType: string;
    public FeedCondition: string;
    public NetworkNumber: string;
    public projectMgr: string;
    public Technician1: string;
    public Technician2: string;
    public Technician1EID: string;
    public Technician2EID: string;
    public ISDirty: boolean;
    public RunDescription: string;

}
export class RunCatalystSearchModel {
    public ISDirty: boolean;
    public LstCatalysts: RunCatalyst[];
    public LstBeds: BedDetails[];
}
export class RunMasterDataModel {
    public Technicians: KeyValue[];
    public lstStreams: KeyValue[];
    public LstAnalysisMethods: KeyValue[];
    public LstLoadingDensiyTypes: KeyValue[];
    public LstNormalizationFactors: KeyValue[];
    public LstFeedSource: KeyValue[];
}
export class FeedBlend {
    ComponentId: string;
    ComponentName: string;
    Amountadded: number;
    //Component: string;
    Weightpct: number;
    UOPNumber: string;
}
export class AnalysisMethod {
    AnalysisMethodId: number;
    AnalysisMethodName: string;
    AnalysisMethodNum: string;
    SourceName: string;
    AnalyticalComponents: MethodComponent[];
}
export class MethodComponent {
    ComponentName: string;
    ComponentAverageValue: number;
    UOM: string;
}
export class NIRModel {
    ParameterId: number;
    Parameter: string;
    Value: number;
    ParameterUOM: string;
    DefaultUnit: string;
    NIRModelID: string;  //Explicit Propetry for NIR Model ID Since it May be some time a String
    ValueText: string;

}
export class ProcessSpecModel
{   
    ParameterId: number;
    ParameterName: string;
    Value: number;
    Range:number
    ParameterUOM: string;
    RecordSet: string;
    IsEditable: boolean;
    IsModeVariable: boolean;
    DisplayOrder: number;
    ValueText: string;
    //selectedMethod: string;
    //methodName: string;   
}
export class BoilingPointModel {
    public RowId: number;
    public InitialBoilingPoint: number;
    public EndBoilingPoint: number;
    public YieldCutLabel: string;
    public BoilingPointType: string;
}
export class AnalyticalInfoModel {
    public RowId: number;
    public StreamName: string;
    public StreamId: number;
    public LIMSOPerationId: number;
    public LIMSOPerationName: string;
    public MethodNumber: string;
    public SampleVolumeinCC: string;
    public SampleCost: string;
    public FrequencyName: string;
    public DataSetType: string;
}
export class RunCatalyst {
    public CatalystIdSQ: number;
    public CatalystId: string;
    public CatalystFamilyName: string;
    public CatalystShape: string;
    public CatalystSize: string;
    public Crushed: string;
    public CatalystDescription: string;
    public Voidfraction: number;
    public PieceDensity: number;
    public CustomBedDensity: number;
    public VibratedBedDensity: string;
    public LoadingDensityTypeName: string;
    public CalculatedBedDensity: number;
    public ISDirty: boolean;

}
export class BedDetails {
    BedId: number;
    CatalystID: string;
    BedNumber: number;
    CatalystVolume: number;
    Split: number;
    DiluentDesignation: string;
    DiluentVolume: number;
}
export class AdditionalInfoModel {
    OffgasHeaviesWeight: number;
    SelectedNormalizationFactor: string;
    SelectedFeedSource: string;
    H2TMFSpec: number;
    PlantTCOffset: number;
    HPSControllerOffset: number;
    ISDirty: boolean;
}
export class TC_Calibration {
    ParameterName: string;
    Value: number;
    ParameterUOM: string;
    DefaultUnit: string;
    ParameterType: string;
    OffSetNum: number;
    //CalibrationchangeDate: string  
    CalibrationDate: Date;
}
export class TMF_Calibration {
    Parameter: string;
    Value: any;
    ParameterUOM: string;
    DefaultUnit: string;
    ISDirty: boolean;
}
export class RunModeData {
    Condition: number;
    Pressure: number;
    LHSV: number;
    SCFB: number;
    RunId: number;
    ModeNo: string;
    ModeId: number;
    WeightChecks: number;
    Sort: number;
    SulfidingType: number;
    ControlMethod: number;
}

export class ExportPopupSummary{
    public isGeneralInfo : boolean;
    public isBoilingPoint : boolean;
    public isCatalyst : boolean;
    public isFeed : boolean;
    public isAnalyticalSample : boolean;
    public isNIRSpecs : boolean;
    public isTMS : boolean;
    public isProcessSpec:boolean;
    public isAdditionalInfo : boolean;
    public isTCCaliration : boolean;
    public isRecipe : boolean;
}

export class StoichiometryModel {
    COMPONENT_NAME: string;
    COMP_MASS_H2S_COMP_MSR: number;
    COMP_MASS_SN_COMP_MSR: number;
    //Component: string;
    DOPANT_TYPE: string;
    FEED_ADJUSTMNT_FACTOR_MSR: number;


}
export class MetaData{
    public ID: number;
    public Plant: string;
    public RunNum: number;
    public RunId: string;
    public PlantLocation: string;
    public StartDate: string;
    public EndDate: string;
    public ZeroHOSTime: string;
    public RunDescription: string;
    public RunStatus: string;
    public ModeType: string;
    public ModeId: string;
    public NIRModelID: string;
    public HighTgtConversion: number;
    public LowTgtConversion: number;
    public DOERun: number;
    public RunFeedId: string;
    public FeedDensity: number;
    public CatalystVolume: number;
    public FeedISCOTemp: number;
    public FeedUOP: string;
    public FeedAnalyticalDensity: number;
    public ModeLHSV: number;
    public ModeSCFB: number;
    public ModePressure: number;
    public SulfidingType: number;
    public lstDoeCataystinfo: any[];
}