﻿/* 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                            COPYRIGHT (c) 2016
                                                              HONEYWELL INC.,
                                                            ALL RIGHTS RESERVED

         This software is a copyrighted work and/or information protected as a trade secret.Legal rights of Honeywell Inc. in this software is distinct from 
         ownership of any medium in which the software is embodied. Copyright or trade secret notices included must be reproduced in any copies authorized by 
         Honeywell Inc. The information in this software is subject to change without notice and should not be considered as a commitment by Honeywell Inc.


                                                File Name				:	UserController.cs
                                                Project Title			:	FDMS
                                                Author(s)				:	H185477
                                                Created Date			:	17 May 2017
                                                Requirements Tag		:	Manage Module
                                                Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

//using MINIDAT.BusinessLogic.ValidationLogic;
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Search;
using MINIDAT.Models.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Xml;

namespace MINIDAT.WebAPI.Controllers
{
    public class UserController : AppController
    {
        private string serverBasePath = string.Empty;
        private string currentUserName = string.Empty;
        public UserController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage User" }));
            serverBasePath = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
            currentUserName = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
        }
        IUserRepository _userFactory = new UserRepository(new MINIDATDatabase());
        [HttpGet, ActionName("SearchUserData")]
        public UserSearchModel GetData([FromUri] UserModel userFilter)
        {
            try
            {
                //   _userFactory.Add(userFilter);
                AppUserCriteria _usrCriteria = new AppUserCriteria();
                var usersrModel = _userFactory.GetUserData(userFilter, _usrCriteria);
                var adminIds = new List<string>();
                foreach (var user in usersrModel.Users)
                {
                    if (user.StatusCode != null && user.StatusCode.Key == "UACT" && user.RoleCode != null && user.RoleCode.Value.Contains("Administrator"))
                    {
                        adminIds.Add(user.EmailId);
                    }
                }
                return usersrModel;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        [HttpPost, HttpOptions, ActionName("SaveUserData")]
        public HttpResponseMessage Post([FromBody] UserModel userFilter)
        {
            if (Request.Method.Method == "POST" && userFilter != null)
            {
                try
                {
                    UserValidationLogic userValidation = new UserValidationLogic();
                    ValidationResult result = userFilter.Validate(userValidation);
                    string roleXMl = CreateMenuXML(userFilter);

                    if (userFilter.ValidationResult.IsValid)
                    {
                        _userFactory.SaveUserData(userFilter, roleXMl, currentUserName, serverBasePath: serverBasePath);
                    }
                    else
                    {

                    }
                    SetSession(true);
                }
                catch (SqlException ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                }
                catch
                {
                    throw;
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
            //return msg;
        }

        private string CreateMenuXML(UserModel root)
        {
            //intialize the xml writer
            using (System.IO.StringWriter writer = new System.IO.StringWriter())
            {
                XmlWriter xmlWriter = XmlWriter.Create(writer);
                //check the root node of menu
                if (root != null)
                {
                    //write the xml document
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("UserRoleItems");
                    WriteMenuElement(xmlWriter, root);
                    xmlWriter.WriteFullEndElement();//RoleMenuItems
                    xmlWriter.Flush();
                }
                return writer.ToString();
            }
        }
        private void WriteMenuElement(XmlWriter xmlWriter, UserModel node)
        {
            //node is selected

            if (node.UserRoleDetails != null)
            {
                foreach (UserModel child in node.UserRoleDetails)
                {
                    // WriteMenuElement(xmlWriter, child);
                    xmlWriter.WriteStartElement("RoleItem");

                    //write Id
                    xmlWriter.WriteStartElement("ApplicationId");
                    xmlWriter.WriteValue(child.ApplicationId);
                    xmlWriter.WriteFullEndElement();//end Id 

                    //write RoleCode
                    xmlWriter.WriteStartElement("RoleCode");
                    xmlWriter.WriteValue(child.RoleName);
                    xmlWriter.WriteFullEndElement();//end RoleCode 

                    xmlWriter.WriteFullEndElement();//Menu Item
                }
            }
        }

        [HttpPost, HttpOptions, ActionName("DeleteUserData")]
        public HttpResponseMessage Delete([FromBody] UserModel userFilter)
        {
            if (Request.Method.Method == "POST" && userFilter != null)
            {
                try
                {
                    var some = _userFactory.DeleteUser(userFilter, User.Identity.Name);
                    SetSession(true);
                    // var some = new UserDataAccess().DeleteUser(userFilter, User.Identity.Name);
                    return Request.CreateResponse(HttpStatusCode.OK, some);
                }
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    return Request.CreateResponse(HttpStatusCode.OK, ex.Message);
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");
        }

        #region New User Email Notification

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2200:RethrowToPreserveStackDetails")]
        [HttpGet, ActionName("SendNewUserNotificationToAdmins"), AllowAnonymous]
        public HttpResponseMessage SendNewUserNotificationToAdmins([FromUri]UserModel user)
        {
            try
            {
                HttpResponseMessage res = null;
                if (user == null || string.IsNullOrEmpty(user.EmailId) || string.IsNullOrEmpty(user.EID))
                {
                    res = Request.CreateResponse(HttpStatusCode.BadRequest, "User cannot be null !");
                    return res;
                }
                _userFactory.SendNewUserNotificationToAdmins(user, serverBasePath: serverBasePath);
                res = Request.CreateResponse(HttpStatusCode.OK);
                return res;
            }
            catch (Exception e)
            {
                LogManager.Error(e);
                throw;
            }
        }

        #endregion
    }
    public class ModelValidationLogic : IValidationLogic<ModelBase>
    {
        public void Validate(ModelBase obj)
        {

        }
    }

    public class UserValidationLogic : IValidationLogic<ModelBase>
    {
        public void Validate(ModelBase objBase)
        {
            UserModel objUser = objBase as UserModel;
            objUser.ValidationResult = new ValidationResult();
            objUser.ValidationResult.IsValid = true;

            if (string.IsNullOrEmpty(objUser.EID))
            {
                objUser.ValidationResult.IsValid = false;
                objUser.ValidationResult.Message.AppendWithNewLine("Employee ID is mandatory");
            }
            if (string.IsNullOrEmpty(objUser.FirstName))
            {
                objUser.ValidationResult.IsValid = false;
                objUser.ValidationResult.Message.AppendWithNewLine("First Name is mandatory");
            }
            if (string.IsNullOrEmpty(objUser.EmailId))
            {
                objUser.ValidationResult.IsValid = false;
                objUser.ValidationResult.Message.AppendWithNewLine("Email ID is mandatory");
            }
        }
    }

    public static class ExtensionMethods
    {
        public static StringBuilder AppendWithNewLine(this StringBuilder value, string obj)
        {
            if (obj == null) throw new ArgumentNullException("obj");
            if (value != null)
            {
                if (value.Length == 0)
                {
                    return value.Append(obj.ToString());
                }
                else
                {

                    return value.Append("\n" + obj.ToString());
                }
            }
            return value;
        }
    }
}
