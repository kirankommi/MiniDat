import { Component, OnInit } from '@angular/core';
import { uploadHandler } from '../../../Directives/filebrowse/filebrowse.component';
import { Observable } from "rxjs";
import { FileModel } from '../../../Models/file.model';
import { ProjectService } from '../../../Services/ProjectServices/project.service';
@Component({
  selector: 'app-createproject',
  templateUrl: './createproject.component.html',
  styleUrls: ['./createproject.component.css']
})
export class CreateProjectComponent implements OnInit {
    searchBy: any = "npd";
    phandler: uploadHandler;    
    files: FileModel[] = [];
    constructor(private projectService: ProjectService) {
      
        this.projectService.GetAllDocuments()
            .subscribe(
            (data: any) => {
                
                this.files = data;
            });
    }

  ngOnInit() {
      this.phandler = new uploadHandler();
      this.phandler.downloadFile = this.onDownload.bind(this);     
  }

  onDownload(file: any): Observable<any> {
    return this.projectService.DownLoadProjectDocuments(file.FileId.toString());     
  }
  
  onSearchBy(by: string)
  {
      this.searchBy = by;
      this.projectService.GetAllDocuments()
          .subscribe(
          (data: any) => {

              this.files = data;
          });
  }
}
