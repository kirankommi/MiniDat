﻿using MINIDAT.Model.Manage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IRoleRepository: ICRUDRepository<RoleModel>
    {
        RoleSearchModel GetRoleData(RoleModel Role);
        string DeleteRoleData(RoleModel Role);
        void SaveRoleData(RoleModel Role, string userId);
        Dictionary<string, string> GetRoleDetailsForTechService();
    }
}
