﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { HttpActionService } from './httpaction.service';
import { AnalysisMethodModel } from '../Models/AnalysisMethodModel';
//import Constants = require('../Shared/globalconstants');
import * as Constants from '../Shared/globalconstants';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class AnalysisMethodService {
    private getMethod = "/LIMSAnalysisMethod/GetLIMSAnalysisMethodData/";
    private saveMethod = "/LIMSAnalysisMethod/SaveLIMSAnalysisMethodData/";
    private deleteMethod = "/LIMSAnalysisMethod/DeleteMethodData/";
    private getBySourceUrl = "/LIMSAnalysisMethod/getallbysource";
    private getLimsSourcesUrl = "/LIMSAnalysisMethod/GetLimsSources";
    constructor(private http: Http, private httpaction: HttpActionService) { }

    private handleError(error: any): Promise<any> {
        // console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    getMethods(methodData: AnalysisMethodModel) {
        return this.modifyUser(methodData, this.getMethod);
       // let params: URLSearchParams = new URLSearchParams();
       // 
       // params.set('MethodName', methodData.MethodName);
       // params.set('MethodNumber', methodData.MethodNumber);
       // params.set('LIMSOperation', methodData.LIMSOperation);
       // params.set('MethodDescription', methodData.MethodDescription);
       // params.set('Sources', methodData.CheckedSources);
       //// params.set('UOMSearch', methodData.UOMGroup.Key);
       

       // let options = new RequestOptions(Constants.getParamOptions(params));
       // return this.http.get(Constants.apiBaseUrl + this.getMethod, options)
       //     .map((res: Response) => res.json())
       //     .catch(this.handleError);
    }

    modifyUser(methodData: AnalysisMethodModel, actionUrl: string) {
        let options = new RequestOptions(Constants.options);
        
        return this.http.post(Constants.apiBaseUrl + actionUrl, methodData, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }

    saveMethodData(methodData: AnalysisMethodModel) {
       // return this.modifyUser(methodData, this.saveMethod);
        return this.httpaction.post(methodData, this.saveMethod);
    }

    deleteMethodData(methodData: AnalysisMethodModel) {
        return this.modifyUser(methodData, this.deleteMethod);
    }
    getBySource(source: string, feedIds: Array<number>) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('source', source);
        params.set('feedIds', JSON.stringify(feedIds)); 
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.httpaction.get(this.getBySourceUrl, options);
    }
    getLimsSources() {
        return this.httpaction.get(this.getLimsSourcesUrl, Constants.options);
    }
}

