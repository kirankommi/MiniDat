﻿import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { FeedService } from '../../Services/FeedServices/Feed.service';
import { FeedModel, KeyValue } from '../../models/Feed/CreateFeed';
import { messageModalUtility } from '../../Shared/message-modal.utility';
import * as Constants from '../../Shared/globalconstants';
import { AlertMessage } from '../../services/alertmessage.service';
import { HttpActionService } from '../../services/httpaction.service';
import { AppComponent } from '../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { UomControl } from '../../Directives/uomcontrol.component';
import { FlyoutExistsDataModel } from '../../Models/FlyoutExistsDataModel';

@Component(
    {  
    templateUrl: 'Feed.component.html',
    providers: [FeedService, AlertMessage, HttpActionService, ConfirmationService]
})

export class FeedComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;   
    defaultUnit: string;         
    @Input()   
    IsallowedSave: boolean=false;
    totalRecords: number;
    feed: FeedModel;   
    deleteIconPath: string;
    disabledDeleteIconPath: string; 
    isCollapsed = false;
    setStyles: boolean; 
    @ViewChild('roleTable') dataTableComponent: any;  
    pieceDensityUomObj: any = {};
    apparentBulkDensityUomObj: any = {};     
    savedFeedList: any;     
    Statuses: KeyValue[];
    sizes: KeyValue[];
    references: KeyValue[];
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    feedSaved: string = "Feed Details Saved Successfully";
    feedDeleted: string = "Feed Deleted Successfully";   
    LocalAccess: boolean = false; 
    check: boolean = false;
    sortField: string;
    sortOrder: number;   
    feedListCols: KeyValue[];
    lstFeedIDs: any = [];
    lstFeeds: any;
    lstParentFeeds: any;
    lstBledDopants: any;
    lstAnalysisMethods: any;
    blendList: any;
    blendTotalWeight: number;
    blendweightpct: number;
    weightedNitrogenAmt: number;
    weightedSufurAmt: number;
    parentFeedsWeight: number;  
    existingfeeds: FlyoutExistsDataModel;
    feedstockLink: string;
     
    public lstMappedFeeds: FeedModel[]; 

    constructor(private feedService: FeedService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService)
    {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath; 
        this.existingfeeds = new FlyoutExistsDataModel();
        this.existingfeeds.ExistsList = [];        
    }

    ngOnInit()
    {
        debugger;
        this.feed = new FeedModel();
        this.existingfeeds.ExistsList = [];
        this.feed.UOPNumber = null;
        this.feed.Name = null;
        this.feed.API = null;
        this.feed.FeedId = null;
        this.feed.Density = null;
        this.feed.Blendcomponents = [];
        this.getFeedsList();
        this.title = Constants.ManageFeed;
        this.fillFlyoutColumns();     
        this.feedstockLink = "http://ie3bvwitss320/FeedStockST/#/Search";
    }

    fillFlyoutColumns()
    {
        this.feedListCols = []
        this.feedListCols.push({ Key: "UOP", Value: "Feed UOP#", Groupcd: null });
        this.feedListCols.push({ Key: "BookNum", Value: "Book#", Groupcd: null });
        this.feedListCols.push({ Key: "FeedName", Value: "Feed Name", Groupcd: null });
        debugger;
        this.feedService.getFeedStockFeeds(this.feed)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.lstFeeds = data;
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );

    }
    updateFeedSelection(event, condition)
    {
        debugger;
        this.feed = new FeedModel();
        this.feed.UOPNumber = null;
        this.feed.Name = null;
        this.feed.API = null;
        this.feed.FeedId = null;
        this.feed.Blendcomponents = [];
        this.lstFeedIDs = [];

        this.feed.UOPNumber = event.UOP;
        this.feed.Name = event.FeedName;
        this.feed.FeedId = event.FeedID;  
        if (this.feed.StatusName == undefined || this.feed.StatusName == null)
        { this.feed.StatusName = Constants.Select; }
            
        debugger;
        this.lstFeedIDs.push(this.feed.FeedId);
        this.feedService.getFeedAnalyticalData(this.feed, this.lstFeedIDs)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.lstParentFeeds = data[0].parentChildFeeds.ParentFeeds;
                this.lstBledDopants = data[0].parentChildFeeds.FeedDopants;
                this.lstAnalysisMethods = data[0].AnalysisMethods;

                //if (data == Constants.Success)
                //{                  
                //    //this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.LoadingTemplateSaved });
                //    //this.appComponent.GetUserData();
                //}
                this.blendTotalWeight = 0;
                this.blendweightpct = 0;
                this.weightedNitrogenAmt = 0;
                this.weightedSufurAmt = 0;
                this.parentFeedsWeight = 0;

                debugger;
                if (this.lstParentFeeds != null && this.lstParentFeeds.length > 0)
                {
                    for (var i = 0; i < this.lstParentFeeds.length; i++)
                    {
                        debugger;
                        this.feed.Blendcomponents.push({ ComponentId: this.lstParentFeeds[i].ParentFeedId, ComponentName: this.lstParentFeeds[i].ParentFeedName, Amountadded: this.lstParentFeeds[i].AmountInGrams, Weightpct: this.lstParentFeeds[i].WeightPercent, UOPNumber: this.lstParentFeeds[i].ParentUOPNo });
                        this.blendTotalWeight = this.blendTotalWeight + (this.lstParentFeeds[i].AmountInGrams);
                        this.blendweightpct = this.blendweightpct + (this.lstParentFeeds[i].WeightPercent);
                        debugger;
                        if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null)
                        {
                            this.weightedNitrogenAmt = null;

                        }
                        else
                        {
                            this.weightedNitrogenAmt = this.weightedNitrogenAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED));
                        }
                         if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null)
                        {
                             this.weightedSufurAmt = null;

                        }
                        else
                        {
                             this.weightedSufurAmt = this.weightedSufurAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Sulfur_IN_SWEET_FEED));
                        }
                        //this.weightedNitrogenAmt = (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED);                       
                        this.parentFeedsWeight = this.parentFeedsWeight + this.lstParentFeeds[i].AmountInGrams;
                    }
                }
                debugger;
                if (this.lstBledDopants != null && this.lstBledDopants.length > 0) {
                    for (var i = 0; i < this.lstBledDopants.length; i++) {
                        debugger;
                        this.feed.Blendcomponents.push({ ComponentId: this.lstBledDopants[i].ParentFeedId, ComponentName: this.lstBledDopants[i].DopantType, Amountadded: this.lstBledDopants[i].WEIGHT_MSR, Weightpct: this.lstBledDopants[i].WEIGHT_PERCENTAGE, UOPNumber: this.lstBledDopants[i].DopantUOPNum });
                        this.blendTotalWeight = this.blendTotalWeight + (this.lstBledDopants[i].WEIGHT_MSR);
                        this.blendweightpct = this.blendweightpct + (this.lstBledDopants[i].WEIGHT_PERCENTAGE);
                    }
                }
                this.blendweightpct = Math.round(this.blendweightpct);               
                //this.units.filter((x: any) => x.DisplayText == this.uomObj.DefaultUnitName)[0]
                debugger;
                this.feed.API = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue);
                this.feed.RelativeDensity = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue);
                debugger;
                var length = this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0];
                this.feed.NitrogenInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0].ComponentAverageValue);
                this.feed.SulfurInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0].ComponentAverageValue);
                this.feed.H2InFeed = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0].ComponentAverageValue);
                debugger;
                this.feed.NitrogenInSweetFeed = (this.weightedNitrogenAmt == null ? null : (this.weightedNitrogenAmt / this.parentFeedsWeight));
                this.feed.SulfurInSweetFeed = (this.weightedSufurAmt == null ? null :  (this.weightedSufurAmt / this.parentFeedsWeight));  
            },
            err => { }
            );
        
    }
    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any)
    {
        debugger;
        this.feed.UOPNumber = event.data.UOPNumber;
        this.feed.Name = event.data.Name;
        this.feed.FeedId = event.data.FeedId;
        this.feed.StatusName = event.data.StatusCode.Key;
        this.feed.Density = event.data.Density;
        this.feed.Blendcomponents = [];
        this.lstFeedIDs = [];
        //this.feed.StatusName = event.data.StatusCode.Key;

        //************************************************************//
        this.lstFeedIDs.push(this.feed.FeedId);
        this.feedService.getFeedAnalyticalData(this.feed, this.lstFeedIDs)
            .subscribe(
            (data: any) => {
                debugger;
                this.lstParentFeeds = data[0].parentChildFeeds.ParentFeeds;
                this.lstBledDopants = data[0].parentChildFeeds.FeedDopants;
                this.lstAnalysisMethods = data[0].AnalysisMethods;

                //if (data == Constants.Success)
                //{                  
                //    //this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.LoadingTemplateSaved });
                //    //this.appComponent.GetUserData();
                //}
                this.blendTotalWeight = 0;
                this.blendweightpct = 0;
                this.weightedNitrogenAmt = 0;
                this.weightedSufurAmt = 0;
                this.parentFeedsWeight = 0;

                debugger;
                if (this.lstParentFeeds != null && this.lstParentFeeds.length > 0) {
                    for (var i = 0; i < this.lstParentFeeds.length; i++) {
                        debugger;
                        this.feed.Blendcomponents.push({ ComponentId: this.lstParentFeeds[i].ParentFeedId, ComponentName: this.lstParentFeeds[i].ParentFeedName, Amountadded: this.lstParentFeeds[i].AmountInGrams, Weightpct: this.lstParentFeeds[i].WeightPercent, UOPNumber: this.lstParentFeeds[i].ParentUOPNo });
                        this.blendTotalWeight = this.blendTotalWeight + (this.lstParentFeeds[i].AmountInGrams);
                        this.blendweightpct = this.blendweightpct + (this.lstParentFeeds[i].WeightPercent);
                        debugger;
                        //this.weightedNitrogenAmt = this.weightedNitrogenAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED));
                        //this.weightedSufurAmt = this.weightedSufurAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Sulfur_IN_SWEET_FEED));
                        if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null)
                        {
                            this.weightedNitrogenAmt = null;
                        }
                        else
                        {
                            this.weightedNitrogenAmt = this.weightedNitrogenAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED));
                        }
                        if (this.lstParentFeeds.length == 1 && this.lstParentFeeds[i].Nitrogen_IN_SWEET_FEED == null)
                        {
                            this.weightedSufurAmt = null;
                        }
                        else
                        {
                            this.weightedSufurAmt = this.weightedSufurAmt + (this.lstParentFeeds[i].AmountInGrams == null ? 0 : (this.lstParentFeeds[i].AmountInGrams * this.lstParentFeeds[i].Sulfur_IN_SWEET_FEED));
                        }
                        this.parentFeedsWeight = this.parentFeedsWeight + this.lstParentFeeds[i].AmountInGrams;
                    }
                }
                debugger;
                if (this.lstBledDopants != null && this.lstBledDopants.length > 0) {
                    for (var i = 0; i < this.lstBledDopants.length; i++) {
                        debugger;
                        this.feed.Blendcomponents.push({ ComponentId: this.lstBledDopants[i].ParentFeedId, ComponentName: this.lstBledDopants[i].DopantType, Amountadded: this.lstBledDopants[i].WEIGHT_MSR, Weightpct: this.lstBledDopants[i].WEIGHT_PERCENTAGE, UOPNumber: this.lstBledDopants[i].DopantUOPNum });
                        this.blendTotalWeight = this.blendTotalWeight + (this.lstBledDopants[i].WEIGHT_MSR);
                        this.blendweightpct = this.blendweightpct + (this.lstBledDopants[i].WEIGHT_PERCENTAGE);
                    }
                }
                this.blendweightpct = Math.round(this.blendweightpct);    
                //this.units.filter((x: any) => x.DisplayText == this.uomObj.DefaultUnitName)[0]
                debugger;
                this.feed.API = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue);
                this.feed.RelativeDensity = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue);
                debugger;
                var length = this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0];
                this.feed.NitrogenInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "NITROGEN D4629 LIQUID PPM")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Nitrogen")[0].ComponentAverageValue);
                this.feed.SulfurInFeedBlend = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "XRF SULFUR HYDROCARBON")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Sulfur")[0].ComponentAverageValue);
                this.feed.H2InFeed = (this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0] == undefined ? null : this.lstAnalysisMethods.filter((x: any) => x.AnalysisMethodName == "Hydrogen by NMR")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Hydrogen")[0].ComponentAverageValue);
                this.feed.NitrogenInSweetFeed = (this.weightedNitrogenAmt == null ? null : (this.weightedNitrogenAmt / this.parentFeedsWeight));
                this.feed.SulfurInSweetFeed = (this.weightedSufurAmt == null ? null :  (this.weightedSufurAmt / this.parentFeedsWeight));

            },
            err => { }
            );

        //*****************************************************************************//
      
    }

    onRowUnselect($event: any)
    {
        debugger;
        this.LocalAccess = false;
    }

    getFeedsList()
    {
        debugger;      
        this.lstFeedIDs = [];
        this.lstMappedFeeds = [];
        let uopNumber: string = null;
        let density: number = null;
        let status: string = null;
        let feedId: string = null;
        uopNumber = this.feed.UOPNumber;
        status = this.feed.StatusName;
        density = this.feed.Density;
        feedId = this.feed.FeedId;

        this.feed = new FeedModel();
        this.feedService.getFeedInformatin(this.feed)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.savedFeedList = data.Lstfeeds;              
                this.Statuses = data.lstStatus;              
                this.totalRecords = data.RecordsFetched;           
                if (status == undefined || status == null)
                { this.feed.StatusName = Constants.Select; }
                else
                { this.feed.StatusName = status}

                this.existingfeeds.ExistsList = [];
                this.existingfeeds.ExistsList = this.savedFeedList;
                this.existingfeeds.MatchColumn = "FeedID";
                this.existingfeeds.SourceColumn = "FeedID";
                this.existingfeeds.MatchColumn2 = "FeedID";
                this.existingfeeds.SourceColumn2 = "FeedID";

                // **********************************************************************************************///
                debugger;
                for (var i = 0; i < this.savedFeedList.length; i++)
                {
                    this.lstFeedIDs.push(this.savedFeedList[i].FeedID);
                }
                debugger;
                if (this.lstFeedIDs.length > 0)
                {
                    this.feedService.getFeedAnalyticalData(this.feed, this.lstFeedIDs)
                        .subscribe(
                        (data: any) =>
                        {
                            debugger;
                            this.lstAnalysisMethods = data[0].AnalysisMethods;
                            for (var i = 0; i < data.length; i++)
                            {
                                if (data[i].FeedID != 0) // Means Original record from source system has been deleted. Hence source system returning 0 as Feed ID as default return when it doesn't find passed in feed ID from MINIDAT
                                {
                                    this.lstMappedFeeds.push({
                                        UOPNumber: data[i].UOP,
                                        Name: data[i].FeedName,
                                        // API: (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue) == null ? null : (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue).toFixed(4),
                                        API: (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0]) == undefined ? null : (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "API")[0].ComponentAverageValue).toFixed(4),
                                        RelativeDensity: (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0]) == undefined ? null : (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue).toFixed(4),
                                        //RelativeDensity: (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue) == null ? null : (data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0] == undefined ? null : data[i].AnalysisMethods.filter((x: any) => x.AnalysisMethodName == "D4052 Relative Density 60F")[0].AnalyticalComponents.filter((x: any) => x.ComponentName == "Relative Density @ 60F (15.56C)")[0].ComponentAverageValue).toFixed(4),
                                        H2InFeed: null,
                                        SulfurInSweetFeed: null,
                                        NitrogenInSweetFeed: null,
                                        SulfurInFeedBlend: null,
                                        NitrogenInFeedBlend: null,
                                        Blendcomponents: null,
                                        StatusCode: this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0] == undefined ? null : this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0].StatusCode,
                                        StatusName: this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0] == undefined ? null : this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0].StatusCode.Key,
                                        Density: this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0] == undefined ? null : this.savedFeedList.filter((x: any) => x.FeedID == data[i].FeedID)[0].Density,
                                        FeedId: data[i].FeedID
                                    }
                                    )};
                            }
                            //**************************************************************************************************************//
                            let searchfields: any = [];
                            let searchvalue: any = [];
                            let andsatisfy: boolean = false;
                            let resultFilter: any = [];
                            debugger;
                            if (feedId != undefined && feedId != "") {
                                searchfields.push("FeedId");
                                searchvalue.push(feedId);
                            }
                            if (uopNumber != undefined && uopNumber != "") {
                                searchfields.push("UOPNumber");
                                searchvalue.push(uopNumber);
                            }
                            if (status != undefined && status != "Select")
                            {
                                searchfields.push("StatusName");
                                searchvalue.push(status);
                            }
                            if (density != undefined && density !=0)
                            {
                                searchfields.push("Density");
                                searchvalue.push(density);
                            }
                            debugger;
                            for (var i = 0; i < this.lstMappedFeeds.length; i++)
                            {
                                andsatisfy = false;
                                debugger;
                                for (var j = 0; j < searchfields.length; j++)
                                {
                                    if (searchfields[j] != "Density" && searchfields[j] != "FeedId" && searchfields[j] != "UOPNumber")
                                    {
                                        if (this.lstMappedFeeds[i][searchfields[j]] != null &&this.lstMappedFeeds[i][searchfields[j]].toString().toUpperCase().includes(searchvalue[j].toUpperCase())) {
                                            andsatisfy = true;
                                        }
                                        else {
                                            andsatisfy = false;
                                            break;
                                        }
                                    }
                                    else if (searchfields[j] == "FeedId") {
                                            if (this.lstMappedFeeds[i][searchfields[j]].toString().includes(searchvalue[j])) {
                                                andsatisfy = true;
                                            }
                                            else {
                                                andsatisfy = false;
                                                break;
                                            }
                                    }
                                    else if (searchfields[j] == "UOPNumber") {
                                        if (this.lstMappedFeeds[i][searchfields[j]].toString().includes(searchvalue[j])) {
                                            andsatisfy = true;
                                        }
                                        else {
                                            andsatisfy = false;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        debugger;
                                        if (this.lstMappedFeeds[i][searchfields[j]]!=null && this.lstMappedFeeds[i][searchfields[j]].toFixed(4).includes(searchvalue[j].toFixed(4)))
                                        {
                                            andsatisfy = true;
                                        }
                                        else
                                        {
                                            andsatisfy = false;
                                            break;
                                        }

                                    }
                                   
                                }
                                if (andsatisfy) {
                                    resultFilter.push(this.lstMappedFeeds[i]);
                                }
                            }

                            if (searchfields.length > 0)
                            {
                                this.lstMappedFeeds = resultFilter;
                            } 
                        },
                        err => { }
                        );        
                }                

               
            },
            err =>{}               
            );        
    }
    onAppchange()
    {
        //
    }

    SaveFeedInformation()
    {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            this.feedService.saveFeedInformation(this.feed)
                .subscribe(
                (data: any) =>
                {
                    debugger;
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.feedSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }                
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(feed: FeedModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deleteFeedInfo(feed);}
        });
    }

    deleteFeedInfo(feed: FeedModel)
    {
        debugger;       

        this.feedService.deleteFeed(feed)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.feedDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }   

    onReset() {
        debugger;
        this.feed = new FeedModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.feed.Name = null;       
        this.getFeedsList();      
        this.selectedApplicationCode = "5";
        this.blendTotalWeight = null;
        this.blendweightpct = null;  
        
    }

    isDataValid()
    {
        debugger;
        if (this.feed == null || !this.feed.UOPNumber || !this.feed.Name || this.feed.StatusName == "Select")
            //|| (this.feed.API == null || this.feed.API == undefined)
            //|| (this.feed.RelativeDensity == null || this.feed.RelativeDensity == undefined))
            //|| (this.feed.H2InFeed == null || this.feed.H2InFeed == undefined)
            //|| (this.feed.SulfurInSweetFeed == null || this.feed.SulfurInSweetFeed == undefined)
            //|| (this.feed.NitrogenInSweetFeed == null || this.feed.NitrogenInSweetFeed == undefined)
            //|| (this.feed.SulfurInFeedBlend == null || this.feed.SulfurInFeedBlend == undefined)
            //|| (this.feed.NitrogenInFeedBlend == null || this.feed.NitrogenInFeedBlend == undefined)         
        
        {
            return false;
        }
        return true;
    }

    getDelPath(CanEdit: string)
    {
       // debugger;
        if (!this.IsallowedSave || CanEdit === 'N')
        {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;       
    }

    ngDoCheck()
    {
        //debugger;
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "FEED" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }
                   
    }
    
}
