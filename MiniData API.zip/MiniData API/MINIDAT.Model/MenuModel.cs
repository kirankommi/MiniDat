﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model
{ 
        public class MenuModel
        {
            public string Name { get; set; }
            public string Link { get; set; }
            public string Title { get; set; }
            public string Action { get; set; }
            public string FunctionCode { get; set; }
            public string FunctionDescription { get; set; }
            public string ParentFunctionCode { get; set; }
            public string FunctionOrder { get; set; }
            public string PrivilegeName { get; set; }
            public bool IsReadOnly { get; set; }

            private IList<MenuModel> _subMenu = new List<MenuModel>();
            public IList<MenuModel> SubMenu { get { return _subMenu; }  } 
    }
}
