import { Pipe, PipeTransform } from '@angular/core';
import { debug } from 'util';
import { get } from 'lodash';

@Pipe({
    name: 'filterUnique'
})
export class UniqueFilterPipe implements PipeTransform {
  transform(value: any[], property: any): any {
    if (value && value.length > 0) {
      // Remove the duplicate elements
      debugger;
      let temp = get(value[0], property);
      let uniqueFlang = [];

      let uniqueArray = value.filter(function (el, index, array) {
        if (uniqueFlang.indexOf(get(el,property)) == -1) {
          uniqueFlang.push(get(el, property));
          return true;
        } else {
          return false;
        }
      });
      return uniqueArray;
    } else {
      return [];
    }
  }
}
