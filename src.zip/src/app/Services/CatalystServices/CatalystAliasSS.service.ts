﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystAliasSSModel, KeyValue } from '../../Models/Catalyst/CatalystAliasSSModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystAliasSSService {
    private getCatalystAliasSSdata = "/CatalystAliasSS/SearchCatalystAliasSSdata/";
    private getActiveCatalystAliasSSinfo = "/CatalystAliasSS/GetActiveCatalystAliasSSdata/";
    private saveCatalystAliasSSdata = "/CatalystAliasSS/SaveCatalystAliasSSInformation/";
    private deleteCatalystAliasSSdata = "/CatalystAliasSS/DeleteCatalystAliasSSInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystAliasSSInformation(catalystAliasSS: CatalystAliasSSModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystAliasSS, this.getCatalystAliasSSdata);
    }

    saveCatalystAliasSSInformation(catalystAliasSS: CatalystAliasSSModel)
    {
        return this.httpaction.post(catalystAliasSS, this.saveCatalystAliasSSdata);
    }

    deleteCatalystAliasSS(catalystAliasSS: CatalystAliasSSModel)
    {
        debugger;
        return this.httpaction.post(catalystAliasSS, this.deleteCatalystAliasSSdata);
    }    
}
