﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DataViewerModel
{
   public class DataViewerModel
    {
        public string Plant { get; set; }
        public int Run { get; set; }
        public int Test { get; set; }
        public string Category { get; set; }
        public string User_Id { get; set; }
    }

    public class DataViewerExport
    {
        public List<dynamic> PlantCalculations { get; set; }
        public List<dynamic> NormalizedGasYields { get; set; }
        public List<dynamic> GasVolumes { get; set; }

        public List<dynamic> GasWeights { get; set; }
        public List<dynamic> WeightRecovery { get; set; }
        public List<dynamic> LiquidWeights_LP690 { get; set; }
        public List<dynamic> LiquidWeights_percent { get; set; }
        public List<dynamic> LiquidWeights_Simdist { get; set; }
        public List<dynamic> NormalizedLiquidWeights { get; set; }
        public List<dynamic> RawProductWeights { get; set; }
        public List<dynamic> RawProductWeights_percent { get; set; }

        public List<dynamic> MBAdjustedProductWt_percent { get; set; }
        public List<dynamic> DopantAdjustments { get; set; }
        public List<dynamic> DAMassBalanceProductWt_perscent { get; set; }
        public List<dynamic> ProductRatios { get; set; }
        public List<dynamic> FeedWeights { get; set; }
        public List<dynamic> FeedWeightsPercent { get; set; }
        public List<dynamic> ConversionCalculation { get; set; }
        public List<dynamic> QualitCalculation { get; set; }
        public List<dynamic> H2LPProductProperties { get; set; }
        public List<dynamic> H2ByNMR { get; set; }
        public List<dynamic> H2ByNIR { get; set; }

    }
   
}
