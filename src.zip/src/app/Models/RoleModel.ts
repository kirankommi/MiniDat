﻿export class RoleModel {
    RoleCode: string;
    RoleName: string;
    StatusCode: KeyValue;
    RoleDescription: string;
    StatusName: string;
    AppCode: string;
    CanDelete: string;
    RoleApplication: ApplicationModel[];
}

export class KeyValue {
    Key: string;
    Value: string;
}

export class ApplicationModel {
    ApplicationName: string;   
    ApplicationId: number;   
    IsChecked: boolean;
    IsallowedCheck: boolean;
}