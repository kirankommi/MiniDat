﻿using MINIDAT.Model.TestCreation;
using MINIDAT.Model.UOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
    public interface IProductPhysicalPropertiesRepository
    {
        ProductPhysicalPropertiesDropdownModel getDropdownData(ProductPhysicalPropertiesInput input);
        List<ProductPhysicalPropertiesModel> getUIDataRepo(ProductPhysicalPropertiesInput input, string userName, IList<UnitGroup> unitGroups);
        void savePhysicalPropertiesRepo(SaveProductPhysicalPropertiesInput data, string userName);
     }
}
