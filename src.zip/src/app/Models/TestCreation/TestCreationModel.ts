﻿export class TestCreationModel {
    Plant: string;
    Run: number;
    Test: number;
    TestStartTime: string;
    TestEndTime: string;
    WeightCheckQuality: KeyValue;
    WCName: string;
    TestComment: string;
    PIData: string;
    LIMSData: string;
    LineOut: boolean;
    PiReTransmitTime: Date;
    LimsReTransmitTime: Date;
    LastCalculatedOn: Date;
    IsInitialLoad: any;
    AutoGenerateInd: string;
    RunTestIdsq: number;
    PlantLocation: string;
}

export class KeyValue {
    Key: string;
    Value: string;
}

export class RunFlyoutModel {
    Plantcode: string;
    RunNumber: number;
}