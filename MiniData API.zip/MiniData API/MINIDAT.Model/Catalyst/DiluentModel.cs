﻿using System.Collections.Generic;

namespace MINIDAT.Model.Catalyst
{
    public class DiluentModel
    {
        public int? DiluentID { get; set; }
        public string Designation { get; set; }
        public string Description { get; set; }
        public string Source { get; set; }
        public int? size { get; set; }
        public string ReferenceName { get; set; }
        public string StatusName { get; set; }      
        public decimal? PieceDensity { get; set; }
        public decimal? ApparentBulkDensity { get; set; }      
        public KeyValue StatusCode { get; set; }
        public KeyValue Sizecd { get; set; }
        public KeyValue Referencecd { get; set; }     

    }
    public class DiluentSearchModel
    {
        private IList<KeyValue> _Sizes = new List<KeyValue>();
        public IList<KeyValue> lstSizes { get { return _Sizes; } }

        private IList<KeyValue> _lstReferences = new List<KeyValue>();
        public IList<KeyValue> lstReferences { get { return _lstReferences; } }

        private IList<KeyValue> status = new List<KeyValue>();
        public IList<KeyValue> lstStatus { get { return status; } }

        private IList<DiluentModel> _lstdiluents = new List<DiluentModel>();
        public IList<DiluentModel> Lstdiluents { get { return _lstdiluents; } }

        public int RecordsFetched { get; set; }

    }
}
