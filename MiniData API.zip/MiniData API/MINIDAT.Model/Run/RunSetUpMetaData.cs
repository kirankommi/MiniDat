﻿using MINIDAT.Model.DOE;
using System;
using System.Collections.Generic;

namespace MINIDAT.Model.Run
{
    public class RunSetUpMetaData
    {
        public int? Plant { get; set; }
        public string PlantLocation { get; set; }
        public int? RunNum { get; set; }
        public int? RunId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? ZeroHOSTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string RunStatus { get; set; }
        public string ProjectMgr { get; set; }
        public string NetworkNumber { get; set; }
        public string NIRModelID { get; set; }
        public Double? NIRNetConv_High { get; set; }
        public Double? NIRNetConv_Low { get; set; }

        public string ModeType { get; set; }
        public int? ModeId { get; set; }

        public int? FeedId { get; set; }
        public double? FeedDensity { get; set; }
        public bool FeedCondition { get; set; }
        public double? FeedISCOTemp { get; set; }

        public double? CatalystVolume { get; set; }

        public List<DOEBed> lstDoeCataystinfo { get; set; }
        public string FeedUOP { get; set; }
        public double? FeedAnalyticalDensity { get; set; }
        public double? ModeLHSV { get; set; }
        public double? ModeSCFB { get; set; }
        public double? ModePressure { get; set; }
        public int? SulfidingType { get; set; }

    }
}
