﻿import { Injectable } from '@angular/core';
import { RequestOptions, URLSearchParams } from '@angular/http';
import { CatalystStateModel, KeyValue } from '../../Models/Catalyst/CatalystStateModel';
import * as Constants from '../../Shared/globalconstants';
import { HttpActionService } from '../httpaction.service';
import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class CatalystStateService {
    private getCatalystStatedata = "/CatalystState/SearchCatalystStatedata/";
    private getActiveCatalystStateinfo = "/CatalystState/GetActiveCatalystStatedata/";
    private saveCatalystStatedata = "/CatalystState/SaveCatalystStateInformation/";
    private deleteCatalystStatedata = "/CatalystState/DeleteCatalystStateInformation/";  

    constructor(private httpaction: HttpActionService) { }

    getCatalystStateInformation(catalystState: CatalystStateModel)
    {
        debugger;      
        let options = new RequestOptions(Constants.options)        
        return this.httpaction.post(catalystState, this.getCatalystStatedata);
    }

    saveCatalystStateInformation(catalystState: CatalystStateModel)
    {
        return this.httpaction.post(catalystState, this.saveCatalystStatedata);
    }

    deleteCatalystState(catalystState: CatalystStateModel)
    {
        debugger;
        return this.httpaction.post(catalystState, this.deleteCatalystStatedata);
    }    
}
