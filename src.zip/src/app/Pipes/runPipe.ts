import { Pipe, PipeTransform } from '@angular/core';
import { debug } from 'util';
import { get } from 'lodash';

@Pipe({
  name: 'runPipe'
})
export class runPipe implements PipeTransform {
  transform(value: any[], plant: any[]): any {
    debugger;
    if (value && value.length > 0) {
      // Remove the duplicate elements
      let plants = plant.map(q => q.Key);
      let uniqueArray: number[] = [];
      uniqueArray = value.filter(q => q.PlantKey in plants).map(w => w.RunNum);
      let result: any[] = Array.from(new Set(uniqueArray)).map(q => {
        return { Run: q };
      });
      return result;
    } else {
      return [];
    }
  }
}
