﻿using MINIDAT.Model.FileBrowser;
using MINIDAT.Model.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.DOE
{
    public class DoeFileModel: FileImport
    {
        public int? UID { get; set; }
    }

    public class DOEFile: FileModel
    {
        public string StudyNM { get; set; }
        public int StudyID { get; set; }
    }
}
