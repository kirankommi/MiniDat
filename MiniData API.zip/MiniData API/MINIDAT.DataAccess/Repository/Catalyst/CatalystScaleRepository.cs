﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystScale.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystScaleRepository : ICatalystScaleRepository
    {
        private IDatabase _db;
        public CatalystScaleRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystScaleSearchModel GetCatalystScaleData(CatalystScaleModel catalystScale)
        {
            try
            {
                CatalystScaleSearchModel catalystScalearr = new CatalystScaleSearchModel();
                if (catalystScale == null)
                {
                    return catalystScalearr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystScale_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystScale", string.IsNullOrEmpty(Convert.ToString(catalystScale.CatalystScale)) ? (object)null : catalystScale.CatalystScale);                  
                    parameters.Add("proc_vr_description", string.IsNullOrEmpty(Convert.ToString(catalystScale.Description)) ? (object)null : catalystScale.Description);                 
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystScale.StatusName == "Select" ? null : catalystScale.StatusName) ? (object)null : catalystScale.StatusName);  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystScalearr.LstcatalystScales.Clear();
                    while (reader.Read())
                    {
                        CatalystScaleModel _catalystScale = new CatalystScaleModel()
                        {
                            CatalystScaleID = Convert.ToInt32(reader["CATALYST_SCALE_ID_SQ"]),                         
                            Description = reader["CATALYST_SCALE_DESC"].ToString(),
                            CatalystScale = reader["CATALYST_SCALE_NM"].ToString(),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() }
                        };
                        catalystScalearr.LstcatalystScales.Add(_catalystScale);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystScalearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystScalearr.lstStatus.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystScalearr.lstStatus).AddRange(statuses);                  
                    return catalystScalearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystScaleData(CatalystScaleModel catalystScale)
        {
            try
            {
                if (catalystScale == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystScale_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystScale_ID", string.IsNullOrEmpty(Convert.ToString(catalystScale.CatalystScaleID)) ? (object)null : catalystScale.CatalystScaleID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystScaleData(CatalystScaleModel _catalystScale, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystScale == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystScale_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystScale_Id", _catalystScale.CatalystScaleID);
                    parameters.Add("proc_vr_catalystScale", _catalystScale.CatalystScale);
                    parameters.Add("proc_vr_description", _catalystScale.Description);                  
                    parameters.Add("proc_vr_Status_Nm", _catalystScale.StatusName);                                    
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystScaleModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystScaleModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystScaleModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystScaleModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
