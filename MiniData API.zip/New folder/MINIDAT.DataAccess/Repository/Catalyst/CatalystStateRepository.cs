﻿/*
 *
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				COPYRIGHT (c) 2003
				  HONEYWELL INC.,
 			    ALL RIGHTS RESERVED
 
 	This software is a copyrighted work and/or information protected as a trade secret. 
	Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium 
	in which the software is embodied. Copyright or trade secret notices included must be reproduced 
	in any copies authorized by Honeywell Inc. The information in this software is subject to change 
	without notice and should not be considered as a commitment by Honeywell Inc.
 
   
 	
 	File Name				:	ManageCatalystState.cs
 	Project Title			:	MINIDAT
	Author(s)				:	Jithender Reddy
	Created Date			:	22 March 2019
	Change History			:   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.Model;
using MINIDAT.Model.Catalyst;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using MINIDAT.Models.Interfaces;
using MINIDAT.Framework.Common;

namespace MINIDAT.DataAccess.Repository.Catalyst
{
    public class CatalystStateRepository : ICatalystStateRepository
    {
        private IDatabase _db;
        public CatalystStateRepository(IDatabase dbInstance)
        {
            _db = dbInstance;
        }

        IList<KeyValue> statuses = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Active"},
                     new KeyValue() {Key="N", Value="Inactive"}
                };

        IList<KeyValue> Lstsulfiding = new List<KeyValue>() {
                    new KeyValue() {Key = "Select",Value="Select"},
                    new KeyValue() {Key="Y", Value="Yes"},
                     new KeyValue() {Key="N", Value="No"}
                };

        public IList<KeyValue> GetStatusData()
        {
            try
            {
                return statuses;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// search role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public CatalystStateSearchModel GetCatalystStateData(CatalystStateModel catalystState)
        {
            try
            {
                CatalystStateSearchModel catalystStatearr = new CatalystStateSearchModel();
                if (catalystState == null)
                {
                    return catalystStatearr;
                }


                IDataReader reader = null;                                
                using (IDbCommand command = _db.CreateCommand("[catalyst].[Search_CatalystState_Information_Sp]"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystState", string.IsNullOrEmpty(Convert.ToString(catalystState.CatalystState)) ? (object)null : catalystState.CatalystState);
                    parameters.Add("proc_in_status", string.IsNullOrEmpty(catalystState.StatusName == "Select" ? null : catalystState.StatusName) ? (object)null : catalystState.StatusName);
                    parameters.Add("proc_in_sulfiding_Ind", string.IsNullOrEmpty(catalystState.SRIndicator== "Select" ? null : catalystState.SRIndicator) ? (object)null : catalystState.SRIndicator);                  
                    parameters.Add("proc_var_src_system_id", ApplicationSettings.AppId);

                    _db.CreateParameters(command, parameters);

                    reader = _db.ExecuteReader(command);
                    catalystStatearr.LstcatalystStates.Clear();

                    while (reader.Read())
                    {
                        CatalystStateModel _catalystState = new CatalystStateModel()
                        {
                            CatalystStateID = Convert.ToInt32(reader["CATALYST_STATE_ID_SQ"]),
                            CatalystState = reader["CATALYST_STATE_NM"].ToString(),                                                 
                            StatusCode = new KeyValue() { Key = reader["STATUS_CD"].ToString(), Value = reader["STATUS_NM"].ToString() },
                            SRIndicatorcd  = new KeyValue() { Key = reader["SULFIDING_IND_CD"].ToString(), Value = reader["SULFIDING_IND_NM"].ToString() }
                        };
                        catalystStatearr.LstcatalystStates.Add(_catalystState);
                    }
                    reader.NextResult();
                    reader.NextResult();  
                    while (reader.Read())
                    {
                        catalystStatearr.RecordsFetched = (int)reader["ROW_COUNT"];
                    }
                    catalystStatearr.lstStatus.Clear();
                    catalystStatearr.lstSRIndicators.Clear();
                    reader.Close();
                    ((List<KeyValue>)catalystStatearr.lstStatus).AddRange(statuses);
                    ((List<KeyValue>)catalystStatearr.lstSRIndicators).AddRange(Lstsulfiding);
                    return catalystStatearr;
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// delete role
        /// </summary>
        /// <param name="Mode"></param>
        /// <returns></returns>
        public string DeleteCatalystStateData(CatalystStateModel catalystState)
        {
            try
            {
                if (catalystState == null)
                {
                    return string.Empty;
                }

                using (IDbCommand command = _db.CreateCommand("[catalyst].Delete_CatalystState_Information_Sp"))
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystState_ID", string.IsNullOrEmpty(Convert.ToString(catalystState.CatalystStateID)) ? (object)null : catalystState.CatalystStateID);    
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
                return "Delete";
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }

        public void SaveCatalystStateData(CatalystStateModel _catalystState, string userId)
        {
            try
            {
                if (string.IsNullOrEmpty(userId) || _catalystState == null)
                {
                    return;
                }
                string Eid = userId.Substring(userId.IndexOf("\\") + 1);

                IDbCommand command = _db.CreateCommand("[catalyst].Insert_Update_CatalystState_Information_Sp");
                using (command)
                {
                    IDictionary parameters = new Dictionary<string, object>();
                    parameters.Add("proc_vr_catalystState_Id", _catalystState.CatalystStateID);
                    parameters.Add("proc_vr_catalystStateNm", _catalystState.CatalystState);                     
                    parameters.Add("proc_vr_Status_Nm", _catalystState.StatusName);
                    parameters.Add("proc_vr_Sulfiding_Cd", _catalystState.SRIndicator);                 
                    parameters.Add("proc_vr_Created_By_User_Id", Eid);
                    parameters.Add("proc_Result_Status_Ind", 0);
                    _db.CreateParameters(command, parameters);
                    _db.ExecuteNonQuery(command);
                }
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }        

        public void Update(CatalystStateModel _model)
        {
            throw new NotImplementedException();
        }

        public void Add(CatalystStateModel _model)
        {
            throw new NotImplementedException();
        }

        public IList<CatalystStateModel> List(ICriteria _criteria)
        {
            throw new NotImplementedException();
        }

        public bool Delete(CatalystStateModel _model)
        {
            throw new NotImplementedException();
        }
    }
}
