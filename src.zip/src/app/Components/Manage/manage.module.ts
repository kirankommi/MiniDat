import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './User/user.component';
import { RoleMenuComponent } from './RoleMenu/role-menu.component';
import { RoleComponent } from './Role/Role.component';
import { UomComponent } from './UOM/uom.component';
import { UomManageVariablesComponent } from './UOM/uom-manage-variables.component';
import { AnalysisMethodComponent } from './LIMS AnalysisMethod/AnalysisMethod.component';
import { LIMSAnalysisComponent } from './LIMSAnalysisMethodComponent/limsanalysis.component';
import { PITagComponent } from './PITagInformation/PITag.component';
import { ModeComponent } from './Mode/Mode.component';
import { routeResolver } from '../../services/route/routeresolver';
import { sharedModule } from '../../Directives/shared.module';
import { RoleSummary } from './RoleMenu/rolesummary.component';
import { TreeView } from './RoleMenu/treeview.component';
import { NIRModelTemplateComponent } from './NIRModelTemplate/NIRModelTemplate.component';
import { ReciepesComponent } from './Mode/Reciepes/Reciepes.component';
import { ModeTemplateComponent } from '../../Components/Manage/Mode/mode-template/mode-template.component';
import { SPPComponent } from '../../Components/Manage/Mode/spp/spp.component';
import { NIRProcessComponent } from '../../Components/Manage/Mode/nirprocess/nirprocess.component';

const routes: Routes = [
  {
    path: 'RoleMenu',
    component: RoleMenuComponent
  },
  {
    path: 'User',
    component: UserComponent
  },
  {
    path: 'Role',
    component: RoleComponent
  },
  {
    path: 'UOM',
    component: UomComponent
  },
  {
    path: 'UOM/view/:TemplateID/:TemplateName',
    component: UomManageVariablesComponent
  },
  {
    path: 'LimsAnalysisMethod',
    component: AnalysisMethodComponent
  },
  {
    path: 'LimsComponent',
    component: LIMSAnalysisComponent
  },
  {
    path: 'PITag',
    component: PITagComponent
  },
  {
    path: 'Mode',
    component: ModeComponent,
    resolve: {
      UOM: routeResolver
    }
  },
  {
      path: 'Mode/:field',
      component: ModeTemplateComponent,
      resolve: {
          UOM: routeResolver
      }
  },
  {
      path: 'NIRModelTemplate',
      component: NIRModelTemplateComponent,
      resolve: {
          UOM: routeResolver
      }
  }

];



@NgModule({
  imports: [sharedModule,
    RouterModule.forChild(routes)],
  declarations: [
    RoleMenuComponent,
    RoleSummary,
    TreeView,
    UserComponent,
    RoleComponent,
    UomComponent,
    UomManageVariablesComponent,
    AnalysisMethodComponent,
    LIMSAnalysisComponent,
    PITagComponent,
    ModeComponent,
    NIRModelTemplateComponent,
    ReciepesComponent,
    ModeTemplateComponent,
    SPPComponent,
    NIRProcessComponent]
})
export class manageModule {

}
