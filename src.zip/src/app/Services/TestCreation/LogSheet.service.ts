import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { PeriodReadingModel, LogSheetKeyModel } from '../../Models/TestCreation/LogSheet.model';
import { HttpActionService } from '../httpaction.service';
import * as Constants from '../../Shared/globalconstants';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class LogSheetService {
    private GetLogSheetPeriodReadingUrl = "/LogSheet/GetLogSheetPeriodReadingDetails";
    private GetLogSheetUrl = "/LogSheet/GetLogSheetDetails";
    private SavePeriodReadingUrl = "/LogSheet/SavePeriodReading";
    private SaveLogSheetUrl = "/LogSheet/SaveLogSheet";
    private ExportLogSheetTimeReading = "/LogSheet/ExportDataLogSheetTimeReading/"; 
    private ExportLogSheetPeriodReading = "/LogSheet/ExportDataLogSheetPeriodReading/";
    private GetLogSheetKeyUrl = "/LogSheet/GetLogSheetKey/"; 

    constructor(private httpaction: HttpActionService) {}

    GetLogSheetPeriodReadingDetails(periodReading: PeriodReadingModel) {
        return this.httpaction.post(periodReading, this.GetLogSheetPeriodReadingUrl);
    }

    GetLogSheetDetails(periodReading: PeriodReadingModel) {
        return this.httpaction.post(periodReading, this.GetLogSheetUrl);
    }

    SavePeriodReading(periodReading: PeriodReadingModel)
    {
        return this.httpaction.post(periodReading, this.SavePeriodReadingUrl);
    }

    SaveLogSheet(LogSheet, plantCd)
    {
        return this.httpaction.post(LogSheet, this.SaveLogSheetUrl+ "?plantCd=" + Number(plantCd));
    }
    GetExportDataLogSheetTimeReading(_exportData:PeriodReadingModel){
        debugger;
        return this.httpaction.post(_exportData, this.ExportLogSheetTimeReading);
    }
    GetExportDataLogSheetPeriodReading(_exportData:PeriodReadingModel){
        debugger;
        return this.httpaction.post(_exportData, this.ExportLogSheetPeriodReading);
    }
    GetLogSheetKey(LogSheetKeyModel:LogSheetKeyModel) {
        return this.httpaction.post(LogSheetKeyModel, this.GetLogSheetKeyUrl);
    }
}