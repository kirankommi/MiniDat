import { Injectable } from '@angular/core';

import { Message } from 'primeng/primeng';
import { AppErrorMessages } from '../Shared/AppErrorMessages';
import { AppSuccessMessages } from '../Shared/AppSuccessMessages';
import { AppWarningMessages } from '../Shared/AppWarningMessages';
import * as  Constants from '../Shared/globalconstants';



@Injectable({
  providedIn: 'root'
})
export class AlertMessage {
    constructor() { }

    displayMultipleMessage(msg: Message) {  
       
        msg.life = 10000;           
        Constants.Msgs.push(msg);
        
    }

    displayMessage(msg: Message) {       
        //Constants.Msgs = [];            
        msg.life = 10000;       
        //msg.sticky = true;
        Constants.Msgs.push(msg);
       
    }
    displayErrorMessage(id: string) { 
        let msg: Message = {};
        var appErrorMessage = new AppErrorMessages();
        var message = appErrorMessage.getErrorMessage(id)
        if (message) { 
            msg.severity = Constants.severityError;
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;           
            this.displayMessage(msg);
        }
    }
    displayWarningMessage(id:string)
    {
        let msg: Message = {};
        var appMessage = new AppWarningMessages();
        var message = appMessage.getWarningMessage(id)
        if (message) {
            msg.severity = Constants.severityWarn;
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;
            this.displayMessage(msg);
        }
    }
    displaySuccessMessage(id:string)
    {
        let msg: Message = {};
        var appMessage = new AppSuccessMessages();
        var message = appMessage.getSuccessMessage(id)
        if (message) {
            msg.severity = Constants.severitySuccess;
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;
            //msg.sticky = true;
            this.displayMessage(msg);
        }
    }
    clearMsgs()
    {
        //TBD
        Constants.ClearMsgs();
    }
    
}
