﻿using Calculations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Web;
using MINIDAT.DataAccess;
using MINIDAT.Calculation;
using MINIDAT.DataAccess.Interfaces;
using MINIDAT.DataAccess.Repository.TestCreation;
using Newtonsoft.Json;
using MINIDAT.Model;
using Honeywell.MINIS.Framework.Threading;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace MINIDAT.WebAPI.Controllers.TestCreationController
{
    public class TestCreationController: CalculationStatusReceiver
    {
        /// <summary>
        /// Synronization context with the main thread
        /// </summary>
        public SynchronizationContext objContext;

        ITestCreationRepository _testCreationRepository;
        public TestCreationController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Test creation" }));
            _testCreationRepository = new TestCreationRepository(new MINIDATDatabase());
        }

        #region Calculation Receiver Members
        /// <summary>
        /// CalculationCompleted
        /// </summary>
        /// <param name="objResult"></param>
        public void CalculationCompleted(CalculationResult objResult)
        {
            DataSet wcResults = objResult.Result as DataSet;
            DataSet dsResults = new DataSet();
            DataTable dtTable = GenericMethods.CreateTable("Result");
            foreach (DataTable dtResult in wcResults.Tables)
            {
                dtTable.Merge(dtResult);
            }
            dsResults.Tables.Add(dtTable);
            string strCalcXml = dsResults.GetXml();
            try
            {
                //Default parameters
                _testCreationRepository.SaveCalculationResults("321", 45, 42, strCalcXml,"E561777");

                if (objContext != null)
                {
                    objContext.Send((object obj) =>
                    {
                        IsExecuting = false;
                        //if (ServiceAccessor.Instance.ShowMessageBox("Calculations executed successfully. Open WC result Summary?", "Completed", MessageBoxButtons.YesNo, MessageBoxImages.Information) == MessageBoxResult.Yes)
                        //{
                        //    OpenWcResultSummary();
                        //    SearchTests(test);
                        //}
                    }, null);
                }
            }
            catch (Exception ex)
            {

                if (objContext != null)
                {
                    objContext.Send((object obj) =>
                    {
                        IsExecuting = false;
                        //ServiceAccessor.Instance.ShowMessageBox(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxImages.Error);

                    }, null);
                }
            }

        }
        public bool isExecuting = false;

        /// <summary>
        /// IsExecuting
        /// </summary>
        public bool IsExecuting
        {
            get
            {
                return isExecuting;
            }
            set
            {
                isExecuting = value;
                //RaisePropertyChanged("IsExecuting");
            }
        }

        /// <summary>
        /// ProgressUpdate
        /// </summary>
        /// <param name="dProgress"></param>
        public void ProgressUpdate(double dProgress)
        {

        }
        #endregion

        ///  <summary>
        /// Allows background threading along with the main one
        /// </summary>
        public class LoadTestDataAsyncTask : ProgressAsyncTask<object, object>
        {
            private TestCreationViewModel objViewModel;

            private ValidationMessage validMsg;

            #region Constructor
            /// <summary>
            /// Initializes a new instance of the <see cref="LoadTestDataAsyncTask"/> class.
            /// </summary>
            /// <param name="objVM">The obj VM.</param>
            public LoadTestDataAsyncTask(TestCreationViewModel objVM)
            {
                objViewModel = objVM;
                objContext = SynchronizationContext.Current;
                objBWThread = new BackgroundWorker();
                objBWThread.DoWork += new DoWorkEventHandler(objBWThreadDoWork);
                objViewModel.objContext = SynchronizationContext.Current;
            }
            #endregion

            /// <summary>
            /// Threading 
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void objBWThreadDoWork(object sender, DoWorkEventArgs e)
            {
                //Get parameter from event args
                object[] parameter = e.Argument as object[];
                if (parameter != null && parameter.Length > 0)
                {
                    string operation = parameter[0] as string;
                    // To synchronize to the main thread
                    InvokeOnUIThread(new SendOrPostCallback(delegate (object obj)
                    {
                        objViewModel.Pagination.IsBusy = true;
                        objViewModel.Pagination.StatusMessage = "Loading Test Info..."; // Set to default message

                    }));
                    switch (operation)
                    {  
                        case "Calculate":
                            //Background threading

                            try
                            {
                                CalculationFacade calcFacade = new CalculationFacade(objViewModel.DataAccess, objViewModel);

                                //code changes for the auto update of log sheet period reading-- Vakula
                                objViewModel.DataAccess.InsertLogSheetPeriodReading(objViewModel.Test.Plant, objViewModel.Test.Run, objViewModel.Test.Test);
                                //
                                calcFacade.ExecuteCalculations(objViewModel.Test.Plant, objViewModel.Test.Run, objViewModel.Test.Test);
                                //InvokeOnUIThread(new SendOrPostCallback(delegate(object obj)
                                //{
                                //    //WeightCheckResultSummaryViewModel objWcResultSummary = new WeightCheckResultSummaryViewModel(objViewModel.Test, objViewModel.WcResults);
                                //    if (ServiceAccessor.Instance.ShowMessageBox("Calculations executed successfully. Open WC result Summary?", "Completed", MessageBoxButtons.YesNo, MessageBoxImages.Information) == MessageBoxResult.Yes)
                                //    {
                                //        objViewModel.OpenWcResultSummary();
                                //    }
                                //}));
                            }
                            catch (Exception ex)
                            {
                                InvokeOnUIThread(new SendOrPostCallback(delegate (object obj)
                                {
                                    //ServiceAccessor.Instance.ShowMessageBox(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxImages.Error);
                                }));

                            }
                            break;
                        default:
                            break;
                    }
                }
            }

            /// <summary>
            /// Method overridden as obsolete. WPF makes use of Background worker.
            /// </summary>
            /// <param name="parameters"></param>
            /// <returns></returns>
            protected override object DoInBackground(params object[] parameters)
            {
                return null;
            }

            /// <summary>
            /// Method overridden as obsolete. WPF makes use of Background worker.
            /// </summary>
            /// <param name="result"></param>
            protected override void OnPostExecute(object result)
            {
                // MessageBox.Show(result.ToString());
            }

        }
    }
}