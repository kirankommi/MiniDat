import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { PITagService } from '../../../Services/PITag.service';
import { PITagInfoModel, KeyValue, PlantFlyoutModel } from '../../../models/PITagInfoModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    templateUrl: 'PITag.component.html',
    providers: [PITagService, AlertMessage, HttpActionService, ConfirmationService]
})

export class PITagComponent implements OnInit
{
    @Input()
    propertyType: string;   
    title: string;
    LIMSOpNameDisabled: boolean = true;    
    defaultUnit: string;  
    PlantsList: PlantFlyoutModel[];
    plantFlyoutmodel: PlantFlyoutModel[];     
    @Input()
    LimsOpComponentList: any[];   
    IsallowedSave: boolean=false;
    totalRecords: number;
    PITag: PITagInfoModel;
    Plant: PlantFlyoutModel;
    deleteIconPath: string;
    disabledDeleteIconPath: string;   
    plantListCols: any[] = [];   
    lstPlants: any;
    isCollapsed = false;
    setStyles: boolean;
    insertUpdate: boolean = false;
    @ViewChild('roleTable') dataTableComponent: any;
    selComponentType: string;
    applicationList: any;
  
    PITagList: any;     
    statuses: KeyValue[];
    sortField: string;
    sortOrder: number;   
    selectedApplicationCode: string;   
    IsallowedChange: boolean = true;
    flyoutHeader: string = "Plants";
    pHolder: string = "Plant code";
    piTagSaved: string = "PI Tag Details Saved Successfully";
    piTagDeleted: string = "PI Tag Deleted Successfully";   

    constructor(private piTagService: PITagService, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }

    ngOnInit() {
        this.PITag = new PITagInfoModel();
        this.Plant = new PlantFlyoutModel();
        this.getRoles();
        this.title = Constants.ManagePITag;
        this.getPlantFlyout();
    }


    ngAfterViewChecked()
    {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }    

    onCollapse()
    {
        let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');

        if (this.isCollapsed) {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
            }
        } else {
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = "auto";
            }
        }
        this.isCollapsed = !this.isCollapsed;
    }

    onRowSelect(event: any) {
        debugger;
        this.PITag.PITagID = event.data.PITagID;
        this.PITag.Plantcode = event.data.Plantcode;
        this.PITag.LogsheetReadingLabel = event.data.LogsheetReadingLabel;
        this.PITag.PITagName = event.data.PITagName;
        this.PITag.MinRange = event.data.MinRange;
        this.PITag.MaxRange = event.data.MaxRange;
        this.PITag.DisplayOrder = event.data.DisplayOrder;
        //this.PITag.PIValueType = event.data.RoleCode;
        this.PITag.ValueTypeName = event.data.PIValueType.Key;
    }

    onRowUnselect($event: any)
    {

    }

    getPlantFlyout() {
        debugger;

        this.plantListCols.push({ Key: "Plantcode", Value: "Plant Code" });
        this.plantListCols.push({ Key: "Location", Value: "Location" });
        this.plantListCols.push({ Key: "BuildingNumber", Value: "Building Number" });

        this.piTagService.getPlantList(this.Plant)
            .subscribe(
            (data: any) => {
                debugger;
                this.lstPlants = data.lstPlants;
                
            
            },
            err => { }
            //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }       
    updateProjectSelection(event, condition)
    {
        debugger;
        this.PITag.Plantcode = event.Plantcode;       
    }

    getRoles()
    {
        debugger;
        this.piTagService.getPITags(this.PITag)
            .subscribe(
            (data: any) =>
            {
                debugger;
                this.PITagList = data.lstPITags;
                this.applicationList = data.ApplicationList;
                this.statuses = data.lstReadingTypes;
                this.totalRecords = data.RecordsFetched;
                this.PITag.ValueTypeName = Constants.Select;

                this.applicationList = data.ApplicationList;

                if (data.ApplicationList.length > 0) {
                    this.selectedApplicationCode = data.ApplicationList[0].ApplicationId;
                }
                else {
                    this.selectedApplicationCode = "5";
                }


                this.sortField = (data.Roles != null && data.Roles.length > 0) ? data.Roles[0].SortColumn : "";
                this.sortOrder = (data.Roles != null && data.Roles.length > 0) ? data.Roles[0].SortOrder : "";
            },
            err =>{}
                //this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onAppchange()
    {
        //
    }

    saveRole() {
        debugger;
        let response: any;
        if (this.isDataValid())
        {
            //this.PITag.PIValueType = this.statuses.filter(x => x.Key == this.RoleData.StatusName)[0];
            this.PITag.AppCode = this.selectedApplicationCode;
            this.piTagService.savePITagData(this.PITag)
                .subscribe(
                (data: any) => {
                    if (data == Constants.Success) {
                        this.onReset()
                        this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.piTagSaved });
                        this.appComponent.GetUserData();
                    }
                },
                err => { }
                // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
                );
        }
        else {
            this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: Constants.RequiredMsg });
        }
    }

    onDelete(pitag: PITagInfoModel) {
          this.messageService.show(Constants.Confirm, Constants.ConfirmMsg, Constants.Confirm).then(result => {
            result = result == Constants.ConfirmTrue; //casting string to boolean
            if (result) { this.deletePITag(pitag);}
        });
    }

    deletePITag(pitag: PITagInfoModel)
    {
        debugger;
        pitag.AppCode = this.selectedApplicationCode;

        this.piTagService.deletePITagData(pitag)
            .subscribe(
            (data: any) => {
                if (data == "Delete")
                {
                    this.onReset()
                    this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: '', detail: this.piTagDeleted });
                }
                else {
                    this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: '', detail: data });
                }
            },
            err => { }
            // this.alertMessage.displayMessage({ severity: Constants.severityError, summary: '', detail: err.Details })
            );
    }

    onReset() {
        this.PITag = new PITagInfoModel();       
        this.sortField = "";
        this.sortOrder = 0;
        this.getRoles();
        //this.dataTableComponent.reset();
        this.selectedApplicationCode = "5";
    }

    isDataValid() {
        if (this.PITag == null || !this.PITag.PITagName || !this.PITag.Plantcode || !this.PITag.LogsheetReadingLabel || this.PITag.ValueTypeName == "Select" || !this.PITag.DisplayOrder) {
            return false;
        }
        return true;
    }

    getDelPath() {
        if (!this.IsallowedSave) {
            return this.disabledDeleteIconPath;
        }
        return this.deleteIconPath;
    }

    ngDoCheck() {
        if (Constants.UserPrivileges.length > 1)
        {
            for (let i in Constants.UserPrivileges) {
              if (Constants.UserPrivileges[i].Action != null && Constants.UserPrivileges[i].Action.trim() != '' && Constants.UserPrivileges[i].Action.toUpperCase() == "MANAGE/PITAG" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                    this.IsallowedSave = true;
                }
            }
        }
    }
    
}
