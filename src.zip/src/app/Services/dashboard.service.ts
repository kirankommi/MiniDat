﻿import { Injectable, ReflectiveInjector } from '@angular/core';
import { HttpActionService } from './httpaction.service';
import * as Constants from  '../Shared/globalconstants';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    csatScoreUrl: string = "/csat ";


    constructor(private httpaction: HttpActionService) {

    }

    GetCsatScore() {
        return this.httpaction.get(this.csatScoreUrl, Constants.options);
    }
}