import { Component, Input, OnInit, Output, EventEmitter } from "@angular/core";

@Component({
  selector: 'UOM-inputBox',
  templateUrl: 'uomInputBox.component.html'
})
export class uomInputComponent implements OnInit {
  @Input() pHolder: string;
  @Input() isDisabled: boolean = false;

  private _baseValue: any;
  defaultUnit: any;
  displayValue: any;

  @Input()
  set inputUnit(unit: any) {
    this.defaultUnit = unit;
    this.updateDisplayValue();
  }

  @Output()
  inputUnitChange = new EventEmitter<any>();

  @Input()
  set baseValue(bv: any) {
    this._baseValue = parseFloat(bv);
    this.updateDisplayValue();
  }

  @Output()
  baseValueChange = new EventEmitter<number>();
  
  constructor() {

  }

  updateBaseValue() {
    if (!isNaN(parseFloat(this.displayValue))) {
      if (this.defaultUnit.UnitName == "API" || this.defaultUnit.UnitName == "BAUME" || this.defaultUnit.UnitName == "BAUME<5") {
        this._baseValue = this.defaultUnit.Slope / (this.displayValue + this.defaultUnit.Intercept);
      }
      else {
        this._baseValue = this.displayValue * this.defaultUnit.Slope + this.defaultUnit.Intercept;
      }
      this.baseValueChange.emit(this._baseValue);

      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
    } else if (this.displayValue == "" || this.displayValue == null || this.displayValue == undefined) {
      this._baseValue = null;
      this.baseValueChange.emit(this._baseValue);
    }
  }

  updateDisplayValue() {
    if (this.defaultUnit && !isNaN(parseFloat(this._baseValue))) {
      if (this.defaultUnit.UnitName == "API" || this.defaultUnit.UnitName == "BAUME" || this.defaultUnit.UnitName == "BAUME<5") {
        this.displayValue = (this.defaultUnit.Slope / this._baseValue) - this.defaultUnit.Intercept;
      }
      else {
        this.displayValue = (this._baseValue - this.defaultUnit.Intercept) / this.defaultUnit.Slope;
      }
      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
    }
    else {
      this.displayValue = null;
    }
  }

  GetPrecison() {
    if (this.defaultUnit.Precision != null) {
      return this.defaultUnit.Precision;
    }
    else {
      return 6;
    }
  }


  ngOnInit(): void {
    this.updateDisplayValue();
  }
}

