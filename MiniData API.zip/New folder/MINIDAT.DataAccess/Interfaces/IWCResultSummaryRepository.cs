﻿using MINIDAT.Model.TestCreation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.DataAccess.Interfaces
{
   public interface IWCResultSummaryRepository
    {
         List<WCResultSummaryModel> getDataForWCResultSummary(string Plant, string Run, string Test, string Category, string User_Id);
    }
}
