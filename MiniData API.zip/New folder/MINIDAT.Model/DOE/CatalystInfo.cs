﻿using MINIDAT.Model.Catalyst;
using System.Collections.Generic;
using System.Linq;

namespace MINIDAT.Model.DOE
{
    public class CatalystInfo
    {
        public int TemplateID { get; set; }
        public string TemplateName { get; set; }
        public List<DOEBed> Beds { get; set; }
        public string LoadingSubmitted { get; set; }
        public string RxLoaded { get; set; }

        public DOEBed this[int BedNum]
        {
            get
            {
                return this.Beds.First(q => q.BedNumber == BedNum);
            }
        }
    }

    public class DOEBed : Bed
    {
        public CatalystLite Catalyst { get; set; }
    }
}
