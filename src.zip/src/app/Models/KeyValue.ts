﻿
export class KeyValue {
    Key: string;
    Value: string;
   
    public constructor(key: string, value: string)
    {
        this.Key = key;
        this.Value = value;
    }
}