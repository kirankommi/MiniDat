import { Component, Input, OnInit, Output, EventEmitter } from "@angular/core";
import * as Constants from '../Shared/globalconstants';

@Component({
  selector: 'UOM-Ctrl',
  templateUrl: 'uomCtrl.component.html'
})
export class uomCtrlComponent implements OnInit {
  @Input() pHolder: string;
  @Input() isDisabled: boolean;

  @Output() onUnitchange: EventEmitter<any> = new EventEmitter<any>();
  @Output() onBaseValue: EventEmitter<any> = new EventEmitter<any>();


  units: any = [];
  private _baseValue: any;
  private _variableCategory: string;
  private _variableName: string;
  uomObj: any;
  defaultUnit: any;
  displayValue: any;

  @Input()
  set baseValue(bv: any) {
    this._baseValue = parseFloat(bv);
    this.updateDisplayValue();
  }

  @Output()
  baseValueChange = new EventEmitter<number>();

  private _uomInstance: any = {};

  @Input()
  set uomInstance(bv: any) {
    this._uomInstance = bv;
  }

  @Output()
  uomInstanceChange = new EventEmitter<any>();


  @Input()
  set variableCategory(vCat: string) {
    this._variableCategory = vCat;
    this.setUnits();
  }

  @Input()
  set variableName(vName: string) {
    this._variableName = vName;
    this.setUnits()
  }

  constructor() {

  }

  updateBaseValue() {
    if (!isNaN(parseFloat(this.displayValue))) {
      if (this.defaultUnit.UnitName == "API" || this.defaultUnit.UnitName == "BAUME" || this.defaultUnit.UnitName == "BAUME<5") {
        this._baseValue = this.defaultUnit.Slope / (this.displayValue + this.defaultUnit.Intercept);
      }
      else {
        this._baseValue = this.displayValue * this.defaultUnit.Slope + this.defaultUnit.Intercept;
      }
      this.baseValueChange.emit(this._baseValue);

      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
      this.emitUomObj();
    } else if (this.displayValue == "" || this.displayValue == null || this.displayValue == undefined) {
      this._baseValue = null;
      this.baseValueChange.emit(this._baseValue);
      this.emitUomObj();
    }
  }

  emitUomObj() {
    this.uomInstanceChange.emit({ "displayValue": this.displayValue, "defaultUnitText": this.defaultUnit.DisplayText });
  }

  updateDisplayValue() {
    if (this._variableCategory && this._variableCategory && this.defaultUnit && !isNaN(parseFloat(this._baseValue))) {
      if (this.defaultUnit.UnitName == "API" || this.defaultUnit.UnitName == "BAUME" || this.defaultUnit.UnitName == "BAUME<5") {
        this.displayValue = (this.defaultUnit.Slope / this._baseValue) - this.defaultUnit.Intercept;
      }
      else {
        this.displayValue = (this._baseValue - this.defaultUnit.Intercept) / this.defaultUnit.Slope;
      }
      this.displayValue = parseFloat(this.displayValue).toFixed(this.GetPrecison());
      this.displayValue = isNaN(this.displayValue) ? '' : this.displayValue;
      this.emitUomObj();
    }
    else {
      this.displayValue = null;
    }
  }

  GetPrecison() {
    if (this.uomObj.Precision != null) {
      return this.uomObj.Precision;
    }
    else {
      return 6;
    }
  }

  setUnits() {
    if (this._variableCategory && this._variableName) {
      this.uomObj = Constants.UOMCATVariables[this._variableCategory][this._variableName];
      this.units = Constants.UnitGroups.filter((x: any) => x.UnitGroupCD == this.uomObj.UnitGroupCD)[0].Units;
      this.defaultUnit = this.units.filter((x: any) => x.DisplayText == this.uomObj.DefaultUnitName)[0];
    }
  }

  ngOnInit(): void {
    this.setUnits();
    this.updateDisplayValue();
  }
}
