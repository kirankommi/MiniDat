import { Injectable } from '@angular/core';
import { IUser } from './IUser';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SessionService {
private isProjectSubMenuVisible = new BehaviorSubject(false);
private isSidebarvisible = new BehaviorSubject(true);
  currentProjectSubMenuStatus = this.isProjectSubMenuVisible.asObservable();
  currentSidebarStatus = this.isSidebarvisible.asObservable();
  constructor() { }
  changeProjectSubMenuVisibility(isProjectSubMenuVisible: boolean) {
    this.isProjectSubMenuVisible.next(isProjectSubMenuVisible);
  }
  changeSidebarVisibility(isSidebarvisible: boolean) {
    this.isSidebarvisible.next(isSidebarvisible);
  }
  getisProjectSubMenuVisible(){
    return this.isProjectSubMenuVisible;
  }
}
