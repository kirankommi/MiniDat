import { Component, OnInit, Input, ViewChild, ElementRef, Renderer } from '@angular/core';
import { RunService } from '../../../Services/RunServices/Run.service';
import { RunModel, GeneralInfoModel } from '../../../models/Run/RunModel';
import { messageModalUtility } from '../../../Shared/message-modal.utility';
import * as Constants from '../../../Shared/globalconstants';
import { AlertMessage } from '../../../services/alertmessage.service';
import { HttpActionService } from '../../../services/httpaction.service';
import { AppComponent } from '../../../app.component';
import { ConfirmDialogModule, ConfirmationService } from 'primeng/primeng';
import { FlyoutExistsDataModel } from '../../../models/FlyoutExistsDataModel';
import { KeyValue } from '../../../Models/KeyValue';
import { RunDataService } from "../run.data.service";
import { ActivatedRoute } from '@angular/router';
import { RunMetaData } from 'src/app/Models/Run/RunMetaData';
import { RunComponent } from '../run.component';
import { RunSetupModel } from 'src/app/Models/Run/RunSetupModel';

@Component({
    templateUrl: 'GeneralInfo.component.html',
    selector: "generalInfo",
    providers: [RunService, AlertMessage, HttpActionService, ConfirmationService]
})

export class GeneralInfoComponent implements OnInit {
    @Input()
    propertyType: string;
    title: string;
    defaultUnit: string;
    @Input()
    // run1: RunModel;
    run: RunSetupModel;
    deleteIconPath: string;
    disabledDeleteIconPath: string;
    IsallowedChange: boolean = true;
    isCollapsed = false;
    setStyles: boolean;
    lstTechnicians1: any;
    lstTechnicians2: any;
    techListCols: KeyValue[];
    @ViewChild('roleTable') dataTableComponent: any;
    IsSaved: boolean = false;
    IsallowedSave: boolean = true;
    LocalAccess: boolean = false;
    check: boolean = false;
    sortField: string;
    sortOrder: number;
    metadata: RunMetaData;
    runSaved: string = "Run Details Saved Successfully";
    sub: any;
    plant: any;
    runNum: any;

    constructor(private runService: RunService, private route: ActivatedRoute, public el: ElementRef, public renderer: Renderer, private appComponent: AppComponent,
        private messageService: messageModalUtility, private alertMessage: AlertMessage, private confirmationService: ConfirmationService, public runDataService: RunDataService, private runComponent: RunComponent) {
        this.deleteIconPath = Constants.deleteIconPath;
        this.disabledDeleteIconPath = Constants.disabledDeleteIconPath;
    }
    ngOnInit() {
        this.runDataService.currentMessage.subscribe(runmodel => { this.run = runmodel });
        this.sub = this.route.params.subscribe(params => {
            this.plant = params['plant'];
            this.runNum = params['run'];
        });
        debugger;
        if (this.run.isInitial) {
            this.getRunData();
        }
        else {
            this.lstTechnicians1 = this.run.MasterData.lstFlyoutTechnicians;
            this.lstTechnicians2 = this.run.MasterData.lstFlyoutTechnicians;
        }
        this.runComponent.exportData.selectedPopupList = [];
        this.runComponent.exportData.selectedPopupList.push({ Key: "1", Value: "General Info", Groupcd: 0 });
    }
    getRunData() {
        this.runService.getRunSetupInfo(this.plant, this.runNum)
            .subscribe(
                (data: any) => {

                    this.run = data;

                    this.lstTechnicians1 = this.run.MasterData.lstFlyoutTechnicians = data.MasterData.Technicians;
                    this.lstTechnicians2 = data.MasterData.Technicians;
                    this.fillFlyoutColumns();
                    this.runDataService.changeMessage(this.run);
                    this.runComponent.processRunBoilingPoints();
                    this.runComponent.processNIRSpecs();
                    this.runComponent.processAdditionalInfo();
                   
                    if (this.run.GeneralInfo.Technician1 == undefined || this.run.GeneralInfo.Technician1 == "" || this.run.GeneralInfo.Technician1 == null) {
                        this.run.GeneralInfo.Technician1 = "Johnson, Karl"; //Default Set to Karl Jason
                        this.run.GeneralInfo.Technician1EID = "E548115";
                    }

                    this.runComponent.processFeedInfo();
                    this.runDataService.changeMessage(this.run);
                    this.getLimsCostVolume();
                    this.run.isInitial = false;
                    this.runDataService.changeMessage(this.run);
                });
    }
    getLimsCostVolume() {
        let limsOperations: any[] = [];

        if (this.run.lstAnalyticalSamples != null && this.run.lstAnalyticalSamples != undefined) {
            this.run.lstAnalyticalSamples.forEach(element => {
                limsOperations.push({ "Value": element.LIMSOPerationName });
            });
        }
        if (limsOperations.length > 0) {
            this.runService.GetLIMSInfo(limsOperations).subscribe((limsData: any) => {
                debugger;

                this.run.lstAnalyticalSamples.forEach(element => {
                    element.SampleCost = limsData.find(x => (x.LimsOperationName == element.LIMSOPerationName)).Cost;
                    element.SampleVolumeinCC = limsData.find(x => (x.LimsOperationName == element.LIMSOPerationName)).Volume;

                });
                this.alertMessage.displayMessage({ severity: Constants.severitySuccess, summary: 'Cost & Volume updated successfully' });
            },
                err => { this.alertMessage.displayMessage({ severity: Constants.Error, summary: 'Failed to update Cost & Volume' }); }
            );
        }
    }
    getRunMasterInfo() {

        // this.runService.GetRunMasterDataInfo(this.run.Plant, this.run.ModeType)
        //     .subscribe(
        //         (data: any) => {
        //             
        //             this.lstTechnicians1 = data.Technicians;
        //             this.lstTechnicians2 = data.Technicians;
        //             this.run.LstAnalysisMethods = data.LstAnalysisMethods;
        //             this.run.lstStreams = data.lstStreams;
        //             this.run.LstLoadingDensiyTypes = data.LstLoadingDensiyTypes;
        //             this.run.LstNormalizationFactors = data.LstNormalizationFactors;
        //             this.run.LstFeedSource = data.LstFeedSource;
        //             this.run.LstStdBoilingPoints = data.LstStdBoilingPoints;
        //             this.run.LstStreams = data.LstStreams;
        //             this.run.LstFrequency = data.LstFrequency;
        //             this.run.lstFlyoutFeeds = data.lstFlyoutFeeds;

        //         });
    }

    fillFlyoutColumns() {
        this.techListCols = [];

        this.techListCols.push({ Key: "Key", Value: "Technician EID" });
        this.techListCols.push({ Key: "Value", Value: "Full Name" });
    }
    updateTechnician1Selection(event, condition) {
        this.run.GeneralInfo.Technician1 = event.Value;
        this.run.GeneralInfo.Technician1EID = event.Key;
    }
    updateTechnician2Selection(event, condition) {
        this.run.GeneralInfo.Technician2 = event.Value;
        this.run.GeneralInfo.Technician2EID = event.Key;
    }

    ngAfterViewChecked() {
        if (!this.setStyles) {
            let datatable = this.el.nativeElement.querySelector('#divUsers > p-datatable > div > div.ui-datatable-scrollable-body');
            let userAppDatatable = this.el.nativeElement.querySelector('#divAppUser > p-datatable > div > div.ui-datatable-scrollable-body');
            if (datatable != null && datatable != Constants.Undefined) {
                datatable.style.height = (window.innerHeight * 30 / 100) - 64 + 'px';
                this.setStyles = true;
            }
            if (userAppDatatable != null && userAppDatatable != Constants.Undefined) {
                userAppDatatable.style.height = (window.innerHeight * 20 / 100) - 64 + 'px';
                this.setStyles = true;
            }
        }
    }

    getRunGeneralInformation(PlantCd: string, RunId: string) {

        this.runService.GetGeneralInfo(PlantCd, RunId)
            .subscribe(
                (data: any) => {

                    if (data.Technician1EID != "" && data.Technician1EID != undefined && data.Technician1EID != null && data.Technician1EID != this.run.GeneralInfo.Technician1EID) {
                        this.run.GeneralInfo.Technician1EID = data.Technician1EID;
                        this.run.GeneralInfo.Technician1 = data.Technician1;
                    }
                    if (data.Technician2EID != undefined && data.Technician2EID != null && data.Technician2EID != this.run.GeneralInfo.Technician1EID) {
                        this.run.GeneralInfo.Technician2EID = data.Technician2EID;
                        this.run.GeneralInfo.Technician2 = data.Technician2;
                    }

                    this.run.GeneralInfo.RunDescription = data.RunDescription;
                },
                err => { }
            );
    }
  
  
    isDataValid() {
        if (this.run.GeneralInfo.Technician1 == "" || this.run.GeneralInfo.Technician1 == null || this.run.GeneralInfo.Technician1 == undefined) { this.run.GeneralInfo.Technician1EID = null };
        if (this.run.GeneralInfo.Technician2 == "" || this.run.GeneralInfo.Technician2 == null || this.run.GeneralInfo.Technician2 == undefined) { this.run.GeneralInfo.Technician2EID = null };

        if (this.run.MetaData.RunNum == null) {
            return false;
        }
        return true;
    }

    onReset() {
        this.getRunGeneralInformation(this.run.MetaData.Plant, this.run.MetaData.RunId);
       this.runDataService.changeMessage(this.run);      
    }

    ngDoCheck() {
        if (!this.check) {
            if (Constants.UserPrivileges.length > 1) {
                for (let i in Constants.UserPrivileges) {
                    if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000067" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
                        this.IsallowedSave = true;
                        this.check = true;
                    }
                }
            }
        }

    }

}
