export class LogSheetPeriodReadingModel {
    LogReadingLabel: string;
    InputVariableType: string;
    UOM: string;
    AverageReadingValueMsr: number;
    InitialReadingValueMsr: number;
    FinalReadingValueMsr: number;
    ParamterDefaultUnitName: string;
}

export class PeriodReadingModel {

    PlantCd: string;
    RunId: number;
    TestId: number;
    TestEndTime: string;
    TestStartTime: string;
    PeriodReadingList: LogSheetPeriodReadingModel[];
}

export class LogSheetKeyModel {
    PlantCd: string;
    ReadingTime: Date;
}

