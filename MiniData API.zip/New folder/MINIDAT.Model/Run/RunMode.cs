﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MINIDAT.Model.Run
{
    public class RunMode
    {
        public double? Condition { get; set; }
        public double? Pressure { get; set; }
        public double? LHSV { get; set; }
        public double? SCFB { get; set; }
        public double? RunId { get; set; }
        public string ModeNo { get; set; }
        public double? ModeId { get; set; }
        public double? WeightChecks { get; set; }
        public double? Sort { get; set; }
        public double? SulfidingType { get; set; }
        public double? ControlMethod { get; set; }
    }
}
