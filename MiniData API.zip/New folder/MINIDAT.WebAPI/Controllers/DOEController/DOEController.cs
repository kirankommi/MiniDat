﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.DOE;
using MINIDAT.Model;
using MINIDAT.Model.DOE;
using System;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using MINIDAT.Model.Project;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using ICSharpCode.SharpZipLib.Zip;

namespace MINIDAT.WebAPI.Controllers.DOEController
{
    public class DOEController : ApiController
    {

        [HttpGet, ActionName("GetMasterData")]
        public HttpResponseMessage GetMasterData()
        {

            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.GetMasterData());

            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectAccoladeLoadError.ToString());
            }
        }


        [HttpGet, ActionName("GetAllDocuments")]
        public HttpResponseMessage GetAllDocuments()
        {
            try
            {

                DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
                List<DOEFile> files = _doeRepository.BrowseFiles();
                return Request.CreateResponse(HttpStatusCode.OK, files);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [ActionName("SaveDoe"), HttpPost]
        public HttpResponseMessage SaveDOE([FromBody] SaveModel studyDtl)
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                studyDtl.DOE.CreatedEID = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.SaveDOE(studyDtl));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateResponse(HttpStatusCode.OK, ex.Message);
            }
        }

        [ActionName("DOEDetail"), HttpGet]
        public HttpResponseMessage GetDOEInformation([FromUri]int studyID)
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.GetDOEInformation(studyID));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "");
            }
        }

        [ActionName("DeleteDOE"), HttpPost]
        public HttpResponseMessage DeleteDOE([FromBody]int studyID)
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.DeleteDOE(studyID));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [ActionName("DOEPoolMaster"), HttpGet]
        public HttpResponseMessage GetDOEPoolMasterData()
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.GetPoolMasterData());

            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [ActionName("SearchDoe"), HttpPost]
        public HttpResponseMessage SearchDoe([FromBody] PoolModel doe)
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.SearchDOE(doe));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "");
            }
        }
        [HttpGet, ActionName("GetStudyFiles")]
        public HttpResponseMessage GetStudyFiles(string studyID, string studyName)
        {
            try
            {
                if (!string.IsNullOrEmpty(studyID))
                {
                    DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());


                    MemoryStream memory = new MemoryStream();
                    using (var zipStream = new ZipOutputStream(memory))
                    {
                        Dictionary<string, int> fileNames = new Dictionary<string, int>();
                        foreach (DoeFileModel file in _doeRepository.GetStudyDocument(studyID))
                        {
                            byte[] fileBytes = (byte[])file.FileData;
                            string FileName = "";
                            if (fileNames.ContainsKey(file.FileName))
                            {
                                FileName = (fileNames[file.FileName]++).ToString() + file.FileName;
                            }
                            else
                            {
                                FileName = file.FileName;
                                fileNames.Add(file.FileName, 1);
                            }
                            var fileEntry = new ZipEntry(Path.GetFileName(FileName))
                            {
                                Size = fileBytes.Length
                            };
                            zipStream.PutNextEntry(fileEntry);
                            zipStream.Write(fileBytes, 0, fileBytes.Length);
                        }
                        zipStream.Flush();
                        zipStream.Close();
                    }
                    FileImport zipData = new FileImport();
                    zipData.FileName = studyName + ".zip";
                    zipData.ContentType = "application/zip";
                    zipData.FileData = (memory.ToArray());

                    return Request.CreateResponse(HttpStatusCode.OK, zipData);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpGet]
        public HttpResponseMessage DownloadFile([FromUri] string fileId, string studyID)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileId) && !string.IsNullOrEmpty(studyID))
                {
                    DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
                    FileImport file = _doeRepository.GetDocument(fileId, studyID);
                    return Request.CreateResponse(HttpStatusCode.OK, file);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        [ActionName("UploadFiles"), HttpPost]
        public HttpResponseMessage UploadFiles()
        {
            DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
            try
            {
                var FileInfo = JArray.Parse(HttpContext.Current.Request.Params["fileInfo"]);
                List<DoeFileModel> Files = new List<DoeFileModel>();
                foreach (var info in FileInfo)
                {
                    DoeFileModel file = new DoeFileModel();
                    file.FileName = info.Value<string>("FileName");
                    file.Description = info.Value<string>("Description");
                    string[] stringParts = file.FileName.Split(new char[] { '.' });
                    string contenttype = stringParts[1];
                    file.ContentType = contenttype;
                    //file.IsDeleted = info.Value<bool>("IsDeleted");
                    file.UID = info.Value<int?>("UID");
                    var fileData = HttpContext.Current.Request.Files[info.Value<string>("FileId")];

                    byte[] byteData = null;
                    if (fileData != null)
                    {
                        using (var binaryReader = new BinaryReader(fileData.InputStream))
                        {
                            byteData = binaryReader.ReadBytes(fileData.ContentLength);
                        }
                        file.setData(byteData);
                    }
                    Files.Add(file);
                }

                return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.UploadFiles(Files, Convert.ToString(HttpContext.Current.Request.Params["DeleteIds"]), Convert.ToInt16(HttpContext.Current.Request.Params["StudyID"]), User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1)));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "");
            }
        }

        //[ActionName("SaveColumnPreferences"), HttpPost]
        //public HttpResponseMessage SaveColumnPreferences([FromBody]ColumnsPreferences columns)
        //{
        //    DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
        //    try
        //    {
        //        columns.UserId = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1);
        //        return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.SaveColPreferences(columns));
        //    }
        //    catch (Exception ex)
        //    {
        //        Model.LogManager.Error(ex);
        //        return Request.CreateResponse(HttpStatusCode.OK, ex.Message);
        //    }
        //}

        //[ActionName("GetColumnPreferences"), HttpGet]
        //public HttpResponseMessage GetColumnPreferences()
        //{
        //    DOERepository _doeRepository = new DOERepository(new MINIDATDatabase());
        //    try
        //    {
        //        return Request.CreateResponse(HttpStatusCode.OK, _doeRepository.GetColumnPreferences(User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1)));
        //    }
        //    catch (Exception ex)
        //    {
        //        Model.LogManager.Error(ex);
        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "");
        //    }
        //}

    }
}