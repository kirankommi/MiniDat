﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MINIDAT.Model.FileBrowser
{
    

        public class FileModel
        {

            public int RowId { get; set; }
            public int FileTypeId { get; set; }
            public string FileType { get; set; }
            public int FileId { get; set; }
            public string FileName { get; set; }
            public string ContentType { get; set; }
            public string Description { get; set; }
            [XmlIgnore]
            public Object FileData { get; set; }

            public decimal FileSize { get; set; }
            public string SizeUnit { get; set; }
            private byte[] _data { get; set; }
            public byte[] getData()
            {
                return _data;
            }
            public void setData(byte[] fileContent)
            {
                _data = fileContent;
            }
            public string CreatedByUserID { get; set; }
            public string UpdatedByUserID { get; set; }
            public string LastUpdatedDateTime { get; set; }

        }
    
}
