﻿//import * as constants from 'constants';

import { Injectable } from '@angular/core';
import { Http, Response, Headers, Request, RequestOptions, RequestMethod, URLSearchParams } from '@angular/http';
import { LimsComponentModel } from '../Models/LimsComponentModel';
import { HttpActionService } from './httpaction.service';
//import Constants = require('../Shared/globalconstants');
import * as Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { MissingOperatorsViewModel, AnalysisSource, filteredMissingComponentGroup } from '../models/Automap/AutoMapModels'; 

@Injectable()
export class LIMSComponentService {
    private getLimsComponentdata = "/LimsComponent/GetLIMSAnalysisMethodComponentData/";
    private saveLimsComponentdata = "/LimsComponent/SaveLIMSAnalysisMethodComponent/";
    private deleteLimsComponentdata = "/LimsComponent/DeleteComponentData/";
    private getLimsOpFlyout = "/LimsComponent/Limsoperation/";
    private getLimsCompFlyout = "/LimsComponent/Limscomponent/";
    private getMissingOperatorsUrl = '/TraceLog/GetAll/';
    private saveMissingOperatorsUrl = '/TraceLog/saveOperations/';
    private saveMissingComponentsUrl = '/TraceLog/saveComponents/';
    private getMissingCountUrl = '/TraceLog/getMissingCount';
    private getLimsComponentUOMdata = "/LimsComponent/GetLIMSAnalysisMethodComponentBindUOM/";
    //MiniDATRunSpecific
    private getLimsOpFlyoutForMiniDAT = "/LimsComponent/MINIDTRunLIMSOperations/";

    constructor(private http: Http, private httpaction: HttpActionService) { }

    private handleError(error: any): Promise<any> {
        // console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }

    getLimsComponent(limsComponentData: LimsComponentModel) {

        debugger;
        let params: URLSearchParams = new URLSearchParams();
        if (limsComponentData.LIMSOperationName)
            params.set('LIMSOperationName', encodeURIComponent(limsComponentData.LIMSOperationName));
        if (limsComponentData.LIMSComponent)
            params.set('LIMSComponent', encodeURIComponent(limsComponentData.LIMSComponent));
        if (limsComponentData.FDMSComponent)
            params.set('FDMSComponent', encodeURIComponent(limsComponentData.FDMSComponent));

        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getLimsComponentdata, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }

    getLimsComponentUOM(limsComponentData: LimsComponentModel) {

        debugger;
        let params: URLSearchParams = new URLSearchParams();
        //if (limsComponentData.LIMSOperationName)
        //    params.set('LIMSOperationName', encodeURIComponent(limsComponentData.LIMSOperationName));
        //if (limsComponentData.LIMSComponent)
        //    params.set('LIMSComponent', encodeURIComponent(limsComponentData.LIMSComponent));
        //if (limsComponentData.FDMSComponent)
        //    params.set('FDMSComponent', encodeURIComponent(limsComponentData.FDMSComponent));

        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getLimsComponentUOMdata, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }

    getLimsOperationList(limsComponentData: LimsComponentModel) {

        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('LIMSOperationName', limsComponentData.LIMSOperationName);
        params.set('LIMSComponent', limsComponentData.LIMSComponent);
        params.set('FDMSComponent', limsComponentData.FDMSComponent);

        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getLimsOpFlyout, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }
    modifyLimsComponent(limsComponentData: LimsComponentModel, actionUrl: string) {
        let options = new RequestOptions(Constants.options);
        return this.http.post(Constants.apiBaseUrl + actionUrl, limsComponentData, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }
    insertUpdateLimsComponent(limsComponentData: LimsComponentModel)
    {
        debugger;
        // return this.modifyLimsComponent(limsComponentData, this.saveLimsComponentdata);
        return this.httpaction.post(limsComponentData, this.saveLimsComponentdata);
    }

    getLimsComponentList(limsComponentData: LimsComponentModel) {

        let params: URLSearchParams = new URLSearchParams();
        params.set('LIMSOperationName', limsComponentData.LIMSOperationName);
        params.set('LIMSComponent', limsComponentData.LIMSComponent);
        params.set('FDMSComponent', limsComponentData.FDMSComponent);
        params.set('ComponentType', limsComponentData.ComponentType);

        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getLimsCompFlyout, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }
    deleteUomTemplate(limsComponentData: LimsComponentModel) {
        return this.modifyLimsComponent(limsComponentData, this.deleteLimsComponentdata);
    }
    getMissingOperators(type: string, feedid: string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('type', type); 
        if (feedid && feedid.length > 0) {
            params.set('feedId', feedid);
        }
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getMissingOperatorsUrl, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);

    }
    saveMissingOperators(data: MissingOperatorsViewModel[]) {
        let options = new RequestOptions(Constants.options);
        return this.http.post(Constants.apiBaseUrl + this.saveMissingOperatorsUrl, data, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }
    saveMissingComponents(data: filteredMissingComponentGroup[]) {
        let options = new RequestOptions(Constants.options);
        return this.http.post(Constants.apiBaseUrl + this.saveMissingComponentsUrl, data, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }

    getMissingCount(feedid: string) {
        let params: URLSearchParams = new URLSearchParams(); 
        if (feedid && feedid.length > 0) {
            params.set('feedId', feedid);
        }
        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getMissingCountUrl, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);

    }
    //MiniDATRunSpecific
    getLimsOperationListForMiniDAT(limsComponentData: LimsComponentModel) {

        debugger;
        let params: URLSearchParams = new URLSearchParams();
        params.set('LIMSOperationName', limsComponentData.LIMSOperationName);
        params.set('LIMSComponent', limsComponentData.LIMSComponent);
        params.set('FDMSComponent', limsComponentData.FDMSComponent);

        let options = new RequestOptions(Constants.getParamOptions(params));
        return this.http.get(Constants.apiBaseUrl + this.getLimsOpFlyoutForMiniDAT, options)
            .map((res: Response) => res.json())
            .catch(this.handleError);
    }
}