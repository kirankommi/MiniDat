﻿/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    COPYRIGHT (c) 2017
	   			      HONEYWELL INC.,
			        ALL RIGHTS RESERVED
 
 	    This software is a copyrighted work and/or information protected as a trade secret.
        Legal rights of Honeywell Inc. in this software is distinct from ownership of any medium
        in which the software is embodied. Copyright or trade secret notices included must be 
        reproduced in any copies authorized by Honeywell Inc. The information in this software
        is subject to change without notice and should not be considered as a commitment by Honeywell Inc.
  
 
Filename:           LIMSAnalysisMethodController.cs
Project Title:      FeedStockDAT
Created on:         25-May-2017
Requirements Tag:   Controller for Managing LIMS Analysis method
Original author:    H119461 -Pranesh Kumar
Change History	:
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 */


using System;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using MINIDAT.Model.Manage.LIMSAnalysisMethod;
using System.Collections.Generic;
using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.Model;
using Newtonsoft.Json;
using System.Data.SqlClient;

namespace MINIDAT.WebAPI.Controllers.Manage
{
    public class LIMSAnalysisMethodController : AppController
    {
        public LIMSAnalysisMethodController()
        {
            LogManager.Info(JsonConvert.SerializeObject(new { Category = LogCategory.FUNCTIONALITY, Value = "Manage LIMS Analysis Method" }));
        }
        /// <summary>
        /// Get LIMS Analysis Method Data
        /// </summary>
        /// <param name="LIMSAnalysisMethod"></param>
        /// <returns></returns>
        [HttpPost, ActionName("GetLIMSAnalysisMethodData")]
        public LIMSAnalysisMethodSearchModel GetData([FromBody] LIMSAnalysisMethodModel methodFilter)
        {

            AnalysisMethodRepository _analysismethodRepository = new AnalysisMethodRepository(new MINIDATDatabase());
            try
            {
                var tbpsrModel = _analysismethodRepository.GetMethodData(methodFilter);
                return tbpsrModel;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Save/update the LIMS analysis Method details provided by the user
        /// </summary>
        /// <param name="LIMSMethod"></param>
        /// <returns></returns>
        [HttpPost, ActionName("SaveLIMSAnalysisMethodData"), HttpOptions,]
        public HttpResponseMessage SaveMethod([FromBody] LIMSAnalysisMethodModel LIMSMethod)
        {

            AnalysisMethodRepository _analysismethodRepository = new AnalysisMethodRepository(new MINIDATDatabase());
            try
            {
                //Call the Save function here.
                _analysismethodRepository.SaveMethodData(LIMSMethod, User.Identity.Name);
                SetSession(true);
            }

            catch (SqlException ex)
            {
                if (ex.Message.Contains("InvalidCategorySelection"))
                {
                    LogManager.Error(ex);
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Invalid");
                }
            }
            catch
            {
                throw;
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }
        /// <summary>
        ///  Delete the LIMS analysis method details selected by user
        /// </summary>
        /// <param name="LIMSMethod"></param>
        /// <returns></returns>
        [HttpPost, ActionName("DeleteMethodData"), HttpOptions,]
        public HttpResponseMessage Delete([FromBody] LIMSAnalysisMethodModel LIMSMethod)
        {
            if (LIMSMethod != null)
            {
                AnalysisMethodRepository _analysismethodRepository = new AnalysisMethodRepository(new MINIDATDatabase());
                try
                {
                    _analysismethodRepository.Delete(LIMSMethod);
                    SetSession(true);
                    return Request.CreateResponse(HttpStatusCode.OK, "Delete");
                }
                //catch (SqlException ex)
                //{
                //    LogManager.Error(ex);
                //    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                //}
                catch (Exception ex)
                {
                    LogManager.Error(ex);
                    throw;

                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, "Success");

        }

        //[HttpGet]
        //public HttpResponseMessage GetAllBySource(string feedIds, string source)
        //{
        //    if (!string.IsNullOrEmpty(source))
        //    {
        //        AnalysisMethodRepository _analysismethodRepository = new AnalysisMethodRepository(new MINIDATDatabase());
        //        try
        //        {
        //            if (!string.IsNullOrEmpty(feedIds))
        //            {
        //                feedIds = feedIds.Trim('[', ']');
        //                var result = _analysismethodRepository.GetAllBySource(feedIds, source);
        //                return Request.CreateResponse(HttpStatusCode.OK, result);
        //            }
        //            else
        //            {
        //                return Request.CreateResponse(HttpStatusCode.BadRequest);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            LogManager.Error(ex);
        //            throw;

        //        }
        //    }
        //    return Request.CreateResponse(HttpStatusCode.BadRequest);
        //}
        [HttpGet, ActionName("GetLimsSources")]
        public HttpResponseMessage GetLimsSources()
        {
            AnalysisMethodRepository _analysismethodRepository = new AnalysisMethodRepository(new MINIDATDatabase());
            try
            {
                var result = _analysismethodRepository.GetLimsSources();
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }
    }
}
