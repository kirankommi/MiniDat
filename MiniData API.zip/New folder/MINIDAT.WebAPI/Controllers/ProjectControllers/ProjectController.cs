﻿using MINIDAT.DataAccess;
using MINIDAT.DataAccess.Repository.FileBrowser;
using MINIDAT.DataAccess.Repository.Manage;
using MINIDAT.DataAccess.Repository.Project;
using MINIDAT.Framework.Login;
using MINIDAT.Model;
using MINIDAT.Model.FileBrowser;
using MINIDAT.Model.Project;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace MINIDAT.WebAPI.Controllers.ProjectControllers
{
    public class ProjectController : ApiController
    {



        [HttpGet, ActionName("GetAccoladeProjects")]
        public HttpResponseMessage GetAccoladeProjects(string projectType)
        {

            ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _projectRepository.GetAccoladeProjects(projectType));
                
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectAccoladeLoadError.ToString());
            }
        }

        [HttpGet, ActionName("GetProjectDetails")]
        public HttpResponseMessage GetProjectDetails(string projectType)
        {
            ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
            try
            {
                 return Request.CreateResponse(HttpStatusCode.OK, _projectRepository.GetProjectDetails(projectType));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }


        [HttpPost, ActionName("SaveNpdProjectDetails")]
        public HttpResponseMessage SaveNpdProjectDetails(NPDProjectModel npd)
        {
            NPDProjectRepository _NPDProjectRepository = new NPDProjectRepository(new MINIDATDatabase());
            try
            {
                int projectId = _NPDProjectRepository.SaveProject(npd);
               return Request.CreateResponse(HttpStatusCode.OK, projectId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "AccoladeProjectAlreadyExists")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
            }
        }

        [HttpPost, ActionName("SearchNpdProjectDetails")]
        public HttpResponseMessage SearchNpdProjectDetails(NPDProjectModel npd)
        {
            NPDProjectRepository _NPDProjectRepository = new NPDProjectRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _NPDProjectRepository.SearchProjectDetails(npd));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }


        [HttpPost, ActionName("SaveCustomerProjectDetails")]
        public HttpResponseMessage SaveCustomerProjectDetails(CustomerProjectModel npd)
        {
            CustomerProjectRepository _NPDProjectRepository = new CustomerProjectRepository(new MINIDATDatabase());
            try
            {
                int projectId = _NPDProjectRepository.SaveProject(npd);
                return Request.CreateResponse(HttpStatusCode.OK, projectId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "AccoladeProjectAlreadyExists")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
            }
        }

        [HttpPost, ActionName("SearchCustomerProjectDetails")]
        public HttpResponseMessage SearchCustomerProjectDetails(CustomerProjectModel npd)
        {
            CustomerProjectRepository _NPDProjectRepository = new CustomerProjectRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _NPDProjectRepository.SearchProjectDetails(npd));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }


        [HttpPost, ActionName("SaveCapabilityProjectDetails")]
        public HttpResponseMessage SaveCapabilityProjectDetails(CapabilityProjectModel npd)
        {
            CapabilityProjectRepository _capProjectRepository = new CapabilityProjectRepository(new MINIDATDatabase());
            try
            {
                int projectId = _capProjectRepository.SaveProject(npd);
                return Request.CreateResponse(HttpStatusCode.OK, projectId);

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "AccoladeProjectAlreadyExists")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSaveError.ToString());
                }
            }
        }

        [HttpPost, ActionName("SearchCapabilityProjectDetails")]
        public HttpResponseMessage SearchCapabilityProjectDetails(CapabilityProjectModel npd)
        {
            CapabilityProjectRepository _capProjectRepository = new CapabilityProjectRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _capProjectRepository.SearchProjectDetails(npd));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectSearchError.ToString());
            }
        }




        [HttpGet, ActionName("DeleteProject")]
        public HttpResponseMessage DeleteProject(int projectId)
        {

            ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
            try
            {
                return Request.CreateResponse(HttpStatusCode.OK, _projectRepository.DeleteProject(projectId));

            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                if (ex.Message == "ProjectInUseDeleteError")
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectInUseDeleteError.ToString());
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ErrroMessges.ProjectDeleteError.ToString());
                }
            }
        }




        [HttpPost, HttpOptions]
        public HttpResponseMessage UploadFile()
        {
            ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
            var file = HttpContext.Current.Request.Files[0];
            var projectid = (HttpContext.Current.Request.Form != null) ? Convert.ToInt32(HttpContext.Current.Request.Form["ProjectId"]) : 0;
            string description = (HttpContext.Current.Request.Form != null) ? Convert.ToString(HttpContext.Current.Request.Form["Description"]) : "";
            if (projectid > 0 && file.ContentLength > 0)
            {
                byte[] fileData = null;
                using (var binaryReader = new BinaryReader(file.InputStream))
                {
                    fileData = binaryReader.ReadBytes(file.ContentLength);
                }
                string filename = file.FileName;
                string[] stringParts = filename.Split(new char[] { '.' });
                string contenttype = stringParts[1];
                var doc = new FileImport()
                {
                    ContentType = contenttype,
                    CreatedByUserID = User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1),
                    ProjectId = projectid,
                    Description = description,
                    FileName = filename,
                };
                doc.setData(fileData);
                _projectRepository.InsertProjectDocument(doc);
                return Request.CreateResponse(HttpStatusCode.OK, doc.FileId);
            }
            return null;
        }

        [ActionName("UploadFiles"), HttpPost]
        public HttpResponseMessage UploadFiles()
        {
            ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
            try
            {
                var FileInfo = JArray.Parse(HttpContext.Current.Request.Params["fileInfo"]);
                List<FileImport> Files = new List<FileImport>();
                foreach (var info in FileInfo)
                {
                    FileImport file = new FileImport();
                    file.FileName = info.Value<string>("FileName");
                    file.Description = info.Value<string>("Description");
                    string[] stringParts = file.FileName.Split(new char[] { '.' });
                    string contenttype = stringParts[1];
                    file.ContentType = contenttype;
                    //file.IsDeleted = info.Value<bool>("IsDeleted");
                    file.UID = info.Value<int?>("UID");
                    var fileData = HttpContext.Current.Request.Files[info.Value<string>("FileId")];

                    byte[] byteData = null;
                    if (fileData != null)
                    {
                        using (var binaryReader = new BinaryReader(fileData.InputStream))
                        {
                            byteData = binaryReader.ReadBytes(fileData.ContentLength);
                        }
                        file.setData(byteData);
                    }
                    Files.Add(file);
                }

                return Request.CreateResponse(HttpStatusCode.OK, _projectRepository.UploadFiles(Files, Convert.ToString(HttpContext.Current.Request.Params["DeleteIds"]), Convert.ToInt32(HttpContext.Current.Request.Params["ProjectID"]), User.Identity.Name.Substring(User.Identity.Name.IndexOf("\\") + 1)));
            }
            catch (Exception ex)
            {
                Model.LogManager.Error(ex);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "");
            }
        }

        [HttpGet]
        public HttpResponseMessage DownloadFile([FromUri] string fileId, string projectId)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileId) && !string.IsNullOrEmpty(projectId))
                {
                    ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
                    FileImport file = _projectRepository.GetProjectDocument(fileId, projectId);
                    return Request.CreateResponse(HttpStatusCode.OK, file);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


        [HttpGet]
        public HttpResponseMessage GetProjectAllDocuments([FromUri] string projectId)
        {
            try
            {
                if (!string.IsNullOrEmpty(projectId))
                {
                    ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
                    List<FileImport> files = _projectRepository.GetProjectAllDocuments( projectId);
                    return Request.CreateResponse(HttpStatusCode.OK, files);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpPost, HttpOptions]
        public HttpResponseMessage DeleteFile(FileImport doc)
        {
            try
            {
                if (doc != null && doc.FileId > 0 && doc.ProjectId > 0)
                {
                    ProjectRepository _projectRepository = new ProjectRepository(new MINIDATDatabase());
                    int isDeleted = _projectRepository.DeleteDocument(doc);
                    return Request.CreateResponse(HttpStatusCode.OK, isDeleted);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }

        }


        [HttpGet, ActionName("GetAllDocuments")]
        public HttpResponseMessage GetAllDocuments()
        {
            try
            {

                FileBrowserRepository _projectRepository = new ProjectFileBrowserRepository(new MINIDATDatabase());
                List<FileModel> files = _projectRepository.BrowseFiles();
                return Request.CreateResponse(HttpStatusCode.OK, files);
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }

        [HttpGet, ActionName("DownloadFile")]
        public HttpResponseMessage DownloadFile(string fileId)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileId) )
                {
                    FileBrowserRepository _projectRepository = new ProjectFileBrowserRepository(new MINIDATDatabase());
                    FileModel file = _projectRepository.DownloadFiles(Convert.ToInt32( fileId));
                    return Request.CreateResponse(HttpStatusCode.OK, file);
                }
                return null;
            }
            catch (Exception ex)
            {
                LogManager.Error(ex);
                throw;
            }
        }


    }
}
