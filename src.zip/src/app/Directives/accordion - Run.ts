﻿import { Component, Input, Output, EventEmitter,Directive,ElementRef, Renderer, OnInit  } from '@angular/core';
import { Message, TreeModule, TreeNode } from 'primeng/primeng';
import { DashboardService } from '../Services/dashboard.service';
import { trigger, state, animate, transition, style } from '@angular/animations';

@Component({
    selector: 'run-accordion',
    templateUrl: 'accordion - Run.html',
    animations: [
        trigger('toggleState', [
            state('true', style({ display: 'block' })),
            state('false', style({ display: 'none' })),
            transition('* => *', animate('300ms')),
        ])
    ]
})
    //@Directive({
    //    selector: '[contentEditable]',
    //    host: {
    //        '(input)': 'update($event)' // I changed it to input to see the changes immediatly
    //    }
    //})
export class RunAccordionDirective{
    @Input() title: string;
    @Input() buttonTitle: string="Add";
    @Input() cssClass: string;
    @Input() shouldToggleContent: boolean = true;
	@Output() shouldToggleContentChange: EventEmitter<any> = new EventEmitter();
    @Input() canAddEdit: boolean = false;
    @Output() addEvent = new EventEmitter();
    @Output() expandOrColapse = new EventEmitter();
    @Input() headerColorClass: string;
    @Input() addEditButtonSource: string;
    toggleContent()
    {
       
        this.shouldToggleContent = !this.shouldToggleContent;        
        this.update(null);
        var eventType = (this.shouldToggleContent ? "Expand" : "Colapse");
        this.expandOrColapse.emit(eventType);
    }
    constructor(private renderer: Renderer) {
        this.cssClass = this.cssClass || 'bg-gray-run';
        this.headerColorClass = this.headerColorClass || "accordion-header-run";        
        if (this.canAddEdit)
        {
             
        }
       
    }
    update(event) {
       
        this.shouldToggleContentChange.emit(this.shouldToggleContent);
    }
    addEdit() {
       
        this.addEvent.emit("AddEditClick");
    }
}
