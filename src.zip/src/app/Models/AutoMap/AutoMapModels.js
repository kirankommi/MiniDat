"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MissingOperatorsViewModel = (function () {
    function MissingOperatorsViewModel() {
        this.errors = [];
    }
    return MissingOperatorsViewModel;
}());
exports.MissingOperatorsViewModel = MissingOperatorsViewModel;
var AnalysisSource = (function () {
    function AnalysisSource() {
    }
    return AnalysisSource;
}());
exports.AnalysisSource = AnalysisSource;
var MissingComponentViewModel = (function (_super) {
    __extends(MissingComponentViewModel, _super);
    function MissingComponentViewModel() {
        _super.apply(this, arguments);
    }
    return MissingComponentViewModel;
}(MissingOperatorsViewModel));
exports.MissingComponentViewModel = MissingComponentViewModel;
var filteredMissingComponentGroup = (function () {
    function filteredMissingComponentGroup() {
    }
    return filteredMissingComponentGroup;
}());
exports.filteredMissingComponentGroup = filteredMissingComponentGroup;
//# sourceMappingURL=AutoMapModels.js.map