export class ProductPhysicalPropertiesModel {
    StreamId:string;
    SampleId: number;
    PropertyId: number;
    AnalysisMethodId: number;
    BaseValue: number;
    TargetValue:string;
    PropertyLabel: string;

    AnalysisMethodName: string;
    AnalysisMethodNumber: string;
    
    LIMSOperation: string;
    LIMSOperationId: string;
    UOM: any;
    UOMlist:any[];
     Precision: string;
    // UOMGroupNumber: string;

    Text: string;
    ValidationIndicator: string;
}

export class Unit{
    unitName:string;
   displayText:string;
   slope:number;
  intercept:number;
} 


export class ArrayOfProductPhysicalPropertyItemViewModel
{
    PlantCd: string;
    RunId: number;
    TestId: number;
    UserName: string;
    StreamId: string;
    ArrayOfProductPhysicalPropertyItemViewModel :ProductPhysicalPropertyItemViewModel[];
}

export class ProductPhysicalPropertyItemViewModel{
    PropertyId:string;
    LimsOperationId:string;
    PropertyLabel:string;
    SampleId:string;
    BaseValue:string;
    Text:string;
    ValidationFlag:string;
}


export class ProductPhysicalPropertiesDropdownModel {
    StreamList: Streams[];
    ValidationIndicatorList: ValidationIndicator[];
}
export class ProductPhysicalPropertiesInputModel {
    PlantCd: string;
    RunId: number;
    TestId: number;
    StreamId: string;
    AllVariableChecked: boolean;
}

export class Streams {
    StreamId: string;
    StreamName: string;
    SortOrder: string;
}
export class ValidationIndicator {
    ValidationId: string;
    ValidationName: string;

}