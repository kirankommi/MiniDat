
export class FileModel {
  UID?: number;
  RowId: number;
  FileId?: number;
  FileName?: string;
  FileSize?: number;
  FileType?: string;
  Description?: string;
  FileData?: any;
  ProgressId?: string;
  isDirty?: boolean = false;
  isDeleted?: boolean;
  FileTypeId: number;  
  SizeUnit: string;
  LastUpdatedDateTime: string;
}
