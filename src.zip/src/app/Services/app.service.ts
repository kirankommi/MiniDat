import { Injectable, ReflectiveInjector } from '@angular/core';
import { Http, Response, RequestOptions, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import * as  Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import { HttpActionService } from './httpaction.service';

@Injectable({
  providedIn: 'root'
})
export class appService {
  private getUserSession = "/App/Get";
  private getUOMVariable = "/App/UOMVariablesData";
  private getMenu = "/Menu";
  private getVersionUrl = "/Version/GetVersion";

  constructor(private http: Http, private httpAction: HttpActionService) {
  }

  private handleError(error: any): Promise<any> {
    console.log(error);
    return Promise.reject(error.message || error);
  }

  populateUOMS(UOMCategories: any[]):Promise<any> {
    return new Promise((resolve, reject) => {
      let lstForRequest: string[] = [];

      UOMCategories.forEach(q => {
        if (Constants.UOMCATVariables[q] == undefined || Constants.UOMCATVariables[q] == null) {
          lstForRequest.push(q);
        }
      });

      let params: URLSearchParams = new URLSearchParams();
      params.set('Categories', lstForRequest.join(','));
      let options = new RequestOptions(Constants.getParamOptions(params));

      if (lstForRequest.length > 0) {
        this.httpAction.get(this.getUOMVariable, options).subscribe((res: any) => {

          let variables: any[] = res;
          lstForRequest.forEach(q => {
            let catObj = {};
            variables.filter(e => e.CategoryName == q).forEach(w => {
              catObj[w.VariableName] = w;
            });
            Constants.SetUOMS(q, catObj);
          });
          resolve();
        });
      }
      else {
        resolve();
      }
    });
  }


  getSessionData() {
    if (Object.keys(Constants.AppSession).length > 0) {
      let ob = new Observable(observer => {
        observer.next(Constants.AppSession);
      });
      return ob;
    } else {
      return this.http.get(Constants.apiBaseUrl + this.getUserSession, Constants.options)
        .map((res: Response) => {
          let json = res.json();
          //TBD
          Constants.SetSession(json);
          return json;
        })
        .catch(this.handleError);
    }
  }

  getMenus() {
    return this.http.get(Constants.apiBaseUrl + this.getMenu, Constants.options)
      .map((res: any) => {
        debugger;
        let json = res.json().data;
        return json;
      })
      .catch(this.handleError);
  }

  getVersion() {
    if (Constants.AppVersion && Constants.AppVersion != '') {
      let ob = new Observable(observer => {
        observer.next(Constants.AppVersion);
      });
      return ob;
    } else {
      //TBD
      return this.http.get(Constants.apiBaseUrl + this.getVersionUrl, Constants.options)
        .map((res: Response) => { let json = res.json(); Constants.SetAppVersion(json); return json; })
        .catch(this.handleError);
    }
  }



}

export class SharedDataService {
  static UserSessionData: any = [];
}
