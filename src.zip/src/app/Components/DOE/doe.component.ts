import { Component, OnInit } from '@angular/core';
import { doeService } from "../../services/doeservices/doe.service";
import { doeMediatorService } from '../../services/doeservices/doemediator.service';
import { Router, ActivatedRoute } from '@angular/router';
import { pipe } from 'rxjs';
import { AlertMessage } from '../../Services/alertmessage.service';
import { KeyValue } from '../../Models/UserModel';
import * as  Constants from '../../Shared/globalconstants';
import { error } from 'protractor';

@Component({
  templateUrl: "doe.component.html",
  providers: [doeService]
})
export class doeComponent implements OnInit {
  currentTab: string = 'basicInfo';
  mstrData: any = {};
  IsallowedSave: boolean = false;
  saveData: any = {};
  doeRun: any;
  // canEdit: boolean = false;
  private studyID: string = null;

  constructor(private route: ActivatedRoute, private router: Router, public service: doeService, public mediatorService: doeMediatorService, private alertMessage: AlertMessage) {

  }
  ngOnInit() {
    this.service.getMasterData().subscribe((data: any) => {
      this.mediatorService.masterData = data;
      this.route.params.subscribe((params: any) => {
        this.studyID = params['studyID'];
        this.doeRun = params['doeRun'];
        if (this.doeRun != undefined) {
          this.currentTab = 'currentRunInfo';
        }
        this.reset();
      });
    });
  }

  intializeStudy() {
    this.service.getDOEInformation(this.studyID).subscribe((data) => {
      let { Runs, ...studyDtl } = data;
      this.mediatorService.projectName = studyDtl.Project.Name;
      this.mediatorService.studyName = studyDtl.Name;
      this.mediatorService.onRuoteIntialized.next({ studyDtl: studyDtl, runs: Runs });
    });
  }

  reset() {
    if (!isNaN(parseInt(this.studyID))) {
      this.intializeStudy();
    }
    else {
      this.mediatorService.onRuoteIntialized.next("create");
    }
  }

  onSave() {
    this.mediatorService.getBasicInformation().then((StudyInfo) => {
      this.mediatorService.getDOEInformation().then(RunInfo => {
        let Study = StudyInfo.Info;
        if (Study != "error" && RunInfo != "error") {
          Study.Runs = RunInfo.Runs;
          this.service.save({ Doe: Study, DeleteIds: RunInfo.DeleteIds }).subscribe((data: any) => {
            if (!isNaN(parseInt(data))) {
              //this.alertMessage.displayMessage({ severity: Constants.severityWarn, summary: 'Experiment', detail: "Uploading the files...." });
              let metaData: KeyValue[] = [];
              metaData.push({ Key: "StudyID", Value: data });
              metaData.push({ Key: "DeleteIds", Value: StudyInfo.deleteIds });
              this.service.uploadFiles(StudyInfo.Files, metaData).subscribe((uploadSuccess: any) => {
                if (uploadSuccess == "Uploaded") {
                  this.alertMessage.displaySuccessMessage("DOESave");
                  this.router.navigateByUrl('/Experiment/DOE/' + data);
                  this.reset();
                } else {
                  this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'UploadFailed', detail: uploadSuccess });
                }
              });
            } else {
              // debugger;
              this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Experiment Save Failed', detail: data });
            }
          }, (error: any) => {
            let msg = JSON.parse(error.Details._body).Message;
            this.alertMessage.displayMessage({ severity: Constants.severityError, summary: 'Experiment Save Failed', detail: msg });
          });
        };
      });
    });
  }

  ngDoCheck() {
    if (Constants.UserSessionData != Constants.Undefined) {
      if (Constants.UserPrivileges.length > 1) {
        for (let i in Constants.UserPrivileges) {
          if (Constants.UserPrivileges[i].FunctionCode.toUpperCase() == "FUNC000020" && Constants.UserPrivileges[i].PrivilegeName.toUpperCase() == "WRITE") {
            this.IsallowedSave = true;
          }
        }

      }
    }
  }
}
