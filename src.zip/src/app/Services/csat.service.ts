import { Injectable, ReflectiveInjector } from '@angular/core';
import { HttpActionService } from './httpaction.service';
import 'rxjs/add/operator/toPromise';
import * as  Constants from '../Shared/globalconstants';

import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';

@Injectable({
    providedIn: 'root'
})
export class csatService {
    csatUrl: string = "/sentiment/csatSentiment";


    constructor(private httpaction: HttpActionService) {

    }

    getCsatSentiment() {
      return this.httpaction.get(this.csatUrl, Constants.options);
    }
}
