﻿export class PITagInfoModel
{
    PITagID: string;
    Plantcode: string;
    LogsheetReadingLabel: string;
    PITagName: string;
    MinRange: number;
    MaxRange: number;
    DisplayOrder: number;
    CanDelete: string;
    PIValueType: KeyValue;
    ValueTypeName: string;
    PITagApplication: ApplicationModel[];
    AppCode: string;
}

export class KeyValue
{
    Key: string;
    Value: string;
}

export class ApplicationModel
{
    ApplicationName: string;   
    ApplicationId: number;   
    IsChecked: boolean;
    IsallowedCheck: boolean;
}

export class PlantFlyoutModel {
    Plantcode: string;
    Location: string;
    BuildingNumber: string;
}